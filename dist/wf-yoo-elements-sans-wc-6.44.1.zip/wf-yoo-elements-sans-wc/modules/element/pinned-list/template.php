<?php
/**
 * WeFrame – Liste à épingler | template.php v1.0
 * Le visiteur epingle les elements qui l'interessent ; ils remontent dans une
 * zone « ma selection ». Le deplacement est anime par la technique FLIP
 * (on mesure avant/apres et on rejoue l'ecart) : pas de bibliotheque.
 *
 * Tout est rendu cote serveur : sans JS, les deux zones restent des listes
 * lisibles et l'element garde son sens. Chaque bouton porte aria-pressed et
 * un changement est annonce dans une zone de statut.
 * Pas de "&&" ni de "||" dans le JS inline (regle interne du plugin).
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$pinTitle  = trim( (string) ( $props['pinned_title'] ?? '' ) );
$emptyText = trim( (string) ( $props['empty_text'] ?? '' ) );
$listTitle = trim( (string) ( $props['list_title'] ?? '' ) );

$cols = max( 1, min( 4, (int) ( $props['columns'] ?? 2 ) ) );
$gap  = max( 0, (int) ( $props['gap'] ?? 14 ) );
$remember = ! empty( $props['remember'] );
$maxPin   = max( 0, (int) ( $props['max_pinned'] ?? 0 ) );
$dur      = max( 0, (int) ( $props['duration'] ?? 420 ) );
$thumb    = max( 0, (int) ( $props['thumb_size'] ?? 56 ) );

$cBg  = (string) ( $props['card_bg'] ?? '#ffffff' );
$cCol = (string) ( $props['card_color'] ?? '#111111' );
$cMut = (string) ( $props['card_muted'] ?? '#6b7280' );
$cBd  = trim( (string) ( $props['card_border'] ?? '' ) );
$cRad = max( 0, (int) ( $props['card_radius'] ?? 14 ) );
$cPad = max( 0, (int) ( $props['card_padding'] ?? 18 ) );
$acc  = (string) ( $props['accent_color'] ?? '#EA5C1C' );
$tSz  = max( 12, (int) ( $props['title_size'] ?? 17 ) );
$hSz  = max( 10, (int) ( $props['heading_size'] ?? 14 ) );

$items = array();
foreach ( $children as $i => $child ) {
	$cp    = (array) ( $child->props ?? array() );
	$title = trim( (string) ( $cp['title'] ?? '' ) );
	if ( '' === $title ) { $title = sprintf( __( 'Élément %d', 'weframe' ), $i + 1 ); }

	$img = $cp['image'] ?? '';
	if ( is_array( $img ) ) { $img = $img['src'] ?? ( $img['url'] ?? '' ); }

	$link = $cp['link'] ?? '';
	if ( is_array( $link ) ) { $link = $link['url'] ?? ''; }

	$items[] = array(
		'title'  => $title,
		'desc'   => trim( (string) ( $cp['description'] ?? '' ) ),
		'badge'  => trim( (string) ( $cp['badge'] ?? '' ) ),
		'img'    => trim( (string) $img ),
		'alt'    => trim( (string) ( $cp['image_alt'] ?? '' ) ),
		'link'   => trim( (string) $link ),
		'pinned' => ! empty( $cp['pinned'] ),
		'i'      => $i,
	);
}

$nPinned = 0;
foreach ( $items as $it ) { if ( $it['pinned'] ) { $nPinned++; } }

$uid = wf_uid( 'wfpl_', $props, count( $items ) );

$pinSvg = '<svg viewBox="0 0 256 256" width="18" height="18" fill="currentColor" aria-hidden="true" focusable="false"><path d="M178.34,165.66,160,147.31V88h8a8,8,0,0,0,5.66-13.66l-40-40a8,8,0,0,0-11.32,0l-40,40A8,8,0,0,0,88,88h8v59.31L77.66,165.66A8,8,0,0,0,83.31,179H120v45a8,8,0,0,0,16,0V179h36.69a8,8,0,0,0,5.65-13.34Z"/></svg>';

// Le balisage de la carte est identique dans les deux zones : on le construit
// une fois ici plutot que de le repeter dans les deux boucles.
foreach ( $items as $k => $it ) {
	ob_start();
	?>
	<article class="wf-pl__card" data-id="i<?= (int) $it['i'] ?>" data-title="<?= esc_attr( $it['title'] ) ?>">
		<?php if ( $thumb > 0 && '' !== $it['img'] ) : ?>
		<span class="__thumb"><img src="<?= esc_url( $it['img'] ) ?>" alt="<?= esc_attr( $it['alt'] ) ?>" loading="lazy" decoding="async"<?= '' === $it['alt'] ? ' aria-hidden="true"' : '' ?>></span>
		<?php endif; ?>
		<div class="__body">
			<?php if ( '' !== $it['badge'] ) : ?><span class="__badge"><?= esc_html( $it['badge'] ) ?></span><?php endif; ?>
			<h4 class="__title"><?php if ( '' !== $it['link'] ) : ?><a href="<?= esc_url( $it['link'] ) ?>"><?= esc_html( $it['title'] ) ?></a><?php else : ?><?= esc_html( $it['title'] ) ?><?php endif; ?></h4>
			<?php if ( '' !== $it['desc'] ) : ?><p class="__desc"><?= esc_html( $it['desc'] ) ?></p><?php endif; ?>
		</div>
		<button type="button" class="__pin" aria-pressed="<?= $it['pinned'] ? 'true' : 'false' ?>"
			aria-label="<?= esc_attr( ( $it['pinned'] ? __( 'Retirer de la sélection :', 'weframe' ) : __( 'Épingler :', 'weframe' ) ) . ' ' . $it['title'] ) ?>"><?= $pinSvg ?></button>
	</article>
	<?php
	$items[ $k ]['html'] = ob_get_clean();
}
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-pl" data-remember="<?= $remember ? '1' : '0' ?>" data-max="<?= (int) $maxPin ?>">

	<section class="wf-pl__zone wf-pl__zone--pinned<?= 0 === $nPinned ? ' is-empty' : '' ?>">
		<?php if ( '' !== $pinTitle ) : ?>
		<h3 class="__heading"><?= esc_html( $pinTitle ) ?> <span class="__count" aria-hidden="true"><?= (int) $nPinned ?></span></h3>
		<?php endif; ?>
		<?php if ( '' !== $emptyText ) : ?>
		<p class="__empty"><?= esc_html( $emptyText ) ?></p>
		<?php endif; ?>
		<div class="__grid" data-zone="pinned">
			<?php foreach ( $items as $it ) : ?>
			<?php if ( ! $it['pinned'] ) { continue; } ?>
			<?= $it['html'] ?>
			<?php endforeach; ?>
		</div>
	</section>

	<section class="wf-pl__zone wf-pl__zone--list">
		<?php if ( '' !== $listTitle ) : ?>
		<h3 class="__heading"><?= esc_html( $listTitle ) ?></h3>
		<?php endif; ?>
		<div class="__grid" data-zone="list">
			<?php foreach ( $items as $it ) : ?>
			<?php if ( $it['pinned'] ) { continue; } ?>
			<?= $it['html'] ?>
			<?php endforeach; ?>
		</div>
	</section>

	<p class="wf-pl__live" role="status" aria-live="polite"></p>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?>{container-type:inline-size;display:flex;flex-direction:column;gap:<?= (int) max( 20, $gap * 2 ) ?>px;}
#<?= esc_attr( $uid ) ?> .__heading{
	margin:0 0 <?= (int) max( 8, round( $gap * .7 ) ) ?>px;
	font-size:<?= (int) $hSz ?>px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;
	color:<?= esc_attr( $cMut ) ?>;display:flex;align-items:center;gap:.6em;
}
#<?= esc_attr( $uid ) ?> .__count{
	display:inline-flex;align-items:center;justify-content:center;min-width:1.8em;height:1.8em;
	padding:0 .4em;border-radius:100px;background:<?= esc_attr( $acc ) ?>;color:#fff;
	font-size:.85em;letter-spacing:0;
}
#<?= esc_attr( $uid ) ?> .__empty{margin:0;color:<?= esc_attr( $cMut ) ?>;font-size:14px;line-height:1.55;}
#<?= esc_attr( $uid ) ?> .wf-pl__zone--pinned:not(.is-empty) .__empty{display:none;}
#<?= esc_attr( $uid ) ?> .wf-pl__zone--pinned.is-empty .__grid{display:none;}

#<?= esc_attr( $uid ) ?> .__grid{
	display:grid;gap:<?= (int) $gap ?>px;
	grid-template-columns:repeat(<?= (int) $cols ?>,minmax(0,1fr));align-items:start;
}
@container (max-width: 640px){#<?= esc_attr( $uid ) ?> .__grid{grid-template-columns:1fr;}}

#<?= esc_attr( $uid ) ?> .wf-pl__card{
	position:relative;display:flex;gap:<?= (int) max( 10, round( $cPad * .7 ) ) ?>px;align-items:flex-start;
	background:<?= esc_attr( $cBg ) ?>;color:<?= esc_attr( $cCol ) ?>;
	border-radius:<?= (int) $cRad ?>px;padding:<?= (int) $cPad ?>px;
	<?= '' !== $cBd ? 'border:1px solid ' . esc_attr( $cBd ) . ';' : '' ?>
	min-width:0;
}
#<?= esc_attr( $uid ) ?> .wf-pl__card.is-moving{transition:transform <?= (int) $dur ?>ms cubic-bezier(.2,.8,.2,1);}
#<?= esc_attr( $uid ) ?> .__thumb{
	flex:0 0 auto;width:<?= (int) $thumb ?>px;height:<?= (int) $thumb ?>px;
	border-radius:<?= (int) max( 4, round( $cRad * .6 ) ) ?>px;overflow:hidden;background:rgba(127,127,127,.12);
}
#<?= esc_attr( $uid ) ?> .__thumb img{width:100%;height:100%;object-fit:cover;display:block;}
#<?= esc_attr( $uid ) ?> .__body{min-width:0;flex:1 1 auto;padding-right:34px;}
#<?= esc_attr( $uid ) ?> .__title{margin:0;font-size:<?= (int) $tSz ?>px;font-weight:700;line-height:1.25;}
#<?= esc_attr( $uid ) ?> .__title a{color:inherit;text-decoration:none;}
#<?= esc_attr( $uid ) ?> .__title a:hover{color:<?= esc_attr( $acc ) ?>;}
#<?= esc_attr( $uid ) ?> .__desc{margin:.35em 0 0;font-size:14px;line-height:1.5;color:<?= esc_attr( $cMut ) ?>;}
#<?= esc_attr( $uid ) ?> .__badge{
	display:inline-block;margin-bottom:.4em;font-size:10px;font-weight:700;letter-spacing:.1em;
	text-transform:uppercase;padding:.35em .6em;border-radius:100px;background:<?= esc_attr( $acc ) ?>;color:#fff;
}
#<?= esc_attr( $uid ) ?> .__pin{
	position:absolute;top:<?= (int) max( 8, round( $cPad * .5 ) ) ?>px;right:<?= (int) max( 8, round( $cPad * .5 ) ) ?>px;
	display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;
	border:0;border-radius:8px;cursor:pointer;
	background:rgba(127,127,127,.12);color:<?= esc_attr( $cMut ) ?>;
	transition:background-color .2s ease,color .2s ease,transform .2s ease;
}
#<?= esc_attr( $uid ) ?> .__pin:hover{background:rgba(127,127,127,.2);color:<?= esc_attr( $cCol ) ?>;}
#<?= esc_attr( $uid ) ?> .__pin:focus-visible{outline:2px solid <?= esc_attr( $acc ) ?>;outline-offset:2px;}
#<?= esc_attr( $uid ) ?> .__pin[aria-pressed="true"]{background:<?= esc_attr( $acc ) ?>;color:#fff;transform:rotate(-20deg);}
@media (pointer:coarse){#<?= esc_attr( $uid ) ?> .__pin{width:44px;height:44px;}}
#<?= esc_attr( $uid ) ?> .wf-pl__live{margin:0;font-size:13px;color:<?= esc_attr( $cMut ) ?>;}
#<?= esc_attr( $uid ) ?> .wf-pl__live:empty{display:none;}
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?> .wf-pl__card.is-moving{transition-duration:.001ms;}
	#<?= esc_attr( $uid ) ?> .__pin{transition-duration:.001ms;}
}
</style>

<script>
(function(){
	var root = document.getElementById('<?= esc_js( $uid ) ?>');
	if (!root) { return; }
	var zonePinned = root.querySelector('[data-zone="pinned"]');
	var zoneList = root.querySelector('[data-zone="list"]');
	var sectionPinned = root.querySelector('.wf-pl__zone--pinned');
	var counter = root.querySelector('.__count');
	var live = root.querySelector('.wf-pl__live');
	if (!zonePinned) { return; }
	if (!zoneList) { return; }

	var key = 'wfpl_<?= esc_js( $uid ) ?>';
	var remember = root.getAttribute('data-remember') === '1';
	var max = parseInt(root.getAttribute('data-max'), 10);
	if (isNaN(max)) { max = 0; }
	var dur = <?= (int) $dur ?>;

	function cards(){ return [].slice.call(root.querySelectorAll('.wf-pl__card')); }
	function pinnedIds(){
		return [].slice.call(zonePinned.querySelectorAll('.wf-pl__card')).map(function(c){
			return c.getAttribute('data-id');
		});
	}

	function save(){
		if (!remember) { return; }
		try { localStorage.setItem(key, JSON.stringify(pinnedIds())); } catch (err) {}
	}

	function refresh(){
		var n = zonePinned.children.length;
		sectionPinned.classList.toggle('is-empty', n === 0);
		if (counter) { counter.textContent = String(n); }
	}

	// FLIP : on note les positions, on deplace, puis on rejoue l'ecart.
	function move(card, target){
		var list = cards();
		var before = list.map(function(c){ return c.getBoundingClientRect(); });

		target.appendChild(card);
		refresh();

		if (dur > 0) {
			for (var i = 0; i < list.length; i++) {
				var a = before[i];
				var b = list[i].getBoundingClientRect();
				var dx = a.left - b.left;
				var dy = a.top - b.top;
				if (dx === 0) { if (dy === 0) { continue; } }
				var el = list[i];
				el.classList.remove('is-moving');
				el.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
				(function(node){
					// on laisse le navigateur enregistrer la position de depart
					void node.offsetWidth;
					node.classList.add('is-moving');
					node.style.transform = '';
					setTimeout(function(){
						node.classList.remove('is-moving');
					}, dur + 40);
				})(el);
			}
		}
	}

	function say(msg){ if (live) { live.textContent = msg; } }

	function toggle(card){
		var btn = card.querySelector('.__pin');
		var isPinned = card.parentNode === zonePinned;
		var title = card.getAttribute('data-title');
		if (!title) { title = ''; }

		if (!isPinned) {
			if (max > 0) {
				if (zonePinned.children.length >= max) {
					say('<?= esc_js( __( 'Limite atteinte :', 'weframe' ) ) ?> ' + max + '. <?= esc_js( __( 'Retirez un élément avant d\'en ajouter un autre.', 'weframe' ) ) ?>');
					return;
				}
			}
			move(card, zonePinned);
			btn.setAttribute('aria-pressed', 'true');
			btn.setAttribute('aria-label', '<?= esc_js( __( 'Retirer de la sélection :', 'weframe' ) ) ?> ' + title);
			say(title + ' <?= esc_js( __( 'ajouté à la sélection.', 'weframe' ) ) ?>');
		} else {
			move(card, zoneList);
			btn.setAttribute('aria-pressed', 'false');
			btn.setAttribute('aria-label', '<?= esc_js( __( 'Épingler :', 'weframe' ) ) ?> ' + title);
			say(title + ' <?= esc_js( __( 'retiré de la sélection.', 'weframe' ) ) ?>');
		}
		save();
	}

	root.addEventListener('click', function(e){
		if (!e.target.closest) { return; }
		var btn = e.target.closest('.__pin');
		if (!btn) { return; }
		toggle(btn.closest('.wf-pl__card'));
	});

	// Restauration : on remet dans l'ordre memorise, sans animation.
	if (remember) {
		try {
			var raw = localStorage.getItem(key);
			if (raw) {
				var ids = JSON.parse(raw);
				if (Array.isArray(ids)) {
					var byId = {};
					cards().forEach(function(c){ byId[c.getAttribute('data-id')] = c; });
					// tout redescend dans la liste, puis on remonte la selection
					cards().forEach(function(c){ zoneList.appendChild(c); });
					cards().forEach(function(c){
						var b = c.querySelector('.__pin');
						b.setAttribute('aria-pressed', 'false');
					});
					ids.forEach(function(id){
						var c = byId[id];
						if (!c) { return; }
						zonePinned.appendChild(c);
						c.querySelector('.__pin').setAttribute('aria-pressed', 'true');
					});
				}
			}
		} catch (err) {}
	}
	refresh();
})();
</script>
