<?php
/**
 * WeFrame – SVG Line Draw | template.php
 * An SVG path that draws itself — tied to scroll progress or on first view.
 * Config inlined (no <script type="application/json">), no "&&" in inline JS.
 */
defined( 'ABSPATH' ) || exit;

$props = is_array( $props ?? null ) ? $props : array();

$preset  = (string) ( $props['preset'] ?? 'wave' );
$color   = (string) ( $props['color'] ?? '#111111' );
$width   = min( 20, max( 1, (int) ( $props['width'] ?? 3 ) ) );
$cap     = ( ( $props['cap'] ?? 'round' ) === 'butt' ) ? 'butt' : 'round';
$trigger = (string) ( $props['trigger'] ?? 'scroll' );
$speed   = min( 4000, max( 400, (int) ( $props['speed'] ?? 1400 ) ) );
$height  = min( 500, max( 60, (int) ( $props['height'] ?? 160 ) ) );
$align   = (string) ( $props['align'] ?? 'center' );
$maxw    = min( 1200, max( 100, (int) ( $props['max_width'] ?? 600 ) ) );

// Preset paths (viewBox 0 0 300 120)
$presets = array(
    'wave'      => array( 'd' => 'M0,60 C40,10 80,110 120,60 S200,10 240,60 300,60 300,60', 'vw' => 300, 'vh' => 120 ),
    'zigzag'    => array( 'd' => 'M0,90 L50,30 L100,90 L150,30 L200,90 L250,30 L300,90', 'vw' => 300, 'vh' => 120 ),
    'curve'     => array( 'd' => 'M0,105 Q150,-30 300,105', 'vw' => 300, 'vh' => 120 ),
    'circle'    => array( 'd' => 'M150,15 a45,45 0 1,1 -0.01,0', 'vw' => 300, 'vh' => 120 ),
    'arrow'     => array( 'd' => 'M8,60 L278,60 M244,32 L286,60 L244,88', 'vw' => 300, 'vh' => 120 ),
    'underline' => array( 'd' => 'M6,70 C80,40 220,40 294,70', 'vw' => 300, 'vh' => 90 ),
);

if ( 'custom' === $preset ) {
    $d  = trim( (string) ( $props['custom_path'] ?? '' ) );
    $vw = min( 1000, max( 10, (int) ( $props['custom_vw'] ?? 300 ) ) );
    $vh = min( 1000, max( 10, (int) ( $props['custom_vh'] ?? 120 ) ) );
    if ( '' === $d ) { $d = $presets['wave']['d']; $vw = 300; $vh = 120; }
} else {
    $p  = isset( $presets[ $preset ] ) ? $presets[ $preset ] : $presets['wave'];
    $d  = $p['d'];
    $vw = $p['vw'];
    $vh = $p['vh'];
}

// Only allow a safe subset of characters in the path data
$d = preg_replace( '/[^0-9A-Za-z,.\-\s]/', '', $d );

$uid = 'wfld_' . substr( md5( $d . serialize( $props ) ), 0, 8 );
$jc  = ( 'center' === $align ) ? 'center' : ( 'right' === $align ? 'flex-end' : 'flex-start' );

$cfg = wp_json_encode( array(
    'uid'     => $uid,
    'trigger' => $trigger,
    'speed'   => $speed,
), JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div class="wf-ld" style="display:flex;justify-content:<?= $jc ?>;">
    <div style="width:100%;max-width:<?= $maxw ?>px;height:<?= $height ?>px;">
        <svg id="<?= esc_attr( $uid ) ?>" viewBox="0 0 <?= $vw ?> <?= $vh ?>" fill="none" preserveAspectRatio="xMidYMid meet" style="width:100%;height:100%;overflow:visible;">
            <path class="wf-ld-path" d="<?= esc_attr( $d ) ?>" stroke="<?= esc_attr( $color ) ?>" stroke-width="<?= $width ?>" stroke-linecap="<?= $cap ?>" stroke-linejoin="round" fill="none" />
        </svg>
    </div>
</div>

<style>
@media (prefers-reduced-motion: reduce) { #<?= esc_attr( $uid ) ?> .wf-ld-path { stroke-dashoffset: 0 !important; } }
</style>

<script>
(function(){
    var C = <?= $cfg ?>;
    function boot(){
        var svg = document.getElementById(C.uid); if (!svg) return;
        var path = svg.querySelector('.wf-ld-path'); if (!path) return;
        var len = 0;
        try { len = path.getTotalLength(); } catch(e) { return; }
        if (len <= 0) { return; }
        path.style.strokeDasharray = len;
        path.style.strokeDashoffset = len;

        function clamp(v){ if (v < 0) return 0; if (v > 1) return 1; return v; }

        if (C.trigger === 'view') {
            var drawn = false;
            function draw(){
                if (drawn) { return; }
                drawn = true;
                path.style.transition = 'stroke-dashoffset ' + C.speed + 'ms cubic-bezier(.22,1,.36,1)';
                requestAnimationFrame(function(){ path.style.strokeDashoffset = '0'; });
            }
            if ('IntersectionObserver' in window) {
                new IntersectionObserver(function(es){
                    var i = 0; while (i < es.length) { if (es[i].isIntersecting) { draw(); } i++; }
                }, { threshold: 0.35 }).observe(svg);
            } else { draw(); }
            return;
        }

        // scroll-linked
        var ticking = false;
        function update(){
            ticking = false;
            var r = svg.getBoundingClientRect();
            var vh = window.innerHeight || 1;
            var p = (vh - r.top) / (vh + r.height);
            p = clamp(p);
            path.style.strokeDashoffset = (len * (1 - p)).toFixed(1);
        }
        function onScroll(){ if (!ticking) { ticking = true; requestAnimationFrame(update); } }
        window.addEventListener('scroll', onScroll, { passive: true });
        window.addEventListener('resize', onScroll, { passive: true });
        update();
    }
    if (window.WF) { if (WF.ready) { WF.ready(boot); return; } }
    if (document.readyState !== 'loading') { boot(); } else { document.addEventListener('DOMContentLoaded', boot); }
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
