<?php
/**
 * WeFrame – Modal Popup | template.php v6.0 (UIkit)
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$bt   = $props['btn_text']   ?? 'Ouvrir';
$bs   = $props['btn_style']  ?? 'filled';
$bc   = $props['btn_color']  ?? '#fff';
$bb   = $props['btn_bg']     ?? '#EA5C1C';
$br   = (int)( $props['btn_radius'] ?? 8 );
$bsz  = $props['btn_size']   ?? 'medium';
$bal  = $props['btn_align']  ?? 'left';
$mw   = (int)( $props['modal_width']   ?? 640 );
$mr   = (int)( $props['modal_radius']  ?? 20 );
$mp   = (int)( $props['modal_padding'] ?? 32 );
$mbg  = $props['modal_bg']    ?? '#fff';
$mc   = $props['modal_color'] ?? '#000';

$uid   = wf_uid( 'wfmd_', $props, count( $children ) );
$inner = '';
foreach ( $children as $child ) {
    $inner .= $builder->render( $child );
}
if ( ! trim( $inner ) ) { return; }

// UIkit button class
$uk_btn = match( $bs ) {
    'filled'  => 'uk-button uk-button-primary',
    'outline' => 'uk-button uk-button-default',
    default   => 'uk-button uk-button-link',
};
$uk_size = match( $bsz ) {
    'small' => ' uk-button-small',
    'large' => ' uk-button-large',
    default => '',
};
$jc = match( $bal ) {
    'center' => ' uk-text-center',
    'right'  => ' uk-text-right',
    default  => '',
};
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>">
    <?php if ( $bt ) : ?>
    <div class="<?= $jc ?>">
        <button class="<?= $uk_btn . $uk_size ?>" type="button" uk-toggle="target: #<?= esc_attr( $uid ) ?>-modal"
            style="border-radius:<?= $br ?>px;<?= $bs === 'filled' ? 'background:' . esc_attr( $bb ) . ';color:' . esc_attr( $bc ) . ';' : 'color:' . esc_attr( $bb ) . ';' ?><?= $bs === 'outline' ? 'border-color:' . esc_attr( $bb ) . ';' : '' ?>">
            <?= esc_html( $bt ) ?>
        </button>
    </div>
    <?php endif; ?>
</div>

<div id="<?= esc_attr( $uid ) ?>-modal" class="uk-modal-full" uk-modal>
    <div class="uk-modal-dialog" style="max-width:<?= $mw ?>px;margin:auto;border-radius:<?= $mr ?>px;background:<?= esc_attr( $mbg ) ?>;color:<?= esc_attr( $mc ) ?>;">
        <button class="uk-modal-close-default" type="button" aria-label="<?= esc_attr__( 'Fermer', 'weframe' ) ?>" uk-close></button>
        <div class="uk-modal-body" style="padding:<?= $mp ?>px;">
            <?= $inner ?>
        </div>
    </div>
</div>

<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
