<?php
defined('ABSPATH') || exit;
if (empty($children)) return;
$layout = $props['layout']??'vertical'; $lc = $props['line_color']??'#e5e5e5';
$dc = $props['dot_color']??'#EA5C1C'; $ds = (int)($props['dot_size']??14);
$gap = (int)($props['gap']??32); $anim = !empty($props['animate']);
$prog = !empty($props['progressive']); $progC = $props['progress_color']??'#EA5C1C';
$uid = 'wftl_'.substr(md5(serialize($props).count($children)),0,8);
$html = ''; $horiz = ($layout === 'horizontal');
foreach ($children as $i => $child) { $html .= $builder->render($child, ['element'=>$props, 'index'=>$i]); }
if (!trim($html)) return;
$half = (int)($ds / 2);
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<?php if ($horiz) : ?>
<div id="<?= esc_attr($uid) ?>" class="wf-tl wf-tl--h" style="overflow-x:auto;padding:0 24px 16px;">
    <div class="wf-tl-track" style="display:flex;gap:<?= $gap ?>px;position:relative;padding-top:<?= $ds + 20 ?>px;min-width:max-content;">
        <div class="wf-tl-line" style="position:absolute;top:<?= $half ?>px;left:0;right:0;height:2px;background:<?= esc_attr($lc) ?>;"></div>
        <?php if ($prog) : ?><div class="wf-tl-progress" style="position:absolute;top:<?= $half ?>px;left:0;height:2px;width:0;background:<?= esc_attr($progC) ?>;transition:width .3s;z-index:1;"></div><?php endif; ?>
        <?= $html ?>
    </div>
</div>
<?php else : ?>
<div id="<?= esc_attr($uid) ?>" class="wf-tl wf-tl--v" style="position:relative;padding-left:<?= $ds + 20 ?>px;">
    <div class="wf-tl-line" style="position:absolute;left:<?= $half ?>px;top:0;bottom:0;width:2px;background:<?= esc_attr($lc) ?>;"></div>
    <?php if ($prog) : ?><div class="wf-tl-progress" style="position:absolute;left:<?= $half ?>px;top:0;width:2px;height:0;background:<?= esc_attr($progC) ?>;transition:height .1s;z-index:1;"></div><?php endif; ?>
    <?= $html ?>
</div>
<?php endif; ?>
<style>
<?php if ($horiz) : ?>
#<?= esc_attr($uid) ?> .wf-tl-item{min-width:200px;max-width:300px;position:relative;flex-shrink:0}
#<?= esc_attr($uid) ?> .wf-tl-dot{position:absolute;top:-<?= $ds + 20 ?>px;left:50%;transform:translateX(-50%);width:<?= $ds ?>px;height:<?= $ds ?>px;border-radius:50%;background:<?= esc_attr($lc) ?>;border:3px solid #fff;box-shadow:0 0 0 2px <?= esc_attr($lc) ?>;z-index:2;transition:background .3s,box-shadow .3s}
#<?= esc_attr($uid) ?> .wf-tl-item{text-align:center}
<?php else : ?>
#<?= esc_attr($uid) ?> .wf-tl-item{position:relative;padding-bottom:<?= $gap ?>px}
#<?= esc_attr($uid) ?> .wf-tl-dot{position:absolute;left:-<?= $ds + 20 - $half + 1 ?>px;top:2px;width:<?= $ds ?>px;height:<?= $ds ?>px;border-radius:50%;background:<?= esc_attr($lc) ?>;border:3px solid #fff;box-shadow:0 0 0 2px <?= esc_attr($lc) ?>;z-index:2;transition:background .3s,box-shadow .3s}
<?php endif; ?>
#<?= esc_attr($uid) ?> .wf-tl-dot.wf-tl-dot--active{background:<?= esc_attr($dc) ?>;box-shadow:0 0 0 2px <?= esc_attr($dc) ?>}
<?php if ($anim) : ?>#<?= esc_attr($uid) ?> .wf-tl-item{opacity:0;transform:translateY(20px);transition:opacity .5s,transform .5s}#<?= esc_attr($uid) ?> .wf-tl-item.wf-tl--vis{opacity:1;transform:none}<?php endif; ?>
</style>
<script>
(function(){
    function boot(){
        var el=document.getElementById('<?= esc_attr($uid) ?>');if(!el)return;
        var items=el.querySelectorAll('.wf-tl-item');var dots=el.querySelectorAll('.wf-tl-dot');
        var progBar=el.querySelector('.wf-tl-progress');var isVert=el.classList.contains('wf-tl--v');
        <?php if ($anim) : ?>
        if('IntersectionObserver' in window){var obs=new IntersectionObserver(function(es){var i=0;while(i<es.length){if(es[i].isIntersecting){es[i].target.classList.add('wf-tl--vis');obs.unobserve(es[i].target)}i++}},{threshold:0.15});var j=0;while(j<items.length){obs.observe(items[j]);j++}}else{var k=0;while(k<items.length){items[k].classList.add('wf-tl--vis');k++}}
        <?php endif; ?>
        <?php if ($prog) : ?>
        function upd(){
            if(!progBar)return;var vh=window.innerHeight;var center=vh*0.6;var lastA=-1;var i=0;
            while(i<dots.length){var dr=dots[i].getBoundingClientRect();if(dr.top<center){dots[i].classList.add('wf-tl-dot--active');lastA=i}else{dots[i].classList.remove('wf-tl-dot--active')}i++}
            if(lastA>=0){var ld=dots[lastA];var line=el.querySelector('.wf-tl-line');
                if(isVert){var lt=line.getBoundingClientRect().top;progBar.style.height=(ld.getBoundingClientRect().bottom-lt)+'px'}
                else{var ll=line.getBoundingClientRect().left;progBar.style.width=(ld.getBoundingClientRect().right-ll)+'px'}
            }else{if(isVert){progBar.style.height='0'}else{progBar.style.width='0'}}
        }
        window.addEventListener('scroll',function(){requestAnimationFrame(upd)},{passive:true});upd();
        <?php endif; ?>
    }
    WF.ready(boot)
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
