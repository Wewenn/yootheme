<?php
/**
 * WeFrame – Navbar plein écran : un lien (item).
 */
defined( 'ABSPATH' ) || exit;

$label = trim( (string) ( $props['label'] ?? '' ) );
if ( '' === $label ) { return; }
$url   = trim( (string) ( $props['url'] ?? '' ) );
$badge = trim( (string) ( $props['badge'] ?? '' ) );
$href  = ( '' !== $url ) ? $url : '#';
?>
<a class="wf-nf-link" href="<?= esc_url( $href ) ?>">
    <span class="wf-nf-link-txt"><?= esc_html( $label ) ?></span>
    <?php if ( '' !== $badge ) : ?><span class="wf-nf-link-badge"><?= esc_html( $badge ) ?></span><?php endif; ?>
</a>
