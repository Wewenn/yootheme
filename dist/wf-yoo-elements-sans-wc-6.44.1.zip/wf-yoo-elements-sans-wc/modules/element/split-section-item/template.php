<?php
defined('ABSPATH') || exit;
if (empty($children)) return;
$mh=(int)($props['min_height']??0);$pad=(int)($props['padding']??0);
$inner='';foreach($children as $child){$inner.=$builder->render($child);}
if(!trim($inner))return;
?>
<div style="<?= $mh?"min-height:{$mh}px;":'' ?><?= $pad?"padding:{$pad}px;":'' ?>"><?= $inner ?></div>
