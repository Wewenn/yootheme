<?php
/**
 * WeFrame – Scroll Photos Item | template.php
 * $props   = this item's props (image, image_alt, caption, side, width_override)
 * $element = parent Scroll Photos props (photo_radius, photo_shadow, photo_width)
 */
defined( 'ABSPATH' ) || exit;

$src = $props['image'] ?? '';
$alt = $props['image_alt'] ?? '';
$cap = trim( $props['caption'] ?? '' );

if ( ! $src ) { return; }

if ( ! preg_match( '#^https?://#i', $src ) ) {
    $src = '/' . ltrim( $src, '/' );
}

$radius = min( 40, max( 0, (int) ( $element['photo_radius'] ?? 14 ) ) );
$shadow = ! empty( $element['photo_shadow'] );
$sh_css = $shadow ? 'box-shadow:0 24px 60px -20px rgba(0,0,0,.35);' : '';

?>
<figure class="wf-sp-fig" style="margin:0;">
    <img src="<?= esc_url( $src ) ?>" alt="<?= esc_attr( $alt ) ?>" loading="lazy"
         style="display:block;width:100%;height:auto;border-radius:<?= $radius ?>px;<?= $sh_css ?>">
    <?php if ( $cap ) : ?>
    <figcaption style="margin-top:10px;font-size:13px;line-height:1.4;opacity:.7;">
        <?= esc_html( $cap ) ?>
    </figcaption>
    <?php endif; ?>
</figure>
