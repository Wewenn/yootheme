<?php
/**
 * WeFrame – Testimonial Branded | template.php v1.0
 */
defined( 'ABSPATH' ) || exit;

$logo    = $props['logo'] ?? '';
$lh      = (int) ( $props['logo_height'] ?? 32 );
$quote   = $props['quote']  ?? '';
$author  = $props['author'] ?? '';
$role    = $props['role']   ?? '';
$avatar  = $props['avatar'] ?? '';
$bg      = $props['bg'] ?? '#E8ECE8';
$tc      = $props['text_color'] ?? '#111111';
$rc      = $props['role_color'] ?? '#6B7280';
$rad     = (int) ( $props['radius'] ?? 16 );
$pad     = (int) ( $props['padding'] ?? 48 );
$qs      = (int) ( $props['quote_size'] ?? 28 );
$qf      = $props['quote_font'] ?? "'Playfair Display', Georgia, serif";
$mw      = (int) ( $props['max_width'] ?? 720 );
$mh      = (int) ( $props['min_height'] ?? 420 );

$uid = wf_uid( 'wftb_', $props );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-tb-wrap" style="background:<?= esc_attr( $bg ) ?>;color:<?= esc_attr( $tc ) ?>;border-radius:<?= $rad ?>px;padding:<?= $pad ?>px;max-width:<?= $mw ?>px;min-height:<?= $mh ?>px;margin:0 auto;display:flex;flex-direction:column;justify-content:space-between;gap:32px;">
    <?php if ( $logo ) : ?>
    <div style="flex-shrink:0;">
        <img src="<?= esc_url( $logo ) ?>" alt="<?= esc_attr( $role ) ?>" style="height:<?= $lh ?>px;width:auto;display:block;" loading="lazy">
    </div>
    <?php endif; ?>

    <?php if ( $quote ) : ?>
    <blockquote style="margin:0;flex:1;display:flex;align-items:center;">
        <p style="margin:0;font-family:<?= esc_attr( $qf ) ?>;font-size:<?= $qs ?>px;line-height:1.35;font-weight:500;">
            &ldquo;<?= esc_html( $quote ) ?>&rdquo;
        </p>
    </blockquote>
    <?php endif; ?>

    <?php if ( $author || $avatar ) : ?>
    <div style="display:flex;align-items:center;gap:14px;flex-shrink:0;">
        <?php if ( $avatar ) : ?>
        <img src="<?= esc_url( $avatar ) ?>" alt="<?= esc_attr( $author ) ?>" style="width:56px;height:56px;border-radius:6px;object-fit:cover;flex-shrink:0;" loading="lazy">
        <?php endif; ?>
        <div style="line-height:1.3;">
            <?php if ( $author ) : ?><div style="font-weight:700;font-size:15px;color:<?= esc_attr( $tc ) ?>;"><?= esc_html( $author ) ?></div><?php endif; ?>
            <?php if ( $role ) : ?><div style="font-size:14px;color:<?= esc_attr( $rc ) ?>;"><?= esc_html( $role ) ?></div><?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
