<?php
/**
 * WeFrame – Tableau responsive | template.php v1.0
 *
 * Un vrai <table> (en-têtes, scope, légende), qui change de forme sous un
 * seuil : chaque ligne devient une carte, ou le tableau défile avec sa première
 * colonne figée, ou les colonnes secondaires disparaissent.
 *
 * En mode cartes, les éléments du tableau passent en display:block, ce qui fait
 * perdre aux navigateurs les rôles implicites de tableau. Les rôles sont donc
 * écrits explicitement : sans ça, un lecteur d'écran ne lirait plus qu'une
 * suite de blocs.
 *
 * Les données viennent d'un collage de tableur : le séparateur est deviné.
 * Pas de "&&" ni de "||" dans le JS inline (règle interne du plugin).
 */

defined( 'ABSPATH' ) || exit;

$raw = (string) ( $props['data'] ?? '' );
$raw = str_replace( array( "\r\n", "\r" ), "\n", $raw );
$lines = array();
foreach ( explode( "\n", $raw ) as $line ) {
	if ( '' !== trim( $line ) ) { $lines[] = $line; }
}
if ( empty( $lines ) ) { return; }

$sepKey = (string) ( $props['separator'] ?? 'auto' );
$sepMap = array( 'tab' => "\t", 'semi' => ';', 'pipe' => '|', 'comma' => ',' );
$sep = "\t";
if ( isset( $sepMap[ $sepKey ] ) ) {
	$sep = $sepMap[ $sepKey ];
} else {
	// Détection : le séparateur le plus présent sur la première ligne l'emporte.
	$best = 0;
	foreach ( $sepMap as $cand ) {
		$n = substr_count( $lines[0], $cand );
		if ( $n > $best ) { $best = $n; $sep = $cand; }
	}
}

$table = array();
$cols  = 0;
foreach ( $lines as $line ) {
	$cells = array_map( 'trim', explode( $sep, $line ) );
	$cols  = max( $cols, count( $cells ) );
	$table[] = $cells;
}

$hasHead    = ! empty( $props['first_row_header'] );
$firstColTh = ! empty( $props['first_col_header'] );
$allowHtml  = ! empty( $props['allow_html'] );
$caption    = trim( (string) ( $props['caption'] ?? '' ) );

$mobileMode = (string) ( $props['mobile_mode'] ?? 'cards' );
if ( ! in_array( $mobileMode, array( 'cards', 'scroll', 'priority' ), true ) ) { $mobileMode = 'cards'; }
$bp = (int) ( $props['mobile_bp'] ?? 640 );
if ( ! in_array( $bp, array( 480, 640, 768, 960 ), true ) ) { $bp = 640; }

$sortable   = ! empty( $props['sortable'] );
$searchable = ! empty( $props['searchable'] );
$searchLbl  = trim( (string) ( $props['search_label'] ?? '' ) );
if ( '' === $searchLbl ) { $searchLbl = 'Rechercher…'; }
$emptyText  = trim( (string) ( $props['empty_text'] ?? '' ) );
if ( '' === $emptyText ) { $emptyText = 'Aucune ligne ne correspond.'; }

$zebra   = ! empty( $props['zebra'] );
$hover   = ! empty( $props['hover'] );
$borders = (string) ( $props['borders'] ?? 'rows' );
if ( ! in_array( $borders, array( 'rows', 'grid', 'none' ), true ) ) { $borders = 'rows'; }
$density = (string) ( $props['density'] ?? 'normal' );
if ( ! in_array( $density, array( 'compact', 'normal', 'roomy' ), true ) ) { $density = 'normal'; }
$stickyHead = ! empty( $props['sticky_head'] );

$headBg  = trim( (string) ( $props['head_bg'] ?? '' ) );
$headCol = trim( (string) ( $props['head_color'] ?? '' ) );
$accent  = (string) ( $props['accent'] ?? '#EA5C1C' );
$bdCol   = trim( (string) ( $props['border_color'] ?? '' ) );
if ( '' === $bdCol ) { $bdCol = 'rgba(127,127,127,.28)'; }
$txtSize = max( 11, min( 22, (int) ( $props['text_size'] ?? 15 ) ) );
$radius  = max( 0, min( 28, (int) ( $props['radius'] ?? 10 ) ) );

// Fond des cellules figées ou collantes : il leur en faut un opaque, sinon le
// contenu défile en transparence par-dessous.
$solidBg = '' !== $headBg ? $headBg : '#ffffff';

$alignMap = array( 'g' => 'left', 'l' => 'left', 'c' => 'center', 'd' => 'right', 'r' => 'right' );
$aligns = array();
foreach ( explode( ',', (string) ( $props['align'] ?? '' ) ) as $a ) {
	$a = strtolower( trim( $a ) );
	$aligns[] = isset( $alignMap[ $a ] ) ? $alignMap[ $a ] : '';
}

$hidden = array();
foreach ( explode( ',', (string) ( $props['hide_cols'] ?? '' ) ) as $h ) {
	$h = (int) trim( $h );
	if ( $h > 0 ) { $hidden[] = $h; }
}

$allowed = array(
	'a'      => array( 'href' => array(), 'title' => array(), 'target' => array(), 'rel' => array() ),
	'strong' => array(),
	'b'      => array(),
	'em'     => array(),
	'i'      => array(),
	'br'     => array(),
	'small'  => array(),
	'span'   => array( 'class' => array() ),
	'code'   => array(),
);

$uid = wf_uid( 'wftb_', $props );

$head = array();
$body = array();

$headRow = $hasHead ? $table[0] : array();
for ( $c = 0; $c < $cols; $c++ ) {
	$v = isset( $headRow[ $c ] ) ? $headRow[ $c ] : '';
	$html = $allowHtml ? wp_kses( $v, $allowed ) : esc_html( $v );
	$cls  = '';
	if ( in_array( $c + 1, $hidden, true ) ) { $cls .= ' wf-tbl--opt'; }
	$style = '';
	if ( ! empty( $aligns[ $c ] ) ) { $style = ' style="text-align:' . esc_attr( $aligns[ $c ] ) . '"'; }
	$head[] = array(
		'html'  => $html,
		'text'  => $v,
		'i'     => $c,
		'attr'  => 'scope="col" role="columnheader" class="wf-tbl__th' . $cls . '"' . $style,
	);
}

$start = $hasHead ? 1 : 0;
for ( $r = $start; $r < count( $table ); $r++ ) {
	$cells = array();
	for ( $c = 0; $c < $cols; $c++ ) {
		$v = isset( $table[ $r ][ $c ] ) ? $table[ $r ][ $c ] : '';
		$html = $allowHtml ? wp_kses( $v, $allowed ) : esc_html( $v );
		$label = $hasHead ? ( isset( $headRow[ $c ] ) ? $headRow[ $c ] : '' ) : '';
		$cls = 'wf-tbl__td';
		if ( in_array( $c + 1, $hidden, true ) ) { $cls .= ' wf-tbl--opt'; }
		$style = '';
		if ( ! empty( $aligns[ $c ] ) ) { $style = ' style="text-align:' . esc_attr( $aligns[ $c ] ) . '"'; }
		$isHead = $firstColTh && 0 === $c;
		$role   = $isHead ? 'rowheader' : 'cell';
		$scope  = $isHead ? ' scope="row"' : '';
		$cells[] = array(
			'html'   => $html,
			'isHead' => $isHead,
			'attr'   => 'role="' . $role . '"' . $scope . ' class="' . $cls . '" data-label="' . esc_attr( $label ) . '"' . $style,
		);
	}
	$body[] = $cells;
}

$padMap = array( 'compact' => '6px 10px', 'normal' => '10px 14px', 'roomy' => '16px 20px' );
$pad = $padMap[ $density ];

$cfg = wp_json_encode(
	array(
		'uid'    => $uid,
		'sort'   => $sortable,
		'search' => $searchable,
	),
	JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE
);
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-tbl wf-tbl--<?= esc_attr( $mobileMode ) ?>">
	<?php if ( $searchable ) : ?>
	<div class="wf-tbl__tools">
		<label class="wf-tbl__search">
			<span class="wf-tbl__srlabel"><?= esc_html( $searchLbl ) ?></span>
			<input type="search" class="wf-tbl__input" placeholder="<?= esc_attr( $searchLbl ) ?>" autocomplete="off">
		</label>
	</div>
	<?php endif; ?>
	<div class="wf-tbl__scroll">
		<table role="table" class="wf-tbl__table">
			<?php if ( '' !== $caption ) : ?><caption class="wf-tbl__caption"><?= esc_html( $caption ) ?></caption><?php endif; ?>
			<?php if ( $hasHead ) : ?>
			<thead role="rowgroup" class="wf-tbl__head">
				<tr role="row">
				<?php foreach ( $head as $h ) : ?>
					<th <?= $h['attr'] ?>>
					<?php if ( $sortable ) : ?><button type="button" class="wf-tbl__sort" data-col="<?= (int) $h['i'] ?>"><?= $h['html'] ?><span class="wf-tbl__arrow" aria-hidden="true"></span></button><?php else : ?><?= $h['html'] ?><?php endif; ?>
					</th>
				<?php endforeach; ?>
				</tr>
			</thead>
			<?php endif; ?>
			<tbody role="rowgroup" class="wf-tbl__body">
			<?php foreach ( $body as $row ) : ?>
				<tr role="row" class="wf-tbl__tr">
				<?php foreach ( $row as $cell ) : ?>
					<?php if ( $cell['isHead'] ) : ?><th <?= $cell['attr'] ?>><?= $cell['html'] ?></th><?php else : ?><td <?= $cell['attr'] ?>><?= $cell['html'] ?></td><?php endif; ?>
				<?php endforeach; ?>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>
	<?php if ( $searchable ) : ?>
	<p class="wf-tbl__empty" hidden><?= esc_html( $emptyText ) ?></p>
	<?php endif; ?>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?>{font-size:<?= (int) $txtSize ?>px;}
#<?= esc_attr( $uid ) ?> .wf-tbl__scroll{overflow-x:auto;border-radius:<?= (int) $radius ?>px;}
#<?= esc_attr( $uid ) ?> .wf-tbl__table{width:100%;border-collapse:collapse;margin:0;}
#<?= esc_attr( $uid ) ?> .wf-tbl__caption{
	caption-side:top;text-align:left;padding:0 0 .7em;font-size:.9em;opacity:.72;
}
#<?= esc_attr( $uid ) ?> .wf-tbl__th{
	padding:<?= esc_attr( $pad ) ?>;text-align:left;font-weight:700;white-space:nowrap;
	<?php if ( '' !== $headBg ) : ?>background:<?= esc_attr( $headBg ) ?>;<?php endif; ?>
	<?php if ( '' !== $headCol ) : ?>color:<?= esc_attr( $headCol ) ?>;<?php endif; ?>
	border-bottom:2px solid <?= esc_attr( $bdCol ) ?>;
}
#<?= esc_attr( $uid ) ?> .wf-tbl__td,#<?= esc_attr( $uid ) ?> tbody th{padding:<?= esc_attr( $pad ) ?>;text-align:left;vertical-align:top;}
#<?= esc_attr( $uid ) ?> tbody th{font-weight:700;}
<?php if ( 'rows' === $borders ) : ?>
#<?= esc_attr( $uid ) ?> tbody tr + tr td,#<?= esc_attr( $uid ) ?> tbody tr + tr th{border-top:1px solid <?= esc_attr( $bdCol ) ?>;}
<?php elseif ( 'grid' === $borders ) : ?>
#<?= esc_attr( $uid ) ?> .wf-tbl__table td,#<?= esc_attr( $uid ) ?> .wf-tbl__table th{border:1px solid <?= esc_attr( $bdCol ) ?>;}
<?php endif; ?>
<?php if ( $zebra ) : ?>
#<?= esc_attr( $uid ) ?> tbody tr:nth-child(even){background:rgba(127,127,127,.06);}
<?php endif; ?>
<?php if ( $hover ) : ?>
#<?= esc_attr( $uid ) ?> tbody tr:hover{background:rgba(127,127,127,.11);}
<?php endif; ?>
<?php if ( $stickyHead ) : ?>
#<?= esc_attr( $uid ) ?> .wf-tbl__th{position:sticky;top:0;z-index:2;background:<?= esc_attr( $solidBg ) ?>;}
<?php endif; ?>
<?php if ( $sortable ) : ?>
#<?= esc_attr( $uid ) ?> .wf-tbl__sort{
	display:inline-flex;align-items:center;gap:.4em;min-height:32px;padding:0;cursor:pointer;
	font:inherit;font-weight:700;color:inherit;background:none;border:0;
}
#<?= esc_attr( $uid ) ?> .wf-tbl__arrow{
	width:0;height:0;border-left:4px solid transparent;border-right:4px solid transparent;
	border-bottom:5px solid currentColor;opacity:.25;
}
#<?= esc_attr( $uid ) ?> [aria-sort="ascending"] .wf-tbl__arrow{opacity:1;color:<?= esc_attr( $accent ) ?>;}
#<?= esc_attr( $uid ) ?> [aria-sort="descending"] .wf-tbl__arrow{opacity:1;color:<?= esc_attr( $accent ) ?>;transform:rotate(180deg);}
<?php endif; ?>
<?php if ( $searchable ) : ?>
#<?= esc_attr( $uid ) ?> .wf-tbl__tools{margin:0 0 .8em;}
#<?= esc_attr( $uid ) ?> .wf-tbl__srlabel{
	position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;
	clip-path:inset(50%);white-space:nowrap;border:0;
}
#<?= esc_attr( $uid ) ?> .wf-tbl__input{
	width:100%;max-width:320px;min-height:44px;padding:.5em .9em;font:inherit;
	color:inherit;background:transparent;border:1px solid <?= esc_attr( $bdCol ) ?>;border-radius:8px;
}
#<?= esc_attr( $uid ) ?> .wf-tbl__empty{margin:.9em 0 0;opacity:.7;}
<?php endif; ?>
<?php if ( 'cards' === $mobileMode ) : ?>
@media (max-width:<?= (int) ( $bp - 1 ) ?>px){
	#<?= esc_attr( $uid ) ?> .wf-tbl__scroll{overflow-x:visible;}
	#<?= esc_attr( $uid ) ?> .wf-tbl__table,#<?= esc_attr( $uid ) ?> .wf-tbl__body,#<?= esc_attr( $uid ) ?> .wf-tbl__tr,#<?= esc_attr( $uid ) ?> .wf-tbl__td,#<?= esc_attr( $uid ) ?> tbody th{display:block;width:auto;}
	#<?= esc_attr( $uid ) ?> .wf-tbl__head{
		position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;
		clip-path:inset(50%);white-space:nowrap;border:0;
	}
	#<?= esc_attr( $uid ) ?> .wf-tbl__tr{
		border:1px solid <?= esc_attr( $bdCol ) ?>;border-radius:<?= (int) $radius ?>px;
		padding:6px 14px;margin:0 0 12px;background:none;
	}
	#<?= esc_attr( $uid ) ?> tbody tr:hover{background:none;}
	#<?= esc_attr( $uid ) ?> .wf-tbl__td,#<?= esc_attr( $uid ) ?> tbody th{
		display:flex;gap:1.2em;justify-content:space-between;align-items:baseline;
		padding:8px 0;border:0;text-align:right;
	}
	#<?= esc_attr( $uid ) ?> tbody tr + tr td,#<?= esc_attr( $uid ) ?> tbody tr + tr th{border-top:0;}
	#<?= esc_attr( $uid ) ?> .wf-tbl__td[data-label]:not([data-label=""])::before{
		content:attr(data-label);flex:0 0 auto;text-align:left;font-weight:700;opacity:.62;
	}
	#<?= esc_attr( $uid ) ?> .wf-tbl__td + .wf-tbl__td{border-top:1px solid rgba(127,127,127,.16);}
}
<?php elseif ( 'scroll' === $mobileMode ) : ?>
@media (max-width:<?= (int) ( $bp - 1 ) ?>px){
	#<?= esc_attr( $uid ) ?> .wf-tbl__table{min-width:<?= (int) ( $cols * 130 ) ?>px;}
	#<?= esc_attr( $uid ) ?> .wf-tbl__th:first-child,#<?= esc_attr( $uid ) ?> tbody tr > :first-child{
		position:sticky;left:0;z-index:1;background:<?= esc_attr( $solidBg ) ?>;
		box-shadow:1px 0 0 <?= esc_attr( $bdCol ) ?>;
	}
	#<?= esc_attr( $uid ) ?> .wf-tbl__th:first-child{z-index:3;}
}
<?php else : ?>
@media (max-width:<?= (int) ( $bp - 1 ) ?>px){
	#<?= esc_attr( $uid ) ?> .wf-tbl--opt{display:none;}
}
<?php endif; ?>
</style>
<?php if ( $sortable || $searchable ) : ?>
<script>
(function(){
	function boot(){
		var c = <?= $cfg ?>;
		var root = document.getElementById(c.uid);
		if(!root){return;}
		if(root.getAttribute('data-wf-ready')){return;}
		root.setAttribute('data-wf-ready','1');

		var tbody = root.querySelector('.wf-tbl__body');
		if(!tbody){return;}
		var rows = Array.prototype.slice.call(tbody.querySelectorAll('.wf-tbl__tr'));

		function txt(tr, i){
			var cells = tr.children;
			if(i >= cells.length){return '';}
			return (cells[i].textContent || '').trim();
		}

		// « 1 234,50 € » doit se trier comme un nombre, pas comme du texte.
		function num(s){
			var t = s.replace(/\s/g, '').replace(/[^0-9,.\-]/g, '').replace(',', '.');
			if(t === ''){return null;}
			var v = parseFloat(t);
			if(isNaN(v)){return null;}
			return v;
		}

		if(c.sort){
			var ths = Array.prototype.slice.call(root.querySelectorAll('.wf-tbl__th'));
			var btns = Array.prototype.slice.call(root.querySelectorAll('.wf-tbl__sort'));
			var b = 0;
			while(b < btns.length){
				(function(btn){
					btn.addEventListener('click', function(){
						var i = parseInt(btn.getAttribute('data-col'), 10);
						var th = btn.parentNode;
						var cur = th.getAttribute('aria-sort');
						var dir = cur === 'ascending' ? -1 : 1;
						var k = 0;
						while(k < ths.length){ ths[k].removeAttribute('aria-sort'); k++; }
						th.setAttribute('aria-sort', dir === 1 ? 'ascending' : 'descending');

						var allNum = true;
						var n = 0;
						while(n < rows.length){
							if(num(txt(rows[n], i)) === null){ allNum = false; }
							n++;
						}
						var sorted = rows.slice();
						sorted.sort(function(x, y){
							var a = txt(x, i), z = txt(y, i);
							if(allNum){ return (num(a) - num(z)) * dir; }
							return a.localeCompare(z, 'fr', {numeric: true}) * dir;
						});
						var s = 0;
						while(s < sorted.length){ tbody.appendChild(sorted[s]); s++; }
					});
				}(btns[b]));
				b++;
			}
		}

		if(c.search){
			var input = root.querySelector('.wf-tbl__input');
			var empty = root.querySelector('.wf-tbl__empty');
			function flat(s){
				return s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
			}
			if(input){
				input.addEventListener('input', function(){
					var q = flat(input.value.trim());
					var shown = 0;
					var i = 0;
					while(i < rows.length){
						var hit = q === '';
						if(!hit){ hit = flat(rows[i].textContent).indexOf(q) !== -1; }
						rows[i].hidden = !hit;
						if(hit){ shown++; }
						i++;
					}
					if(empty){ empty.hidden = shown !== 0; }
				});
			}
		}
	}
	WF.ready(boot);
}());
</script>
<?php endif; ?>
