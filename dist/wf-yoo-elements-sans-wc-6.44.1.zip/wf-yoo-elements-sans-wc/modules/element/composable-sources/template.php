<?php
defined( 'ABSPATH' ) || exit;
require_once __DIR__ . '/../../wf-motion-kit.php';

$p        = wfmk_props( 'composable-sources', $props );
$template = wp_kses_post( (string) ( $p['template'] ?? '' ) );
$empty    = wfmk_choice( $p['empty_behavior'] ?? 'remove', array( 'remove', 'fallback', 'hide' ), 'remove' );
$hide     = false;

foreach ( $children ?? array() as $child ) {
	$cp       = isset( $child->props ) ? (array) $child->props : (array) ( $child['props'] ?? array() );
	$token    = preg_replace( '/[^A-Za-z0-9_.-]/', '', (string) ( $cp['token'] ?? '' ) );
	$value    = $cp['value'] ?? '';
	$fallback = $cp['fallback'] ?? '';
	if ( '' === $token ) { continue; }
	if ( is_array( $value ) || is_object( $value ) ) { $value = ''; }
	$value = trim( (string) $value );
	if ( '' === $value ) {
		if ( 'hide' === $empty ) { $hide = true; break; }
		$value = 'fallback' === $empty ? (string) $fallback : '';
	}
	$format = wfmk_choice( $cp['format'] ?? 'text', array( 'text', 'number', 'currency', 'date', 'url', 'email' ), 'text' );
	if ( 'number' === $format || 'currency' === $format ) {
		$number = is_numeric( str_replace( ',', '.', $value ) ) ? (float) str_replace( ',', '.', $value ) : 0;
		$value  = number_format_i18n( $number, max( 0, min( 6, (int) ( $cp['decimals'] ?? 0 ) ) ) );
		if ( 'currency' === $format ) { $value .= ' ' . sanitize_text_field( (string) ( $cp['currency'] ?? '€' ) ); }
	} elseif ( 'date' === $format && strtotime( $value ) ) {
		$value = wp_date( sanitize_text_field( (string) ( $cp['date_format'] ?? 'j F Y' ) ), strtotime( $value ) );
	} elseif ( 'url' === $format ) {
		$url   = esc_url( $value );
		$value = $url ? '<a href="' . esc_attr( $url ) . '">' . esc_html( $url ) . '</a>' : '';
	} elseif ( 'email' === $format ) {
		$mail  = sanitize_email( $value );
		$value = $mail ? '<a href="mailto:' . esc_attr( $mail ) . '">' . esc_html( $mail ) . '</a>' : '';
	} else {
		$value = esc_html( $value );
	}
	$value    = esc_html( (string) ( $cp['prefix'] ?? '' ) ) . $value . esc_html( (string) ( $cp['suffix'] ?? '' ) );
	$template = str_replace( '{{' . $token . '}}', $value, $template );
}
if ( $hide || '' === trim( wp_strip_all_tags( $template ) ) ) { return; }
$template = preg_replace( '/\{\{[A-Za-z0-9_.-]+\}\}/', '', $template );
$tag      = wfmk_choice( $p['html_element'] ?? 'p', array( 'p', 'div', 'span', 'h1', 'h2', 'h3', 'h4' ), 'p' );
$wf_el    = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $tag ) : null;
if ( $wf_el ) { echo $wf_el( $props, $attrs ?? array() ); }
?>
<span class="wf-composable-sources" style="<?= wfmk_vars( array(
	'color' => wfmk_color( $p['text_color'] ?? '', 'currentColor' ),
	'size'  => wfmk_n( $p, 'font_size', 18, 8, 180 ) . 'px',
	'line'  => wfmk_n( $p, 'line_height', 1.5, 0.8, 3 ),
	'align' => wfmk_choice( $p['align'] ?? 'left', array( 'left', 'center', 'right' ), 'left' ),
) ) ?>"><?= wp_kses_post( $template ) ?></span>
<?php if ( $wf_el ) { echo $wf_el->end(); } ?>
