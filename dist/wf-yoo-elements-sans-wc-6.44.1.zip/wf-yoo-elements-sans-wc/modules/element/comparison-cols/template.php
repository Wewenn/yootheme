<?php
/**
 * WeFrame – Comparaison (Versus) | template.php v1.0
 * Deux colonnes : "désavantage" (gauche, atténuée) vs "avantage" (droite, mise en avant).
 */
defined( 'ABSPATH' ) || exit;

$s_title  = (string) ( $props['section_title'] ?? '' );
$t_color  = $props['title_color'] ?? '#111111';
$t_size   = (int) ( $props['title_size'] ?? 56 );
$t_align  = $props['title_align'] ?? 'center';
$cstyle   = $props['check_style'] ?? 'filled';
$reveal   = ! empty( $props['reveal'] );

$l_title  = (string) ( $props['left_title'] ?? '' );
$l_bg     = $props['left_bg'] ?? '#ffffff';
$l_tc     = $props['left_text_color'] ?? '#6b7280';
$l_cc     = $props['left_check_color'] ?? '#c9ccd1';
$l_muted  = ! empty( $props['left_muted'] );
$l_items  = (string) ( $props['left_items'] ?? '' );

$r_title  = (string) ( $props['right_title'] ?? '' );
$r_logo   = trim( (string) ( $props['right_logo'] ?? '' ) );
$r_logo_w = (int) ( $props['right_logo_width'] ?? 26 );
$r_bg     = $props['right_bg'] ?? '#f7a8e0';
$r_tc     = $props['right_text_color'] ?? '#111111';
$r_cc     = $props['right_check_color'] ?? '#111111';
$r_items  = (string) ( $props['right_items'] ?? '' );

$radius   = (int) ( $props['radius'] ?? 20 );
$gap      = (int) ( $props['gap'] ?? 28 );
$pad      = (int) ( $props['card_padding'] ?? 34 );
$mw       = (int) ( $props['max_width'] ?? 1040 );

if ( $r_logo && ! preg_match( '#^https?://#i', $r_logo ) ) { $r_logo = '/' . ltrim( $r_logo, '/' ); }

$uid = wf_uid( 'wfcmp_', $props );

if ( ! function_exists( 'wf_cmp_items' ) ) {
    function wf_cmp_items( $raw ) {
        $out = array();
        $lines = preg_split( '/\r\n|\r|\n/', (string) $raw );
        foreach ( $lines as $l ) {
            $l = trim( $l );
            if ( '' !== $l ) { $out[] = $l; }
        }
        return $out;
    }
}

if ( ! function_exists( 'wf_cmp_check' ) ) {
    function wf_cmp_check( $style, $color ) {
        $c = esc_attr( $color );
        if ( 'outline' === $style ) {
            return '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="' . $c . '" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M8.5 12l2.2 2.2 4.6-4.8"/></svg>';
        }
        return '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" fill="' . $c . '"/><path d="M8 12l2.5 2.5 5-5" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"/></svg>';
    }
}

$li_l = wf_cmp_items( $l_items );
$li_r = wf_cmp_items( $r_items );

$col_open = $reveal ? ' wf-cmp-rev' : '';
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-cmp" style="max-width:<?= $mw ?>px;margin-left:auto;margin-right:auto;">

    <?php if ( $s_title ) : ?>
    <h2 class="wf-cmp-title" style="text-align:<?= esc_attr( $t_align ) ?>;color:<?= esc_attr( $t_color ) ?>;font-size:<?= $t_size ?>px;"><?= esc_html( $s_title ) ?></h2>
    <?php endif; ?>

    <div class="wf-cmp-grid" style="gap:<?= $gap ?>px;">

        <div class="wf-cmp-col<?= $col_open ?>" style="background:<?= esc_attr( $l_bg ) ?>;color:<?= esc_attr( $l_tc ) ?>;border-radius:<?= $radius ?>px;padding:<?= $pad ?>px;<?= $l_muted ? 'opacity:.96;' : '' ?>">
            <?php if ( $l_title ) : ?>
            <div class="wf-cmp-head"><span class="wf-cmp-h" style="color:<?= esc_attr( $l_tc ) ?>;"><?= esc_html( $l_title ) ?></span></div>
            <?php endif; ?>
            <ul class="wf-cmp-list">
                <?php foreach ( $li_l as $i => $it ) : ?>
                <li style="transition-delay:<?= $reveal ? round( $i * 0.06, 3 ) : 0 ?>s;"><span class="wf-cmp-ic"><?= wf_cmp_check( $cstyle, $l_cc ) ?></span><span><?= esc_html( $it ) ?></span></li>
                <?php endforeach; ?>
            </ul>
        </div>

        <div class="wf-cmp-col wf-cmp-col--hl<?= $col_open ?>" style="background:<?= esc_attr( $r_bg ) ?>;color:<?= esc_attr( $r_tc ) ?>;border-radius:<?= $radius ?>px;padding:<?= $pad ?>px;">
            <div class="wf-cmp-head">
                <?php if ( $r_logo ) : ?><img src="<?= esc_url( $r_logo ) ?>" alt="" style="width:<?= $r_logo_w ?>px;height:auto;"><?php endif; ?>
                <?php if ( $r_title ) : ?><span class="wf-cmp-h" style="color:<?= esc_attr( $r_tc ) ?>;"><?= esc_html( $r_title ) ?></span><?php endif; ?>
            </div>
            <ul class="wf-cmp-list">
                <?php foreach ( $li_r as $i => $it ) : ?>
                <li style="transition-delay:<?= $reveal ? round( $i * 0.06, 3 ) : 0 ?>s;"><span class="wf-cmp-ic"><?= wf_cmp_check( $cstyle, $r_cc ) ?></span><span><?= esc_html( $it ) ?></span></li>
                <?php endforeach; ?>
            </ul>
        </div>

    </div>
</div>

<style>
#<?= esc_attr( $uid ) ?> .wf-cmp-title { font-weight:800; letter-spacing:-.02em; line-height:1.05; margin:0 0 40px; }
#<?= esc_attr( $uid ) ?> .wf-cmp-grid { display:grid; grid-template-columns:1fr 1fr; align-items:start; }
#<?= esc_attr( $uid ) ?> .wf-cmp-col { box-shadow:0 6px 30px rgba(0,0,0,.05); }
#<?= esc_attr( $uid ) ?> .wf-cmp-col--hl { box-shadow:0 12px 44px rgba(0,0,0,.10); }
#<?= esc_attr( $uid ) ?> .wf-cmp-head { display:flex; align-items:center; gap:10px; margin-bottom:22px; }
#<?= esc_attr( $uid ) ?> .wf-cmp-h { font-size:24px; font-weight:700; letter-spacing:-.01em; }
#<?= esc_attr( $uid ) ?> .wf-cmp-list { list-style:none; margin:0; padding:0; }
#<?= esc_attr( $uid ) ?> .wf-cmp-list li { display:flex; align-items:center; gap:12px; font-size:17px; line-height:1.4; padding:9px 0; }
#<?= esc_attr( $uid ) ?> .wf-cmp-ic { display:inline-flex; flex-shrink:0; }
<?php if ( $reveal ) : ?>
#<?= esc_attr( $uid ) ?> .wf-cmp-rev .wf-cmp-list li { opacity:0; transform:translateY(10px); transition:opacity .5s ease, transform .5s ease; }
#<?= esc_attr( $uid ) ?> .wf-cmp-rev.is-in .wf-cmp-list li { opacity:1; transform:none; }
@media (prefers-reduced-motion: reduce) { #<?= esc_attr( $uid ) ?> .wf-cmp-rev .wf-cmp-list li { opacity:1 !important; transform:none !important; } }
<?php endif; ?>
@media (max-width:768px) {
    #<?= esc_attr( $uid ) ?> .wf-cmp-grid { grid-template-columns:1fr; }
    #<?= esc_attr( $uid ) ?> .wf-cmp-title { font-size:<?= max( 30, (int) ( $t_size * 0.62 ) ) ?>px !important; margin-bottom:26px; }
}
</style>

<?php if ( $reveal ) : ?>
<script>
(function(){
    var id = <?= wp_json_encode( $uid ) ?>;
    function boot(){
        var root = document.getElementById(id); if (!root) return;
        var cols = root.querySelectorAll('.wf-cmp-rev');
        if ('IntersectionObserver' in window) {
            var obs = new IntersectionObserver(function(es){
                var i = 0; while (i < es.length) { if (es[i].isIntersecting) { es[i].target.classList.add('is-in'); obs.unobserve(es[i].target); } i++; }
            }, { threshold: 0.2 });
            var k = 0; while (k < cols.length) { obs.observe(cols[k]); k++; }
        } else {
            var j = 0; while (j < cols.length) { cols[j].classList.add('is-in'); j++; }
        }
    }
    if (window.WF) { if (WF.ready) { WF.ready(boot); return; } }
    if (document.readyState !== 'loading') { boot(); } else { document.addEventListener('DOMContentLoaded', boot); }
})();
</script>
<?php endif; ?>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
