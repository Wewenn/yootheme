<?php
defined('ABSPATH') || exit;
require_once __DIR__ . '/../../wf-motion-kit.php';
$p=wfmk_props('creative-cards',$props);
$uid=wf_uid('wfmk_', $props);
$wfmkEl=(isset($this) && method_exists($this,'el'))?$this->el('div'):null;
if($wfmkEl)echo $wfmkEl($props,$attrs??[]);
?>
<?php $cfg=['layout'=>wfmk_choice($p['layout'],['collage','scatter'],'collage'),'drag'=>!empty($p['drag'])];?>
<div id="<?=esc_attr($uid)?>" class="wfmk wfmk-cards<?=!empty($p['shadow'])?' has-shadow':''?>" data-wf-motion="cards" data-wf-config="<?=wfmk_json($cfg)?>" style="<?=wfmk_vars(['height'=>wfmk_n($p,'height',620,360,1200).'px','cw'=>wfmk_n($p,'card_width',410,180,620).'px','ch'=>wfmk_n($p,'card_height',360,180,700).'px','bg'=>wfmk_color($p['bg'])])?>">
 <div class="wfmk-cards__stage"><?php foreach($children??[] as $i=>$child)echo $builder->render($child,['element'=>$props,'index'=>$i]);?></div>
 <?php if($p['reset']):?><div class="wfmk-controls"><button type="button" data-action="reset">Recentrer les cartes</button></div><?php endif;?>
</div>

<?php if($wfmkEl)echo $wfmkEl->end(); ?>
