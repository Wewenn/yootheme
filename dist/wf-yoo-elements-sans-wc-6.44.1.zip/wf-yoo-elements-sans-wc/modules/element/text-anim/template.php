<?php
/**
 * WeFrame – Text Animé | template.php v1.0
 * 7 animations : fade-up | split-chars | split-words | blur-reveal | scramble | clip-reveal | typewriter
 * GSAP (free) pour tweens chainés. Scramble + typewriter = pure JS.
 * Trigger : IntersectionObserver (scroll) ou immédiat (load).
 */
defined( 'ABSPATH' ) || exit;

$headline   = $props['headline']   ?? '';
$hl_tag     = $props['headline_tag'] ?? 'h2';
$subtext    = $props['subtext']    ?? '';
$anim       = $props['animation']  ?? 'fade-up';
$trigger    = $props['trigger']    ?? 'scroll';
$delay_ms   = (int) ( $props['delay']    ?? 0 );
$dur_ms     = (int) ( $props['duration'] ?? 800 );
$stagger_ms = (int) ( $props['stagger']  ?? 40 );
$ease       = $props['ease']       ?? 'power3.out';
$replay     = ! empty( $props['replay'] );
$align      = $props['align']      ?? 'left';
$hl_color   = $props['headline_color']          ?? '#111111';
$hl_sz      = (int) ( $props['headline_size']         ?? 48 );
$hl_szm     = (int) ( $props['headline_size_mobile']  ?? 32 );
$hl_w       = $props['headline_weight']         ?? '700';
$hl_lh      = (float) ( $props['headline_line_height']    ?? 1.1 );
$hl_ls      = (float) ( $props['headline_letter_spacing'] ?? -0.02 );
$tx_color   = $props['subtext_color']           ?? '#555555';
$tx_sz      = (int) ( $props['subtext_size']        ?? 17 );
$tx_szm     = (int) ( $props['subtext_size_mobile'] ?? 15 );
$gap        = (int) ( $props['gap']       ?? 20 );
$mw         = (int) ( $props['max_width'] ?? 0 );

if ( ! $headline && ! $subtext ) {
    return;
}

// Validate tag
$allowed_tags = [ 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p' ];
if ( ! in_array( $hl_tag, $allowed_tags, true ) ) { $hl_tag = 'h2'; }

// GSAP needed for: fade-up, split-chars, split-words, blur-reveal, clip-reveal
$needs_gsap = in_array( $anim, [ 'fade-up', 'split-chars', 'split-words', 'split-lines', 'blur-reveal', 'clip-reveal' ], true );
if ( $needs_gsap ) { wp_enqueue_script( 'gsap' ); }

$uid      = wf_uid( 'wfta_', $props );
$dur_s    = round( $dur_ms / 1000, 3 );
$stag_s   = round( $stagger_ms / 1000, 4 );
$delay_s  = round( $delay_ms / 1000, 3 );
$ease_js  = esc_js( $ease );
$mw_css   = $mw > 0 ? 'max-width:' . $mw . 'px;' : '';

// Clip-reveal: wrap headline in overflow:hidden container
$clip_wrap_open  = $anim === 'clip-reveal' ? '<div class="wfta-clip" style="overflow:hidden;display:block;">' : '';
$clip_wrap_close = $anim === 'clip-reveal' ? '</div>' : '';

// -- Effets continus (style permanent, en plus de l'animation d'entree) --
$fx      = (string) ( $props['text_effect'] ?? 'none' );
$fxKnown = array( 'none', 'aurora', 'shiny', 'gradient', 'sparkles', 'line-shadow', 'neon', 'comic', 'outline', 'flip3d' );
if ( ! in_array( $fx, $fxKnown, true ) ) { $fx = 'none'; }
$fxC1  = (string) ( $props['effect_color_1'] ?? '#EA5C1C' );
$fxC2  = (string) ( $props['effect_color_2'] ?? '#7C3AED' );
$fxSpd = max( 1, (int) ( $props['effect_speed'] ?? 6 ) );
$fxCls = ( 'none' !== $fx ) ? ' wfta-fx wfta-fx--' . $fx : '';

// Subtext clip wrap
$clip_sub_open  = $anim === 'clip-reveal' ? '<div class="wfta-clip-sub" style="overflow:hidden;display:block;">' : '';
$clip_sub_close = $anim === 'clip-reveal' ? '</div>' : '';
?>

<?php $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( 'div' ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wfta-wrap<?= $fxCls ?>" style="text-align:<?= esc_attr( $align ) ?>;<?= $mw_css ?><?= $mw > 0 ? 'margin-left:auto;margin-right:auto;' : '' ?>">

    <?php if ( $headline ) : ?>
    <?= $clip_wrap_open ?>
    <<?= $hl_tag ?> class="wfta-headline" style="margin:0 0 <?= $gap ?>px;color:<?= esc_attr( $hl_color ) ?>;font-size:<?= $hl_sz ?>px;font-weight:<?= esc_attr( $hl_w ) ?>;line-height:<?= $hl_lh ?>;letter-spacing:<?= $hl_ls ?>em;"><?= esc_html( $headline ) ?></<?= $hl_tag ?>>
    <?= $clip_wrap_close ?>
    <?php endif; ?>

    <?php if ( $subtext ) : ?>
    <?= $clip_sub_open ?>
    <p class="wfta-subtext" style="margin:0;color:<?= esc_attr( $tx_color ) ?>;font-size:<?= $tx_sz ?>px;line-height:1.6;"><?= nl2br( esc_html( $subtext ) ) ?></p>
    <?= $clip_sub_close ?>
    <?php endif; ?>

</div>

<style>
@media (max-width:767px) {
    #<?= esc_attr( $uid ) ?> .wfta-headline { font-size:<?= $hl_szm ?>px !important; }
    #<?= esc_attr( $uid ) ?> .wfta-subtext  { font-size:<?= $tx_szm ?>px !important; }
}
/* Split spans */
#<?= esc_attr( $uid ) ?> .wfta-char,
#<?= esc_attr( $uid ) ?> .wfta-word { display:inline-block; }
#<?= esc_attr( $uid ) ?> .wfta-char--space { display:inline-block; width:0.28em; }
</style>

<script>
(function(){
    var ANIM    = <?= wp_json_encode( $anim ) ?>;
    var TRIGGER = <?= wp_json_encode( $trigger ) ?>;
    var DELAY   = <?= (float) $delay_s ?>;
    var DUR     = <?= (float) $dur_s ?>;
    var STAG    = <?= (float) $stag_s ?>;
    var EASE    = <?= wp_json_encode( $ease ) ?>;
    var REPLAY  = <?= $replay ? 'true' : 'false' ?>;

    /* ── Helpers ─────────────────────────────────────────── */
    function splitChars(el) {
        var text = el.textContent;
        el.innerHTML = '';
        var spans = [];
        for (var i = 0; i < text.length; i++) {
            var s = document.createElement('span');
            if (text[i] === ' ') {
                s.className = 'wfta-char wfta-char--space';
                s.textContent = ' ';
            } else {
                s.className = 'wfta-char';
                s.textContent = text[i];
            }
            el.appendChild(s);
            spans.push(s);
        }
        return spans;
    }

    function splitWords(el) {
        var words = el.textContent.split(/(\s+)/);
        el.innerHTML = '';
        var spans = [];
        words.forEach(function(w) {
            var s = document.createElement('span');
            if (/^\s+$/.test(w)) {
                s.innerHTML = '&nbsp;';
                s.className = 'wfta-word';
                s.style.width = '0.3em';
            } else {
                s.className = 'wfta-word';
                s.textContent = w;
            }
            el.appendChild(s);
            spans.push(s);
        });
        return spans.filter(function(s){ return !/^\s+$/.test(s.textContent); });
    }

    function splitLines(el) {
        var raw = el.textContent;
        el.innerHTML = '';
        var parts = raw.split(/(\s+)/);
        var wordSpans = [];
        parts.forEach(function(p) {
            if (p === '') { return; }
            var s = document.createElement('span');
            s.style.display = 'inline-block';
            if (/^\s+$/.test(p)) { s.innerHTML = '&nbsp;'; s.style.width = '0.28em'; }
            else { s.textContent = p; }
            el.appendChild(s);
            wordSpans.push(s);
        });
        // Group words by vertical position (line)
        var lines = [], cur = [], curTop = null;
        wordSpans.forEach(function(s) {
            var ot = s.offsetTop;
            if (curTop === null) { curTop = ot; }
            if (Math.abs(ot - curTop) > 2) { lines.push(cur); cur = []; curTop = ot; }
            cur.push(s);
        });
        if (cur.length) { lines.push(cur); }
        // Rewrap each line in an overflow-hidden mask
        el.innerHTML = '';
        var inners = [];
        lines.forEach(function(nodes) {
            var wrap = document.createElement('span');
            wrap.style.cssText = 'display:block;overflow:hidden;';
            var inner = document.createElement('span');
            inner.style.cssText = 'display:block;';
            nodes.forEach(function(n) { inner.appendChild(n); });
            wrap.appendChild(inner);
            el.appendChild(wrap);
            inners.push(inner);
        });
        return inners;
    }

    function wordFocus(root, els) {
        var words = [];
        els.forEach(function(el) {
            if (!el) { return; }
            splitWords(el).forEach(function(w) {
                w.style.transition = 'opacity .15s linear';
                w.style.opacity = '0.15';
                words.push(w);
            });
        });
        if (!words.length) { return; }
        var n = words.length;
        var ticking = false;
        function paint() {
            ticking = false;
            var rect = root.getBoundingClientRect();
            var vh = window.innerHeight || document.documentElement.clientHeight;
            var startY = vh * 0.85, endY = vh * 0.30;
            var prog = (startY - rect.top) / (startY - endY);
            if (prog < 0) { prog = 0; }
            if (prog > 1) { prog = 1; }
            var lead = prog * (n + 4);
            for (var i = 0; i < n; i++) {
                var v = lead - i;
                var o = v * 0.6 + 0.15;
                if (o < 0.15) { o = 0.15; }
                if (o > 1) { o = 1; }
                words[i].style.opacity = o.toFixed(3);
            }
        }
        function onScroll() { if (!ticking) { ticking = true; requestAnimationFrame(paint); } }
        window.addEventListener('scroll', onScroll, { passive: true });
        window.addEventListener('resize', onScroll, { passive: true });
        paint();
    }

    function scramble(el, finalText, totalMs, staggerMs) {
        var CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#%&?';
        var len = finalText.length;
        var resolved = 0;
        var resolveAt = [];
        // Each char resolves at a staggered time
        for (var i = 0; i < len; i++) {
            resolveAt[i] = i * staggerMs + Math.random() * staggerMs * 0.5;
        }
        var maxTime = resolveAt[len - 1] + totalMs * 0.4;
        var start = null;
        function frame(ts) {
            if (!start) start = ts;
            var elapsed = ts - start;
            var result = '';
            for (var j = 0; j < len; j++) {
                if (finalText[j] === ' ') { result += ' '; continue; }
                if (elapsed >= resolveAt[j]) {
                    result += finalText[j];
                } else {
                    result += CHARS[Math.floor(Math.random() * CHARS.length)];
                }
            }
            el.textContent = result;
            if (elapsed < maxTime) { requestAnimationFrame(frame); }
            else { el.textContent = finalText; }
        }
        requestAnimationFrame(frame);
    }

    function typewriter(el, finalText, staggerMs) {
        el.textContent = '';
        // Create cursor
        var cursor = document.createElement('span');
        cursor.textContent = '|';
        cursor.style.cssText = 'display:inline-block;animation:wf-blink 0.75s step-end infinite;margin-left:2px;opacity:1;';
        el.appendChild(cursor);
        var i = 0;
        function next() {
            if (i < finalText.length) {
                cursor.insertAdjacentText('beforebegin', finalText[i]);
                i++;
                setTimeout(next, staggerMs + Math.random() * staggerMs * 0.3);
            } else {
                // Remove cursor after 2s
                setTimeout(function(){ cursor.style.opacity = '0'; }, 2000);
            }
        }
        setTimeout(next, 120);
    }

    /* ── Main boot ───────────────────────────────────────── */
    WF.ready(function() {
        var root = document.getElementById(<?= wp_json_encode( $uid ) ?>);
        if (typeof WF !== 'undefined' && WF.reducedMotion && WF.reducedMotion()) { return; } // reduced-motion : texte affiché en état final
        if (!root) return;
        var hl  = root.querySelector('.wfta-headline');
        var sub = root.querySelector('.wfta-subtext');

        if (ANIM === 'word-focus') { wordFocus(root, [hl, sub]); return; }

        function run(fromScroll) {
            var delay = DELAY + (fromScroll ? 0 : 0);

            if (ANIM === 'fade-up') {
                if (typeof gsap === 'undefined') return;
                var tl = gsap.timeline({ delay: delay });
                if (hl)  tl.from(hl,  { opacity:0, y:36, duration:DUR, ease:EASE }, 0);
                if (sub) tl.from(sub, { opacity:0, y:24, duration:DUR, ease:EASE }, DUR * 0.35);

            } else if (ANIM === 'split-chars') {
                if (typeof gsap === 'undefined') return;
                var tl = gsap.timeline({ delay: delay });
                if (hl) {
                    var chars = splitChars(hl);
                    tl.from(chars, { opacity:0, y:40, rotateX:-60, duration:DUR, ease:EASE, stagger:STAG }, 0);
                }
                if (sub) tl.from(sub, { opacity:0, duration:DUR * 0.8, ease:'power2.out' }, DUR * 0.5);

            } else if (ANIM === 'split-words') {
                if (typeof gsap === 'undefined') return;
                var tl = gsap.timeline({ delay: delay });
                if (hl) {
                    var words = splitWords(hl);
                    tl.from(words, { opacity:0, y:28, duration:DUR, ease:EASE, stagger:STAG }, 0);
                }
                if (sub) {
                    var subwords = splitWords(sub);
                    tl.from(subwords, { opacity:0, y:18, duration:DUR * 0.7, ease:EASE, stagger:STAG * 0.6 }, DUR * 0.4);
                }

            } else if (ANIM === 'split-lines') {
                if (typeof gsap === 'undefined') return;
                var tl = gsap.timeline({ delay: delay });
                if (hl) {
                    var hlLines = splitLines(hl);
                    tl.from(hlLines, { yPercent:120, duration:DUR, ease:EASE, stagger:STAG }, 0);
                }
                if (sub) {
                    var subLines = splitLines(sub);
                    tl.from(subLines, { yPercent:120, duration:DUR * 0.8, ease:EASE, stagger:STAG * 0.8 }, DUR * 0.3);
                }

            } else if (ANIM === 'blur-reveal') {
                if (typeof gsap === 'undefined') return;
                var tl = gsap.timeline({ delay: delay });
                if (hl)  tl.from(hl,  { filter:'blur(14px)', opacity:0, y:16, duration:DUR, ease:EASE }, 0);
                if (sub) tl.from(sub, { filter:'blur(8px)',  opacity:0, y:10, duration:DUR * 0.75, ease:EASE }, DUR * 0.3);

            } else if (ANIM === 'scramble') {
                var d = delay * 1000;
                if (hl) {
                    var hlText = hl.textContent;
                    hl.style.opacity = '0';
                    setTimeout(function(){
                        hl.style.opacity = '1';
                        scramble(hl, hlText, DUR * 1000, STAG * 1000);
                    }, d);
                }
                if (sub) {
                    var subText = sub.textContent;
                    sub.style.opacity = '0';
                    setTimeout(function(){
                        sub.style.opacity = '1';
                        scramble(sub, subText, DUR * 800, STAG * 600);
                    }, d + DUR * 400);
                }

            } else if (ANIM === 'clip-reveal') {
                if (typeof gsap === 'undefined') return;
                var tl = gsap.timeline({ delay: delay });
                if (hl) {
                    tl.from(hl,  { yPercent:110, duration:DUR, ease:EASE }, 0);
                }
                if (sub) {
                    tl.from(sub, { yPercent:110, duration:DUR * 0.75, ease:EASE }, DUR * 0.25);
                }

            } else if (ANIM === 'typewriter') {
                var d = delay * 1000;
                if (hl) {
                    var hlText2 = hl.textContent;
                    hl.textContent = '';
                    setTimeout(function(){ typewriter(hl, hlText2, STAG * 1000); }, d);
                }
                if (sub) {
                    var subText2 = sub.textContent;
                    var hlLen = hl ? hlText2.length * STAG * 1000 : 0;
                    sub.style.opacity = '0';
                    setTimeout(function(){
                        sub.style.opacity = '1';
                        typewriter(sub, subText2, Math.max(12, STAG * 600));
                    }, d + hlLen + 300);
                }
            }
        }

        if (TRIGGER === 'load') {
            run(false);
        } else {
            // Scroll trigger via IntersectionObserver
            if (REPLAY) {
                // Re-trigger every time element enters viewport
                var obs = new IntersectionObserver(function(entries) {
                    entries.forEach(function(e) {
                        if (e.isIntersecting) { run(true); }
                    });
                }, { threshold: 0.15 });
                obs.observe(root);
            } else {
                WF.onVisible(root, function() { run(true); }, 0.15);
            }
        }
    });
})();
</script>

<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<?php if ( 'none' !== $fx ) : ?>
<style>
/* La couleur du titre est posee en style inline : il faut !important pour
   passer devant, c'est la seule facon. */
#<?= esc_attr( $uid ) ?>.wfta-fx .wfta-headline{position:relative;display:inline-block;}
<?php if ( 'aurora' === $fx ) : ?>
#<?= esc_attr( $uid ) ?>.wfta-fx--aurora .wfta-headline{
	background:linear-gradient(100deg,<?= esc_attr( $fxC1 ) ?>,<?= esc_attr( $fxC2 ) ?>,#22d3ee,<?= esc_attr( $fxC1 ) ?>);
	background-size:300% 100%;
	-webkit-background-clip:text;background-clip:text;
	color:transparent !important;
	animation:<?= esc_attr( $uid ) ?>-fx <?= (int) $fxSpd ?>s linear infinite;
}
@keyframes <?= esc_attr( $uid ) ?>-fx{from{background-position:0% 0}to{background-position:300% 0}}
<?php elseif ( 'gradient' === $fx ) : ?>
#<?= esc_attr( $uid ) ?>.wfta-fx--gradient .wfta-headline{
	background:linear-gradient(90deg,<?= esc_attr( $fxC1 ) ?>,<?= esc_attr( $fxC2 ) ?>,<?= esc_attr( $fxC1 ) ?>);
	background-size:200% 100%;
	-webkit-background-clip:text;background-clip:text;
	color:transparent !important;
	animation:<?= esc_attr( $uid ) ?>-fx <?= (int) $fxSpd ?>s linear infinite;
}
@keyframes <?= esc_attr( $uid ) ?>-fx{from{background-position:0% 0}to{background-position:200% 0}}
<?php elseif ( 'shiny' === $fx ) : ?>
#<?= esc_attr( $uid ) ?>.wfta-fx--shiny .wfta-headline{
	background:linear-gradient(110deg,currentColor 0 42%,<?= esc_attr( $fxC1 ) ?> 50%,currentColor 58% 100%);
	background-size:220% 100%;
	-webkit-background-clip:text;background-clip:text;
	color:transparent !important;
	animation:<?= esc_attr( $uid ) ?>-fx <?= (int) $fxSpd ?>s linear infinite;
}
@keyframes <?= esc_attr( $uid ) ?>-fx{from{background-position:220% 0}to{background-position:-20% 0}}
<?php elseif ( 'sparkles' === $fx ) : ?>
#<?= esc_attr( $uid ) ?>.wfta-fx--sparkles .wfta-headline::before,
#<?= esc_attr( $uid ) ?>.wfta-fx--sparkles .wfta-headline::after{
	content:"";position:absolute;width:3px;height:3px;border-radius:50%;
	background:<?= esc_attr( $fxC1 ) ?>;
	box-shadow:
		1.2em -0.4em 0 0 <?= esc_attr( $fxC2 ) ?>, 3.4em 0.5em 0 0 <?= esc_attr( $fxC1 ) ?>,
		5.8em -0.7em 0 0 <?= esc_attr( $fxC2 ) ?>, 7.9em 0.3em 0 0 <?= esc_attr( $fxC1 ) ?>,
		9.6em -0.5em 0 0 <?= esc_attr( $fxC2 ) ?>;
	top:.2em;left:-.3em;pointer-events:none;
	animation:<?= esc_attr( $uid ) ?>-fx <?= (int) $fxSpd ?>s ease-in-out infinite;
}
#<?= esc_attr( $uid ) ?>.wfta-fx--sparkles .wfta-headline::after{
	top:.8em;left:.6em;animation-delay:-<?= (int) round( $fxSpd / 2 ) ?>s;
}
@keyframes <?= esc_attr( $uid ) ?>-fx{
	0%,100%{opacity:0;transform:scale(.4)}
	40%{opacity:1;transform:scale(1)}
	70%{opacity:.2;transform:scale(.7)}
}
<?php elseif ( 'line-shadow' === $fx ) : ?>
#<?= esc_attr( $uid ) ?>.wfta-fx--line-shadow .wfta-headline{
	animation:<?= esc_attr( $uid ) ?>-fx <?= (int) $fxSpd ?>s ease-in-out infinite alternate;
}
@keyframes <?= esc_attr( $uid ) ?>-fx{
	from{text-shadow:1px 1px <?= esc_attr( $fxC1 ) ?>,2px 2px <?= esc_attr( $fxC1 ) ?>,3px 3px <?= esc_attr( $fxC1 ) ?>;}
	to{text-shadow:2px 2px <?= esc_attr( $fxC2 ) ?>,4px 4px <?= esc_attr( $fxC2 ) ?>,6px 6px <?= esc_attr( $fxC2 ) ?>,8px 8px <?= esc_attr( $fxC2 ) ?>;}
}
<?php elseif ( 'neon' === $fx ) : ?>
#<?= esc_attr( $uid ) ?>.wfta-fx--neon .wfta-headline{
	color:<?= esc_attr( $fxC1 ) ?> !important;
	animation:<?= esc_attr( $uid ) ?>-fx <?= (int) $fxSpd ?>s ease-in-out infinite alternate;
}
@keyframes <?= esc_attr( $uid ) ?>-fx{
	from{text-shadow:0 0 4px <?= esc_attr( $fxC1 ) ?>;}
	to{text-shadow:0 0 10px <?= esc_attr( $fxC1 ) ?>,0 0 28px <?= esc_attr( $fxC2 ) ?>,0 0 48px <?= esc_attr( $fxC2 ) ?>;}
}
<?php elseif ( 'comic' === $fx ) : ?>
#<?= esc_attr( $uid ) ?>.wfta-fx--comic .wfta-headline{
	-webkit-text-stroke:2px <?= esc_attr( $fxC2 ) ?>;
	text-shadow:4px 4px 0 <?= esc_attr( $fxC1 ) ?>;
	paint-order:stroke fill;
}
<?php elseif ( 'outline' === $fx ) : ?>
#<?= esc_attr( $uid ) ?>.wfta-fx--outline .wfta-headline{
	-webkit-text-stroke:2px <?= esc_attr( $fxC1 ) ?>;
	color:transparent !important;
}
<?php else : ?>
#<?= esc_attr( $uid ) ?>.wfta-fx--flip3d .wfta-headline{
	transform-style:preserve-3d;transition:transform .6s cubic-bezier(.2,.8,.2,1);
}
#<?= esc_attr( $uid ) ?>.wfta-fx--flip3d:hover .wfta-headline{transform:perspective(600px) rotateX(-14deg) rotateY(8deg);}
<?php endif; ?>
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?>.wfta-fx .wfta-headline{animation:none !important;transition:none;}
}
</style>
<?php endif; ?>
