<?php
/**
 * WeFrame – Testimonial Marquee | template.php v1.0
 */
defined( 'ABSPATH' ) || exit;

$items_raw = $props['items'] ?? '';
$two_rows  = ! empty( $props['two_rows'] );
$speed     = max( 5, (int) ( $props['speed'] ?? 40 ) );
$pause     = ! empty( $props['pause_hover'] );
$fade      = ! empty( $props['fade_edges'] );
$cw        = (int) ( $props['card_width'] ?? 340 );
$cbg       = $props['card_bg'] ?? '#ffffff';
$cbd       = $props['card_border'] ?? '#EEEEEE';
$crad      = (int) ( $props['card_radius'] ?? 12 );
$cpad      = (int) ( $props['card_padding'] ?? 18 );
$gap       = (int) ( $props['gap'] ?? 16 );
$tc        = $props['text_color'] ?? '#111111';
$rc        = $props['role_color'] ?? '#6B7280';
$sc        = $props['star_color'] ?? '#F59E0B';
$bg        = $props['bg_color'] ?? '#FAFAFA';

$items = [];
foreach ( preg_split( "/\r?\n/", trim( $items_raw ) ) as $line ) {
    $line = trim( $line );
    if ( ! $line ) continue;
    $parts = array_map( 'trim', explode( '||', $line ) );
    $items[] = [
        'text'    => $parts[0] ?? '',
        'rating'  => (int) ( $parts[1] ?? 5 ),
        'author'  => $parts[2] ?? '',
        'company' => $parts[3] ?? '',
        'logo'    => $parts[4] ?? '',
    ];
}
if ( empty( $items ) ) return;

$uid = wf_uid( 'wftm_', $props );

// Split rows
if ( $two_rows && count( $items ) > 2 ) {
    $half = ceil( count( $items ) / 2 );
    $rows = [ array_slice( $items, 0, $half ), array_slice( $items, $half ) ];
} else {
    $rows = [ $items ];
}

$render_card = function( $it ) use ( $cw, $cbg, $cbd, $crad, $cpad, $tc, $rc, $sc ) {
    ob_start(); ?>
    <div class="wf-tm-card" style="flex-shrink:0;width:<?= $cw ?>px;background:<?= esc_attr( $cbg ) ?>;border:1px solid <?= esc_attr( $cbd ) ?>;border-radius:<?= $crad ?>px;padding:<?= $cpad ?>px;display:flex;flex-direction:column;gap:10px;">
        <?php if ( $it['rating'] > 0 ) : ?>
        <div style="display:flex;gap:2px;color:<?= esc_attr( $sc ) ?>;">
            <?php for ( $i = 1; $i <= 5; $i++ ) : ?>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="<?= $i <= $it['rating'] ? 'currentColor' : 'none' ?>" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
            <?php endfor; ?>
        </div>
        <?php endif; ?>
        <div style="font-size:14px;line-height:1.5;color:<?= esc_attr( $tc ) ?>;"><?= esc_html( $it['text'] ) ?></div>
        <?php if ( $it['author'] || $it['company'] ) : ?>
        <div style="display:flex;align-items:center;gap:10px;margin-top:4px;">
            <?php if ( $it['logo'] ) : ?>
            <img src="<?= esc_url( $it['logo'] ) ?>" alt="" style="width:28px;height:28px;border-radius:50%;object-fit:contain;background:#fff;border:1px solid <?= esc_attr( $cbd ) ?>;padding:3px;flex-shrink:0;" loading="lazy">
            <?php endif; ?>
            <div style="line-height:1.3;font-size:12px;">
                <?php if ( $it['author'] ) : ?><div style="font-weight:700;color:<?= esc_attr( $tc ) ?>;"><?= esc_html( $it['author'] ) ?></div><?php endif; ?>
                <?php if ( $it['company'] ) : ?><div style="color:<?= esc_attr( $rc ) ?>;"><?= esc_html( $it['company'] ) ?></div><?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <?php return ob_get_clean();
};
?>
<?php $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( 'div' ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<section id="<?= esc_attr( $uid ) ?>" class="wf-tm-wrap" style="background:<?= esc_attr( $bg ) ?>;padding:32px 0;overflow:hidden;<?= $fade ? 'mask-image:linear-gradient(90deg,transparent,#000 8%,#000 92%,transparent);-webkit-mask-image:linear-gradient(90deg,transparent,#000 8%,#000 92%,transparent);' : '' ?>">
<?php foreach ( $rows as $r => $row ) :
    $dir = ( $r % 2 === 1 ) ? 'reverse' : 'normal';
?>
    <div class="wf-tm-row" style="display:flex;gap:<?= $gap ?>px;margin-bottom:<?= $r < count( $rows ) - 1 ? $gap : 0 ?>px;width:max-content;animation: wf-tm-scroll-<?= esc_attr( $uid ) ?> <?= $speed ?>s linear infinite; animation-direction:<?= $dir ?>;">
        <?php foreach ( $row as $it ) echo $render_card( $it ); ?>
        <?php foreach ( $row as $it ) echo $render_card( $it ); // duplicate for seamless loop ?>
    </div>
<?php endforeach; ?>
</section>
<style>
@keyframes wf-tm-scroll-<?= esc_attr( $uid ) ?> { from { transform:translateX(0); } to { transform:translateX(-50%); } }
<?php if ( $pause ) : ?>
#<?= esc_attr( $uid ) ?>:hover .wf-tm-row { animation-play-state:paused; }
<?php endif; ?>
@media (prefers-reduced-motion: reduce) { #<?= esc_attr( $uid ) ?> .wf-tm-row { animation:none !important; } }
</style>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
