<?php
/**
 * WeFrame – Grille qui s'assemble (parent) | les cases (items) volent en place au scroll.
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }
$cols = (int) ( $props['columns'] ?? 3 );
$cols = in_array( $cols, array( 2, 3, 4 ), true ) ? $cols : 3;
$gap  = max( 0, (int) ( $props['gap'] ?? 14 ) );
$rad  = max( 0, (int) ( $props['radius'] ?? 14 ) );
$h    = max( 100, (int) ( $props['height'] ?? 220 ) );

$html = '';
foreach ( $children as $child ) { $html .= $builder->render( $child, array( 'element' => $props ) ); }
if ( ! trim( $html ) ) { return; }
$uid = wf_uid( 'wfag_', $props, count( $children ) );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-ag" style="display:grid;grid-template-columns:repeat(<?= $cols ?>,1fr);gap:<?= $gap ?>px;"><?= $html ?></div>
<style>
#<?= esc_attr( $uid ) ?> .wf-ag-i{height:<?= $h ?>px;border-radius:<?= $rad ?>px;overflow:hidden;opacity:0;transform:translateY(34px) scale(.92);transition:opacity .7s cubic-bezier(.16,1,.3,1),transform .7s cubic-bezier(.16,1,.3,1);will-change:opacity,transform;}
#<?= esc_attr( $uid ) ?> .wf-ag-i:nth-child(2n){transform:translate(26px,34px) rotate(3deg) scale(.92);}
#<?= esc_attr( $uid ) ?> .wf-ag-i:nth-child(3n){transform:translate(-26px,34px) rotate(-4deg) scale(.92);}
#<?= esc_attr( $uid ) ?> .wf-ag-i.on{opacity:1 !important;transform:none !important;}
@media(max-width:600px){ #<?= esc_attr( $uid ) ?>{grid-template-columns:repeat(2,1fr) !important;} }
</style>
<script>
(function(){
    var el = document.getElementById('<?= esc_js( $uid ) ?>'); if (!el) return;
    var items = el.querySelectorAll('.wf-ag-i');
    function show(){ for (var i = 0; i < items.length; i++){ (function(x,d){ setTimeout(function(){ x.classList.add('on'); }, d); })(items[i], i * 70); } }
    if (window.matchMedia) if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { for (var k = 0; k < items.length; k++) items[k].classList.add('on'); return; }
    if (!window.IntersectionObserver) { show(); return; }
    var io = new IntersectionObserver(function(ents){ for (var i = 0; i < ents.length; i++){ if (ents[i].isIntersecting) { show(); io.disconnect(); } } }, { threshold: 0.2 });
    io.observe(el);
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
