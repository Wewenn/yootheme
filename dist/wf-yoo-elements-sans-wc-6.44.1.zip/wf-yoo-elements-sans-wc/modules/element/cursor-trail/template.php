<?php
/**
 * WeFrame – Traînée d'images au curseur | template.php v1.0
 * Les images naissent le long du parcours du curseur, tous les X pixels, puis
 * s'effacent. Effet purement decoratif : les images sont aria-hidden, la zone
 * reste lisible sans souris, et rien ne se declenche si le visiteur a demande
 * moins d'animations ou n'a qu'un ecran tactile.
 * Pas de "&&" ni de "||" dans le JS inline (regle interne du plugin).
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$title = trim( (string) ( $props['title'] ?? '' ) );
$sub   = trim( (string) ( $props['subtitle'] ?? '' ) );

$h      = max( 200, (int) ( $props['height'] ?? 460 ) );
$spawn  = max( 20, (int) ( $props['spawn_distance'] ?? 80 ) );
$trail  = max( 2, min( 20, (int) ( $props['trail_length'] ?? 8 ) ) );
$size   = max( 40, (int) ( $props['image_size'] ?? 120 ) );
$ratio  = (string) ( $props['image_ratio'] ?? '1-1' );
$rot    = max( 0, min( 60, (int) ( $props['rotation'] ?? 20 ) ) );
$fade   = max( 150, (int) ( $props['fade'] ?? 700 ) );
$shrink = max( 0.2, min( 1, (float) ( $props['shrink'] ?? 0.6 ) ) );
$rad    = max( 0, (int) ( $props['radius'] ?? 10 ) );

$bg     = (string) ( $props['bg'] ?? '#0e0e11' );
$txt    = (string) ( $props['text_color'] ?? '#ffffff' );
$tSize  = max( 16, (int) ( $props['title_size'] ?? 44 ) );
$sSize  = max( 11, (int) ( $props['sub_size'] ?? 16 ) );
$hideC  = ! empty( $props['hide_cursor'] );
$shadow = ! empty( $props['shadow'] );

$ratios = array( '1-1' => '1 / 1', '3-4' => '3 / 4', '4-3' => '4 / 3', '16-9' => '16 / 9' );
$ar = $ratios[ $ratio ] ?? '1 / 1';

$imgs = array();
foreach ( $children as $child ) {
	$cp  = (array) ( $child->props ?? array() );
	$src = $cp['image'] ?? '';
	if ( is_array( $src ) ) { $src = $src['src'] ?? ( $src['url'] ?? '' ); }
	$src = trim( (string) $src );
	if ( '' !== $src ) { $imgs[] = $src; }
}
if ( empty( $imgs ) ) { return; }

$uid = wf_uid( 'wfct_', $props, count( $imgs ) );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-ct<?= $hideC ? ' wf-ct--nocursor' : '' ?>">
	<div class="__layer" aria-hidden="true">
		<?php foreach ( $imgs as $i => $src ) : ?>
		<img class="__img" src="<?= esc_url( $src ) ?>" alt="" loading="lazy" decoding="async" data-i="<?= (int) $i ?>">
		<?php endforeach; ?>
	</div>
	<div class="__content">
		<?php if ( '' !== $title ) : ?><p class="__title"><?= esc_html( $title ) ?></p><?php endif; ?>
		<?php if ( '' !== $sub ) : ?><p class="__sub"><?= nl2br( esc_html( $sub ) ) ?></p><?php endif; ?>
	</div>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?>{
	position:relative;overflow:hidden;isolation:isolate;
	min-height:<?= (int) $h ?>px;background:<?= esc_attr( $bg ) ?>;color:<?= esc_attr( $txt ) ?>;
	display:flex;align-items:center;justify-content:center;text-align:center;
	container-type:inline-size;
}
#<?= esc_attr( $uid ) ?>.wf-ct--nocursor{cursor:none;}
#<?= esc_attr( $uid ) ?> .__layer{position:absolute;inset:0;z-index:0;pointer-events:none;}
#<?= esc_attr( $uid ) ?> .__img{
	position:absolute;top:0;left:0;
	width:<?= (int) $size ?>px;aspect-ratio:<?= esc_attr( $ar ) ?>;object-fit:cover;
	border-radius:<?= (int) $rad ?>px;
	<?= $shadow ? 'box-shadow:0 18px 40px rgba(0,0,0,.35);' : '' ?>
	opacity:0;will-change:transform,opacity;
	transform:translate(-50%,-50%) scale(<?= esc_attr( $shrink ) ?>);
	transition:opacity <?= (int) $fade ?>ms ease,transform <?= (int) $fade ?>ms cubic-bezier(.2,.8,.2,1);
}
#<?= esc_attr( $uid ) ?> .__img.is-live{opacity:1;}
#<?= esc_attr( $uid ) ?> .__content{position:relative;z-index:1;padding:32px;max-width:36em;pointer-events:none;}
#<?= esc_attr( $uid ) ?> .__title{
	margin:0;font-size:clamp(<?= (int) max( 18, round( $tSize * .55 ) ) ?>px, 7cqw, <?= (int) $tSize ?>px);
	font-weight:700;line-height:1.1;
}
#<?= esc_attr( $uid ) ?> .__sub{margin:.6em 0 0;font-size:<?= (int) $sSize ?>px;line-height:1.6;opacity:.8;}
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?> .__img{display:none;}
	#<?= esc_attr( $uid ) ?>.wf-ct--nocursor{cursor:auto;}
}
</style>

<script>
(function(){
	var root = document.getElementById('<?= esc_js( $uid ) ?>');
	if (!root) { return; }
	var imgs = [].slice.call(root.querySelectorAll('.__img'));
	if (!imgs.length) { return; }

	// Effet decoratif : on s'abstient si le visiteur veut moins d'animations,
	// ou s'il n'y a pas de vrai pointeur (l'effet n'aurait aucun sens au doigt).
	if (window.matchMedia) {
		if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { return; }
		if (!window.matchMedia('(hover: hover)').matches) { return; }
	}

	var spawn = <?= (int) $spawn ?>;
	var trail = <?= (int) $trail ?>;
	var rot = <?= (int) $rot ?>;
	var shrink = <?= esc_js( (string) $shrink ) ?>;
	var fade = <?= (int) $fade ?>;

	var lastX = null, lastY = null;
	var next = 0;
	var live = [];

	function place(x, y){
		var el = imgs[next % imgs.length];
		next++;
		var a = (Math.random() * 2 - 1) * rot;
		el.style.transform = 'translate(-50%,-50%) translate(' + x + 'px,' + y + 'px) rotate(' + a.toFixed(1) + 'deg) scale(1)';
		el.classList.add('is-live');
		el.style.zIndex = String(next);

		var i = live.indexOf(el);
		if (i > -1) { live.splice(i, 1); }
		live.push(el);

		while (live.length > trail) {
			retire(live.shift());
		}
	}

	function retire(el){
		if (!el) { return; }
		el.classList.remove('is-live');
		var t = el.style.transform;
		// on garde la position, on ne change que l'echelle : l'image s'efface sur place
		el.style.transform = t.replace(/scale\([^)]*\)/, 'scale(' + shrink + ')');
	}

	root.addEventListener('pointermove', function(e){
		if (e.pointerType === 'touch') { return; }
		var r = root.getBoundingClientRect();
		var x = e.clientX - r.left;
		var y = e.clientY - r.top;
		if (lastX === null) { lastX = x; lastY = y; place(x, y); return; }
		var dx = x - lastX;
		var dy = y - lastY;
		if (Math.sqrt(dx * dx + dy * dy) < spawn) { return; }
		lastX = x; lastY = y;
		place(x, y);
	});

	root.addEventListener('pointerleave', function(){
		lastX = null; lastY = null;
		while (live.length) { retire(live.shift()); }
	});
})();
</script>
