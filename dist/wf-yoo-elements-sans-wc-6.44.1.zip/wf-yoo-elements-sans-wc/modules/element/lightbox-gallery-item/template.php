<?php
// Rendered by parent lightbox-gallery.
defined( 'ABSPATH' ) || exit;
