<?php
/**
 * WeFrame – Custom Cursor | template.php
 * A dot that tracks the cursor + a trailing ring that eases behind it.
 * Placed once per page. Disabled on touch devices.
 * Config inlined (no <script type="application/json">), no "&&" in inline JS.
 */
defined( 'ABSPATH' ) || exit;

$props = is_array( $props ?? null ) ? $props : array();

$dot_sz  = min( 24, max( 0, (int) ( $props['dot_size'] ?? 8 ) ) );
$dot_col = (string) ( $props['dot_color'] ?? '#111111' );
$ring_sz = min( 80, max( 16, (int) ( $props['ring_size'] ?? 38 ) ) );
$ring_col= (string) ( $props['ring_color'] ?? '#111111' );
$ring_st = ( ( $props['ring_style'] ?? 'outline' ) === 'filled' ) ? 'filled' : 'outline';
$follow  = min( 40, max( 5, (int) ( $props['follow'] ?? 16 ) ) ) / 100;
$blend   = (string) ( $props['blend_mode'] ?? 'none' );
$hide    = ! empty( $props['hide_default'] );
$grow    = ! empty( $props['grow_on_links'] );
$grow_sc = min( 300, max( 120, (int) ( $props['grow_scale'] ?? 180 ) ) ) / 100;

$allowed_blend = array( 'none', 'difference', 'exclusion' );
if ( ! in_array( $blend, $allowed_blend, true ) ) { $blend = 'none'; }

$uid = wf_uid( 'wfcur_', $props );

$ring_bg  = ( 'filled' === $ring_st ) ? esc_attr( $ring_col ) : 'transparent';
$ring_brd = ( 'filled' === $ring_st ) ? 'none' : '2px solid ' . esc_attr( $ring_col );
$blend_css = ( 'none' !== $blend ) ? 'mix-blend-mode:' . $blend . ';' : '';

$cfg = wp_json_encode( array(
    'uid'    => $uid,
    'ease'   => $follow,
    'grow'   => $grow ? 1 : 0,
    'growSc' => $grow_sc,
    'hide'   => $hide ? 1 : 0,
), JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-cur" aria-hidden="true" style="position:fixed;top:0;left:0;z-index:2147483000;pointer-events:none;<?= $blend_css ?>opacity:0;transition:opacity .3s ease;">
    <?php if ( $dot_sz > 0 ) : ?>
    <div class="wf-cur-dot" style="position:fixed;top:0;left:0;width:<?= $dot_sz ?>px;height:<?= $dot_sz ?>px;border-radius:50%;background:<?= esc_attr( $dot_col ) ?>;transform:translate(-50%,-50%);will-change:transform;"></div>
    <?php endif; ?>
    <div class="wf-cur-ring" style="position:fixed;top:0;left:0;width:<?= $ring_sz ?>px;height:<?= $ring_sz ?>px;border-radius:50%;background:<?= $ring_bg ?>;border:<?= $ring_brd ?>;transform:translate(-50%,-50%);will-change:transform;transition:width .25s ease,height .25s ease,background .25s ease;"></div>
</div>

<script>
(function(){
    var C = <?= $cfg ?>;
    function boot(){
        var wrap = document.getElementById(C.uid); if (!wrap) return;

        // Disable on touch / no-hover devices
        var noHover = false;
        try { noHover = window.matchMedia('(hover: none)').matches; } catch(e) {}
        if (noHover) { wrap.parentNode.removeChild(wrap); return; }

        var dot = wrap.querySelector('.wf-cur-dot');
        var ring = wrap.querySelector('.wf-cur-ring');
        if (!ring) { return; }

        if (C.hide) {
            var st = document.createElement('style');
            st.textContent = '*{cursor:none !important;}';
            document.head.appendChild(st);
        }

        var mx = window.innerWidth / 2, my = window.innerHeight / 2;
        var rx = mx, ry = my;
        var visible = false;

        function onMove(e){
            mx = e.clientX; my = e.clientY;
            if (dot) { dot.style.transform = 'translate(' + mx + 'px,' + my + 'px) translate(-50%,-50%)'; }
            if (!visible) { visible = true; wrap.style.opacity = '1'; }
        }
        document.addEventListener('mousemove', onMove, { passive: true });
        document.addEventListener('mouseleave', function(){ wrap.style.opacity = '0'; visible = false; });

        function loop(){
            rx += (mx - rx) * C.ease;
            ry += (my - ry) * C.ease;
            ring.style.transform = 'translate(' + rx.toFixed(1) + 'px,' + ry.toFixed(1) + 'px) translate(-50%,-50%)';
            requestAnimationFrame(loop);
        }
        requestAnimationFrame(loop);

        if (C.grow) {
            var sel = 'a, button, [role="button"], input, textarea, select, label, .wf-mag';
            var base = <?= $ring_sz ?>;
            var big = Math.round(base * C.growSc);
            document.addEventListener('mouseover', function(e){
                var t = e.target;
                if (t) { if (t.closest) { if (t.closest(sel)) { ring.style.width = big + 'px'; ring.style.height = big + 'px'; } } }
            }, { passive: true });
            document.addEventListener('mouseout', function(e){
                var t = e.target;
                if (t) { if (t.closest) { if (t.closest(sel)) { ring.style.width = base + 'px'; ring.style.height = base + 'px'; } } }
            }, { passive: true });
        }
    }
    if (window.WF) { if (WF.ready) { WF.ready(boot); return; } }
    if (document.readyState !== 'loading') { boot(); } else { document.addEventListener('DOMContentLoaded', boot); }
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
