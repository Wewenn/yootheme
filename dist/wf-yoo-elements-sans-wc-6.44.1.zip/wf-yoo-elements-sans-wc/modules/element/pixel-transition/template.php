<?php
/**
 * WeFrame – Transition pixels au scroll | template.php v1.0
 * Le contenu depose est recouvert d'une grille de pixels qui s'efface au
 * defilement, du centre vers les bords ou dans le sens choisi.
 *
 * Le voile est un <canvas> pose par le script : sans JS il n'existe pas et le
 * contenu s'affiche normalement. Idem si le visiteur demande moins d'animations.
 * Un canvas plutot que des milliers de <div> : au-dela de ~1 500 cellules,
 * le DOM ne suit plus.
 * Pas de "&&" ni de "||" dans le JS inline (regle interne du plugin).
 */
defined( 'ABSPATH' ) || exit;

$mode = ( 'inline' === ( $props['mode'] ?? 'sticky' ) ) ? 'inline' : 'sticky';
$dist = max( 100, min( 500, (int) ( $props['distance'] ?? 200 ) ) );
$top  = max( 0, (int) ( $props['stick_top'] ?? 0 ) );
$h    = max( 200, (int) ( $props['height'] ?? 520 ) );

$cell = max( 6, (int) ( $props['cell'] ?? 24 ) );
$gap  = max( 0, min( 12, (int) ( $props['gap'] ?? 0 ) ) );
$dir  = (string) ( $props['direction'] ?? 'center-out' );
if ( ! in_array( $dir, array( 'center-out', 'center-in', 'top', 'bottom', 'left', 'right' ), true ) ) { $dir = 'center-out'; }
$pat  = (string) ( $props['pattern'] ?? 'random' );
if ( ! in_array( $pat, array( 'random', 'checker', 'diagonal', 'wave', 'spiral', 'radial' ), true ) ) { $pat = 'random'; }
$inten = max( 0, min( 1, (float) ( $props['intensity'] ?? 0.5 ) ) );
$endAt = max( 40, min( 100, (int) ( $props['end_at'] ?? 85 ) ) ) / 100;
$rev   = ! empty( $props['reverse'] );

$cover = (string) ( $props['cover_color'] ?? '#0b0b10' );
$a1    = (string) ( $props['accent_1'] ?? '#EA5C1C' );
$a2    = (string) ( $props['accent_2'] ?? '#7C3AED' );
$share = max( 0, min( 60, (int) ( $props['accent_share'] ?? 15 ) ) ) / 100;
$rad   = max( 0, (int) ( $props['radius'] ?? 0 ) );

$inner = '';
if ( ! empty( $children ) ) {
	foreach ( $children as $ci => $child ) {
		$inner .= $builder->render( $child, array( 'element' => $props, 'index' => $ci ) );
	}
}
if ( '' === trim( $inner ) ) { return; }

$uid = wf_uid( 'wfpx_', $props );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<?php if ( 'sticky' === $mode ) : ?>
<div class="wf-px-track" id="<?= esc_attr( $uid ) ?>-track">
<div class="wf-px-pin">
<?php endif; ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-px wf-px--<?= esc_attr( $mode ) ?>">
	<div class="__stage"><?= $inner ?></div>
</div>

<?php if ( 'sticky' === $mode ) : ?>
</div>
</div>
<?php endif; ?>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?>{
	position:relative;overflow:hidden;
	border-radius:<?= (int) $rad ?>px;
<?php if ( 'inline' === $mode ) : ?>
	min-height:<?= (int) $h ?>px;
<?php else : ?>
	min-height:calc(100vh - <?= (int) $top ?>px);
<?php endif; ?>
	display:flex;align-items:center;justify-content:center;
}
#<?= esc_attr( $uid ) ?> .__stage{position:relative;z-index:0;width:100%;}
#<?= esc_attr( $uid ) ?> canvas.__mask{
	position:absolute;inset:0;z-index:1;pointer-events:none;
	width:100%;height:100%;display:block;
}
<?php if ( 'sticky' === $mode ) : ?>
#<?= esc_attr( $uid ) ?>-track{min-height:calc(<?= (int) $dist ?>vh + 100vh);}
#<?= esc_attr( $uid ) ?>-track .wf-px-pin{position:sticky;top:<?= (int) $top ?>px;}
<?php endif; ?>
/* Moins d'animations : pas de voile du tout, le contenu est simplement la. */
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?> canvas.__mask{display:none;}
<?php if ( 'sticky' === $mode ) : ?>
	#<?= esc_attr( $uid ) ?>-track{min-height:0;}
	#<?= esc_attr( $uid ) ?>-track .wf-px-pin{position:static;}
	#<?= esc_attr( $uid ) ?>{min-height:<?= (int) $h ?>px;}
<?php endif; ?>
}
</style>

<script>
(function(){
	var root = document.getElementById('<?= esc_js( $uid ) ?>');
	if (!root) { return; }
	if (window.matchMedia) {
		if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { return; }
	}

	var cell = <?= (int) $cell ?>;
	var gap = <?= (int) $gap ?>;
	var dir = '<?= esc_js( $dir ) ?>';
	var pat = '<?= esc_js( $pat ) ?>';
	var inten = <?= esc_js( (string) $inten ) ?>;
	var endAt = <?= esc_js( (string) $endAt ) ?>;
	var reverse = <?= $rev ? 'true' : 'false' ?>;
	var cover = '<?= esc_js( $cover ) ?>';
	var accents = ['<?= esc_js( $a1 ) ?>', '<?= esc_js( $a2 ) ?>'];
	var share = <?= esc_js( (string) $share ) ?>;

	var canvas = document.createElement('canvas');
	canvas.className = '__mask';
	canvas.setAttribute('aria-hidden', 'true');
	root.appendChild(canvas);
	var ctx = canvas.getContext('2d');

	var cols = 0, rows = 0, cw = 0, ch = 0, dpr = 1;
	var thresholds = [];
	var accentOf = [];

	// Ordre de disparition : un seuil par cellule, entre 0 et 1.
	function base(cx, cy){
		if (dir === 'top') { return cy; }
		if (dir === 'bottom') { return 1 - cy; }
		if (dir === 'left') { return cx; }
		if (dir === 'right') { return 1 - cx; }
		var dx = cx - 0.5, dy = cy - 0.5;
		var d = Math.sqrt(dx * dx + dy * dy) / 0.7071;
		if (dir === 'center-in') { return 1 - d; }
		return d;
	}

	function motif(x, y, cx, cy){
		if (pat === 'checker') { return ((x + y) % 2) === 0 ? 0.15 : 0.85; }
		if (pat === 'diagonal') { return ((x + y) % (cols + rows)) / Math.max(1, cols + rows - 1); }
		if (pat === 'wave') { return 0.5 + 0.5 * Math.sin(cx * Math.PI * 3 + cy * Math.PI * 2); }
		if (pat === 'radial') {
			var dx = cx - 0.5, dy = cy - 0.5;
			return (Math.sqrt(dx * dx + dy * dy) * 3) % 1;
		}
		if (pat === 'spiral') {
			var ax = cx - 0.5, ay = cy - 0.5;
			var ang = (Math.atan2(ay, ax) + Math.PI) / (Math.PI * 2);
			var r = Math.sqrt(ax * ax + ay * ay);
			return (ang + r * 2) % 1;
		}
		return Math.random();
	}

	function build(){
		var r = root.getBoundingClientRect();
		if (r.width < 2) { return; }
		if (r.height < 2) { return; }
		var ratio = window.devicePixelRatio;
		if (!ratio) { ratio = 1; }
		dpr = Math.min(2, ratio);
		canvas.width = Math.ceil(r.width * dpr);
		canvas.height = Math.ceil(r.height * dpr);
		cw = r.width;
		ch = r.height;
		var step = cell + gap;
		cols = Math.ceil(cw / step);
		rows = Math.ceil(ch / step);

		thresholds = new Float32Array(cols * rows);
		accentOf = new Int8Array(cols * rows);
		var min = 1, max = 0;
		for (var y = 0; y < rows; y++) {
			for (var x = 0; x < cols; x++) {
				var cx = cols > 1 ? x / (cols - 1) : 0.5;
				var cy = rows > 1 ? y / (rows - 1) : 0.5;
				var v = base(cx, cy) * (1 - inten) + motif(x, y, cx, cy) * inten;
				thresholds[y * cols + x] = v;
				if (v < min) { min = v; }
				if (v > max) { max = v; }
				accentOf[y * cols + x] = Math.random() < share ? (Math.random() < 0.5 ? 1 : 2) : 0;
			}
		}
		// normalisation : la derniere cellule part exactement a la fin
		var span = max - min;
		if (span > 0.0001) {
			for (var i = 0; i < thresholds.length; i++) {
				thresholds[i] = (thresholds[i] - min) / span;
			}
		}
	}

	function paintAt(p){
		if (!cols) { return; }
		if (p < 0) { p = 0; }
		if (p > 1) { p = 1; }
		var t = p / endAt;
		if (t > 1) { t = 1; }
		if (reverse) { t = 1 - t; }

		ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		ctx.clearRect(0, 0, cw, ch);
		var step = cell + gap;
		for (var y = 0; y < rows; y++) {
			for (var x = 0; x < cols; x++) {
				var i = y * cols + x;
				var th = thresholds[i];
				if (th < t) { continue; }              // pixel deja parti
				// juste avant de partir, quelques pixels s'allument
				var near = (th - t) < 0.08;
				var col = cover;
				if (near) {
					if (accentOf[i] === 1) { col = accents[0]; }
					else if (accentOf[i] === 2) { col = accents[1]; }
				}
				ctx.fillStyle = col;
				ctx.fillRect(x * step, y * step, cell, cell);
			}
		}
	}

	var track = document.getElementById('<?= esc_js( $uid ) ?>-track');
	var scope = track ? track : root;
	var ticking = false;

	function progress(){
		var r = scope.getBoundingClientRect();
		var vh = window.innerHeight;
		if (track) {
			var run = r.height - vh;
			return run > 0 ? (-r.top) / run : 0;
		}
		var total = r.height + vh;
		return total > 0 ? (vh - r.top) / total : 0;
	}

	function paint(){
		ticking = false;
		paintAt(progress());
	}

	function onScroll(){
		if (ticking) { return; }
		ticking = true;
		// Un onglet en arriere-plan ne declenche aucun requestAnimationFrame.
		if (document.hidden) { paint(); }
		else { requestAnimationFrame(paint); }
	}

	function refresh(){ build(); paint(); }

	refresh();
	window.addEventListener('scroll', onScroll, { passive: true });
	window.addEventListener('resize', refresh);
	if (window.ResizeObserver) { new ResizeObserver(refresh).observe(root); }
})();
</script>
