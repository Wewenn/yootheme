<?php
/**
 * WeFrame – Counter Item | template.php v2.2
 * + icon/image above, separate unit display
 */
defined( 'ABSPATH' ) || exit;

$number   = (float)( $props['number']   ?? 0 );
$decimals = max( 0, (int)( $props['decimals'] ?? 0 ) );
$prefix   = $props['prefix'] ?? '';
$suffix   = $props['suffix'] ?? '';
$unit     = $props['unit']   ?? '';
$title    = $props['title']  ?? '';
$color_ov = $props['color_override'] ?? '';
$icon     = $props['icon']   ?? '';
$image    = $props['image']  ?? '';

if ( $image && ! preg_match( '#^https?://#i', $image ) ) { $image = '/' . ltrim( $image, '/' ); }

$num_size   = (int)( $element['number_size']   ?? 48 );
$num_weight = $element['number_weight']        ?? '700';
$num_color  = $color_ov ?: ( $element['number_color'] ?? '' );
$unit_size  = (int)( $element['unit_size']     ?? 28 );
$title_size = (int)( $element['title_size']    ?? 15 );
$title_clr  = $element['title_color']          ?? '';
$icon_size  = (int)( $element['icon_size']     ?? 40 );
$icon_color = $element['icon_color']           ?? '';
$duration   = (int)( $element['duration']      ?? 2000 );

$ncss = $num_color  ? "color:{$num_color};" : '';
$tcss = $title_clr  ? "color:{$title_clr};" : 'color:#666;';
$icss = $icon_color ? "color:{$icon_color};" : '';

$static = $prefix . number_format( $number, $decimals, ',', ' ' ) . $suffix;

// Icon SVG map (UIkit icon names)
$icon_map = [
    'users'    => '<svg width="'.$icon_size.'" height="'.$icon_size.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
    'location' => '<svg width="'.$icon_size.'" height="'.$icon_size.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>',
    'calendar' => '<svg width="'.$icon_size.'" height="'.$icon_size.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>',
    'heart'    => '<svg width="'.$icon_size.'" height="'.$icon_size.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78L12 21.23l8.84-8.84a5.5 5.5 0 0 0 0-7.78z"/></svg>',
    'star'     => '<svg width="'.$icon_size.'" height="'.$icon_size.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
    'check'    => '<svg width="'.$icon_size.'" height="'.$icon_size.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
    'world'    => '<svg width="'.$icon_size.'" height="'.$icon_size.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>',
    'arrow-up' => '<svg width="'.$icon_size.'" height="'.$icon_size.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>',
    'bolt'     => '<svg width="'.$icon_size.'" height="'.$icon_size.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',
];

?>
<div class="wf-counter-cell" style="padding:8px 0;">

    <?php // Icon or Image ?>
    <?php if ( $image ) : ?>
    <div style="margin-bottom:12px;"><img src="<?= esc_url( $image ) ?>" alt="" loading="lazy" style="width:<?= $icon_size ?>px;height:<?= $icon_size ?>px;object-fit:contain;"></div>
    <?php elseif ( $icon && isset( $icon_map[ $icon ] ) ) : ?>
    <div style="margin-bottom:12px;<?= $icss ?>"><?= $icon_map[ $icon ] ?></div>
    <?php endif; ?>

    <?php // Number + unit row ?>
    <div style="display:inline-flex;align-items:baseline;gap:4px;">
        <div style="font-size:<?= $num_size ?>px;font-weight:<?= esc_attr( $num_weight ) ?>;line-height:1.1;<?= $ncss ?>"><?php
            if ( $duration > 0 ) : ?>
                <span data-wf-target="<?= esc_attr( $number ) ?>"
                      data-wf-decimals="<?= $decimals ?>"
                      data-wf-prefix="<?= esc_attr( $prefix ) ?>"
                      data-wf-suffix="<?= esc_attr( $suffix ) ?>"><?= esc_html( $prefix . '0' . $suffix ) ?></span>
            <?php else :
                echo esc_html( $static );
            endif;
        ?></div>
        <?php if ( $unit ) : ?>
        <span style="font-size:<?= $unit_size ?>px;font-weight:<?= esc_attr( $num_weight ) ?>;<?= $ncss ?>opacity:.7;"><?= esc_html( $unit ) ?></span>
        <?php endif; ?>
    </div>

    <?php if ( $title ) : ?>
    <div style="font-size:<?= $title_size ?>px;margin-top:8px;line-height:1.4;<?= $tcss ?>"><?= esc_html( $title ) ?></div>
    <?php endif; ?>
</div>
