<?php
/**
 * WeFrame – Parallaxe (couches) | fond + avant-plan à vitesses différentes au scroll.
 */
defined( 'ABSPATH' ) || exit;
$bg = trim( (string) ( $props['bg_image'] ?? '' ) );
$fg = trim( (string) ( $props['fg_image'] ?? '' ) );
if ( '' === $bg && '' === $fg ) { return; }
if ( $bg && ! preg_match( '#^https?://#i', $bg ) ) { $bg = '/' . ltrim( $bg, '/' ); }
if ( $fg && ! preg_match( '#^https?://#i', $fg ) ) { $fg = '/' . ltrim( $fg, '/' ); }
$title = (string) ( $props['title'] ?? '' );
$int   = max( 0, min( 200, (int) ( $props['intensity'] ?? 60 ) ) );
$ovl   = max( 0, min( 90, (int) ( $props['overlay'] ?? 15 ) ) );
$h     = max( 200, (int) ( $props['height'] ?? 520 ) );
$r     = max( 0, (int) ( $props['radius'] ?? 16 ) );
$uid   = wf_uid( 'wfpx_', $props );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-px" style="position:relative;overflow:hidden;height:<?= $h ?>px;border-radius:<?= $r ?>px;">
    <?php if ( $bg ) : ?><img class="wf-px-bg" src="<?= esc_url( $bg ) ?>" alt="" loading="lazy" style="position:absolute;left:0;top:-15%;width:100%;height:130%;object-fit:cover;display:block;will-change:transform;"><?php endif; ?>
    <?php if ( $ovl > 0 ) : ?><span style="position:absolute;inset:0;background:rgba(0,0,0,<?= $ovl / 100 ?>);"></span><?php endif; ?>
    <?php if ( $fg ) : ?><img class="wf-px-fg" src="<?= esc_url( $fg ) ?>" alt="" loading="lazy" style="position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);max-width:52%;max-height:70%;object-fit:contain;display:block;filter:drop-shadow(0 20px 40px rgba(0,0,0,.35));will-change:transform;"><?php endif; ?>
    <?php if ( '' !== $title ) : ?><div class="wf-px-t" style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;text-align:center;color:#fff;font-size:clamp(26px,5vw,52px);font-weight:800;letter-spacing:-.02em;padding:20px;will-change:transform;"><?= esc_html( $title ) ?></div><?php endif; ?>
</div>
<script>
(function(){
    var el = document.getElementById('<?= esc_js( $uid ) ?>'); if (!el) return;
    var bg = el.querySelector('.wf-px-bg'), fg = el.querySelector('.wf-px-fg'), tt = el.querySelector('.wf-px-t');
    if (window.matchMedia) if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    var I = <?= (int) $int ?>, ticking = false;
    function upd(){
        ticking = false;
        var r = el.getBoundingClientRect(), vh = window.innerHeight || document.documentElement.clientHeight;
        var p = (vh - r.top) / (vh + r.height);
        if (p < 0) p = 0; if (p > 1) p = 1;
        var d = (p - 0.5) * 2;
        if (bg) bg.style.transform = 'translateY(' + (d * I) + 'px)';
        if (fg) fg.style.transform = 'translate(-50%,-50%) translateY(' + (-d * I * 0.6) + 'px)';
        if (tt) tt.style.transform = 'translateY(' + (-d * I * 0.35) + 'px)';
    }
    function onS(){ if (!ticking) { ticking = true; requestAnimationFrame(upd); } }
    window.addEventListener('scroll', onS, { passive: true });
    window.addEventListener('resize', onS, { passive: true });
    upd();
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
