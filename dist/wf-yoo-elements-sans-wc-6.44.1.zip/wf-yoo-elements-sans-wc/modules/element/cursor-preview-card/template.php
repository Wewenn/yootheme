<?php
defined('ABSPATH') || exit;
require_once __DIR__ . '/../../wf-motion-kit.php';
$p=wfmk_props('cursor-preview-card',$props);
$uid=wf_uid('wfmk_', $props);
$wfmkEl=(isset($this) && method_exists($this,'el'))?$this->el('div'):null;
if($wfmkEl)echo $wfmkEl($props,$attrs??[]);
?>
<?php
$src=wfmk_src($p['image']);
$media=array_values(array_filter([$src,wfmk_src($p['image_2']??''),wfmk_src($p['image_3']??'')]));
$slider=(($p['media_mode']??'single')==='slider' && count($media)>1);
$sentence=(string)$p['before'].(string)$p['title'].(string)$p['after'];
$interactive=array_values(array_filter(array_unique(array_merge([(string)$p['title']],preg_split('/\\R+/',(string)$p['interactive_texts']))),'strlen'));
$bold=array_values(array_filter(array_unique(preg_split('/\\R+/',(string)$p['bold_words'])),'strlen'));
$terms=array_values(array_unique(array_merge($interactive,$bold)));
usort($terms,fn($a,$b)=>strlen($b)<=>strlen($a));
$pattern=$terms?'/('.implode('|',array_map(fn($v)=>preg_quote($v,'/'),$terms)).')/iu':null;
$parts=$pattern?preg_split($pattern,$sentence,-1,PREG_SPLIT_DELIM_CAPTURE):[$sentence];
$lowerText=fn($value)=>function_exists('mb_strtolower')?mb_strtolower($value):strtolower($value);
$interactiveLower=array_map($lowerText,$interactive);$boldLower=array_map($lowerText,$bold);
?>
<div id="<?=esc_attr($uid)?>" class="wfmk wfmk-cursor wfmk-cursor--<?=esc_attr(wfmk_choice($p['underline_effect'],['slide','center','highlight','static'],'slide'))?><?=!empty($p['underline_hover'])?' is-hover-line':''?>" data-wf-motion="cursor" style="<?=wfmk_vars(['width'=>wfmk_n($p,'width',270,140,480).'px','radius'=>wfmk_n($p,'radius',18,0,60).'px','size'=>wfmk_n($p,'font_size',30,14,100).'px','bg'=>wfmk_color($p['bg']),'ink'=>wfmk_color($p['ink']),'accent'=>wfmk_color($p['accent']),'line-height'=>wfmk_n($p,'underline_height',2,1,12).'px','line-offset'=>wfmk_n($p,'underline_offset',3,0,16).'px','line-speed'=>wfmk_n($p,'underline_speed',350,100,1500).'ms','weight'=>wfmk_choice((string)$p['weight'],['400','500','600','700'],'400'),'align'=>wfmk_choice($p['align'],['left','center','right'],'left')])?>">
 <p class="wfmk-cursor__line"><?php foreach($parts as $part):$lower=$lowerText($part);$interactivePart=in_array($lower,$interactiveLower,true);$boldPart=in_array($lower,$boldLower,true);?><?php if($interactivePart):?><button type="button" class="wfmk-cursor__trigger" aria-expanded="false" aria-controls="<?=esc_attr($uid)?>-preview"><?=$boldPart?'<strong>'.esc_html($part).'</strong>':esc_html($part)?></button><?php elseif($boldPart):?><strong><?=esc_html($part)?></strong><?php else:?><?=esc_html($part)?><?php endif;?><?php endforeach;?></p>
 <div id="<?=esc_attr($uid)?>-preview" class="wfmk-cursor__preview" hidden>
  <?php if($media):?><div class="wfmk-cursor__media" data-slider="<?=$slider?'1':'0'?>" data-interval="<?=max(500,min(8000,(int)($p['media_interval']??1400)))?>"><?php foreach($media as $i=>$mediaSrc):?><img src="<?=$mediaSrc?>" alt="<?=$i===0?esc_attr($p['image_alt']):''?>" loading="lazy" class="<?=$i===0?'is-active':''?>"><?php endforeach;?></div><?php else:?><div class="wfmk-placeholder" aria-hidden="true"></div><?php endif;?>
  <p><?=esc_html($p['text'])?></p>
  <?php if(esc_url($p['link'])):?><a href="<?=esc_url($p['link'])?>"<?=!empty($p['target'])?' target="_blank" rel="noopener noreferrer"':''?>>Découvrir →</a><?php endif;?>
  <button type="button" class="wfmk-cursor__close" aria-label="Fermer l’aperçu">×</button>
 </div>
</div>
<?php if($slider):?><style>#<?=esc_attr($uid)?> .wfmk-cursor__media{position:relative;height:180px;overflow:hidden;border-radius:max(0px,calc(var(--wm-radius) - 6px))}#<?=esc_attr($uid)?> .wfmk-cursor__media img{position:absolute;inset:0;height:100%;opacity:0;transform:scale(1.04);transition:opacity .45s,transform .75s}#<?=esc_attr($uid)?> .wfmk-cursor__media img.is-active{opacity:1;transform:scale(1)}</style><script>(function(){var r=document.getElementById('<?=esc_js($uid)?>'),m=r&&r.querySelector('.wfmk-cursor__media');if(!m)return;var a=[].slice.call(m.querySelectorAll('img')),i=0,t=0;function start(){if(t||a.length<2)return;t=setInterval(function(){a[i].classList.remove('is-active');i=(i+1)%a.length;a[i].classList.add('is-active')},Number(m.dataset.interval||1400))}function stop(){if(t){clearInterval(t);t=0}}r.addEventListener('pointerenter',start);r.addEventListener('pointerleave',stop);r.addEventListener('focusin',start);r.addEventListener('focusout',stop)})();</script><?php endif;?>

<?php if($wfmkEl)echo $wfmkEl->end(); ?>
