<?php
/**
 * WeFrame - Avis en ligne de texte (avis enfant) | template.php v1.0
 * Le parent assemble le paragraphe : l'enfant n'affiche rien seul.
 */
defined( 'ABSPATH' ) || exit;
echo '';
