<?php
defined('ABSPATH') || exit;
if (empty($children)) return;
$side=$props['sticky_side']??'left';$sw=(int)($props['sticky_width']??40);$gap=(int)($props['gap']??48);
$va=$props['sticky_valign']??'center';
$st=$props['sticky_title']??'';$sts=(int)($props['sticky_title_size']??40);$stw=$props['sticky_title_weight']??'700';
$sd=$props['sticky_desc']??'';$sds=(int)($props['sticky_desc_size']??17);
$ctat=$props['sticky_cta_text']??'';$ctal=$props['sticky_cta_link']??'';
$uid='wfsp_'.substr(md5(serialize($props).count($children)),0,8);
$panels='';
foreach($children as $child){$panels.=$builder->render($child,['element'=>$props]);}
if(!trim($panels))return;
$isRight=($side==='right');
$cta='';
if($ctat)$cta='<a href="'.esc_url($ctal).'" style="display:inline-block;margin-top:24px;padding:10px 28px;border-radius:100px;border:2px solid currentColor;font-size:15px;font-weight:600;text-decoration:none;color:inherit;">'.esc_html($ctat).'</a>';
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr($uid) ?>" class="wf-split" style="display:flex;gap:<?= $gap ?>px;<?= $isRight?'flex-direction:row-reverse;':'' ?>">
    <div class="wf-sp-sticky" style="width:<?= $sw ?>%;flex-shrink:0;position:sticky;top:80px;align-self:flex-start;display:flex;flex-direction:column;justify-content:<?= esc_attr($va) ?>;min-height:50vh;">
        <?php if($st):?><div style="font-size:<?= $sts ?>px;font-weight:<?= esc_attr($stw) ?>;line-height:1.15;letter-spacing:-0.02em;margin-bottom:16px;"><?= esc_html($st) ?></div><?php endif;?>
        <?php if($sd):?><p style="font-size:<?= $sds ?>px;line-height:1.6;opacity:.7;margin:0;"><?= esc_html($sd) ?></p><?php endif;?>
        <?= $cta ?>
    </div>
    <div class="wf-sp-scroll" style="flex:1;display:flex;flex-direction:column;gap:<?= $gap ?>px;">
        <?= $panels ?>
    </div>
</div>
<style>@media(max-width:767px){#<?= esc_attr($uid) ?>{flex-direction:column !important}#<?= esc_attr($uid) ?> .wf-sp-sticky{width:100% !important;position:relative !important;top:auto !important;min-height:auto !important;margin-bottom:24px}}</style>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
