<?php
/**
 * WeFrame – Modal Pro | template.php v1.0
 * Modale a 4 modes d'affichage (dialogue / defilement interne / debordement / plein ecran).
 * Le contenu est libre : tout element depose dedans est rendu par le builder.
 * S'appuie sur uk-modal (UIkit livre avec YOOtheme Pro) : Echap, verrou du scroll et
 * piege de focus sont donc geres nativement. On ajoute role/aria-modal, que UIkit n'ecrit pas.
 * Pas de "&&" ni de "||" dans le JS inline (regle interne du plugin).
 */
defined( 'ABSPATH' ) || exit;

$trigger  = (string) ( $props['trigger_type'] ?? 'button' );
if ( ! in_array( $trigger, array( 'button', 'link', 'icon', 'selector', 'none' ), true ) ) { $trigger = 'button'; }
$btnText  = trim( (string) ( $props['btn_text'] ?? '' ) );
$btnIcon  = (string) ( $props['btn_icon'] ?? 'none' );
$selector = trim( (string) ( $props['trigger_selector'] ?? '' ) );

$eyebrow  = trim( (string) ( $props['modal_eyebrow'] ?? '' ) );
$title    = trim( (string) ( $props['modal_title'] ?? '' ) );

$layout   = (string) ( $props['layout'] ?? 'dialog' );
if ( ! in_array( $layout, array( 'dialog', 'scroll', 'overflow', 'full' ), true ) ) { $layout = 'dialog'; }

$mW       = max( 280, (int) ( $props['modal_width'] ?? 720 ) );
$mMaxH    = max( 30, min( 95, (int) ( $props['modal_max_height'] ?? 70 ) ) );
$mRad     = max( 0, (int) ( $props['modal_radius'] ?? 20 ) );
$mPad     = max( 0, (int) ( $props['modal_padding'] ?? 32 ) );
$vAlign   = ( 'top' === ( $props['modal_valign'] ?? 'center' ) ) ? 'top' : 'center';

$mBg      = (string) ( $props['modal_bg'] ?? '#ffffff' );
$mCol     = (string) ( $props['modal_color'] ?? '#111111' );
$bdCol    = (string) ( $props['backdrop_color'] ?? '#000000' );
$bdOp     = max( 0, min( 100, (int) ( $props['backdrop_opacity'] ?? 60 ) ) );
$bdBlur   = max( 0, (int) ( $props['backdrop_blur'] ?? 6 ) );

$bStyle   = (string) ( $props['btn_style'] ?? 'filled' );
$bSize    = (string) ( $props['btn_size'] ?? 'medium' );
$bAlign   = (string) ( $props['btn_align'] ?? 'left' );
$bBg      = (string) ( $props['btn_bg'] ?? '#EA5C1C' );
$bCol     = (string) ( $props['btn_color'] ?? '#ffffff' );
$bRad     = max( 0, (int) ( $props['btn_radius'] ?? 8 ) );
$bFull    = ! empty( $props['btn_full'] );

$tSize    = max( 14, (int) ( $props['title_size'] ?? 30 ) );
$tCol     = trim( (string) ( $props['title_color'] ?? '' ) );
$eCol     = (string) ( $props['eyebrow_color'] ?? '#EA5C1C' );
$stickyH  = ! empty( $props['sticky_header'] );

$showX    = ! empty( $props['show_close'] );
$xStyle   = ( 'outside' === ( $props['close_style'] ?? 'inside' ) ) ? 'outside' : 'inside';
$xLabel   = trim( (string) ( $props['close_label'] ?? '' ) );
if ( '' === $xLabel ) { $xLabel = __( 'Fermer', 'weframe' ); }
$bgClose  = ! empty( $props['bg_close'] );
$escClose = ! empty( $props['esc_close'] );

$auto     = (string) ( $props['auto_open'] ?? 'none' );
if ( ! in_array( $auto, array( 'none', 'delay', 'scroll', 'exit' ), true ) ) { $auto = 'none'; }
$autoDel  = max( 0, (int) ( $props['auto_delay'] ?? 3 ) );
$autoScr  = max( 5, min( 100, (int) ( $props['auto_scroll'] ?? 40 ) ) );
$autoOnce = ! empty( $props['auto_once'] );
$autoDays = max( 1, (int) ( $props['auto_days'] ?? 7 ) );

$anim     = (string) ( $props['modal_anim'] ?? 'scale' );
if ( ! in_array( $anim, array( 'scale', 'fade', 'top', 'bottom', 'left', 'right' ), true ) ) { $anim = 'scale'; }

$inner = '';
if ( ! empty( $children ) ) {
	foreach ( $children as $ci => $child ) {
		$inner .= $builder->render( $child, array( 'element' => $props, 'index' => $ci ) );
	}
}
// Une modale sans contenu ni titre n'a rien a montrer.
if ( '' === trim( $inner ) && '' === $title && '' === $eyebrow ) { return; }

$uid  = wf_uid( 'wfmp_', $props, count( (array) $children ) );
$mid  = $uid . '-modal';

// Voile : couleur choisie + opacite, avec repli si la couleur n'est pas un hexa.
$bdRgb = function_exists( 'wf_hex_to_rgb' ) ? wf_hex_to_rgb( $bdCol ) : null;
$bdCss = $bdRgb ? 'rgba(' . $bdRgb . ',' . ( $bdOp / 100 ) . ')' : $bdCol;

$modalCls = 'wf-modal-pro wf-modal-pro--' . $layout . ' wf-modal-pro--anim-' . $anim;
if ( 'full' === $layout ) { $modalCls .= ' uk-modal-full'; }
if ( 'top' === $vAlign ) { if ( 'full' !== $layout ) { $modalCls .= ' uk-flex-top'; } }
if ( 'overflow' === $layout ) { $modalCls .= ' uk-flex-top'; }

$dialogCls = 'uk-modal-dialog wf-modal-pro__dialog';
if ( 'top' === $vAlign || 'overflow' === $layout ) { if ( 'full' !== $layout ) { $dialogCls .= ' uk-margin-auto-vertical'; } }

$closeCls = 'uk-modal-close-default';
if ( 'full' === $layout ) { $closeCls = 'uk-modal-close-full'; }
elseif ( 'outside' === $xStyle ) { $closeCls = 'uk-modal-close-outside'; }

$ukOpts = 'bg-close: ' . ( $bgClose ? 'true' : 'false' ) . '; esc-close: ' . ( $escClose ? 'true' : 'false' ) . '; stack: true';

$hasHead = ( '' !== $title || '' !== $eyebrow );
$ariaLbl = '' !== $title ? $title : ( '' !== $eyebrow ? $eyebrow : __( 'Fenêtre', 'weframe' ) );

// Icones du declencheur (jeu Phosphor, trace unique).
$icons = array(
	'eye'    => '<path d="M247.31,124.76c-.35-.79-8.82-19.58-27.65-38.41C194.57,61.26,162.88,48,128,48S61.43,61.26,36.34,86.35C17.51,105.18,9,124,8.69,124.76a8,8,0,0,0,0,6.5c.35.79,8.82,19.57,27.65,38.4C61.43,194.74,93.12,208,128,208s66.57-13.26,91.66-38.34c18.83-18.83,27.3-37.61,27.65-38.4A8,8,0,0,0,247.31,124.76ZM128,192c-30.78,0-57.67-11.19-79.93-33.25A133.47,133.47,0,0,1,25,128,133.33,133.33,0,0,1,48.07,97.25C70.33,75.19,97.22,64,128,64s57.67,11.19,79.93,33.25A133.46,133.46,0,0,1,231.05,128C223.84,141.46,192.43,192,128,192Zm0-112a48,48,0,1,0,48,48A48.05,48.05,0,0,0,128,80Zm0,80a32,32,0,1,1,32-32A32,32,0,0,1,128,160Z"/>',
	'plus'   => '<path d="M224,128a8,8,0,0,1-8,8H136v80a8,8,0,0,1-16,0V136H40a8,8,0,0,1,0-16h80V40a8,8,0,0,1,16,0v80h80A8,8,0,0,1,224,128Z"/>',
	'arrow'  => '<path d="M221.66,133.66l-72,72a8,8,0,0,1-11.32-11.32L196.69,136H40a8,8,0,0,1,0-16H196.69L138.34,61.66a8,8,0,0,1,11.32-11.32l72,72A8,8,0,0,1,221.66,133.66Z"/>',
	'play'   => '<path d="M232.4,114.49,88.32,26.35a16,16,0,0,0-16.2-.3A15.86,15.86,0,0,0,64,39.87V216.13A15.94,15.94,0,0,0,80,232a16.07,16.07,0,0,0,8.36-2.35L232.4,141.51a15.81,15.81,0,0,0,0-27ZM80,215.94V40.09l143.83,88Z"/>',
	'info'   => '<path d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Zm16-40a8,8,0,0,1-8,8,16,16,0,0,1-16-16V128a8,8,0,0,1,0-16,16,16,0,0,1,16,16v40A8,8,0,0,1,144,176ZM112,84a12,12,0,1,1,12,12A12,12,0,0,1,112,84Z"/>',
	'expand' => '<path d="M216,48V96a8,8,0,0,1-16,0V67.31l-50.34,50.35a8,8,0,0,1-11.32-11.32L188.69,56H160a8,8,0,0,1,0-16h48A8,8,0,0,1,216,48ZM106.34,138.34,56,188.69V160a8,8,0,0,0-16,0v48a8,8,0,0,0,8,8H96a8,8,0,0,0,0-16H67.31l50.35-50.34a8,8,0,0,0-11.32-11.32Z"/>',
);
$iconSvg = '';
if ( 'none' !== $btnIcon && isset( $icons[ $btnIcon ] ) ) {
	$iconSvg = '<svg class="wf-modal-pro__ico" viewBox="0 0 256 256" width="18" height="18" fill="currentColor" aria-hidden="true" focusable="false">' . $icons[ $btnIcon ] . '</svg>';
}

$padMap  = array( 'small' => '8px 14px', 'medium' => '12px 22px', 'large' => '16px 30px' );
$fontMap = array( 'small' => 13, 'medium' => 15, 'large' => 17 );
$btnPad  = $padMap[ $bSize ] ?? $padMap['medium'];
$btnFs   = $fontMap[ $bSize ] ?? 15;

$alignMap = array( 'left' => 'flex-start', 'center' => 'center', 'right' => 'flex-end' );
$btnJust  = $alignMap[ $bAlign ] ?? 'flex-start';

$fromT = array(
	'scale'  => 'transform:scale(.94);',
	'fade'   => 'transform:none;',
	'top'    => 'transform:translateY(-40px);',
	'bottom' => 'transform:translateY(40px);',
	'left'   => 'transform:translateX(-40px);',
	'right'  => 'transform:translateX(40px);',
);
$animFrom = isset( $fromT[ $anim ] ) ? $fromT[ $anim ] : '';

$showTrigger = in_array( $trigger, array( 'button', 'link', 'icon' ), true );
$iconAria = '' !== $btnText ? $btnText : $ariaLbl;
if ( $showTrigger && '' === $btnText && 'none' === $btnIcon ) { $btnText = __( 'Ouvrir', 'weframe' ); }
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<?php if ( $showTrigger ) : ?>
<div class="wf-modal-pro-trigger" id="<?= esc_attr( $uid ) ?>">
	<button type="button" class="wf-modal-pro__btn wf-modal-pro__btn--<?= esc_attr( $bStyle ) ?><?= 'icon' === $trigger ? ' wf-modal-pro__btn--iconly' : '' ?><?= $bFull ? ' wf-modal-pro__btn--full' : '' ?>"
		uk-toggle="target: #<?= esc_attr( $mid ) ?>"
		aria-haspopup="dialog"
		<?= 'icon' === $trigger ? ' aria-label="' . esc_attr( $iconAria ) . '"' : '' ?>>
		<?= $iconSvg ?><?php if ( 'icon' !== $trigger && '' !== $btnText ) : ?><span><?= esc_html( $btnText ) ?></span><?php endif; ?>
	</button>
</div>
<?php endif; ?>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<div id="<?= esc_attr( $mid ) ?>" class="<?= esc_attr( $modalCls ) ?>" uk-modal="<?= esc_attr( $ukOpts ) ?>">
	<div class="<?= esc_attr( $dialogCls ) ?>" role="dialog" aria-modal="true" aria-label="<?= esc_attr( $ariaLbl ) ?>">
		<?php if ( $showX ) : ?>
		<button class="<?= esc_attr( $closeCls ) ?> wf-modal-pro__x" type="button" aria-label="<?= esc_attr( $xLabel ) ?>" uk-close></button>
		<?php endif; ?>
		<?php if ( $hasHead ) : ?>
		<header class="wf-modal-pro__head<?= ( $stickyH && 'scroll' === $layout ) ? ' is-sticky' : '' ?>">
			<?php if ( '' !== $eyebrow ) : ?><p class="wf-modal-pro__eyebrow"><?= esc_html( $eyebrow ) ?></p><?php endif; ?>
			<?php if ( '' !== $title ) : ?><h2 class="wf-modal-pro__title"><?= esc_html( $title ) ?></h2><?php endif; ?>
		</header>
		<?php endif; ?>
		<div class="wf-modal-pro__body"><?= $inner ?></div>
	</div>
</div>

<style>
#<?= esc_attr( $uid ) ?> .wf-modal-pro__btn{
	display:inline-flex;align-items:center;justify-content:center;gap:.55em;
	padding:<?= esc_attr( $btnPad ) ?>;font-size:<?= (int) $btnFs ?>px;font-weight:600;line-height:1.2;
	border-radius:<?= (int) $bRad ?>px;border:1px solid transparent;cursor:pointer;
	transition:opacity .2s ease,transform .2s ease,background-color .2s ease,color .2s ease;
	font-family:inherit;text-decoration:none;
}
#<?= esc_attr( $uid ) ?>{display:flex;justify-content:<?= esc_attr( $btnJust ) ?>;}
#<?= esc_attr( $uid ) ?> .wf-modal-pro__btn--full{width:100%;}
#<?= esc_attr( $uid ) ?> .wf-modal-pro__btn--iconly{padding:.7em;border-radius:<?= (int) $bRad ?>px;}
#<?= esc_attr( $uid ) ?> .wf-modal-pro__btn--filled{background:<?= esc_attr( $bBg ) ?>;color:<?= esc_attr( $bCol ) ?>;}
#<?= esc_attr( $uid ) ?> .wf-modal-pro__btn--outline{background:transparent;color:<?= esc_attr( $bBg ) ?>;border-color:<?= esc_attr( $bBg ) ?>;}
#<?= esc_attr( $uid ) ?> .wf-modal-pro__btn--text{background:transparent;color:<?= esc_attr( $bBg ) ?>;padding-left:0;padding-right:0;}
#<?= esc_attr( $uid ) ?> .wf-modal-pro__btn:hover{opacity:.88;}
#<?= esc_attr( $uid ) ?> .wf-modal-pro__btn--text:hover{text-decoration:underline;opacity:1;}
#<?= esc_attr( $uid ) ?> .wf-modal-pro__btn:focus-visible{outline:2px solid currentColor;outline-offset:3px;}
@media (pointer:coarse){#<?= esc_attr( $uid ) ?> .wf-modal-pro__btn{min-height:44px;}}

#<?= esc_attr( $mid ) ?>.uk-modal{background:<?= esc_attr( $bdCss ) ?>;<?= $bdBlur > 0 ? '-webkit-backdrop-filter:blur(' . (int) $bdBlur . 'px);backdrop-filter:blur(' . (int) $bdBlur . 'px);' : '' ?>}
#<?= esc_attr( $mid ) ?> .wf-modal-pro__dialog{
	background:<?= esc_attr( $mBg ) ?>;color:<?= esc_attr( $mCol ) ?>;
	/* UIkit impose max-width:calc(100% - .01px)!important sur .uk-modal-dialog :
	   sans !important ici, le reglage « Largeur max » resterait sans effet. */
	<?= 'full' === $layout ? 'border-radius:0;width:100%;max-width:100%!important;' : 'border-radius:' . (int) $mRad . 'px;width:100%;max-width:' . (int) $mW . 'px!important;' ?>
	<?= 'full' === $layout ? 'min-height:100vh;min-height:100dvh;display:flex;flex-direction:column;' : '' ?>
	<?= 'scroll' === $layout ? 'max-height:' . (int) $mMaxH . 'vh;display:flex;flex-direction:column;overflow:hidden;' : '' ?>
	padding:0;
}
#<?= esc_attr( $mid ) ?> .wf-modal-pro__head{
	padding:<?= (int) $mPad ?>px <?= (int) $mPad ?>px 0;
	background:<?= esc_attr( $mBg ) ?>;
}
#<?= esc_attr( $mid ) ?> .wf-modal-pro__head.is-sticky{position:sticky;top:0;z-index:2;padding-bottom:12px;}
#<?= esc_attr( $mid ) ?> .wf-modal-pro__eyebrow{
	margin:0 0 .4em;font-size:12px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;
	color:<?= esc_attr( $eCol ) ?>;
}
#<?= esc_attr( $mid ) ?> .wf-modal-pro__title{
	margin:0;font-size:<?= (int) $tSize ?>px;line-height:1.15;font-weight:700;
	<?= '' !== $tCol ? 'color:' . esc_attr( $tCol ) . ';' : '' ?>
}
#<?= esc_attr( $mid ) ?> .wf-modal-pro__body{padding:<?= (int) $mPad ?>px;<?= $hasHead ? 'padding-top:' . max( 12, (int) round( $mPad / 2 ) ) . 'px;' : '' ?>}
<?php if ( 'scroll' === $layout ) : ?>
#<?= esc_attr( $mid ) ?> .wf-modal-pro__body{overflow-y:auto;-webkit-overflow-scrolling:touch;flex:1 1 auto;min-height:0;}
<?php endif; ?>
<?php if ( 'full' === $layout ) : ?>
#<?= esc_attr( $mid ) ?> .wf-modal-pro__body{flex:1 1 auto;}
#<?= esc_attr( $mid ) ?> .wf-modal-pro__head,#<?= esc_attr( $mid ) ?> .wf-modal-pro__body{max-width:1200px;margin-inline:auto;width:100%;}
<?php endif; ?>
#<?= esc_attr( $mid ) ?> .wf-modal-pro__x{color:<?= esc_attr( $mCol ) ?>;}
<?php if ( 'outside' === $xStyle && 'full' !== $layout ) : ?>
#<?= esc_attr( $mid ) ?> .wf-modal-pro__x{color:#fff;}
<?php endif; ?>

/* Animation d'ouverture : on remplace celle d'UIkit (l'id suffit a passer devant). */
#<?= esc_attr( $mid ) ?> .wf-modal-pro__dialog{
	opacity:0;transition:opacity .28s ease,transform .28s cubic-bezier(.2,.8,.2,1);
<?= $animFrom ?>
}
#<?= esc_attr( $mid ) ?>.uk-open .wf-modal-pro__dialog{opacity:1;transform:none;}
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $mid ) ?> .wf-modal-pro__dialog{transition-duration:.001ms;transform:none;}
}
@media (max-width:640px){
	#<?= esc_attr( $mid ) ?> .wf-modal-pro__head{padding:<?= max( 16, (int) round( $mPad * .6 ) ) ?>px <?= max( 16, (int) round( $mPad * .6 ) ) ?>px 0;}
	#<?= esc_attr( $mid ) ?> .wf-modal-pro__body{padding:<?= max( 16, (int) round( $mPad * .6 ) ) ?>px;}
	#<?= esc_attr( $mid ) ?> .wf-modal-pro__title{font-size:<?= max( 20, (int) round( $tSize * .74 ) ) ?>px;}
}
</style>

<script>
(function(){
	var mid = '<?= esc_js( $mid ) ?>';
	var m = document.getElementById(mid);
	if (!m) { return; }

	// Un ancetre avec transform/filter casse le position:fixed du voile.
	// Dans ce cas seulement, on deplace la modale a la racine du body.
	(function(){
		var p = m.parentNode;
		while (p) {
			if (p === document.body) { break; }
			if (p.nodeType !== 1) { break; }
			var cs = getComputedStyle(p);
			var moved = false;
			if (cs.transform !== 'none') { moved = true; }
			if (cs.filter !== 'none') { moved = true; }
			if (cs.perspective !== 'none') { moved = true; }
			if (moved) { document.body.appendChild(m); return; }
			p = p.parentNode;
		}
	})();

	function show(){
		if (typeof UIkit === 'undefined') { return; }
		UIkit.modal(m).show();
	}

<?php if ( 'selector' === $trigger && '' !== $selector ) : ?>
	document.addEventListener('click', function(e){
		if (!e.target.closest) { return; }
		var t = e.target.closest('<?= esc_js( $selector ) ?>');
		if (!t) { return; }
		e.preventDefault();
		show();
	});
<?php endif; ?>

<?php if ( 'none' !== $auto ) : ?>
	var reduced = false;
	if (window.matchMedia) {
		if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { reduced = true; }
	}
	var key = 'wfmp_' + mid;
	function seen(){
<?php if ( $autoOnce ) : ?>
		try {
			var v = localStorage.getItem(key);
			if (!v) { return false; }
			if (parseInt(v, 10) > Date.now()) { return true; }
			localStorage.removeItem(key);
		} catch (err) {}
<?php endif; ?>
		return false;
	}
	function remember(){
<?php if ( $autoOnce ) : ?>
		try { localStorage.setItem(key, String(Date.now() + <?= (int) $autoDays ?> * 864e5)); } catch (err) {}
<?php endif; ?>
	}
	var fired = false;
	function auto(){
		if (fired) { return; }
		if (seen()) { return; }
		fired = true;
		remember();
		show();
	}
	if (!reduced) {
		if (!seen()) {
<?php if ( 'delay' === $auto ) : ?>
			setTimeout(auto, <?= (int) $autoDel ?> * 1000);
<?php elseif ( 'scroll' === $auto ) : ?>
			var onScroll = function(){
				var h = document.documentElement.scrollHeight - window.innerHeight;
				if (h <= 0) { return; }
				var pct = (window.scrollY / h) * 100;
				if (pct < <?= (int) $autoScr ?>) { return; }
				window.removeEventListener('scroll', onScroll);
				auto();
			};
			window.addEventListener('scroll', onScroll, { passive: true });
<?php else : ?>
			document.addEventListener('mouseout', function(e){
				if (e.relatedTarget) { return; }
				if (e.clientY > 12) { return; }
				auto();
			});
<?php endif; ?>
		}
	}
<?php endif; ?>
})();
</script>
