<?php
defined('ABSPATH') || exit;
require_once __DIR__ . '/../../wf-motion-kit.php';
$p=wfmk_props('number-flow-pro',$props);
$uid=wf_uid('wfmk_', $props);
$wfmkEl=(isset($this) && method_exists($this,'el'))?$this->el('div'):null;
if($wfmkEl)echo $wfmkEl($props,$attrs??[]);
?>
<?php
$mode=wfmk_choice($p['mode'],['counter','manual','random','timer'],'counter');
$cfg=['mode'=>$mode,'value'=>wfmk_n($p,'value',1250,-99999999,99999999),'from'=>wfmk_n($p,'from',0,-99999999,99999999),'min'=>wfmk_n($p,'minimum',0,-99999999,99999999),'max'=>wfmk_n($p,'maximum',9999,-99999999,99999999),'step'=>wfmk_n($p,'step',1,.01,100000),'seconds'=>wfmk_n($p,'seconds',60,1,86400),'duration'=>wfmk_n($p,'duration',1.6,.2,10),'decimals'=>(int)wfmk_n($p,'decimals',0,0,3)];
?>
<div id="<?=esc_attr($uid)?>" class="wfmk wfmk-number" data-wf-motion="number" data-wf-config="<?=wfmk_json($cfg)?>" style="<?=wfmk_vars(['size'=>wfmk_n($p,'size',96,24,200).'px','mobile-size'=>wfmk_n($p,'size_mobile',54,20,100).'px','ink'=>wfmk_color($p['ink']),'align'=>wfmk_choice($p['align'],['left','center','right'],'center')])?>">
 <div class="wfmk-number__line"><span><?=esc_html($p['prefix'])?></span><span class="wfmk-number__digits" aria-hidden="true"><?=esc_html($mode==='timer'?gmdate('i:s',(int)$cfg['seconds']):number_format($cfg['value'],$cfg['decimals'],',',' '))?></span><span><?=esc_html($p['suffix'])?></span></div>
 <span class="wfmk-sr" data-number-label><?=esc_html($cfg['value'])?></span><p><?=esc_html($p['title'])?></p>
 <?php if($mode==='manual'):?><div class="wfmk-controls"><button type="button" data-action="minus" aria-label="Diminuer">−</button><button type="button" data-action="plus" aria-label="Augmenter">+</button></div><?php endif;?>
 <?php if($mode==='random'):?><div class="wfmk-controls"><button type="button" data-action="random">Nouveau nombre</button></div><?php endif;?>
 <?php if($mode==='timer'):?><div class="wfmk-controls"><button type="button" data-action="timer" aria-pressed="false">Démarrer</button><button type="button" data-action="reset">Réinitialiser</button></div><?php endif;?>
</div>

<?php if($wfmkEl)echo $wfmkEl->end(); ?>
