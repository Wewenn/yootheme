<?php
/**
 * WeFrame – Grille WeFrame (parent) | template.php v1.0
 * Grille responsive + apparition en cascade + chiffres animés (5 courbes) + barres de progression.
 * Config inlinée (pas de <script type="application/json">), pas de "&&" dans le JS inline.
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$cols   = max( 1, (int) ( $props['columns'] ?? 3 ) );
$colsT  = max( 1, (int) ( $props['columns_tablet'] ?? 2 ) );
$colsM  = max( 1, (int) ( $props['columns_mobile'] ?? 1 ) );
$gap    = max( 0, (int) ( $props['gap'] ?? 24 ) );
$gapRow = max( 0, (int) ( $props['gap_row'] ?? 0 ) );
$gapRow = $gapRow > 0 ? $gapRow : $gap;
$equal  = ! empty( $props['equal_height'] );

$reveal = (string) ( $props['reveal'] ?? 'up' );
if ( ! in_array( $reveal, array( 'none', 'fade', 'up', 'scale' ), true ) ) { $reveal = 'up'; }
$revDur = max( 0, (int) ( $props['reveal_duration'] ?? 600 ) );
$stag   = max( 0, (int) ( $props['stagger'] ?? 90 ) );
$cntDur = max( 0, (int) ( $props['count_duration'] ?? 1800 ) );

$cBg    = $props['card_bg']     ?? '#04305c';
$cCol   = $props['card_color']  ?? '#ffffff';
$cMut   = $props['card_muted']  ?? '#9db4cc';
$cBd    = trim( (string) ( $props['card_border'] ?? '' ) );
$cRad   = max( 0, (int) ( $props['card_radius'] ?? 0 ) );
$cPad   = max( 0, (int) ( $props['card_padding'] ?? 34 ) );

$corner  = ! empty( $props['corner'] );
$coCol   = $props['corner_color'] ?? '#c9a227';
$coSize  = max( 4, (int) ( $props['corner_size'] ?? 42 ) );
$coWidth = max( 1, (int) ( $props['corner_width'] ?? 1 ) );

$txtRev  = (string) ( $props['text_reveal'] ?? 'none' );
if ( ! in_array( $txtRev, array( 'none', 'fade', 'words', 'chars' ), true ) ) { $txtRev = 'none'; }
$txtStag = max( 0, (int) ( $props['text_stagger'] ?? 28 ) );
$cEase   = (string) ( $props['count_ease'] ?? 'out-cubic' );
if ( ! in_array( $cEase, array( 'out-cubic', 'linear', 'out-expo', 'in-out', 'back' ), true ) ) { $cEase = 'out-cubic'; }
$cFrom   = (float) ( $props['count_from'] ?? 0 );
$barH    = max( 1, (int) ( $props['bar_height'] ?? 8 ) );
$barTrk  = $props['bar_track'] ?? '#0a4478';
$barFil  = $props['bar_fill']  ?? '#c9a227';
$barRad  = max( 0, (int) ( $props['bar_radius'] ?? 100 ) );
$barVal  = ! empty( $props['bar_value'] );
$numSize = max( 10, (int) ( $props['number_size'] ?? 44 ) );
$labSize = max( 10, (int) ( $props['label_size'] ?? 16 ) );

$uid = wf_uid( 'wfgr_', $props, count( $children ) );

$html = '';
foreach ( $children as $i => $child ) {
	$html .= $builder->render( $child, array( 'element' => $props, 'index' => $i ) );
}
if ( ! trim( $html ) ) { return; }
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-grid<?= $reveal !== 'none' ? ' wf-grid--reveal' : '' ?>">
	<?= $html ?>
</div>

<style>
#<?= esc_attr( $uid ) ?>.wf-grid{
	display:grid;
	grid-template-columns:repeat(<?= $cols ?>,minmax(0,1fr));
	column-gap:<?= $gap ?>px;
	row-gap:<?= $gapRow ?>px;
	align-items:<?= $equal ? 'stretch' : 'start' ?>;
}
#<?= esc_attr( $uid ) ?> .wf-grid-item{
	position:relative;
	background:<?= esc_attr( $cBg ) ?>;
	color:<?= esc_attr( $cCol ) ?>;
	border-radius:<?= $cRad ?>px;
	padding:<?= $cPad ?>px;
	box-sizing:border-box;
	<?= '' !== $cBd ? 'border:1px solid ' . esc_attr( $cBd ) . ';' : '' ?>
	display:flex;flex-direction:column;gap:10px;justify-content:center;
	<?= $equal ? 'height:100%;' : '' ?>
	text-decoration:none;
}
#<?= esc_attr( $uid ) ?> .wf-grid-num{
	font-size:<?= $numSize ?>px;line-height:1.05;font-weight:600;
	font-variant-numeric:tabular-nums;letter-spacing:-.01em;
	color:<?= esc_attr( $cCol ) ?>;
}
#<?= esc_attr( $uid ) ?> .wf-grid-label{
	font-size:<?= $labSize ?>px;line-height:1.45;color:<?= esc_attr( $cMut ) ?>;
}
#<?= esc_attr( $uid ) ?> .wf-grid-title{
	font-size:<?= $labSize + 3 ?>px;font-weight:600;color:<?= esc_attr( $cCol ) ?>;
}
#<?= esc_attr( $uid ) ?> .wf-grid-free{width:100%;}
#<?= esc_attr( $uid ) ?> .wf-grid-free > * + *{margin-top:12px;}
#<?= esc_attr( $uid ) ?> .wf-grid-bar{
	width:100%;height:<?= $barH ?>px;background:<?= esc_attr( $barTrk ) ?>;
	border-radius:<?= $barRad ?>px;overflow:hidden;margin-top:4px;
}
#<?= esc_attr( $uid ) ?> .wf-grid-bar-fill{
	display:block;height:100%;background:<?= esc_attr( $barFil ) ?>;border-radius:inherit;
}
<?php if ( ! $barVal ) : ?>
#<?= esc_attr( $uid ) ?> .wf-grid-item--bar .wf-grid-num{display:none;}
<?php endif; ?>
<?php if ( $corner ) : ?>
/* Équerre décorative : deux traits qui se rejoignent en haut à droite. */
#<?= esc_attr( $uid ) ?> .wf-grid-item::before{
	content:"";position:absolute;top:0;right:0;
	width:<?= $coSize ?>px;height:<?= $coSize ?>px;
	border-top:<?= $coWidth ?>px solid <?= esc_attr( $coCol ) ?>;
	border-right:<?= $coWidth ?>px solid <?= esc_attr( $coCol ) ?>;
	border-top-right-radius:<?= $cRad ?>px;
	pointer-events:none;
}
<?php endif; ?>
<?php if ( 'none' !== $txtRev ) : ?>
#<?= esc_attr( $uid ) ?> .wf-grid-t{
	display:inline-block;opacity:0;transform:translateY(.45em);
	transition:opacity <?= $revDur ?>ms cubic-bezier(.22,.9,.32,1), transform <?= $revDur ?>ms cubic-bezier(.22,.9,.32,1);
}
#<?= esc_attr( $uid ) ?> .wf-grid-t.is-in{opacity:1;transform:none;}
#<?= esc_attr( $uid ) ?> .wf-grid-fade{
	opacity:0;transition:opacity <?= $revDur ?>ms ease;
}
#<?= esc_attr( $uid ) ?> .wf-grid-fade.is-in{opacity:1;}
<?php endif; ?>
<?php if ( 'none' !== $reveal ) : ?>
#<?= esc_attr( $uid ) ?>.wf-grid--reveal.wf-grid--js .wf-grid-item{
	opacity:0;
	transition:opacity <?= $revDur ?>ms cubic-bezier(.22,.9,.32,1), transform <?= $revDur ?>ms cubic-bezier(.22,.9,.32,1);
	<?php if ( 'up' === $reveal ) : ?>transform:translateY(22px);<?php endif; ?>
	<?php if ( 'scale' === $reveal ) : ?>transform:scale(.94);<?php endif; ?>
}
#<?= esc_attr( $uid ) ?>.wf-grid--reveal.wf-grid--js .wf-grid-item.is-in{opacity:1;transform:none;}
<?php endif; ?>
@media(max-width:959px){
	#<?= esc_attr( $uid ) ?>.wf-grid{grid-template-columns:repeat(<?= $colsT ?>,minmax(0,1fr));}
}
@media(max-width:639px){
	#<?= esc_attr( $uid ) ?>.wf-grid{grid-template-columns:repeat(<?= $colsM ?>,minmax(0,1fr));}
}
</style>

<script>
(function(){
	var root = document.getElementById('<?= esc_js( $uid ) ?>');
	if (!root) { return; }

	var reduced = false;
	if (typeof WF !== 'undefined') { if (WF.reducedMotion) { reduced = WF.reducedMotion(); } }

	/* Garde-fou : l'état masqué n'existe que si le JS tourne vraiment.
	   Sans JS (ou en cas d'erreur), les cartes restent visibles. */
	var doReveal = <?= 'none' !== $reveal ? 'true' : 'false' ?>;
	if (doReveal) { root.classList.add('wf-grid--js'); }

	var items   = root.querySelectorAll('.wf-grid-item');
	var stagger = <?= $stag ?>;
	var cntDur  = <?= $cntDur ?>;
	var cFrom   = <?= 0 + $cFrom ?>;
	var easeName = '<?= esc_js( $cEase ) ?>';

	/* Courbes disponibles dans le panneau. */
	function ease(p){
		if (easeName === 'linear')   { return p; }
		if (easeName === 'out-expo') { return p === 1 ? 1 : 1 - Math.pow(2, -10 * p); }
		if (easeName === 'in-out')   { return p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2; }
		if (easeName === 'back')     { var c1 = 1.70158, c3 = c1 + 1, u = p - 1;
		                               return 1 + c3 * u * u * u + c1 * u * u; }
		return 1 - Math.pow(1 - p, 3);
	}

	/* Chiffre : 0 → valeur cible, easing doux, séparateur de milliers en espace fine. */
	function runCount(node){
		var target = parseFloat(node.getAttribute('data-target'));
		if (isNaN(target)) { return; }
		var dec = parseInt(node.getAttribute('data-decimals') || '0', 10);
		var pre = node.getAttribute('data-prefix') || '';
		var suf = node.getAttribute('data-suffix') || '';
		function out(v){
			return pre + v.toFixed(dec).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + suf;
		}
		if (reduced) { node.textContent = out(target); return; }
		if (cntDur <= 0) { node.textContent = out(target); return; }
		var start = null;
		var from  = cFrom;
		function step(ts){
			if (!start) { start = ts; }
			var p = Math.min((ts - start) / cntDur, 1);
			var e = ease(p);
			node.textContent = out(from + (target - from) * e);
			if (p < 1) { requestAnimationFrame(step); }
		}
		requestAnimationFrame(step);
	}

	/* La carte est rendue avec sa valeur finale (secours sans JS / SEO).
	   Si l'animation va jouer, on repart de 0 tout de suite pour éviter le saut. */
	function fmt(node, v){
		var dec = parseInt(node.getAttribute('data-decimals') || '0', 10);
		var pre = node.getAttribute('data-prefix') || '';
		var suf = node.getAttribute('data-suffix') || '';
		return pre + v.toFixed(dec).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + suf;
	}
	if (!reduced) {
		if (cntDur > 0) {
			var pre0 = root.querySelectorAll('.wf-grid-num[data-target]');
			for (var k = 0; k < pre0.length; k++) { pre0[k].textContent = fmt(pre0[k], cFrom); }
			var bar0 = root.querySelectorAll('.wf-grid-bar-fill[data-pct]');
			for (var b = 0; b < bar0.length; b++) { bar0[b].style.width = '0%'; }
		}
	}

	/* Barre : même durée et même courbe que le chiffre, pour qu'ils avancent ensemble. */
	function runBar(node){
		var pct = parseFloat(node.getAttribute('data-pct'));
		if (isNaN(pct)) { return; }
		if (reduced) { node.style.width = pct + '%'; return; }
		if (cntDur <= 0) { node.style.width = pct + '%'; return; }
		var start = null;
		function step(ts){
			if (!start) { start = ts; }
			var p = Math.min((ts - start) / cntDur, 1);
			node.style.width = (pct * ease(p)) + '%';
			if (p < 1) { requestAnimationFrame(step); }
		}
		requestAnimationFrame(step);
	}

	var txtRev  = '<?= esc_js( $txtRev ) ?>';
	var txtStag = <?= $txtStag ?>;

	/* Découpe le texte en spans animables.
	   Le texte complet est remis en aria-label et les morceaux sont
	   masqués aux lecteurs d'écran : on n'épelle pas mot par mot. */
	function splitText(node){
		var txt = node.textContent;
		if (!txt) { return []; }
		node.setAttribute('aria-label', txt);
		node.textContent = '';
		var parts = txtRev === 'chars' ? txt.split('') : txt.split(/(\s+)/);
		var frag = document.createDocumentFragment();
		var out = [];
		for (var i = 0; i < parts.length; i++) {
			var sp = document.createElement('span');
			sp.className = 'wf-grid-t';
			sp.setAttribute('aria-hidden', 'true');
			sp.textContent = parts[i];
			frag.appendChild(sp);
			if (parts[i].replace(/\s/g, '') !== '') { out.push(sp); }
		}
		node.appendChild(frag);
		return out;
	}

	/* Préparation avant peinture, sinon le texte clignote. */
	var textNodes = [];
	if (txtRev !== 'none') {
		if (!reduced) {
			var cand = root.querySelectorAll('.wf-grid-title, .wf-grid-label');
			for (var c = 0; c < cand.length; c++) {
				if (txtRev === 'fade') {
					cand[c].classList.add('wf-grid-fade');
					textNodes.push({ node: cand[c], parts: null });
				} else {
					textNodes.push({ node: cand[c], parts: splitText(cand[c]) });
				}
			}
		}
	}

	function revealText(item, delay){
		if (txtRev === 'none') { return; }
		if (reduced) { return; }
		for (var i = 0; i < textNodes.length; i++) {
			var entry = textNodes[i];
			if (!item.contains(entry.node)) { continue; }
			if (entry.parts === null) {
				(function(nd, d){ setTimeout(function(){ nd.classList.add('is-in'); }, d); })(entry.node, delay);
			} else {
				for (var j = 0; j < entry.parts.length; j++) {
					(function(sp, d){ setTimeout(function(){ sp.classList.add('is-in'); }, d); })(entry.parts[j], delay + j * txtStag);
				}
			}
		}
	}

	function activate(item, delay){
		revealText(item, delay);
		if (doReveal) {
			if (reduced) { item.classList.add('is-in'); }
			else { setTimeout(function(){ item.classList.add('is-in'); }, delay); }
		}
		var nums = item.querySelectorAll('.wf-grid-num[data-target]');
		for (var i = 0; i < nums.length; i++) {
			(function(n, d){
				if (reduced) { runCount(n); }
				else { setTimeout(function(){ runCount(n); }, d); }
			})(nums[i], delay);
		}
		var bars = item.querySelectorAll('.wf-grid-bar-fill[data-pct]');
		for (var j = 0; j < bars.length; j++) {
			(function(n, d){
				if (reduced) { runBar(n); }
				else { setTimeout(function(){ runBar(n); }, d); }
			})(bars[j], delay);
		}
	}

	function start(){
		for (var i = 0; i < items.length; i++) {
			activate(items[i], reduced ? 0 : i * stagger);
		}
	}

	if (typeof WF !== 'undefined') {
		if (WF.onVisible) { WF.onVisible(root, start, 0.15); return; }
	}
	start();
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
