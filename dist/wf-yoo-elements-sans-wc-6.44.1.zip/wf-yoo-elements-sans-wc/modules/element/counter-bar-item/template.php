<?php
defined('ABSPATH') || exit;
$label = $props['label']??''; $val = max(0,min(100,(int)($props['value']??75)));
$color = $props['bar_color']??'#EA5C1C'; $showPct = !empty($props['show_pct']);
$suffix = $props['suffix']??'%';
$bh = (int)($element['bar_height']??12); $bbg = $element['bar_bg']??'#e5e5e5';
$br = (int)($element['bar_radius']??100); $dur = (int)($element['duration']??1500);
?>
<div>
    <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:6px;">
        <?php if ($label) : ?><span style="font-size:14px;font-weight:600;"><?= esc_html($label) ?></span><?php endif; ?>
        <?php if ($showPct) : ?><span style="font-size:14px;font-weight:700;color:<?= esc_attr($color) ?>;"><?= $val ?><?= esc_html($suffix) ?></span><?php endif; ?>
    </div>
    <div style="height:<?= $bh ?>px;background:<?= esc_attr($bbg) ?>;border-radius:<?= $br ?>px;overflow:hidden;">
        <div class="wf-cb-fill" data-target="<?= $val ?>" style="height:100%;width:0;background:<?= esc_attr($color) ?>;border-radius:<?= $br ?>px;transition:width <?= $dur ?>ms cubic-bezier(.25,.8,.25,1);"></div>
    </div>
</div>
