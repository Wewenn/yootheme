<?php
/**
 * WeFrame – Texte en cercle | template.php v1.0
 * Le texte est disposé lettre par lettre autour d'un cercle, l'ensemble tourne.
 *
 * Chaque lettre est un <span> tourné et écarté du centre : pas de textPath SVG,
 * donc la police du thème s'applique normalement. Le texte complet est répété
 * en clair pour les lecteurs d'écran, les lettres isolées étant illisibles pour
 * eux.
 */
defined( 'ABSPATH' ) || exit;

$text = (string) ( $props['text'] ?? '' );
if ( '' === trim( $text ) ) { return; }

$size  = max( 100, (int) ( $props['size'] ?? 220 ) );
$fs    = max( 8, (int) ( $props['font_size'] ?? 15 ) );
$fw    = (string) ( $props['weight'] ?? '700' );
$ls    = max( 0, (float) ( $props['letter_spacing'] ?? 2 ) );
$upper = ! empty( $props['uppercase'] );
$speed = max( 2, (int) ( $props['speed'] ?? 18 ) );
$rev   = ! empty( $props['reverse'] );
$pause = ! empty( $props['pause_hover'] );
$col   = (string) ( $props['color'] ?? '#111111' );

$icon  = (string) ( $props['center_icon'] ?? 'arrow' );
$iCol  = (string) ( $props['center_color'] ?? '#EA5C1C' );
$iSize = max( 10, (int) ( $props['center_size'] ?? 34 ) );

$link = $props['link'] ?? '';
if ( is_array( $link ) ) { $link = $link['url'] ?? ''; }
$link = trim( (string) $link );

$icons = array(
	'arrow' => '<path d="M200,64V168a8,8,0,0,1-16,0V83.31L69.66,197.66a8,8,0,0,1-11.32-11.32L172.69,72H88a8,8,0,0,1,0-16H192A8,8,0,0,1,200,64Z"/>',
	'plus'  => '<path d="M224,128a8,8,0,0,1-8,8H136v80a8,8,0,0,1-16,0V136H40a8,8,0,0,1,0-16h80V40a8,8,0,0,1,16,0v80h80A8,8,0,0,1,224,128Z"/>',
	'dot'   => '<circle cx="128" cy="128" r="48"/>',
	'play'  => '<path d="M232.4,114.49,88.32,26.35a16,16,0,0,0-16.2-.3A15.86,15.86,0,0,0,64,39.87V216.13A15.94,15.94,0,0,0,80,232a16.07,16.07,0,0,0,8.36-2.35L232.4,141.51a15.81,15.81,0,0,0,0-27Z"/>',
);

$chars = preg_split( '//u', $text, -1, PREG_SPLIT_NO_EMPTY );
$n = count( $chars );
if ( 0 === $n ) { return; }
$step = round( 360 / $n, 4 );

$uid = wf_uid( 'wfsx_', $props, $n );
$tag = ( '' !== $link ) ? 'a' : 'div';
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-sx<?= $pause ? ' wf-sx--pause' : '' ?>">
	<<?= $tag ?> class="__stage"<?= ( '' !== $link ) ? ' href="' . esc_url( $link ) . '"' : '' ?>>
		<span class="wf-sr"><?= esc_html( trim( $text ) ) ?></span>
		<span class="__ring" aria-hidden="true">
			<?php foreach ( $chars as $i => $ch ) : ?>
			<span class="__c" style="--i:<?= (int) $i ?>;"><?= esc_html( $ch ) ?></span>
			<?php endforeach; ?>
		</span>
		<?php if ( 'none' !== $icon && isset( $icons[ $icon ] ) ) : ?>
		<span class="__center" aria-hidden="true">
			<svg viewBox="0 0 256 256" width="<?= (int) $iSize ?>" height="<?= (int) $iSize ?>" fill="currentColor"><?= $icons[ $icon ] ?></svg>
		</span>
		<?php endif; ?>
	</<?= $tag ?>>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?>{display:flex;justify-content:center;}
#<?= esc_attr( $uid ) ?> .__stage{
	position:relative;display:block;text-decoration:none;color:<?= esc_attr( $col ) ?>;
	width:min(<?= (int) $size ?>px,100%);aspect-ratio:1 / 1;
}
#<?= esc_attr( $uid ) ?> .__stage:focus-visible{outline:2px solid <?= esc_attr( $iCol ) ?>;outline-offset:6px;border-radius:50%;}
#<?= esc_attr( $uid ) ?> .__ring{
	position:absolute;inset:0;display:block;
	animation:<?= esc_attr( $uid ) ?>-turn <?= (int) $speed ?>s linear infinite<?= $rev ? ' reverse' : '' ?>;
}
#<?= esc_attr( $uid ) ?> .__c{
	position:absolute;left:50%;top:50%;display:block;
	font-size:<?= (int) $fs ?>px;font-weight:<?= esc_attr( $fw ) ?>;line-height:1;
	letter-spacing:<?= esc_attr( $ls ) ?>px;
	<?= $upper ? 'text-transform:uppercase;' : '' ?>
	/* on tourne jusqu'a la position de la lettre, puis on l'ecarte du centre */
	transform:translate(-50%,-50%) rotate(calc(var(--i) * <?= esc_attr( $step ) ?>deg)) translateY(-<?= (int) round( $size / 2 - $fs ) ?>px);
	transform-origin:50% 50%;
}
#<?= esc_attr( $uid ) ?> .__center{
	position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);
	color:<?= esc_attr( $iCol ) ?>;display:flex;
}
#<?= esc_attr( $uid ) ?> .wf-sr{
	position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;
	clip:rect(0,0,0,0);white-space:nowrap;border:0;
}
@keyframes <?= esc_attr( $uid ) ?>-turn{to{transform:rotate(1turn)}}
<?php if ( $pause ) : ?>
#<?= esc_attr( $uid ) ?>.wf-sx--pause:hover .__ring,
#<?= esc_attr( $uid ) ?>.wf-sx--pause:focus-within .__ring{animation-play-state:paused;}
<?php endif; ?>
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?> .__ring{animation:none;}
}
</style>
