<?php
/**
 * WeFrame – Avis en ligne de texte | template.php v1.0
 * Les avis s'enchainent dans un paragraphe, portraits ronds insérés dans le fil.
 * Survoler (ou atteindre au clavier) un avis met les autres en retrait et
 * decouvre son auteur.
 *
 * Zero JS : tout tient en :hover / :focus-within. Chaque avis est focusable,
 * sinon l'effet n'existerait que pour la souris. Une option affiche les auteurs
 * en permanence, pour l'impression ou les pages qui doivent rester sobres.
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$fs    = max( 14, (int) ( $props['font_size'] ?? 30 ) );
$fsMin = max( 12, (int) ( $props['font_size_min'] ?? 18 ) );
if ( $fsMin > $fs ) { $fsMin = $fs; }
$fw    = (string) ( $props['weight'] ?? '500' );
$lh    = max( 1, min( 2.4, (float) ( $props['line_height'] ?? 1.5 ) ) );
$align = (string) ( $props['align'] ?? 'left' );
if ( ! in_array( $align, array( 'left', 'center', 'justify' ), true ) ) { $align = 'left'; }
$maxW  = max( 300, (int) ( $props['max_width'] ?? 900 ) );

$av    = max( 0, (int) ( $props['avatar_size'] ?? 32 ) );
$blur  = max( 0, min( 12, (int) ( $props['blur'] ?? 5 ) ) );
$dim   = max( 0, min( 100, (int) ( $props['dim'] ?? 25 ) ) );
$acc   = (string) ( $props['accent_color'] ?? '#f97316' );
$txt   = (string) ( $props['text_color'] ?? '#111111' );
$sep   = trim( (string) ( $props['separator'] ?? '' ) );
$quo   = ! empty( $props['quotes'] );
$always = ! empty( $props['always_author'] );

$list = array();
foreach ( $children as $child ) {
	$cp    = (array) ( $child->props ?? array() );
	$quote = trim( (string) ( $cp['quote'] ?? '' ) );
	if ( '' === $quote ) { continue; }

	$img = $cp['image'] ?? '';
	if ( is_array( $img ) ) { $img = $img['src'] ?? ( $img['url'] ?? '' ); }

	$link = $cp['link'] ?? '';
	if ( is_array( $link ) ) { $link = $link['url'] ?? ''; }

	$list[] = array(
		'quote'  => $quote,
		'author' => trim( (string) ( $cp['author'] ?? '' ) ),
		'role'   => trim( (string) ( $cp['role'] ?? '' ) ),
		'img'    => trim( (string) $img ),
		'link'   => trim( (string) $link ),
	);
}
if ( empty( $list ) ) { return; }
$n = count( $list );

$uid = wf_uid( 'wfit_', $props, $n );
$cls = 'wf-it';
if ( $always ) { $cls .= ' wf-it--always'; }
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="<?= esc_attr( $cls ) ?>">
	<p class="__flow">
		<?php foreach ( $list as $i => $t ) : ?>
		<span class="__q" tabindex="0">
			<?php if ( $av > 0 && '' !== $t['img'] ) : ?>
			<img class="__av" src="<?= esc_url( $t['img'] ) ?>" alt="" loading="lazy" decoding="async" aria-hidden="true">
			<?php endif; ?>
			<span class="__txt"><?= $quo ? '«&nbsp;' : '' ?><?= esc_html( $t['quote'] ) ?><?= $quo ? '&nbsp;»' : '' ?></span>
			<?php if ( '' !== $t['author'] ) : ?>
			<span class="__who">
				<?php if ( '' !== $t['link'] ) : ?><a href="<?= esc_url( $t['link'] ) ?>"><?= esc_html( $t['author'] ) ?></a><?php else : ?><?= esc_html( $t['author'] ) ?><?php endif; ?><?php if ( '' !== $t['role'] ) : ?><span class="__role">, <?= esc_html( $t['role'] ) ?></span><?php endif; ?>
			</span>
			<?php endif; ?>
		</span><?php if ( '' !== $sep && $i < $n - 1 ) : ?><span class="__sep" aria-hidden="true"> <?= esc_html( $sep ) ?> </span><?php endif; ?>
		<?php endforeach; ?>
	</p>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?>{container-type:inline-size;}
#<?= esc_attr( $uid ) ?> .__flow{
	margin:0;max-width:<?= (int) $maxW ?>px;
	<?= 'center' === $align ? 'margin-inline:auto;' : '' ?>
	text-align:<?= esc_attr( $align ) ?>;
	font-size:clamp(<?= (int) $fsMin ?>px, 4cqw, <?= (int) $fs ?>px);
	font-weight:<?= esc_attr( $fw ) ?>;line-height:<?= esc_attr( $lh ) ?>;
	color:<?= esc_attr( $txt ) ?>;
}
#<?= esc_attr( $uid ) ?> .__q{
	display:inline;border-radius:6px;
	transition:filter .35s ease,opacity .35s ease;
}
#<?= esc_attr( $uid ) ?> .__q:focus-visible{outline:2px solid <?= esc_attr( $acc ) ?>;outline-offset:3px;}
#<?= esc_attr( $uid ) ?> .__av{
	width:<?= (int) $av ?>px;height:<?= (int) $av ?>px;border-radius:50%;object-fit:cover;
	display:inline-block;vertical-align:middle;margin-right:.28em;
	transform:translateY(-.06em);
}
#<?= esc_attr( $uid ) ?> .__sep{color:<?= esc_attr( $acc ) ?>;opacity:.5;}
#<?= esc_attr( $uid ) ?> .__who{
	color:<?= esc_attr( $acc ) ?>;font-weight:700;white-space:nowrap;
	font-size:.72em;
	display:inline-block;max-width:0;overflow:hidden;vertical-align:middle;
	opacity:0;transform:translateY(.15em);
	transition:max-width .4s cubic-bezier(.2,.8,.2,1),opacity .3s ease,transform .3s ease;
}
#<?= esc_attr( $uid ) ?> .__who a{color:inherit;text-decoration:none;}
#<?= esc_attr( $uid ) ?> .__who a:hover{text-decoration:underline;}
#<?= esc_attr( $uid ) ?> .__role{font-weight:400;opacity:.8;}

/* Mise en retrait des autres avis pendant qu'on en regarde un. */
<?php if ( $blur > 0 || $dim < 100 ) : ?>
#<?= esc_attr( $uid ) ?> .__flow:hover .__q,
#<?= esc_attr( $uid ) ?> .__flow:focus-within .__q{
	<?= $blur > 0 ? 'filter:blur(' . (int) $blur . 'px);' : '' ?>
	opacity:<?= esc_attr( round( $dim / 100, 2 ) ) ?>;
}
<?php endif; ?>
#<?= esc_attr( $uid ) ?> .__flow .__q:hover,
#<?= esc_attr( $uid ) ?> .__flow .__q:focus-within,
#<?= esc_attr( $uid ) ?> .__flow .__q:focus{
	filter:none;opacity:1;
}
#<?= esc_attr( $uid ) ?> .__q:hover .__who,
#<?= esc_attr( $uid ) ?> .__q:focus .__who,
#<?= esc_attr( $uid ) ?> .__q:focus-within .__who,
#<?= esc_attr( $uid ) ?>.wf-it--always .__who{
	max-width:24ch;opacity:1;transform:none;margin-left:.3em;
}
@media (pointer:coarse){
	/* Au doigt il n'y a pas de survol : on montre tout. */
	#<?= esc_attr( $uid ) ?> .__who{max-width:24ch;opacity:1;transform:none;margin-left:.3em;}
	#<?= esc_attr( $uid ) ?> .__flow:hover .__q{filter:none;opacity:1;}
}
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?> .__q,#<?= esc_attr( $uid ) ?> .__who{transition-duration:.001ms;}
}
@media print{
	#<?= esc_attr( $uid ) ?> .__who{max-width:none;opacity:1;transform:none;}
	#<?= esc_attr( $uid ) ?> .__q{filter:none;opacity:1;}
}
</style>
