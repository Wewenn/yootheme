<?php
/**
 * WeFrame – Globe à points | template.php v1.0
 * Une sphère de points qui tourne, avec vos villes marquées dessus.
 *
 * Dessiné dans un <canvas> avec de la trigonométrie : pas de three.js, pas de
 * WebGL, ~4 Ko de script. Les points sont répartis en spirale de Fibonacci,
 * la seule méthode simple qui donne une densité régulière sur une sphère.
 *
 * La liste des lieux est aussi rendue en texte, masquée visuellement : sans
 * canvas ni JS, l'information reste lisible et indexable.
 * Pas de "&&" ni de "||" dans le JS inline (regle interne du plugin).
 */
defined( 'ABSPATH' ) || exit;

$size  = max( 200, (int) ( $props['size'] ?? 460 ) );
$dots  = max( 200, min( 4000, (int) ( $props['dots'] ?? 1400 ) ) );
$dSize = max( 0.5, min( 5, (float) ( $props['dot_size'] ?? 1.6 ) ) );
$speed = max( 5, (int) ( $props['speed'] ?? 40 ) );
$tilt  = max( -45, min( 45, (int) ( $props['tilt'] ?? 18 ) ) );

$gCol  = (string) ( $props['globe_color'] ?? '#2a3550' );
$dCol  = (string) ( $props['dot_color'] ?? '#7f8db0' );
$mCol  = (string) ( $props['marker_color'] ?? '#EA5C1C' );
$bg    = trim( (string) ( $props['bg'] ?? '' ) );
$glow  = ! empty( $props['glow'] );
$drag  = ! empty( $props['drag'] );

$marks = array();
if ( ! empty( $children ) ) {
	foreach ( $children as $child ) {
		$cp  = (array) ( $child->props ?? array() );
		$lab = trim( (string) ( $cp['label'] ?? '' ) );
		$marks[] = array(
			'label' => $lab,
			'lat'   => max( -90, min( 90, (float) ( $cp['lat'] ?? 0 ) ) ),
			'lng'   => max( -180, min( 180, (float) ( $cp['lng'] ?? 0 ) ) ),
		);
	}
}

$uid  = wf_uid( 'wfgl_', $props, count( $marks ) );
$json = wp_json_encode( $marks );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-gl<?= $glow ? ' wf-gl--glow' : '' ?>" data-marks="<?= esc_attr( $json ) ?>">
	<div class="__stage"></div>
	<?php if ( ! empty( $marks ) ) : ?>
	<ul class="wf-sr">
		<?php foreach ( $marks as $m ) : ?>
		<?php if ( '' === $m['label'] ) { continue; } ?>
		<li><?= esc_html( $m['label'] ) ?></li>
		<?php endforeach; ?>
	</ul>
	<?php endif; ?>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?>{display:flex;justify-content:center;<?= '' !== $bg ? 'background:' . esc_attr( $bg ) . ';' : '' ?>}
#<?= esc_attr( $uid ) ?> .__stage{
	position:relative;width:min(<?= (int) $size ?>px,100%);aspect-ratio:1 / 1;
}
#<?= esc_attr( $uid ) ?> canvas{width:100%;height:100%;display:block;<?= $drag ? 'cursor:grab;touch-action:none;' : '' ?>}
#<?= esc_attr( $uid ) ?> canvas.is-grabbing{cursor:grabbing;}
<?php if ( $glow ) : ?>
#<?= esc_attr( $uid ) ?> .__stage::before{
	content:"";position:absolute;inset:6%;border-radius:50%;z-index:0;
	background:radial-gradient(circle at 50% 50%,<?= esc_attr( $mCol ) ?>33,transparent 68%);
	filter:blur(24px);
}
<?php endif; ?>
#<?= esc_attr( $uid ) ?> .wf-sr{
	position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;
	clip:rect(0,0,0,0);white-space:nowrap;border:0;
}
</style>

<script>
(function(){
	var root = document.getElementById('<?= esc_js( $uid ) ?>');
	if (!root) { return; }
	var stage = root.querySelector('.__stage');
	if (!stage) { return; }

	var N = <?= (int) $dots ?>;
	var DOT = <?= esc_js( (string) $dSize ) ?>;
	var SPEED = <?= (int) $speed ?>;
	var TILT = <?= (int) $tilt ?> * Math.PI / 180;
	var C_GLOBE = '<?= esc_js( $gCol ) ?>';
	var C_DOT = '<?= esc_js( $dCol ) ?>';
	var C_MARK = '<?= esc_js( $mCol ) ?>';
	var DRAG = <?= $drag ? 'true' : 'false' ?>;

	var marks = [];
	try { marks = JSON.parse(root.getAttribute('data-marks')); } catch (err) { marks = []; }
	if (!Array.isArray(marks)) { marks = []; }

	var canvas = document.createElement('canvas');
	stage.appendChild(canvas);
	var ctx = canvas.getContext('2d');
	if (!ctx) { return; }

	var W = 0, H = 0, R = 0, dpr = 1;

	// Spirale de Fibonacci : repartition reguliere sans zones vides aux poles.
	var pts = [];
	(function(){
		var golden = Math.PI * (3 - Math.sqrt(5));
		for (var i = 0; i < N; i++) {
			var y = 1 - (i / (N - 1)) * 2;
			var r = Math.sqrt(1 - y * y);
			var th = golden * i;
			pts.push([Math.cos(th) * r, y, Math.sin(th) * r]);
		}
	})();

	function toXYZ(lat, lng){
		var phi = (90 - lat) * Math.PI / 180;
		var th = (lng + 180) * Math.PI / 180;
		return [
			-Math.sin(phi) * Math.cos(th),
			Math.cos(phi),
			Math.sin(phi) * Math.sin(th)
		];
	}
	var mpts = marks.map(function(m){ return toXYZ(m.lat, m.lng); });

	function resize(){
		var r = stage.getBoundingClientRect();
		if (r.width < 2) { return; }
		var ratio = window.devicePixelRatio;
		if (!ratio) { ratio = 1; }
		dpr = Math.min(2, ratio);
		W = r.width; H = r.height;
		canvas.width = Math.ceil(W * dpr);
		canvas.height = Math.ceil(H * dpr);
		R = Math.min(W, H) / 2 * 0.92;
	}

	var spin = 0;
	var manual = 0;

	function project(p, a){
		// rotation autour de l'axe vertical, puis inclinaison
		var x = p[0] * Math.cos(a) - p[2] * Math.sin(a);
		var z = p[0] * Math.sin(a) + p[2] * Math.cos(a);
		var y = p[1] * Math.cos(TILT) - z * Math.sin(TILT);
		var zz = p[1] * Math.sin(TILT) + z * Math.cos(TILT);
		return [x, y, zz];
	}

	function draw(){
		if (!R) { return; }
		ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		ctx.clearRect(0, 0, W, H);
		var cx = W / 2, cy = H / 2;
		var a = spin + manual;

		ctx.fillStyle = C_GLOBE;
		ctx.beginPath();
		ctx.arc(cx, cy, R, 0, Math.PI * 2);
		ctx.fill();

		for (var i = 0; i < pts.length; i++) {
			var p = project(pts[i], a);
			if (p[2] < 0) { continue; }          // face cachee
			var d = 0.35 + 0.65 * p[2];          // plus pale vers le bord
			ctx.globalAlpha = d;
			ctx.fillStyle = C_DOT;
			ctx.beginPath();
			ctx.arc(cx + p[0] * R, cy - p[1] * R, DOT * d, 0, Math.PI * 2);
			ctx.fill();
		}

		ctx.globalAlpha = 1;
		for (var m = 0; m < mpts.length; m++) {
			var q = project(mpts[m], a);
			if (q[2] < 0) { continue; }
			var s = DOT * 2.6;
			var x = cx + q[0] * R, y = cy - q[1] * R;
			ctx.fillStyle = C_MARK;
			ctx.beginPath();
			ctx.arc(x, y, s, 0, Math.PI * 2);
			ctx.fill();
			ctx.globalAlpha = 0.28;
			ctx.beginPath();
			ctx.arc(x, y, s * 2.4, 0, Math.PI * 2);
			ctx.fill();
			ctx.globalAlpha = 1;
		}
	}

	var reduced = false;
	if (window.matchMedia) {
		if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { reduced = true; }
	}

	var last = 0;
	var running = false;
	function loop(ts){
		if (!running) { return; }
		if (!last) { last = ts; }
		spin += ((ts - last) / 1000) * (Math.PI * 2 / SPEED);
		last = ts;
		draw();
		requestAnimationFrame(loop);
	}

	function start(){
		if (running) { return; }
		running = true;
		last = 0;
		requestAnimationFrame(loop);
	}

	resize();
	draw();
	window.addEventListener('resize', function(){ resize(); draw(); });
	if (window.ResizeObserver) { new ResizeObserver(function(){ resize(); draw(); }).observe(stage); }

<?php if ( $drag ) : ?>
	// Rotation a la main : on suspend la rotation auto le temps du glissement.
	var dragging = false, sx = 0, base = 0;
	canvas.addEventListener('pointerdown', function(e){
		dragging = true; sx = e.clientX; base = manual;
		running = false;
		canvas.classList.add('is-grabbing');
		canvas.setPointerCapture(e.pointerId);
	});
	canvas.addEventListener('pointermove', function(e){
		if (!dragging) { return; }
		manual = base + (e.clientX - sx) / 120;
		draw();
	});
	function release(){
		if (!dragging) { return; }
		dragging = false;
		canvas.classList.remove('is-grabbing');
		if (!reduced) { start(); }
	}
	canvas.addEventListener('pointerup', release);
	canvas.addEventListener('pointercancel', release);
<?php endif; ?>

	if (reduced) { return; }
	if (typeof WF !== 'undefined') {
		if (WF.onVisible) { WF.onVisible(root, start, 0.2); return; }
	}
	start();
})();
</script>
