<?php
/**
 * WeFrame - Liste animee (element enfant) | template.php v1.0
 * Le parent lit les proprietes de l'enfant : celui-ci n'affiche rien seul.
 */
defined( 'ABSPATH' ) || exit;
echo '';
