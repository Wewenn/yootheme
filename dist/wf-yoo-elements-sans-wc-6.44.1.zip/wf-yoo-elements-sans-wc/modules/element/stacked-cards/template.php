<?php
/**
 * WeFrame – Cartes empilées | template.php v1.0
 * Quatre dispositions : empilement au defilement (sticky, zero JS), colonne,
 * ligne horizontale ou grille — ces trois-la sans aucune animation.
 * Reorganisation facultative a la souris ET au clavier (poignee focusable,
 * fleches pour deplacer, annonce vocale) : le glisser-deposer seul exclurait
 * une partie des visiteurs.
 * Pas de "&&" ni de "||" dans le JS inline (regle interne du plugin).
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$mode = (string) ( $props['mode'] ?? 'stack' );
if ( ! in_array( $mode, array( 'stack', 'column', 'row', 'grid' ), true ) ) { $mode = 'stack'; }

$stickTop = max( 0, (int) ( $props['stick_top'] ?? 100 ) );
$dwell    = max( 40, min( 140, (int) ( $props['dwell'] ?? 70 ) ) );
$stepOff  = max( 0, (int) ( $props['step_offset'] ?? 20 ) );
$stepSc   = max( 0, min( 0.15, (float) ( $props['step_scale'] ?? 0.03 ) ) );
$tilt     = max( 0, min( 6, (float) ( $props['tilt'] ?? 1.2 ) ) );

$cols  = max( 1, min( 6, (int) ( $props['columns'] ?? 3 ) ) );
$colsT = max( 1, min( 4, (int) ( $props['columns_tablet'] ?? 2 ) ) );
$gap   = max( 0, (int) ( $props['gap'] ?? 20 ) );

$drag    = ( 'stack' !== $mode ) && ! empty( $props['drag'] );
$dragMem = $drag && ! empty( $props['drag_remember'] );

$cBg   = (string) ( $props['card_bg'] ?? '#ffffff' );
$cCol  = (string) ( $props['card_color'] ?? '#111111' );
$cMut  = (string) ( $props['card_muted'] ?? '#6b7280' );
$cBd   = trim( (string) ( $props['card_border'] ?? '' ) );
$cRad  = max( 0, (int) ( $props['card_radius'] ?? 18 ) );
$cPad  = max( 0, (int) ( $props['card_padding'] ?? 28 ) );
$cMinH = max( 0, (int) ( $props['card_min_height'] ?? 180 ) );
$shadow = ! empty( $props['shadow'] );

$nSize = max( 9, (int) ( $props['num_size'] ?? 13 ) );
$nCol  = (string) ( $props['num_color'] ?? '#9aa0a6' );
$tSize = max( 13, (int) ( $props['title_size'] ?? 22 ) );
$acc   = (string) ( $props['accent_color'] ?? '#EA5C1C' );

$n   = count( $children );
$uid = wf_uid( 'wfsc_', $props, $n );

$cards = array();
foreach ( $children as $i => $child ) {
	$cp = (array) ( $child->props ?? array() );
	$st = '';
	$sp = max( 1, min( 3, (int) ( $cp['span'] ?? 1 ) ) );
	if ( 'grid' === $mode && $sp > 1 ) { $st .= 'grid-column:span ' . $sp . ';'; }
	$bg = trim( (string) ( $cp['bg_override'] ?? '' ) );
	$co = trim( (string) ( $cp['color_override'] ?? '' ) );
	if ( '' !== $bg ) { $st .= 'background:' . esc_attr( $bg ) . ';'; }
	if ( '' !== $co ) { $st .= 'color:' . esc_attr( $co ) . ';'; }

	$title = trim( (string) ( $cp['title'] ?? '' ) );
	if ( '' === $title ) { $title = sprintf( __( 'Carte %d', 'weframe' ), $i + 1 ); }

	$cards[] = array(
		'html'  => $builder->render( $child, array( 'element' => $props, 'index' => $i ) ),
		'style' => $st,
		'title' => $title,
		'i'     => $i,
	);
}

$rootCls = 'wf-sc wf-sc--' . $mode;
if ( $drag ) { $rootCls .= ' wf-sc--drag'; }
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="<?= esc_attr( $rootCls ) ?>"<?= $drag ? ' data-remember="' . ( $dragMem ? '1' : '0' ) . '"' : '' ?>>
	<?php foreach ( $cards as $c ) : ?>
	<article class="wf-sc__card" style="--i:<?= (int) $c['i'] ?>;<?= $c['style'] ?>" data-pos="<?= (int) $c['i'] ?>">
		<?php if ( $drag ) : ?>
		<button type="button" class="__grip" aria-label="<?= esc_attr( sprintf( __( 'Déplacer : %s', 'weframe' ), $c['title'] ) ) ?>">
			<svg viewBox="0 0 256 256" width="16" height="16" fill="currentColor" aria-hidden="true" focusable="false"><path d="M104,60A12,12,0,1,1,92,48,12,12,0,0,1,104,60Zm60,12a12,12,0,1,0-12-12A12,12,0,0,0,164,72ZM92,116a12,12,0,1,0,12,12A12,12,0,0,0,92,116Zm72,0a12,12,0,1,0,12,12A12,12,0,0,0,164,116ZM92,184a12,12,0,1,0,12,12A12,12,0,0,0,92,184Zm72,0a12,12,0,1,0,12,12A12,12,0,0,0,164,184Z"/></svg>
		</button>
		<?php endif; ?>
		<div class="__body"><?= $c['html'] ?></div>
	</article>
	<?php endforeach; ?>
</div>
<?php if ( $drag ) : ?>
<p class="wf-sc__live" id="<?= esc_attr( $uid ) ?>-live" role="status" aria-live="polite"></p>
<?php endif; ?>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?>{container-type:inline-size;}
#<?= esc_attr( $uid ) ?> .wf-sc__card{
	position:relative;min-width:0;
	background:<?= esc_attr( $cBg ) ?>;color:<?= esc_attr( $cCol ) ?>;
	border-radius:<?= (int) $cRad ?>px;padding:<?= (int) $cPad ?>px;
	<?= '' !== $cBd ? 'border:1px solid ' . esc_attr( $cBd ) . ';' : '' ?>
	<?= $cMinH > 0 ? 'min-height:' . (int) $cMinH . 'px;' : '' ?>
	<?= $shadow ? 'box-shadow:0 18px 44px rgba(0,0,0,.10);' : '' ?>
	display:flex;flex-direction:column;gap:.55em;
}
#<?= esc_attr( $uid ) ?> .__body{display:flex;flex-direction:column;gap:.55em;min-width:0;}
#<?= esc_attr( $uid ) ?> .__num{
	font-size:<?= (int) $nSize ?>px;font-weight:700;letter-spacing:.12em;
	font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
	color:<?= esc_attr( $nCol ) ?>;
}
#<?= esc_attr( $uid ) ?> .__icon{
	display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;
	border-radius:12px;background:<?= esc_attr( $acc ) ?>;color:#fff;flex:0 0 auto;
}
#<?= esc_attr( $uid ) ?> .__title{margin:0;font-size:<?= (int) $tSize ?>px;line-height:1.2;font-weight:700;}
#<?= esc_attr( $uid ) ?> .__title a{color:inherit;text-decoration:none;}
#<?= esc_attr( $uid ) ?> .__title a:hover{color:<?= esc_attr( $acc ) ?>;}
#<?= esc_attr( $uid ) ?> .__desc{margin:0;color:<?= esc_attr( $cMut ) ?>;line-height:1.55;}
#<?= esc_attr( $uid ) ?> .__linkline{margin:auto 0 0;}
#<?= esc_attr( $uid ) ?> .__linkline a{color:<?= esc_attr( $acc ) ?>;font-weight:700;text-decoration:none;}
#<?= esc_attr( $uid ) ?> .__arrow{
	position:absolute;right:<?= (int) max( 12, round( $cPad * .55 ) ) ?>px;bottom:<?= (int) max( 12, round( $cPad * .55 ) ) ?>px;
	display:inline-flex;align-items:center;justify-content:center;width:34px;height:34px;
	border-radius:50%;background:<?= esc_attr( $acc ) ?>;color:#fff;
	transition:transform .25s ease;
}
#<?= esc_attr( $uid ) ?> .wf-sc__card:hover .__arrow{transform:translate(2px,-2px);}
#<?= esc_attr( $uid ) ?> .wf-sc__live{margin:8px 0 0;font-size:13px;color:<?= esc_attr( $cMut ) ?>;}
#<?= esc_attr( $uid ) ?> .wf-sc__live:empty{margin:0;}

<?php if ( 'stack' === $mode ) : ?>
/* Empilement : chaque carte est collante et s'arrete un peu plus bas que la
   precedente. Le sticky porte sur l'element directement enfant du bloc haut,
   sinon la carte se decroche quand son propre bloc quitte l'ecran. */
#<?= esc_attr( $uid ) ?>{display:flex;flex-direction:column;}
#<?= esc_attr( $uid ) ?> .wf-sc__card{
	position:sticky;
	top:calc(<?= (int) $stickTop ?>px + var(--i) * <?= (int) $stepOff ?>px);
	min-height:max(<?= (int) $dwell ?>vh, <?= (int) ( $cMinH + 80 ) ?>px);
	<?= $stepSc > 0 ? 'transform-origin:50% 0;' : '' ?>
}
<?php if ( $tilt > 0 ) : ?>
#<?= esc_attr( $uid ) ?> .wf-sc__card:nth-child(odd){rotate:-<?= esc_attr( $tilt ) ?>deg;}
#<?= esc_attr( $uid ) ?> .wf-sc__card:nth-child(even){rotate:<?= esc_attr( $tilt ) ?>deg;}
<?php endif; ?>
<?php elseif ( 'column' === $mode ) : ?>
#<?= esc_attr( $uid ) ?>{display:flex;flex-direction:column;gap:<?= (int) $gap ?>px;}
<?php elseif ( 'row' === $mode ) : ?>
#<?= esc_attr( $uid ) ?>{display:flex;flex-direction:row;gap:<?= (int) $gap ?>px;overflow-x:auto;scroll-snap-type:x proximity;padding-bottom:4px;}
#<?= esc_attr( $uid ) ?> .wf-sc__card{flex:0 0 min(320px,80cqw);scroll-snap-align:start;}
<?php else : ?>
#<?= esc_attr( $uid ) ?>{display:grid;gap:<?= (int) $gap ?>px;grid-template-columns:repeat(<?= (int) $cols ?>,minmax(0,1fr));align-items:start;}
@container (max-width: 900px){
	#<?= esc_attr( $uid ) ?>{grid-template-columns:repeat(<?= (int) $colsT ?>,minmax(0,1fr));}
	#<?= esc_attr( $uid ) ?> .wf-sc__card{grid-column:span 1;}
}
@container (max-width: 560px){#<?= esc_attr( $uid ) ?>{grid-template-columns:1fr;}}
<?php endif; ?>

<?php if ( $drag ) : ?>
#<?= esc_attr( $uid ) ?> .__grip{
	position:absolute;top:10px;right:10px;z-index:2;
	display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;
	border:0;border-radius:8px;background:rgba(127,127,127,.12);color:<?= esc_attr( $cMut ) ?>;
	cursor:grab;touch-action:none;
}
#<?= esc_attr( $uid ) ?> .__grip:hover{background:rgba(127,127,127,.2);}
#<?= esc_attr( $uid ) ?> .__grip:focus-visible{outline:2px solid <?= esc_attr( $acc ) ?>;outline-offset:2px;}
@media (pointer:coarse){#<?= esc_attr( $uid ) ?> .__grip{width:44px;height:44px;}}
#<?= esc_attr( $uid ) ?> .wf-sc__card.is-dragging{
	opacity:.9;cursor:grabbing;z-index:5;
	box-shadow:0 24px 60px rgba(0,0,0,.22);
}
#<?= esc_attr( $uid ) ?> .wf-sc__card.is-moved{outline:2px solid <?= esc_attr( $acc ) ?>;outline-offset:2px;}
<?php endif; ?>
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?> .__arrow{transition-duration:.001ms;}
<?php if ( 'stack' === $mode ) : ?>
	#<?= esc_attr( $uid ) ?> .wf-sc__card{min-height:0;position:static;rotate:none;margin-bottom:<?= (int) max( 12, $gap ) ?>px;}
<?php endif; ?>
}
</style>

<?php if ( 'stack' === $mode && $stepSc > 0 ) : ?>
<script>
(function(){
	// Retrecissement progressif des cartes deja empilees. Pur confort visuel :
	// sans script, l'empilement fonctionne quand meme (le sticky est en CSS).
	var root = document.getElementById('<?= esc_js( $uid ) ?>');
	if (!root) { return; }
	if (window.matchMedia) {
		if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { return; }
	}
	var cards = [].slice.call(root.querySelectorAll('.wf-sc__card'));
	var top = <?= (int) $stickTop ?>;
	var step = <?= (int) $stepOff ?>;
	var k = <?= esc_js( (string) $stepSc ) ?>;
	var ticking = false;
	function paint(){
		ticking = false;
		for (var i = 0; i < cards.length; i++) {
			var r = cards[i].getBoundingClientRect();
			var rest = top + i * step;
			var over = rest - r.top;          // > 0 quand la carte est depassee
			if (over < 0) { over = 0; }
			var d = over / Math.max(1, r.height);
			if (d > 1) { d = 1; }
			cards[i].style.scale = String(1 - k * d * 3);
		}
	}
	function onScroll(){
		if (ticking) { return; }
		ticking = true;
		// Un onglet en arriere-plan ne declenche aucun requestAnimationFrame :
		// on peint alors directement, sinon l'element resterait fige.
		if (document.hidden) { paint(); }
		else { requestAnimationFrame(paint); }
	}
	window.addEventListener('scroll', onScroll, { passive: true });
	window.addEventListener('resize', onScroll);
	paint();
})();
</script>
<?php endif; ?>

<?php if ( $drag ) : ?>
<script>
(function(){
	var root = document.getElementById('<?= esc_js( $uid ) ?>');
	if (!root) { return; }
	var live = document.getElementById('<?= esc_js( $uid ) ?>-live');
	var key = 'wfsc_<?= esc_js( $uid ) ?>';
	var remember = root.getAttribute('data-remember') === '1';

	function cards(){ return [].slice.call(root.querySelectorAll('.wf-sc__card')); }

	function say(msg){ if (live) { live.textContent = msg; } }

	function save(){
		if (!remember) { return; }
		try {
			var order = cards().map(function(c){ return c.getAttribute('data-pos'); });
			localStorage.setItem(key, JSON.stringify(order));
		} catch (err) {}
	}

	function restore(){
		if (!remember) { return; }
		try {
			var raw = localStorage.getItem(key);
			if (!raw) { return; }
			var order = JSON.parse(raw);
			if (!Array.isArray(order)) { return; }
			var byPos = {};
			cards().forEach(function(c){ byPos[c.getAttribute('data-pos')] = c; });
			order.forEach(function(p){ if (byPos[p]) { root.appendChild(byPos[p]); } });
		} catch (err) {}
	}
	restore();

	function announce(card){
		var list = cards();
		var idx = list.indexOf(card) + 1;
		var t = card.querySelector('.__title');
		var label = t ? t.textContent.trim() : '<?= esc_js( __( 'Carte', 'weframe' ) ) ?>';
		say(label + ' — <?= esc_js( __( 'position', 'weframe' ) ) ?> ' + idx + '/' + list.length);
	}

	function move(card, dir){
		var list = cards();
		var i = list.indexOf(card);
		var j = i + dir;
		if (j < 0) { return; }
		if (j >= list.length) { return; }
		if (dir < 0) { root.insertBefore(card, list[j]); }
		else { root.insertBefore(card, list[j].nextSibling); }
		card.classList.add('is-moved');
		setTimeout(function(){ card.classList.remove('is-moved'); }, 700);
		announce(card);
		save();
	}

	// --- clavier : la poignee reste atteignable au Tab, les fleches deplacent ---
	root.addEventListener('keydown', function(e){
		var grip = e.target.closest ? e.target.closest('.__grip') : null;
		if (!grip) { return; }
		var card = grip.closest('.wf-sc__card');
		var k = e.key;
		var dir = 0;
		if (k === 'ArrowLeft') { dir = -1; }
		if (k === 'ArrowUp') { dir = -1; }
		if (k === 'ArrowRight') { dir = 1; }
		if (k === 'ArrowDown') { dir = 1; }
		if (dir === 0) { return; }
		e.preventDefault();
		move(card, dir);
		grip.focus();
	});

	// --- souris et tactile : un seul jeu d'evenements (Pointer Events) ---
	var dragging = null;
	root.addEventListener('pointerdown', function(e){
		var grip = e.target.closest ? e.target.closest('.__grip') : null;
		if (!grip) { return; }
		e.preventDefault();
		dragging = grip.closest('.wf-sc__card');
		dragging.classList.add('is-dragging');
		grip.setPointerCapture(e.pointerId);
	});

	root.addEventListener('pointermove', function(e){
		if (!dragging) { return; }
		var over = document.elementFromPoint(e.clientX, e.clientY);
		if (!over) { return; }
		var target = over.closest ? over.closest('.wf-sc__card') : null;
		if (!target) { return; }
		if (target === dragging) { return; }
		if (target.parentNode !== root) { return; }
		var list = cards();
		var after;
		if (list.indexOf(target) > list.indexOf(dragging)) {
			after = true;
		} else {
			after = false;
		}
		if (after) { root.insertBefore(dragging, target.nextSibling); }
		else { root.insertBefore(dragging, target); }
	});

	function endDrag(){
		if (!dragging) { return; }
		dragging.classList.remove('is-dragging');
		announce(dragging);
		save();
		dragging = null;
	}
	root.addEventListener('pointerup', endDrag);
	root.addEventListener('pointercancel', endDrag);
})();
</script>
<?php endif; ?>
