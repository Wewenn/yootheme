<?php
/**
 * WeFrame – Changelog Item | template.php v2.2
 * + timeline dot, anchor, data-label for filters
 */
defined( 'ABSPATH' ) || exit;

$version = $props['version'] ?? '';
$date    = $props['date']    ?? '';
$entries = $props['entries']  ?? '';
if ( ! $version ) { return; }

$ver_size  = (int)( $element['version_size'] ?? 24 );
$show_date = ! empty( $element['show_date'] );
$collapsed = ! empty( $element['collapsed'] );
$is_first  = ! empty( $args['is_first'] ?? false );
$style     = $element['style']    ?? 'bordered';
$timeline  = ! empty( $element['show_timeline'] );
$anchors   = ! empty( $element['show_anchors'] );

$colors = [
    'added'      => $element['color_added']      ?? '#16a34a',
    'changed'    => $element['color_changed']     ?? '#2563eb',
    'fixed'      => $element['color_fixed']       ?? '#d97706',
    'removed'    => $element['color_removed']     ?? '#dc2626',
    'deprecated' => $element['color_deprecated']  ?? '#6b7280',
];

$open = ( ! $collapsed || $is_first ) ? ' open' : '';
$pad  = $style === 'card' ? 'padding:24px 28px;' : 'padding:20px 0;';
$slug = 'v' . preg_replace( '/[^a-zA-Z0-9._-]/', '', $version );

$lines = array_filter( array_map( 'trim', explode( "\n", $entries ) ) );

?>
<details class="wf-cl-version" id="<?= esc_attr( $slug ) ?>"<?= $open ?> style="<?= $pad ?>">

    <?php if ( $timeline ) : ?><div class="wf-cl-dot"></div><?php endif; ?>

    <summary style="display:flex;align-items:baseline;gap:12px;font-size:<?= $ver_size ?>px;font-weight:700;line-height:1.3;">
        <?php if ( $anchors ) : ?>
            <a href="#<?= esc_attr( $slug ) ?>" class="wf-cl-anchor">v<?= esc_html( $version ) ?></a>
        <?php else : ?>
            <span>v<?= esc_html( $version ) ?></span>
        <?php endif; ?>
        <?php if ( $show_date && $date ) : ?>
        <span style="font-size:13px;font-weight:400;color:#888;"><?= esc_html( $date ) ?></span>
        <?php endif; ?>
    </summary>

    <?php if ( $lines ) : ?>
    <ul style="margin:16px 0 0;padding:0;list-style:none;display:flex;flex-direction:column;gap:8px;">
        <?php foreach ( $lines as $line ) :
            $label = ''; $text = $line;
            if ( preg_match( '/^\[(\w+)\]\s*(.*)$/i', $line, $m ) ) { $label = strtolower( $m[1] ); $text = $m[2]; }
            $lbl_color = $colors[ $label ] ?? '#888';
        ?>
        <li class="wf-cl-entry" data-label="<?= esc_attr( $label ) ?>" style="display:flex;align-items:baseline;gap:10px;font-size:14px;line-height:1.5;">
            <?php if ( $label ) : ?>
            <span class="wf-cl-label" style="background:<?= esc_attr( $lbl_color ) ?>;flex-shrink:0;"><?= esc_html( ucfirst( $label ) ) ?></span>
            <?php endif; ?>
            <span><?= esc_html( $text ) ?></span>
        </li>
        <?php endforeach; ?>
    </ul>
    <?php endif; ?>
</details>
