<?php
/**
 * WeFrame – Cartes à faire glisser | template.php v1.0
 *
 * Une pile de cartes : on attrape celle du dessus et on la jette à gauche ou à
 * droite, la suivante remonte. Boutons, pastilles et flèches du clavier font la
 * même chose, pour ceux qui ne peuvent pas glisser.
 *
 * L'ordre est tenu par une seule liste ; le placement de chaque carte se déduit
 * de son rang. Rien n'est déplacé dans le DOM, donc le focus ne saute pas.
 *
 * Pas de "&&" ni de "||" dans le JS inline (règle interne du plugin).
 */

defined( 'ABSPATH' ) || exit;

// Les cartes viennent des articles du panneau : mediatheque et
// reordonnancement, ce qu'une zone de texte ne donnait pas.
$cards = array();
if ( ! empty( $children ) ) {
	foreach ( $children as $child ) {
		$cp  = (array) ( $child->props ?? array() );
		$src = trim( (string) ( $cp['image'] ?? '' ) );
		if ( '' === $src ) { continue; }
		if ( ! preg_match( '#^https?://#i', $src ) ) { $src = '/' . ltrim( $src, '/' ); }
		$cards[] = array(
			'src'     => $src,
			'caption' => trim( (string) ( $cp['title'] ?? '' ) ),
			'link'    => trim( (string) ( $cp['link'] ?? '' ) ),
			'target'  => ! empty( $cp['link_target'] ) ? ' target="_blank" rel="noopener"' : '',
		);
	}
}
if ( empty( $cards ) ) { return; }

$w        = max( 180, min( 700, (int) ( $props['width'] ?? 340 ) ) );
$ratio    = (string) ( $props['ratio'] ?? '133' );
$visible  = max( 1, min( 4, (int) ( $props['visible'] ?? 3 ) ) );
$offset   = max( 0, min( 60, (int) ( $props['offset'] ?? 14 ) ) );
$scaleStep = max( 0, min( 15, (int) ( $props['scale_step'] ?? 5 ) ) );
$rotate   = max( 0, min( 12, (int) ( $props['rotate'] ?? 4 ) ) );
$radius   = max( 0, min( 40, (int) ( $props['radius'] ?? 18 ) ) );
$shadow   = ! empty( $props['shadow'] );
$showCap  = ! empty( $props['show_caption'] );
$showBtn  = ! empty( $props['show_buttons'] );
$showDots = ! empty( $props['show_dots'] );
$auto     = ! empty( $props['autoplay'] );
$autoDel  = max( 2, min( 20, (int) ( $props['autoplay_delay'] ?? 5 ) ) );
$accent   = (string) ( $props['accent'] ?? '#EA5C1C' );

$h = (int) round( $w * ( (float) $ratio ) / 100 );

$uid = wf_uid( 'wfcs_', $props );

$cfg = wp_json_encode(
	array(
		'uid'     => $uid,
		'count'   => count( $cards ),
		'visible' => $visible,
		'offset'  => $offset,
		'scale'   => $scaleStep / 100,
		'rotate'  => $rotate,
		'auto'    => $auto,
		'delay'   => $autoDel * 1000,
	),
	JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE
);
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-cs" role="group" aria-roledescription="carrousel" aria-label="Cartes">
	<div class="wf-cs__stack">
	<?php foreach ( $cards as $i => $card ) : ?>
		<div class="wf-cs__card" data-i="<?= (int) $i ?>" aria-hidden="true">
		<?php if ( '' !== $card['link'] ) : ?>
			<a class="wf-cs__link" href="<?= esc_url( $card['link'] ) ?>"<?= $card['target'] ?>><img src="<?= esc_url( $card['src'] ) ?>" alt="<?= esc_attr( $card['caption'] ) ?>" loading="lazy" decoding="async" draggable="false"></a>
		<?php else : ?>
			<img src="<?= esc_url( $card['src'] ) ?>" alt="<?= esc_attr( $card['caption'] ) ?>" loading="lazy" decoding="async" draggable="false">
		<?php endif; ?>
		</div>
	<?php endforeach; ?>
	</div>
	<?php if ( $showCap ) : ?>
	<p class="wf-cs__caption" aria-live="polite"><?= esc_html( $cards[0]['caption'] ) ?></p>
	<?php endif; ?>
	<?php if ( $showBtn || $showDots ) : ?>
	<div class="wf-cs__nav">
		<?php if ( $showBtn ) : ?>
		<button type="button" class="wf-cs__btn wf-cs__prev" aria-label="Carte précédente">
			<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 5 8 12l7 7"/></svg>
		</button>
		<?php endif; ?>
		<?php if ( $showDots ) : ?>
		<div class="wf-cs__dots">
		<?php foreach ( $cards as $i => $card ) : ?>
			<button type="button" class="wf-cs__dot" data-go="<?= (int) $i ?>" aria-label="Carte <?= (int) ( $i + 1 ) ?>"></button>
		<?php endforeach; ?>
		</div>
		<?php endif; ?>
		<?php if ( $showBtn ) : ?>
		<button type="button" class="wf-cs__btn wf-cs__next" aria-label="Carte suivante">
			<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 5 7 7-7 7"/></svg>
		</button>
		<?php endif; ?>
	</div>
	<?php endif; ?>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?>{display:flex;flex-direction:column;align-items:center;gap:18px;}
#<?= esc_attr( $uid ) ?> .wf-cs__stack{
	position:relative;width:<?= (int) $w ?>px;max-width:100%;
	height:<?= (int) $h ?>px;
	touch-action:pan-y;
}
#<?= esc_attr( $uid ) ?> .wf-cs__card{
	position:absolute;inset:0;
	border-radius:<?= (int) $radius ?>px;overflow:hidden;background:#e5e7eb;
	<?php if ( $shadow ) : ?>box-shadow:0 18px 40px rgba(0,0,0,.18);<?php endif; ?>
	transform-origin:center bottom;
	transition:transform .42s cubic-bezier(.2,.8,.2,1),opacity .42s ease;
	cursor:grab;user-select:none;-webkit-user-select:none;
}
#<?= esc_attr( $uid ) ?> .wf-cs__card.is-drag{transition:none;cursor:grabbing;}
#<?= esc_attr( $uid ) ?> .wf-cs__link{display:block;width:100%;height:100%;}
#<?= esc_attr( $uid ) ?> .wf-cs__card img{display:block;width:100%;height:100%;object-fit:cover;pointer-events:none;}
#<?= esc_attr( $uid ) ?> .wf-cs__caption{margin:0;text-align:center;font-size:.95rem;opacity:.75;min-height:1.4em;}
#<?= esc_attr( $uid ) ?> .wf-cs__nav{display:flex;align-items:center;gap:14px;}
#<?= esc_attr( $uid ) ?> .wf-cs__btn{
	display:inline-flex;align-items:center;justify-content:center;
	width:44px;height:44px;cursor:pointer;color:inherit;background:transparent;
	border:1px solid rgba(127,127,127,.45);border-radius:100px;
}
#<?= esc_attr( $uid ) ?> .wf-cs__btn:hover{border-color:<?= esc_attr( $accent ) ?>;color:<?= esc_attr( $accent ) ?>;}
#<?= esc_attr( $uid ) ?> .wf-cs__dots{display:flex;align-items:center;gap:8px;}
#<?= esc_attr( $uid ) ?> .wf-cs__dot{
	width:8px;height:8px;padding:0;cursor:pointer;border:0;border-radius:100px;
	background:currentColor;opacity:.25;transition:opacity .2s ease,width .2s ease;
}
#<?= esc_attr( $uid ) ?> .wf-cs__dot.is-on{opacity:1;width:22px;background:<?= esc_attr( $accent ) ?>;}
/* Cible tactile : la pastille reste petite a l'oeil, pas au doigt. */
#<?= esc_attr( $uid ) ?> .wf-cs__dots{padding:12px 0;}
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?> .wf-cs__card{transition:none;}
}
</style>
<script>
(function(){
	function boot(){
		var c = <?= $cfg ?>;
		var root = document.getElementById(c.uid);
		if(!root){return;}
		if(root.getAttribute('data-wf-ready')){return;}
		root.setAttribute('data-wf-ready','1');

		var stack = root.querySelector('.wf-cs__stack');
		var cards = Array.prototype.slice.call(root.querySelectorAll('.wf-cs__card'));
		var caption = root.querySelector('.wf-cs__caption');
		var dots = Array.prototype.slice.call(root.querySelectorAll('.wf-cs__dot'));
		if(!cards.length){return;}

		var top = 0;
		var timer = null;

		function place(){
			var i = 0;
			while(i < cards.length){
				// Rang de la carte a partir de celle du dessus, en boucle.
				var rank = (i - top + c.count) % c.count;
				var card = cards[i];
				if(rank > c.visible){
					card.style.opacity = '0';
					card.style.pointerEvents = 'none';
					card.style.zIndex = '0';
					card.style.transform = 'translate3d(0,' + (c.offset * c.visible) + 'px,0) scale(' + (1 - c.scale * c.visible) + ')';
					card.setAttribute('aria-hidden', 'true');
					i++;
					continue;
				}
				var rot = 0;
				if(c.rotate > 0){ rot = ((i % 2 === 0) ? 1 : -1) * c.rotate * (rank / Math.max(1, c.visible)); }
				card.style.opacity = '1';
				card.style.zIndex = String(c.count - rank);
				card.style.pointerEvents = rank === 0 ? 'auto' : 'none';
				card.style.transform = 'translate3d(0,' + (rank * c.offset) + 'px,0) scale(' + (1 - c.scale * rank) + ') rotate(' + rot.toFixed(2) + 'deg)';
				card.setAttribute('aria-hidden', rank === 0 ? 'false' : 'true');
				i++;
			}
			if(caption){
				var img = cards[top].querySelector('img');
				caption.textContent = img ? (img.getAttribute('alt') || '') : '';
			}
			var d = 0;
			while(d < dots.length){
				if(d === top){ dots[d].classList.add('is-on'); }
				else { dots[d].classList.remove('is-on'); }
				d++;
			}
		}

		function go(n){
			top = ((n % c.count) + c.count) % c.count;
			place();
		}
		function next(){ go(top + 1); }
		function prev(){ go(top - 1); }

		var prevBtn = root.querySelector('.wf-cs__prev');
		var nextBtn = root.querySelector('.wf-cs__next');
		if(prevBtn){ prevBtn.addEventListener('click', function(){ stopAuto(); prev(); }); }
		if(nextBtn){ nextBtn.addEventListener('click', function(){ stopAuto(); next(); }); }
		var di = 0;
		while(di < dots.length){
			(function(b){
				b.addEventListener('click', function(){ stopAuto(); go(parseInt(b.getAttribute('data-go'), 10)); });
			}(dots[di]));
			di++;
		}

		root.addEventListener('keydown', function(e){
			if(e.key === 'ArrowRight'){ e.preventDefault(); stopAuto(); next(); return; }
			if(e.key === 'ArrowLeft'){ e.preventDefault(); stopAuto(); prev(); }
		});

		// Glisser : on suit le doigt, et au-dela d'un quart de carte on valide.
		var drag = null, sx = 0, sy = 0, dx = 0, axis = '';
		stack.addEventListener('pointerdown', function(e){
			var card = cards[top];
			if(e.target.closest('.wf-cs__card') !== card){return;}
			drag = card;
			axis = '';
			dx = 0;
			sx = e.clientX;
			sy = e.clientY;
			card.classList.add('is-drag');
			// La capture echoue si le pointeur n'est plus actif : sans garde,
			// l'exception avale la suite du glissement.
			try{ stack.setPointerCapture(e.pointerId); }catch(err){}
			stopAuto();
		});
		stack.addEventListener('pointermove', function(e){
			if(!drag){return;}
			var mx = e.clientX - sx;
			var my = e.clientY - sy;
			if(axis === ''){
				if(Math.abs(mx) + Math.abs(my) < 6){return;}
				axis = Math.abs(mx) > Math.abs(my) ? 'x' : 'y';
				// Geste vertical : c'est un defilement de page, on lache.
				if(axis === 'y'){ release(false); return; }
			}
			dx = mx;
			drag.style.transform = 'translate3d(' + dx + 'px,0,0) rotate(' + (dx / 22).toFixed(2) + 'deg)';
		});

		function release(commit){
			if(!drag){return;}
			var card = drag;
			drag = null;
			card.classList.remove('is-drag');
			if(commit){
				var dir = dx > 0 ? 1 : -1;
				card.style.transform = 'translate3d(' + (dir * 140) + '%,0,0) rotate(' + (dir * 18) + 'deg)';
				card.style.opacity = '0';
				window.setTimeout(function(){
					if(dir > 0){ prev(); }
					else { next(); }
				}, 220);
				return;
			}
			place();
		}

		function endDrag(){
			if(!drag){return;}
			release(Math.abs(dx) > stack.clientWidth * 0.25);
		}
		stack.addEventListener('pointerup', endDrag);
		stack.addEventListener('pointercancel', endDrag);

		function stopAuto(){
			if(!timer){return;}
			window.clearInterval(timer);
			timer = null;
		}
		if(c.auto){
			timer = window.setInterval(next, c.delay);
			root.addEventListener('mouseenter', stopAuto);
		}

		place();
	}
	if(document.readyState === 'loading'){
		document.addEventListener('DOMContentLoaded', boot);
	}else{
		boot();
	}
}());
</script>
