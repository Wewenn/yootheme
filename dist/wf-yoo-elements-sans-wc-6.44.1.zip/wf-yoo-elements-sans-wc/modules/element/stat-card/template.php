<?php
defined( 'ABSPATH' ) || exit;
$number = $props['number']??''; $label = $props['label']??''; $sub = $props['sublabel']??'';
$icon = $props['icon']??''; $ic = $props['icon_color']??'';
if (!$number) return;
$bg = $props['card_bg']??'#fff'; $border = !empty($props['card_border']);
$bc = $props['card_border_color']??'#e5e5e5'; $r = (int)($props['card_radius']??16);
$pad = (int)($props['card_padding']??32);
$ns = (int)($props['number_size']??48); $nc = $props['number_color']??'#000'; $nw = $props['number_weight']??'800';
$ls = (int)($props['label_size']??15); $lc = $props['label_color']??'#333'; $slc = $props['sublabel_color']??'#16a34a';
$spark = !empty($props['sparkline']); $spc = $props['sparkline_color']??'#EA5C1C';
$spo = max(5,min(40,(int)($props['sparkline_opacity']??15)));
$bdr = $border ? "border:1px solid {$bc};" : '';
$icons = [
    'arrow-up'=>'<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>',
    'heart'=>'<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78L12 21.23l8.84-8.84a5.5 5.5 0 0 0 0-7.78z"/></svg>',
    'star'=>'<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
    'users'=>'<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>',
    'world'=>'<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/></svg>',
];
$sparkSvg = '';
if ($spark) {
    $seed = crc32($number.$label);
    $points = [];
    for ($i=0; $i<12; $i++) { $points[] = 30 + (($seed >> ($i*2)) % 50); }
    $w = 100; $step = $w / 11;
    $path = "M0,{$points[0]}";
    for ($i=1; $i<12; $i++) { $x = round($i * $step, 1); $path .= " L{$x},{$points[$i]}"; }
    $path .= " L{$w},100 L0,100 Z";
    $sparkSvg = '<svg viewBox="0 0 100 100" preserveAspectRatio="none" style="position:absolute;bottom:0;left:0;width:100%;height:50%;opacity:'.($spo/100).';pointer-events:none;"><path d="'.$path.'" fill="'.esc_attr($spc).'"/></svg>';
}
$wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div';
$wfEl  = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null;
?>
<?php if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div style="position:relative;overflow:hidden;background:<?= esc_attr($bg) ?>;<?= $bdr ?>border-radius:<?= $r ?>px;padding:<?= $pad ?>px;">
    <?= $sparkSvg ?>
    <div style="position:relative;z-index:1;">
        <?php if ($icon && isset($icons[$icon])) : ?>
        <div style="margin-bottom:12px;<?= $ic ? "color:{$ic};" : '' ?>"><?= $icons[$icon] ?></div>
        <?php endif; ?>
        <div style="font-size:<?= $ns ?>px;font-weight:<?= esc_attr($nw) ?>;color:<?= esc_attr($nc) ?>;line-height:1.1;"><?= esc_html($number) ?></div>
        <?php if ($label) : ?><div style="font-size:<?= $ls ?>px;color:<?= esc_attr($lc) ?>;margin-top:8px;"><?= esc_html($label) ?></div><?php endif; ?>
        <?php if ($sub) : ?><div style="font-size:13px;color:<?= esc_attr($slc) ?>;margin-top:4px;font-weight:600;"><?= esc_html($sub) ?></div><?php endif; ?>
    </div>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
