<?php
defined('ABSPATH') || exit;
$before = $props['image_before']??''; $after = $props['image_after']??'';
if (!$before) return; if (!$after) return;
if (!preg_match('#^https?://#i',$before)) $before='/'.ltrim($before,'/');
if (!preg_match('#^https?://#i',$after)) $after='/'.ltrim($after,'/');
$ab = $props['alt_before']??'Avant'; $aa = $props['alt_after']??'Après';
$start = max(10,min(90,(int)($props['start_position']??50)));
$static = !empty($props['static_mode']); $orient = $props['orientation']??'horizontal';
$hc = $props['handle_color']??'#fff'; $hw = (int)($props['handle_width']??4);
$r = (int)($props['border_radius']??12); $mh = (int)($props['max_height']??500); $mhm = (int)($props['max_height_mobile']??300);
$labels = !empty($props['show_labels']); $lb = $props['label_before']??'Avant'; $la = $props['label_after']??'Après';
$lbg = $props['label_bg']??'rgba(0,0,0,.6)'; $lc = $props['label_color']??'#fff';
$uid = 'wfba_'.substr(md5(serialize($props)),0,8);
$vert = ($orient === 'vertical');
$cursor = $static ? 'default' : ($vert ? 'row-resize' : 'col-resize');
$cfg = json_encode(['uid'=>$uid,'vert'=>$vert], JSON_HEX_AMP|JSON_HEX_APOS);
$handleSvg = $vert
    ? '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="#333" stroke-width="2.5" stroke-linecap="round"><polyline points="6 7 10 3 14 7"/><polyline points="6 13 10 17 14 13"/></svg>'
    : '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="#333" stroke-width="2.5" stroke-linecap="round"><polyline points="7 6 3 10 7 14"/><polyline points="13 6 17 10 13 14"/></svg>';

/* Both images use object-fit:cover inside a fixed-height container.
   This guarantees identical scale/crop for both images regardless of natural dimensions. */
$img_shared = 'position:absolute;top:0;left:0;width:100%;height:100%;object-fit:cover;display:block;pointer-events:none;';
$wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div';
$wfEl  = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null;
?>
<?php if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr($uid) ?>" class="wf-ba" style="position:relative;overflow:hidden;border-radius:<?= $r ?>px;cursor:<?= $cursor ?>;height:<?= $mh ?>px;user-select:none;-webkit-user-select:none;touch-action:none;">

    <img src="<?= esc_url($after) ?>" alt="<?= esc_attr($aa) ?>" loading="lazy" draggable="false" style="<?= $img_shared ?>">

    <?php if ($vert) : ?>
    <div class="wf-ba-clip" style="position:absolute;top:0;left:0;right:0;height:<?= $start ?>%;overflow:hidden;">
        <img src="<?= esc_url($before) ?>" alt="<?= esc_attr($ab) ?>" loading="lazy" draggable="false" class="wf-ba-before-img" style="<?= $img_shared ?>max-height:none;">
    </div>
    <div class="wf-ba-handle" style="position:absolute;left:0;right:0;top:<?= $start ?>%;height:<?= $hw ?>px;background:<?= esc_attr($hc) ?>;transform:translateY(-50%);z-index:3;">
        <?php if (!$static) : ?><div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:40px;height:40px;border-radius:50%;background:<?= esc_attr($hc) ?>;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,.3);"><?= $handleSvg ?></div><?php endif; ?>
    </div>
    <?php else : ?>
    <div class="wf-ba-clip" style="position:absolute;top:0;left:0;bottom:0;width:<?= $start ?>%;overflow:hidden;">
        <img src="<?= esc_url($before) ?>" alt="<?= esc_attr($ab) ?>" loading="lazy" draggable="false" class="wf-ba-before-img" style="position:absolute;top:0;left:0;height:100%;object-fit:cover;display:block;pointer-events:none;max-width:none;">
    </div>
    <div class="wf-ba-handle" style="position:absolute;top:0;bottom:0;left:<?= $start ?>%;width:<?= $hw ?>px;background:<?= esc_attr($hc) ?>;transform:translateX(-50%);z-index:3;">
        <?php if (!$static) : ?><div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:40px;height:40px;border-radius:50%;background:<?= esc_attr($hc) ?>;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,.3);"><?= $handleSvg ?></div><?php endif; ?>
    </div>
    <?php endif; ?>

    <?php if ($labels) : ?>
    <?php if ($vert) : ?>
    <div style="position:absolute;top:12px;left:12px;background:<?= esc_attr($lbg) ?>;color:<?= esc_attr($lc) ?>;padding:4px 12px;border-radius:100px;font-size:12px;font-weight:700;text-transform:uppercase;z-index:4;pointer-events:none;"><?= esc_html($lb) ?></div>
    <div style="position:absolute;bottom:12px;left:12px;background:<?= esc_attr($lbg) ?>;color:<?= esc_attr($lc) ?>;padding:4px 12px;border-radius:100px;font-size:12px;font-weight:700;text-transform:uppercase;z-index:4;pointer-events:none;"><?= esc_html($la) ?></div>
    <?php else : ?>
    <div style="position:absolute;top:12px;left:12px;background:<?= esc_attr($lbg) ?>;color:<?= esc_attr($lc) ?>;padding:4px 12px;border-radius:100px;font-size:12px;font-weight:700;text-transform:uppercase;z-index:4;pointer-events:none;"><?= esc_html($lb) ?></div>
    <div style="position:absolute;top:12px;right:12px;background:<?= esc_attr($lbg) ?>;color:<?= esc_attr($lc) ?>;padding:4px 12px;border-radius:100px;font-size:12px;font-weight:700;text-transform:uppercase;z-index:4;pointer-events:none;"><?= esc_html($la) ?></div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<style>
#<?= esc_attr($uid) ?> { height:<?= $mh ?>px; }
@media(max-width:767px){#<?= esc_attr($uid) ?>{height:<?= $mhm ?>px !important;}}
</style>
<?php if (!$static) : ?>
<script>
(function(){
    function boot(){
        
        var c = <?= $cfg ?>;
        var el=document.getElementById(c.uid);if(!el)return;
        var clip=el.querySelector('.wf-ba-clip');var handle=el.querySelector('.wf-ba-handle');
        if(!clip)return;if(!handle)return;
        var active=false;

        /* Sync AVANT img to full container dimensions so both images render at identical scale */
        var beforeImg = clip.querySelector('.wf-ba-before-img');
        function syncBefore() {
            if (!beforeImg) return;
            if (c.vert) {
                beforeImg.style.width  = el.offsetWidth  + 'px';
                beforeImg.style.height = el.offsetHeight + 'px';
            } else {
                beforeImg.style.width  = el.offsetWidth  + 'px';
                beforeImg.style.height = el.offsetHeight + 'px';
            }
        }
        syncBefore();
        window.addEventListener('resize', syncBefore);

        function move(px,py){
            var rect=el.getBoundingClientRect();
            if(c.vert){
                var pct=((py-rect.top)/rect.height)*100;
                if(pct<0)pct=0;if(pct>100)pct=100;
                clip.style.height=pct+'%';
                handle.style.top=pct+'%';
            }else{
                var pct2=((px-rect.left)/rect.width)*100;
                if(pct2<0)pct2=0;if(pct2>100)pct2=100;
                clip.style.width=pct2+'%';
                handle.style.left=pct2+'%';
            }
        }
        function onDown(e){
            e.preventDefault();active=true;
            move(e.clientX,e.clientY);
            document.addEventListener('mousemove',onMove);
            document.addEventListener('mouseup',onUp);
        }
        function onMove(e){if(active)move(e.clientX,e.clientY)}
        function onUp(){active=false;document.removeEventListener('mousemove',onMove);document.removeEventListener('mouseup',onUp)}
        el.addEventListener('mousedown',onDown);
        handle.setAttribute('tabindex','0');handle.setAttribute('role','slider');
        handle.addEventListener('keydown',function(e){
            var cur=c.vert?parseFloat(clip.style.height||'50'):parseFloat(clip.style.width||'50');
            var delta=(e.key==='ArrowRight'||e.key==='ArrowDown')?5:(e.key==='ArrowLeft'||e.key==='ArrowUp')?-5:0;
            if(!delta)return;e.preventDefault();
            var pct=Math.max(0,Math.min(100,cur+delta));
            if(c.vert){clip.style.height=pct+'%';handle.style.top=pct+'%';}
            else{clip.style.width=pct+'%';handle.style.left=pct+'%';}
        });
        el.addEventListener('touchstart',function(e){active=true;var t=e.touches[0];move(t.clientX,t.clientY)},{passive:false});
        el.addEventListener('touchmove',function(e){if(!active)return;e.preventDefault();var t=e.touches[0];move(t.clientX,t.clientY)},{passive:false});
        el.addEventListener('touchend',function(){active=false});
    }
    WF.ready(boot);
})();
</script>
<?php endif; ?>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
