<?php
/**
 * WeFrame – Unfold (tuile enfant) | template.php v1.0
 * L'enfant ne rend que le contenu du volet deplie : la tuile cliquable est
 * construite par le parent a partir de titre / sous-titre / image / icone.
 */
defined( 'ABSPATH' ) || exit;

$inner = '';
if ( ! empty( $children ) ) {
	foreach ( $children as $ci => $child ) {
		$inner .= $builder->render( $child, array( 'element' => $props, 'index' => $ci ) );
	}
}
echo $inner;
