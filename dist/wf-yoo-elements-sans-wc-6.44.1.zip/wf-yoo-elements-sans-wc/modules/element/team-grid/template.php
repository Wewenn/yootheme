<?php
/**
 * WeFrame – Équipe (parent) | template.php v1.0
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$cols  = (int) ( $props['columns'] ?? 3 );
$cols  = in_array( $cols, array( 2, 3, 4 ), true ) ? $cols : 3;
$gap   = max( 0, (int) ( $props['gap'] ?? 24 ) );
$align = ( 'left' === ( $props['align'] ?? 'center' ) ) ? 'left' : 'center';

$html = '';
foreach ( $children as $child ) {
    $html .= $builder->render( $child, array( 'element' => $props ) );
}
if ( ! trim( $html ) ) { return; }

$uid = wf_uid( 'wftm_', $props, count( $children ) );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-team" style="display:grid;grid-template-columns:repeat(<?= $cols ?>,1fr);gap:<?= $gap ?>px;text-align:<?= esc_attr( $align ) ?>;">
    <?= $html ?>
</div>
<style>
@media(max-width:900px){ #<?= esc_attr( $uid ) ?>{ grid-template-columns:repeat(2,1fr) !important; } }
@media(max-width:520px){ #<?= esc_attr( $uid ) ?>{ grid-template-columns:1fr !important; } }
</style>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
