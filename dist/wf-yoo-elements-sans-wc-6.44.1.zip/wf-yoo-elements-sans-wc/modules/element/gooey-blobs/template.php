<?php
/**
 * WeFrame – Fond gouttes fusionnées | template.php v1.0
 * Des gouttes derivent lentement et se collent entre elles (filtre SVG :
 * flou gaussien puis contraste sur l'alpha). Le contenu depose reste net,
 * au-dessus, hors du filtre.
 *
 * Le contraste alpha n'est pas rendu par Safari ni Firefox : ces navigateurs
 * affichent des gouttes floues, ce qui reste presentable. Rien a corriger.
 * Zero JS : tout est en CSS + un filtre SVG.
 */
defined( 'ABSPATH' ) || exit;

$strength = max( 0, min( 40, (int) ( $props['strength'] ?? 15 ) ) );
$count    = max( 2, min( 12, (int) ( $props['count'] ?? 5 ) ) );
$size     = max( 60, (int) ( $props['blob_size'] ?? 220 ) );
$speed    = max( 4, (int) ( $props['speed'] ?? 18 ) );
$c1       = (string) ( $props['color_1'] ?? '#EA5C1C' );
$c2       = (string) ( $props['color_2'] ?? '#7C3AED' );
$op       = max( 10, min( 100, (int) ( $props['opacity'] ?? 90 ) ) );
$h        = max( 120, (int) ( $props['height'] ?? 420 ) );
$bg       = (string) ( $props['bg'] ?? '#0b0b10' );
$rad      = max( 0, (int) ( $props['radius'] ?? 24 ) );
$pad      = max( 0, (int) ( $props['padding'] ?? 48 ) );
$alignV   = (string) ( $props['content_align'] ?? 'center' );
if ( ! in_array( $alignV, array( 'center', 'start', 'end' ), true ) ) { $alignV = 'center'; }
$seed     = max( 1, (int) ( $props['seed'] ?? 3 ) );

$inner = '';
if ( ! empty( $children ) ) {
	foreach ( $children as $ci => $child ) {
		$inner .= $builder->render( $child, array( 'element' => $props, 'index' => $ci ) );
	}
}

// Tirage reproductible : la meme graine redonne exactement la meme disposition.
$rngState = ( $seed * 22695477 ) % 4294967296;
$rng = function () use ( &$rngState ) {
	$rngState = ( $rngState * 1103515245 + 12345 ) % 2147483648;
	return $rngState / 2147483648;
};

$blobs = array();
for ( $i = 0; $i < $count; $i++ ) {
	$blobs[] = array(
		'x'  => (int) round( 6 + $rng() * 82 ),        // %
		'y'  => (int) round( 6 + $rng() * 76 ),        // %
		'sz' => (int) round( $size * ( 0.55 + $rng() * 0.75 ) ),
		'dx' => (int) round( ( $rng() * 2 - 1 ) * 26 ),
		'dy' => (int) round( ( $rng() * 2 - 1 ) * 22 ),
		'dl' => round( -$rng() * $speed, 2 ),
		'c'  => ( $rng() > 0.5 ) ? $c2 : $c1,
	);
}

$uid = wf_uid( 'wfgo_', $props, $count );
$fid = $uid . '-goo';
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-goo">
	<svg class="__filter" aria-hidden="true" focusable="false" width="0" height="0">
		<defs>
			<filter id="<?= esc_attr( $fid ) ?>">
				<feGaussianBlur in="SourceGraphic" stdDeviation="<?= (int) $strength ?>" result="blur"/>
				<feColorMatrix in="blur" mode="matrix"
					values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 20 -10" result="goo"/>
				<feBlend in="SourceGraphic" in2="goo"/>
			</filter>
		</defs>
	</svg>

	<div class="__blobs" aria-hidden="true">
		<?php foreach ( $blobs as $i => $b ) : ?>
		<span class="__blob" style="
			left:<?= (int) $b['x'] ?>%;top:<?= (int) $b['y'] ?>%;
			width:<?= (int) $b['sz'] ?>px;height:<?= (int) $b['sz'] ?>px;
			background:<?= esc_attr( $b['c'] ) ?>;
			--dx:<?= (int) $b['dx'] ?>%;--dy:<?= (int) $b['dy'] ?>%;
			animation-delay:<?= esc_attr( $b['dl'] ) ?>s;"></span>
		<?php endforeach; ?>
	</div>

	<?php if ( '' !== trim( $inner ) ) : ?>
	<div class="__content"><?= $inner ?></div>
	<?php endif; ?>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?>{
	position:relative;isolation:isolate;overflow:hidden;
	min-height:<?= (int) $h ?>px;background:<?= esc_attr( $bg ) ?>;
	border-radius:<?= (int) $rad ?>px;padding:<?= (int) $pad ?>px;
	display:flex;flex-direction:column;justify-content:<?= 'center' === $alignV ? 'center' : ( 'end' === $alignV ? 'flex-end' : 'flex-start' ) ?>;
	container-type:inline-size;
}
#<?= esc_attr( $uid ) ?> .__filter{position:absolute;width:0;height:0;}
#<?= esc_attr( $uid ) ?> .__blobs{
	position:absolute;inset:0;z-index:0;pointer-events:none;
	filter:url(#<?= esc_attr( $fid ) ?>);
	opacity:<?= esc_attr( round( $op / 100, 2 ) ) ?>;
}
#<?= esc_attr( $uid ) ?> .__blob{
	position:absolute;border-radius:50%;display:block;
	transform:translate(-50%,-50%);
	animation:<?= esc_attr( $uid ) ?>-drift <?= (int) $speed ?>s ease-in-out infinite alternate;
	will-change:transform;
}
@keyframes <?= esc_attr( $uid ) ?>-drift{
	from{transform:translate(-50%,-50%);}
	to{transform:translate(calc(-50% + var(--dx)), calc(-50% + var(--dy)));}
}
#<?= esc_attr( $uid ) ?> .__content{position:relative;z-index:1;}
/* Moins d'animations : les gouttes restent, elles ne bougent plus. */
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?> .__blob{animation:none;}
}
</style>
