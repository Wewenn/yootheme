<?php
// Rendered by parent accordion-faq — this file exists for builder compatibility.
defined( 'ABSPATH' ) || exit;
