<?php
/**
 * WeFrame – Pile d'avatars : avatar (item).
 */
defined( 'ABSPATH' ) || exit;
$img = trim( (string) ( $props['image'] ?? '' ) );
if ( '' === $img ) { return; }
if ( ! preg_match( '#^https?://#i', $img ) ) { $img = '/' . ltrim( $img, '/' ); }
?>
<span class="wf-av-i"><img src="<?= esc_url( $img ) ?>" alt="" loading="lazy"></span>
