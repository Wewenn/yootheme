<?php
/**
 * WeFrame – Cartes à faire glisser (carte) | template.php v1.0
 * L'enfant ne rend rien : le parent compose la pile et place chaque carte.
 */
defined( 'ABSPATH' ) || exit;
