<?php
defined('ABSPATH') || exit;
require_once __DIR__ . '/../../wf-motion-kit.php';
$p=wfmk_props('horizontal-words',$props);
$uid=wf_uid('wfmk_', $props);
$wfmkEl=(isset($this) && method_exists($this,'el'))?$this->el('div'):null;
if($wfmkEl)echo $wfmkEl($props,$attrs??[]);
?>
<?php $tag=wfmk_choice($p['tag'],['h1','h2','h3','p'],'h2');$cfg=['shift'=>wfmk_n($p,'shift',90,0,500),'skew'=>wfmk_n($p,'skew',6,0,25),'dim'=>wfmk_n($p,'dim',10,0,80)/100,'duration'=>wfmk_n($p,'duration',700,150,2000),'stagger'=>wfmk_n($p,'stagger',45,0,250),'replay'=>!empty($p['replay'])];?>
<div id="<?=esc_attr($uid)?>" class="wfmk wfmk-words" data-wf-motion="words" data-wf-config="<?=wfmk_json($cfg)?>" style="<?=wfmk_vars(['size'=>wfmk_n($p,'size',72,24,150).'px','mobile-size'=>wfmk_n($p,'size_mobile',36,20,72).'px','width'=>wfmk_n($p,'width',1120,300,1600).'px','ink'=>wfmk_color($p['ink']),'shift'=>wfmk_n($p,'shift',90,0,500).'px','skew'=>wfmk_n($p,'skew',6,0,25).'deg','dim'=>wfmk_n($p,'dim',10,0,80)/100,'duration'=>wfmk_n($p,'duration',700,150,2000).'ms','weight'=>wfmk_choice((string)$p['weight'],['400','500','600','700'],'600'),'leading'=>wfmk_n($p,'leading',1.1,.8,2),'spacing'=>wfmk_n($p,'spacing',-.035,-.1,.2).'em','align'=>wfmk_choice($p['align'],['left','center','right'],'left')])?>"><div class="wfmk-words__sticky"><<?=$tag?> class="wfmk-words__text"><?=esc_html($p['text'])?></<?=$tag?>></div></div>

<?php if($wfmkEl)echo $wfmkEl->end(); ?>
