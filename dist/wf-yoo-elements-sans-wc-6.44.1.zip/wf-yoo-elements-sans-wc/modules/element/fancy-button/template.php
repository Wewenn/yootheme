<?php
/**
 * WeFrame – Bouton animé | template.php v2.0
 * 9 styles : reflet, halo, degrade, contour, arc-en-ciel, scintillement,
 * onde au clic, pulsation, echange au survol.
 * Tout en CSS sauf l'onde, qui a besoin du point de clic.
 * Pas de "&&" ni de "||" dans le JS inline (regle interne du plugin).
 */
defined( 'ABSPATH' ) || exit;

$text  = (string) ( $props['text'] ?? 'Bouton' );
$icon  = trim( (string) ( $props['icon'] ?? '' ) );
$style = (string) ( $props['style'] ?? 'shine' );
$known = array( 'shine', 'glow', 'gradient', 'outline', 'rainbow', 'shimmer', 'ripple', 'pulse', 'swap', 'slide', 'hold' );
if ( ! in_array( $style, $known, true ) ) { $style = 'shine'; }

$c1    = (string) ( $props['color'] ?? '#c0272d' );
$c2    = (string) ( $props['color2'] ?? '#f0563f' );
$size  = (string) ( $props['size'] ?? 'medium' );
$align = (string) ( $props['align'] ?? 'center' );
$full  = ! empty( $props['full_width'] );
$rad   = isset( $props['radius'] ) ? max( 0, (int) $props['radius'] ) : 100;
$swapText = trim( (string) ( $props['swap_text'] ?? '' ) );

$link = $props['link'] ?? '';
if ( is_array( $link ) ) { $link = $link['url'] ?? ''; }
$link = (string) $link;
if ( '' === $link ) { $link = '#'; }

$pad = array( 'small' => '10px 20px', 'medium' => '14px 30px', 'large' => '18px 42px' );
$fsz = array( 'small' => '14px', 'medium' => '16px', 'large' => '18px' );
$p   = $pad[ $size ] ?? $pad['medium'];
$fs  = $fsz[ $size ] ?? $fsz['medium'];
$jc  = array( 'left' => 'flex-start', 'right' => 'flex-end', 'center' => 'center' );
$just = $jc[ $align ] ?? 'center';

$uid   = wf_uid( 'wffb_', $props );
$label = ( '' !== $icon ? '<span class="wf-fb-ico">' . esc_html( $icon ) . '</span> ' : '' ) . esc_html( $text );
$wcss  = $full ? 'display:flex;width:100%;' : 'display:inline-flex;';
$twoLabels = ( 'swap' === $style ) || ( 'slide' === $style );
if ( $twoLabels && '' === $swapText ) { $swapText = $text; }

$isHold   = ( 'hold' === $style );
$holdMs   = max( 400, min( 4000, (int) ( $props['hold_ms'] ?? 1200 ) ) );
$holdDone = trim( (string) ( $props['hold_done'] ?? '' ) );
if ( '' === $holdDone ) { $holdDone = 'C’est noté'; }
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div style="display:flex;justify-content:<?= esc_attr( $just ) ?>;">
<a id="<?= esc_attr( $uid ) ?>" class="wf-fb wf-fb--<?= esc_attr( $style ) ?>" href="<?= esc_url( $link ) ?>" style="<?= $wcss ?>align-items:center;justify-content:center;gap:8px;padding:<?= $p ?>;font-size:<?= $fs ?>;font-weight:700;text-decoration:none;border-radius:<?= (int) $rad ?>px;cursor:pointer;position:relative;overflow:hidden;box-sizing:border-box;<?= $full ? '' : 'max-width:100%;' ?>"><?php if ( $twoLabels ) : ?><span class="wf-fb-a"><?= $label ?></span><span class="wf-fb-b" aria-hidden="true"><?= esc_html( $swapText ) ?></span><?php elseif ( $isHold ) : ?><span class="wf-fb-fill" aria-hidden="true"></span><span class="wf-fb-a"><?= $label ?></span><?php else : ?><?= $label ?><?php endif; ?></a>
</div>
<style>
#<?= esc_attr( $uid ) ?>{transition:transform .2s ease, box-shadow .3s ease, color .3s ease;}
#<?= esc_attr( $uid ) ?>:hover{transform:translateY(-2px);}
#<?= esc_attr( $uid ) ?>:focus-visible{outline:3px solid <?= esc_attr( $c1 ) ?>;outline-offset:3px;}
@media (pointer:coarse){#<?= esc_attr( $uid ) ?>{min-height:44px;}}
<?php if ( 'shine' === $style ) : ?>
#<?= esc_attr( $uid ) ?>{background:<?= esc_attr( $c1 ) ?>;color:#fff;}
#<?= esc_attr( $uid ) ?>::after{content:"";position:absolute;top:0;left:-120%;width:60%;height:100%;background:linear-gradient(120deg,transparent,rgba(255,255,255,.55),transparent);transform:skewX(-20deg);animation:wffb-shine 3s ease-in-out infinite;}
@keyframes wffb-shine{0%{left:-120%}45%,100%{left:130%}}
<?php elseif ( 'glow' === $style ) : ?>
#<?= esc_attr( $uid ) ?>{background:<?= esc_attr( $c1 ) ?>;color:#fff;animation:wffb-glow 2.4s ease-in-out infinite;}
@keyframes wffb-glow{0%,100%{box-shadow:0 0 0 0 <?= esc_attr( $c2 ) ?>66,0 6px 18px <?= esc_attr( $c1 ) ?>55}50%{box-shadow:0 0 0 8px <?= esc_attr( $c2 ) ?>00,0 10px 26px <?= esc_attr( $c1 ) ?>88}}
<?php elseif ( 'gradient' === $style ) : ?>
#<?= esc_attr( $uid ) ?>{color:#fff;background:linear-gradient(90deg,<?= esc_attr( $c1 ) ?>,<?= esc_attr( $c2 ) ?>,<?= esc_attr( $c1 ) ?>);background-size:200% 100%;animation:wffb-grad 4s linear infinite;}
@keyframes wffb-grad{0%{background-position:0% 0}100%{background-position:200% 0}}
<?php elseif ( 'outline' === $style ) : ?>
#<?= esc_attr( $uid ) ?>{background:transparent;color:<?= esc_attr( $c1 ) ?>;border:2px solid <?= esc_attr( $c1 ) ?>;}
#<?= esc_attr( $uid ) ?>::before{content:"";position:absolute;inset:0;border-radius:<?= (int) $rad ?>px;background:<?= esc_attr( $c1 ) ?>;transform:scaleX(0);transform-origin:left;transition:transform .35s ease;z-index:-1;}
#<?= esc_attr( $uid ) ?>:hover{color:#fff;}
#<?= esc_attr( $uid ) ?>:hover::before{transform:scaleX(1);}
<?php elseif ( 'rainbow' === $style ) : ?>
/* Arc-en-ciel : le degrade defile sous le bouton et sert aussi de halo. */
#<?= esc_attr( $uid ) ?>{
	color:#fff;background:transparent;isolation:isolate;
}
#<?= esc_attr( $uid ) ?>::before,#<?= esc_attr( $uid ) ?>::after{
	content:"";position:absolute;z-index:-1;
	background:linear-gradient(90deg,<?= esc_attr( $c1 ) ?>,<?= esc_attr( $c2 ) ?>,#22d3ee,#a855f7,<?= esc_attr( $c1 ) ?>);
	background-size:300% 100%;animation:wffb-rain 6s linear infinite;
}
#<?= esc_attr( $uid ) ?>::before{inset:0;border-radius:<?= (int) $rad ?>px;}
#<?= esc_attr( $uid ) ?>::after{inset:-2px 8px -6px;filter:blur(14px);opacity:.75;border-radius:<?= (int) $rad ?>px;}
@keyframes wffb-rain{0%{background-position:0% 0}100%{background-position:300% 0}}
<?php elseif ( 'shimmer' === $style ) : ?>
/* Scintillement : un liseré tourne autour du bouton (conic-gradient). */
#<?= esc_attr( $uid ) ?>{
	background:#0f0f12;color:#fff;border:1px solid transparent;
	background-clip:padding-box;
}
#<?= esc_attr( $uid ) ?>::before{
	content:"";position:absolute;inset:-140%;z-index:-1;
	background:conic-gradient(from 0deg,transparent 0 78%,<?= esc_attr( $c2 ) ?> 88%,<?= esc_attr( $c1 ) ?> 94%,transparent 100%);
	animation:wffb-spin 2.6s linear infinite;
}
#<?= esc_attr( $uid ) ?>::after{
	content:"";position:absolute;inset:1px;z-index:-1;border-radius:<?= (int) max( 0, $rad - 1 ) ?>px;background:#0f0f12;
}
@keyframes wffb-spin{to{transform:rotate(1turn)}}
<?php elseif ( 'ripple' === $style ) : ?>
#<?= esc_attr( $uid ) ?>{background:<?= esc_attr( $c1 ) ?>;color:#fff;}
#<?= esc_attr( $uid ) ?> .wf-fb-wave{
	position:absolute;border-radius:50%;pointer-events:none;
	background:<?= esc_attr( $c2 ) ?>;opacity:.55;transform:translate(-50%,-50%) scale(0);
	animation:wffb-wave .6s ease-out forwards;
}
@keyframes wffb-wave{to{transform:translate(-50%,-50%) scale(1);opacity:0}}
<?php elseif ( 'pulse' === $style ) : ?>
#<?= esc_attr( $uid ) ?>{background:<?= esc_attr( $c1 ) ?>;color:#fff;overflow:visible;}
#<?= esc_attr( $uid ) ?>::before{
	content:"";position:absolute;inset:0;border-radius:<?= (int) $rad ?>px;z-index:-1;
	background:<?= esc_attr( $c1 ) ?>;animation:wffb-pulse 1.9s cubic-bezier(.2,.8,.2,1) infinite;
}
@keyframes wffb-pulse{0%{transform:scale(1);opacity:.6}70%,100%{transform:scale(1.28);opacity:0}}
<?php elseif ( 'slide' === $style ) : ?>
/* Roulement : le libelle monte, sa copie le remplace — sans fondu, le mouvement
   suffit et le texte reste lisible du debut a la fin. */
#<?= esc_attr( $uid ) ?>{background:<?= esc_attr( $c1 ) ?>;color:#fff;}
#<?= esc_attr( $uid ) ?> .wf-fb-a,#<?= esc_attr( $uid ) ?> .wf-fb-b{
	display:block;transition:transform .32s cubic-bezier(.2,.8,.2,1);
}
#<?= esc_attr( $uid ) ?> .wf-fb-b{position:absolute;left:0;right:0;transform:translateY(100%);}
#<?= esc_attr( $uid ) ?>:hover .wf-fb-a,#<?= esc_attr( $uid ) ?>:focus-visible .wf-fb-a{transform:translateY(-100%);}
#<?= esc_attr( $uid ) ?>:hover .wf-fb-b,#<?= esc_attr( $uid ) ?>:focus-visible .wf-fb-b{transform:translateY(0);}
<?php elseif ( 'hold' === $style ) : ?>
/* Appui maintenu : la jauge se remplit tant que le doigt reste pose. Relacher
   avant la fin annule — c'est le principe, on ne valide pas par megarde. */
#<?= esc_attr( $uid ) ?>{background:<?= esc_attr( $c1 ) ?>;color:#fff;touch-action:none;}
#<?= esc_attr( $uid ) ?> .wf-fb-fill{
	position:absolute;inset:0;transform-origin:left center;transform:scaleX(0);
	background:<?= esc_attr( $c2 ) ?>;transition:transform .22s ease-out;
}
#<?= esc_attr( $uid ) ?>.is-holding .wf-fb-fill{
	transform:scaleX(1);transition:transform <?= (int) $holdMs ?>ms linear;
}
#<?= esc_attr( $uid ) ?> .wf-fb-a{position:relative;z-index:1;}
#<?= esc_attr( $uid ) ?>.is-done{background:<?= esc_attr( $c2 ) ?>;}
<?php else : ?>
/* Echange : le libelle sort par le haut, le second entre par le bas. */
#<?= esc_attr( $uid ) ?>{background:<?= esc_attr( $c1 ) ?>;color:#fff;}
#<?= esc_attr( $uid ) ?> .wf-fb-a,#<?= esc_attr( $uid ) ?> .wf-fb-b{
	display:block;transition:transform .35s cubic-bezier(.2,.8,.2,1),opacity .35s ease;
}
#<?= esc_attr( $uid ) ?> .wf-fb-b{position:absolute;left:0;right:0;transform:translateY(120%);opacity:0;}
#<?= esc_attr( $uid ) ?>:hover .wf-fb-a,#<?= esc_attr( $uid ) ?>:focus-visible .wf-fb-a{transform:translateY(-120%);opacity:0;}
#<?= esc_attr( $uid ) ?>:hover .wf-fb-b,#<?= esc_attr( $uid ) ?>:focus-visible .wf-fb-b{transform:translateY(0);opacity:1;}
<?php endif; ?>
@media(prefers-reduced-motion:reduce){
	#<?= esc_attr( $uid ) ?>,#<?= esc_attr( $uid ) ?>::before,#<?= esc_attr( $uid ) ?>::after{animation:none!important}
	#<?= esc_attr( $uid ) ?> .wf-fb-a,#<?= esc_attr( $uid ) ?> .wf-fb-b{transition-duration:.001ms}
}
</style>
<?php if ( $isHold ) : ?>
<script>
(function(){
	var b = document.getElementById('<?= esc_js( $uid ) ?>');
	if (!b) { return; }
	var lab = b.querySelector('.wf-fb-a');
	var ms = <?= (int) $holdMs ?>;
	var href = b.getAttribute('href');
	var timer = null, running = false, finished = false;

	function stop(){
		if (!running) { return; }
		running = false;
		window.clearTimeout(timer);
		b.classList.remove('is-holding');
	}
	function done(){
		running = false;
		finished = true;
		b.classList.remove('is-holding');
		b.classList.add('is-done');
		lab.textContent = <?= wp_json_encode( $holdDone ) ?>;
		if (!href) { return; }
		if (href === '#') { return; }
		window.location.href = href;
	}
	function start(){
		if (finished) { return; }
		if (running) { return; }
		running = true;
		b.classList.add('is-holding');
		timer = window.setTimeout(done, ms);
	}

	b.addEventListener('click', function(e){ e.preventDefault(); });
	b.addEventListener('pointerdown', function(e){ e.preventDefault(); start(); });
	b.addEventListener('pointerup', stop);
	b.addEventListener('pointerleave', stop);
	b.addEventListener('pointercancel', stop);
	b.addEventListener('blur', stop);
	// Au clavier : maintenir Entree ou Espace fait le meme travail.
	b.addEventListener('keydown', function(e){
		if (e.key !== 'Enter') { if (e.key !== ' ') { return; } }
		e.preventDefault();
		start();
	});
	b.addEventListener('keyup', function(e){
		if (e.key !== 'Enter') { if (e.key !== ' ') { return; } }
		stop();
	});
})();
</script>
<?php endif; ?>
<?php if ( 'ripple' === $style ) : ?>
<script>
(function(){
	var b = document.getElementById('<?= esc_js( $uid ) ?>');
	if (!b) { return; }
	if (window.matchMedia) {
		if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { return; }
	}
	b.addEventListener('pointerdown', function(e){
		var r = b.getBoundingClientRect();
		var d = Math.max(r.width, r.height) * 2.2;
		var w = document.createElement('span');
		w.className = 'wf-fb-wave';
		w.style.width = d + 'px';
		w.style.height = d + 'px';
		w.style.left = (e.clientX - r.left) + 'px';
		w.style.top = (e.clientY - r.top) + 'px';
		b.appendChild(w);
		setTimeout(function(){ if (w.parentNode) { w.parentNode.removeChild(w); } }, 650);
	});
})();
</script>
<?php endif; ?>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
