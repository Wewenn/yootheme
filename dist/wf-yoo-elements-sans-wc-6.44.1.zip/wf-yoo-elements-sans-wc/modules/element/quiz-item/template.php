<?php
/**
 * WeFrame - Questionnaire (question enfant) | template.php v1.0
 * Le parent construit le parcours : l'enfant n'affiche rien seul.
 */
defined( 'ABSPATH' ) || exit;
echo '';
