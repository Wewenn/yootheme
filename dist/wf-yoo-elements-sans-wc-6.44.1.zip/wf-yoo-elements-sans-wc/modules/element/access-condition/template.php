<?php
defined( 'ABSPATH' ) || exit;
require_once __DIR__ . '/../../wf-motion-kit.php';

$p       = wfmk_props( 'access-condition', $props );
$checks  = array();
$login   = wfmk_choice( $p['login'] ?? 'any', array( 'any', 'guest', 'logged' ), 'any' );
$now     = current_time( 'timestamp' );
$today   = wp_date( 'Y-m-d', $now );
$minutes = (int) wp_date( 'G', $now ) * 60 + (int) wp_date( 'i', $now );

if ( 'any' !== $login ) { $checks[] = 'logged' === $login ? is_user_logged_in() : ! is_user_logged_in(); }
if ( '' !== trim( (string) ( $p['roles'] ?? '' ) ) ) {
	$wanted = array_filter( array_map( 'sanitize_key', preg_split( '/[\s,]+/', (string) $p['roles'] ) ) );
	$user   = wp_get_current_user();
	$checks[] = (bool) array_intersect( $wanted, (array) $user->roles );
}
if ( '' !== trim( (string) ( $p['capability'] ?? '' ) ) ) { $checks[] = current_user_can( sanitize_key( $p['capability'] ) ); }
if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $p['date_start'] ?? '' ) ) ) { $checks[] = $today >= $p['date_start']; }
if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $p['date_end'] ?? '' ) ) ) { $checks[] = $today <= $p['date_end']; }
if ( '' !== trim( (string) ( $p['weekdays'] ?? '' ) ) ) {
	$days = array_map( 'intval', preg_split( '/[\s,]+/', (string) $p['weekdays'] ) );
	$checks[] = in_array( (int) wp_date( 'N', $now ), $days, true );
}
$to_minutes = static function ( $time ) {
	return preg_match( '/^(\d{1,2}):(\d{2})$/', (string) $time, $m ) ? min( 1439, (int) $m[1] * 60 + (int) $m[2] ) : null;
};
$start = $to_minutes( $p['time_start'] ?? '' );
$end   = $to_minutes( $p['time_end'] ?? '' );
if ( null !== $start || null !== $end ) {
	if ( null === $start ) { $checks[] = $minutes <= $end; }
	elseif ( null === $end ) { $checks[] = $minutes >= $start; }
	elseif ( $start <= $end ) { $checks[] = $minutes >= $start && $minutes <= $end; }
	else { $checks[] = $minutes >= $start || $minutes <= $end; }
}
$path = wp_parse_url( home_url( add_query_arg( array() ) ), PHP_URL_PATH ) ?: '/';
$uri  = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : $path; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
$rule = wfmk_choice( $p['url_rule'] ?? 'any', array( 'any', 'contains', 'not_contains', 'exact' ), 'any' );
$needle = (string) ( $p['url_value'] ?? '' );
if ( 'any' !== $rule && '' !== $needle ) {
	if ( 'exact' === $rule ) { $checks[] = untrailingslashit( wp_parse_url( $uri, PHP_URL_PATH ) ?: '/' ) === untrailingslashit( $needle ); }
	else { $has = false !== strpos( $uri, $needle ); $checks[] = 'contains' === $rule ? $has : ! $has; }
}
$qkey = sanitize_key( (string) ( $p['query_key'] ?? '' ) );
if ( '' !== $qkey ) {
	$actual = isset( $_GET[ $qkey ] ) && ! is_array( $_GET[ $qkey ] ) ? sanitize_text_field( wp_unslash( $_GET[ $qkey ] ) ) : null;
	$checks[] = '' === (string) ( $p['query_value'] ?? '' ) ? null !== $actual : hash_equals( (string) $p['query_value'], (string) $actual );
}
$device = wfmk_choice( $p['device'] ?? 'any', array( 'any', 'mobile', 'desktop' ), 'any' );
if ( 'any' !== $device ) { $checks[] = 'mobile' === $device ? wp_is_mobile() : ! wp_is_mobile(); }
if ( '' !== trim( (string) ( $p['language'] ?? '' ) ) ) {
	$languages = array_map( 'strtolower', array_filter( preg_split( '/[\s,]+/', (string) $p['language'] ) ) );
	$locale = strtolower( determine_locale() );
	$checks[] = in_array( $locale, $languages, true ) || in_array( substr( $locale, 0, 2 ), $languages, true );
}
$meta_key = sanitize_key( (string) ( $p['post_meta_key'] ?? '' ) );
if ( '' !== $meta_key ) {
	$meta = get_post_meta( get_the_ID(), $meta_key, true );
	$expected = (string) ( $p['post_meta_value'] ?? '' );
	$checks[] = '' === $expected ? '' !== (string) $meta : hash_equals( $expected, (string) $meta );
}

$allowed = empty( $checks ) || ( 'or' === ( $p['logic'] ?? 'and' ) ? in_array( true, $checks, true ) : ! in_array( false, $checks, true ) );
if ( ! empty( $p['invert'] ) ) { $allowed = ! $allowed; }
$in_builder = function_exists( 'is_admin' ) && is_admin();
if ( ! $allowed && ! ( $in_builder && ! empty( $p['builder_preview'] ) ) ) { return; }

$inner = '';
foreach ( $children ?? array() as $child ) { $inner .= $builder->render( $child, array( 'element' => $props ) ); }
if ( '' === trim( $inner ) ) { return; }
$wf_el = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( 'div' ) : null;
if ( $wf_el ) { echo $wf_el( $props, $attrs ?? array() ); }
?>
<div class="wf-access-condition<?= $allowed ? '' : ' wf-access-condition--preview' ?>"<?= $allowed ? '' : ' data-wf-condition-preview="hidden"' ?>><?= $inner // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
<?php if ( $wf_el ) { echo $wf_el->end(); } ?>
