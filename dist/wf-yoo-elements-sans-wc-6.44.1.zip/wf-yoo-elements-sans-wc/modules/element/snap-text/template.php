<?php
/**
 * WeFrame – Texte qui accroche | template.php v1.0
 * Un texte fixe suivi d'une liste de mots qui defilent verticalement et
 * s'accrochent (scroll-snap). Trois moteurs : automatique, a la molette dans la
 * zone, ou pilote par le defilement de la page.
 *
 * Sans JS, ou en « moins d'animations », la liste reste une liste lisible :
 * tous les mots sont dans le DOM, le premier est mis en avant.
 * Pas de "&&" ni de "||" dans le JS inline (regle interne du plugin).
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$prefix = trim( (string) ( $props['prefix'] ?? '' ) );
$mode   = (string) ( $props['mode'] ?? 'auto' );
if ( ! in_array( $mode, array( 'auto', 'scroll', 'page' ), true ) ) { $mode = 'auto'; }

$interval = max( 600, (int) ( $props['interval'] ?? 2200 ) );
$dur      = max( 100, (int) ( $props['duration'] ?? 520 ) );

$fs    = max( 16, (int) ( $props['font_size'] ?? 56 ) );
$fsMin = max( 14, (int) ( $props['font_size_min'] ?? 28 ) );
if ( $fsMin > $fs ) { $fsMin = $fs; }
$fw    = (string) ( $props['weight'] ?? '700' );
$align = (string) ( $props['align'] ?? 'center' );
if ( ! in_array( $align, array( 'left', 'center', 'right' ), true ) ) { $align = 'center'; }

$pCol = (string) ( $props['prefix_color'] ?? '#111111' );
$aCol = (string) ( $props['active_color'] ?? '#EA5C1C' );
$iCol = (string) ( $props['idle_color'] ?? '#111111' );
$iOp  = max( 0, min( 100, (int) ( $props['idle_opacity'] ?? 25 ) ) );
$bar  = ! empty( $props['show_scrollbar'] );

$words = array();
foreach ( $children as $child ) {
	$cp = (array) ( $child->props ?? array() );
	$w  = trim( (string) ( $cp['word'] ?? '' ) );
	if ( '' === $w ) { continue; }
	$words[] = array( 'w' => $w, 'c' => trim( (string) ( $cp['color'] ?? '' ) ) );
}
if ( empty( $words ) ) { return; }
$n = count( $words );

$lineH = 1.15;
$uid   = wf_uid( 'wfst_', $props, $n );
$just  = array( 'left' => 'flex-start', 'center' => 'center', 'right' => 'flex-end' );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-st wf-st--<?= esc_attr( $mode ) ?><?= $bar ? '' : ' wf-st--nobar' ?>" data-count="<?= (int) $n ?>">
	<p class="__line">
		<?php if ( '' !== $prefix ) : ?><span class="__prefix"><?= esc_html( $prefix ) ?></span><?php endif; ?>
		<span class="__viewport">
			<span class="__list" role="list">
				<?php foreach ( $words as $i => $w ) : ?>
				<span class="__word<?= 0 === $i ? ' is-active' : '' ?>" role="listitem"<?= '' !== $w['c'] ? ' style="--wc:' . esc_attr( $w['c'] ) . '"' : '' ?>><?= esc_html( $w['w'] ) ?></span>
				<?php endforeach; ?>
			</span>
		</span>
	</p>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?>{container-type:inline-size;}
#<?= esc_attr( $uid ) ?> .__line{
	margin:0;display:flex;flex-wrap:wrap;align-items:baseline;gap:.35em;
	justify-content:<?= esc_attr( $just[ $align ] ) ?>;
	font-size:clamp(<?= (int) $fsMin ?>px, 8cqw, <?= (int) $fs ?>px);
	font-weight:<?= esc_attr( $fw ) ?>;line-height:<?= esc_attr( $lineH ) ?>;
}
#<?= esc_attr( $uid ) ?> .__prefix{color:<?= esc_attr( $pCol ) ?>;}
#<?= esc_attr( $uid ) ?> .__viewport{
	display:block;overflow:hidden;height:<?= esc_attr( $lineH ) ?>em;
	position:relative;min-width:0;
}
#<?= esc_attr( $uid ) ?> .__list{
	display:block;transition:transform <?= (int) $dur ?>ms cubic-bezier(.2,.8,.2,1);
	will-change:transform;
}
#<?= esc_attr( $uid ) ?> .__word{
	display:block;height:<?= esc_attr( $lineH ) ?>em;white-space:nowrap;
	color:<?= esc_attr( $iCol ) ?>;opacity:<?= esc_attr( round( $iOp / 100, 2 ) ) ?>;
	transition:color <?= (int) $dur ?>ms ease,opacity <?= (int) $dur ?>ms ease;
}
#<?= esc_attr( $uid ) ?> .__word.is-active{color:var(--wc,<?= esc_attr( $aCol ) ?>);opacity:1;}

<?php if ( 'scroll' === $mode ) : ?>
/* Molette dans la zone : c'est le navigateur qui accroche, pas un script. */
#<?= esc_attr( $uid ) ?> .__viewport{
	overflow-y:auto;scroll-snap-type:y mandatory;overscroll-behavior:contain;
	scrollbar-width:thin;
}
#<?= esc_attr( $uid ) ?>.wf-st--nobar .__viewport{scrollbar-width:none;-ms-overflow-style:none;}
#<?= esc_attr( $uid ) ?>.wf-st--nobar .__viewport::-webkit-scrollbar{display:none;}
#<?= esc_attr( $uid ) ?> .__list{transition:none;}
#<?= esc_attr( $uid ) ?> .__word{scroll-snap-align:start;}
<?php endif; ?>

@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?> .__list,#<?= esc_attr( $uid ) ?> .__word{transition-duration:.001ms;}
	#<?= esc_attr( $uid ) ?> .__viewport{height:auto;overflow:visible;scroll-snap-type:none;}
	#<?= esc_attr( $uid ) ?> .__word{opacity:1;color:<?= esc_attr( $iCol ) ?>;}
	#<?= esc_attr( $uid ) ?> .__word.is-active{color:var(--wc,<?= esc_attr( $aCol ) ?>);}
}
</style>

<script>
(function(){
	var root = document.getElementById('<?= esc_js( $uid ) ?>');
	if (!root) { return; }
	var list = root.querySelector('.__list');
	var view = root.querySelector('.__viewport');
	var words = [].slice.call(root.querySelectorAll('.__word'));
	var n = words.length;
	if (n < 2) { return; }

	var reduced = false;
	if (window.matchMedia) {
		if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { reduced = true; }
	}
	if (reduced) { return; }

	var cur = 0;
	function mark(i){
		if (i < 0) { i = 0; }
		if (i > n - 1) { i = n - 1; }
		cur = i;
		for (var k = 0; k < n; k++) { words[k].classList.toggle('is-active', k === i); }
	}

<?php if ( 'scroll' === $mode ) : ?>
	// La position vient du defilement reel de la zone : rien a deplacer nous-memes.
	var t = null;
	view.addEventListener('scroll', function(){
		if (t) { return; }
		t = requestAnimationFrame(function(){
			t = null;
			var h = words[0].offsetHeight;
			if (h < 1) { return; }
			mark(Math.round(view.scrollTop / h));
		});
	}, { passive: true });
<?php else : ?>
	function go(i){
		if (i < 0) { i = n - 1; }
		if (i > n - 1) { i = 0; }
		var h = words[0].offsetHeight;
		list.style.transform = 'translateY(' + (-i * h) + 'px)';
		mark(i);
	}
<?php if ( 'auto' === $mode ) : ?>
	var timer = null;
	function start(){ stop(); timer = setInterval(function(){ go(cur + 1); }, <?= (int) $interval ?>); }
	function stop(){ if (timer) { clearInterval(timer); timer = null; } }
	root.addEventListener('mouseenter', stop);
	root.addEventListener('mouseleave', start);
	go(0);
	if (typeof WF !== 'undefined') {
		if (WF.onVisible) { WF.onVisible(root, start, 0.3); }
		else { start(); }
	} else { start(); }
<?php else : ?>
	// Pilote par la page : la liste avance au fil du defilement du bloc.
	var ticking = false;
	function paint(){
		ticking = false;
		var r = root.getBoundingClientRect();
		var vh = window.innerHeight;
		var span = r.height + vh;
		var p = span > 0 ? (vh - r.top) / span : 0;
		if (p < 0) { p = 0; }
		if (p > 1) { p = 1; }
		go(Math.min(n - 1, Math.floor(p * n)));
	}
	function onScroll(){
		if (ticking) { return; }
		ticking = true;
		// Un onglet en arriere-plan ne declenche aucun requestAnimationFrame :
		// on peint alors directement, sinon l'element resterait fige.
		if (document.hidden) { paint(); }
		else { requestAnimationFrame(paint); }
	}
	window.addEventListener('scroll', onScroll, { passive: true });
	window.addEventListener('resize', onScroll);
	paint();
<?php endif; ?>
<?php endif; ?>
<?php if ( 'scroll' !== $mode ) : ?>
	// La hauteur d'une ligne change avec la largeur : on repositionne sur la bonne.
	window.addEventListener('resize', function(){
		var h = words[0].offsetHeight;
		list.style.transform = 'translateY(' + (-cur * h) + 'px)';
	});
<?php endif; ?>
})();
</script>
