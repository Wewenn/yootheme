<?php
defined('ABSPATH') || exit;
require_once __DIR__ . '/../../wf-motion-kit.php';
$p=wfmk_props('rays-panel',$props);
$uid=wf_uid('wfmk_', $props);
$wfmkEl=(isset($this) && method_exists($this,'el'))?$this->el('div'):null;
if($wfmkEl)echo $wfmkEl($props,$attrs??[]);
?>
<?php $inner=wfmk_fragment($children??[],$builder,$props);$speed=wfmk_n($p,'speed',35,0,120);?>
<div id="<?=esc_attr($uid)?>" class="wfmk wfmk-rays" style="<?=wfmk_vars(['height'=>wfmk_n($p,'height',540,200,1200).'px','bg'=>wfmk_color($p['bg']),'ink'=>wfmk_color($p['ink']),'c1'=>wfmk_color($p['color1']),'c2'=>wfmk_color($p['color2']),'c3'=>wfmk_color($p['color3']),'speed'=>max(.1,$speed).'s','play'=>$speed>0?'running':'paused','opacity'=>wfmk_n($p,'opacity',70,0,100)/100,'blur'=>wfmk_n($p,'blur',10,0,60).'px','angle'=>wfmk_n($p,'angle',100,0,180).'deg','radius'=>wfmk_n($p,'radius',0,0,100).'px'])?>"><div class="wfmk-rays__paint" aria-hidden="true"></div><div class="wfmk-rays__content"><?php if(trim($inner)!==''):echo $inner;else:?><h2><?=esc_html($p['title'])?></h2><p><?=esc_html($p['text'])?></p><?php endif;?></div></div>

<?php if($wfmkEl)echo $wfmkEl->end(); ?>
