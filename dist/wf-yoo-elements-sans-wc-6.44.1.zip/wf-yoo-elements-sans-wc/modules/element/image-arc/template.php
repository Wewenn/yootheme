<?php
/**
 * WeFrame – Image Arc | template.php
 * Hero with images fanned along a circular arc around centered content.
 * Cards burst out from the centre on page load (opening animation).
 * Config inlined (no <script type="application/json">), no "&&" in inline JS.
 */
defined( 'ABSPATH' ) || exit;

$props = is_array( $props ?? null ) ? $props : array();
if ( ! isset( $builder ) || ! is_object( $builder ) ) { return; }

$eyebrow  = trim( (string) ( $props['eyebrow'] ?? '' ) );
$title    = trim( (string) ( $props['title'] ?? '' ) );
$subtitle = trim( (string) ( $props['subtitle'] ?? '' ) );
$b1t = trim( (string) ( $props['btn1_text'] ?? '' ) );
$b1l = (string) ( $props['btn1_link'] ?? '' );
$b2t = trim( (string) ( $props['btn2_text'] ?? '' ) );
$b2l = (string) ( $props['btn2_link'] ?? '' );

$radius  = min( 600, max( 200, (int) ( $props['arc_radius'] ?? 380 ) ) );
$spread  = min( 340, max( 120, (int) ( $props['arc_spread'] ?? 210 ) ) );
$card_w  = min( 260, max( 80, (int) ( $props['card_width'] ?? 150 ) ) );
$ratio   = (string) ( $props['card_ratio'] ?? '3/4' );
$tilt    = min( 100, max( 0, (int) ( $props['card_tilt'] ?? 60 ) ) ) / 100;
$card_r  = min( 30, max( 0, (int) ( $props['card_radius'] ?? 12 ) ) );
$card_sh = ! empty( $props['card_shadow'] );
$mob_arc = (string) ( $props['mobile_arc'] ?? 'hide' );

$bg       = (string) ( $props['bg'] ?? '#0b0b0d' );
$tcol     = (string) ( $props['text_color'] ?? '#ffffff' );
$scol     = (string) ( $props['subtitle_color'] ?? 'rgba(255,255,255,0.6)' );
$minh     = min( 100, max( 60, (int) ( $props['min_height'] ?? 92 ) ) );
$ts       = (int) ( $props['title_size'] ?? 72 );
$ts_t     = (int) ( $props['title_size_tablet'] ?? 52 );
$ts_m     = (int) ( $props['title_size_mobile'] ?? 34 );
$tw       = (string) ( $props['title_weight'] ?? '700' );

$b1bg  = (string) ( $props['btn1_bg'] ?? '#ff5b1e' );
$b1c   = (string) ( $props['btn1_color'] ?? '#ffffff' );
$b2brd = (string) ( $props['btn2_border'] ?? 'rgba(255,255,255,0.25)' );
$b2c   = (string) ( $props['btn2_color'] ?? '#ffffff' );

$anim    = ! empty( $props['anim_load'] );
$dur     = min( 2500, max( 400, (int) ( $props['duration'] ?? 1100 ) ) );
$stagger = min( 300, max( 0, (int) ( $props['stagger'] ?? 90 ) ) );
$float   = ! empty( $props['float_cards'] );
$hover   = ! empty( $props['hover_cards'] );
$parallax= min( 50, max( 0, (int) ( $props['parallax'] ?? 18 ) ) );
$depth   = ! empty( $props['depth_fade'] );

$allowed_ratio = array( '3/4', '4/5', '2/3', '1/1' );
if ( ! in_array( $ratio, $allowed_ratio, true ) ) { $ratio = '3/4'; }

// ── Render image children into arc cards ───────────────
$cards = '';
$k     = 0;
$rendered = array();
if ( ! empty( $children ) && is_array( $children ) ) {
    foreach ( $children as $child ) {
        $inner = '';
        try { $inner = (string) $builder->render( $child, array( 'element' => $props ) ); }
        catch ( \Throwable $e ) { $inner = ''; }
        if ( trim( $inner ) ) { $rendered[] = $inner; }
    }
}
$n = count( $rendered );

if ( $n > 0 ) {
    $px_calc = $parallax > 0 ? ' + var(--px,0px)' : '';
    $py_calc = $parallax > 0 ? ' + var(--py,0px)' : '';
    foreach ( $rendered as $i => $inner ) {
        $t     = ( $n > 1 ) ? $i / ( $n - 1 ) : 0.5;
        $angle = -$spread / 2 + $t * $spread;
        $rad   = deg2rad( $angle );
        $x     = round( $radius * sin( $rad ), 1 );
        $y     = round( -$radius * cos( $rad ), 1 );
        $rot   = round( $angle * $tilt, 1 );
        $delay = $i * $stagger;
        $op    = $depth ? max( 0.72, round( 1 - ( abs( $angle ) / max( 1, $spread / 2 ) ) * 0.22, 2 ) ) : 1;
        $outer = 'translate(calc(-50% + ' . $x . 'px' . $px_calc . '), calc(-50% + ' . $y . 'px' . $py_calc . '))';
        $trans = $anim ? 'transition:transform ' . $dur . 'ms cubic-bezier(.22,1,.36,1) ' . $delay . 'ms,opacity ' . $dur . 'ms ease ' . $delay . 'ms;' : '';
        $float_css = $float ? 'animation:wf-arc-float ' . ( 3 + ( $i % 3 ) ) . 's ease-in-out ' . round( $i * 0.25, 2 ) . 's infinite;' : '';
        $cards .= '<div class="wf-arc-card" style="position:absolute;left:50%;top:50%;width:' . $card_w . 'px;z-index:0;--op:' . $op . ';will-change:transform,opacity;transform:' . $outer . ';' . $trans . '">'
            . '<div class="wf-arc-tilt" style="transform:rotate(' . $rot . 'deg);--rot:' . $rot . 'deg;' . $float_css . '">' . $inner . '</div>'
            . '</div>';
        $k++;
    }
}

$uid = 'wfarc_' . substr( md5( $title . serialize( $props ) . $k ), 0, 8 );

$cfg = wp_json_encode( array(
    'uid'  => $uid,
    'anim' => $anim ? 1 : 0,
    'px'   => $parallax,
), JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE );

$sh_css = $card_sh ? 'box-shadow:0 30px 60px -25px rgba(0,0,0,.6);' : '';
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-arc<?= $anim ? '' : ' is-loaded' ?>" style="position:relative;overflow:hidden;min-height:<?= $minh ?>vh;display:flex;align-items:center;justify-content:center;background:<?= esc_attr( $bg ) ?>;padding:60px 20px;box-sizing:border-box;">

    <div class="wf-arc-stage" aria-hidden="true" style="position:absolute;inset:0;z-index:0;pointer-events:none;">
        <?= $cards ?>
    </div>

    <div class="wf-arc-content" style="position:relative;z-index:2;text-align:center;max-width:760px;">
        <?php if ( $eyebrow ) : ?>
        <div style="font-size:13px;letter-spacing:.12em;text-transform:uppercase;font-weight:600;opacity:.6;color:<?= esc_attr( $tcol ) ?>;margin-bottom:18px;"><?= esc_html( $eyebrow ) ?></div>
        <?php endif; ?>
        <?php if ( $title ) : ?>
        <h2 class="wf-arc-title" style="margin:0;color:<?= esc_attr( $tcol ) ?>;font-size:<?= $ts ?>px;font-weight:<?= esc_attr( $tw ) ?>;line-height:1.04;letter-spacing:-.02em;"><?= nl2br( esc_html( $title ) ) ?></h2>
        <?php endif; ?>
        <?php if ( $subtitle ) : ?>
        <p style="margin:20px auto 0;max-width:520px;color:<?= esc_attr( $scol ) ?>;font-size:17px;line-height:1.5;"><?= nl2br( esc_html( $subtitle ) ) ?></p>
        <?php endif; ?>
        <?php if ( $b1t || $b2t ) : ?>
        <div style="display:flex;gap:14px;justify-content:center;flex-wrap:wrap;margin-top:32px;">
            <?php if ( $b1t ) : ?>
            <a href="<?= esc_url( $b1l ?: '#' ) ?>" style="display:inline-flex;align-items:center;padding:15px 30px;border-radius:10px;background:<?= esc_attr( $b1bg ) ?>;color:<?= esc_attr( $b1c ) ?>;font-weight:700;text-decoration:none;letter-spacing:.02em;transition:transform .2s ease;"><?= esc_html( $b1t ) ?></a>
            <?php endif; ?>
            <?php if ( $b2t ) : ?>
            <a href="<?= esc_url( $b2l ?: '#' ) ?>" style="display:inline-flex;align-items:center;gap:8px;padding:15px 28px;border-radius:10px;background:transparent;border:1px solid <?= esc_attr( $b2brd ) ?>;color:<?= esc_attr( $b2c ) ?>;font-weight:600;text-decoration:none;transition:transform .2s ease;"><?= esc_html( $b2t ) ?> &rarr;</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<style>
@keyframes wf-arc-float { 0%,100% { transform: rotate(var(--rot,0deg)) translateY(0); } 50% { transform: rotate(var(--rot,0deg)) translateY(-9px); } }
#<?= esc_attr( $uid ) ?> .wf-arc-card { opacity: var(--op, 1); }
#<?= esc_attr( $uid ) ?> .wf-arc-tilt { display: block; }
#<?= esc_attr( $uid ) ?> .wf-arc-card .wf-sp-fig { margin: 0; }
#<?= esc_attr( $uid ) ?> .wf-arc-card .wf-sp-fig img { width: 100%; height: auto; aspect-ratio: <?= esc_attr( $ratio ) ?>; object-fit: cover; border-radius: <?= $card_r ?>px !important; <?= $sh_css ?> }
<?php if ( $anim ) : ?>
#<?= esc_attr( $uid ) ?>:not(.is-loaded) .wf-arc-card { transform: translate(-50%, -50%) scale(.12) !important; opacity: 0 !important; }
#<?= esc_attr( $uid ) ?>:not(.is-loaded) .wf-arc-tilt { animation-play-state: paused !important; }
<?php endif; ?>
<?php if ( $hover ) : ?>
#<?= esc_attr( $uid ) ?> .wf-arc-card { pointer-events: auto; }
#<?= esc_attr( $uid ) ?> .wf-arc-tilt { transition: transform .35s cubic-bezier(.22,1,.36,1); }
#<?= esc_attr( $uid ) ?>.is-loaded .wf-arc-card:hover { z-index: 6; }
#<?= esc_attr( $uid ) ?>.is-loaded .wf-arc-card:hover .wf-arc-tilt { transform: rotate(0deg) scale(1.08) !important; animation-play-state: paused !important; }
<?php endif; ?>
#<?= esc_attr( $uid ) ?> .wf-arc-content a:hover { transform: translateY(-2px); }

@media (min-width:768px) and (max-width:1024px) {
    #<?= esc_attr( $uid ) ?> .wf-arc-title { font-size: <?= $ts_t ?>px !important; }
    #<?= esc_attr( $uid ) ?> .wf-arc-stage { transform: scale(.72); }
}
@media (max-width:767px) {
    #<?= esc_attr( $uid ) ?> .wf-arc-title { font-size: <?= $ts_m ?>px !important; }
    <?php if ( 'hide' === $mob_arc ) : ?>
    #<?= esc_attr( $uid ) ?> .wf-arc-stage { display: none !important; }
    <?php else : ?>
    #<?= esc_attr( $uid ) ?> .wf-arc-stage { transform: scale(.5); }
    <?php endif; ?>
}
@media (prefers-reduced-motion: reduce) {
    #<?= esc_attr( $uid ) ?> .wf-arc-card { transition: none !important; }
    #<?= esc_attr( $uid ) ?>:not(.is-loaded) .wf-arc-card { opacity: 1; transform: translate(calc(-50% + 0px), -50%) scale(1) !important; }
}
</style>

<script>
(function(){
    var C = <?= $cfg ?>;
    function boot(){
        var el = document.getElementById(C.uid); if (!el) return;

        if (C.anim) {
            var reveal = function(){
                requestAnimationFrame(function(){ requestAnimationFrame(function(){ el.classList.add('is-loaded'); }); });
            };
            if ('IntersectionObserver' in window) {
                var fired = false;
                new IntersectionObserver(function(es){
                    var i = 0; while (i < es.length) {
                        if (es[i].isIntersecting) { if (!fired) { fired = true; reveal(); } }
                        i++;
                    }
                }, { threshold: 0.2 }).observe(el);
            } else { reveal(); }
        }

        if (C.px > 0) {
            var stage = el.querySelector('.wf-arc-stage');
            var ticking = false, mx = 0, my = 0;
            function apply(){
                ticking = false;
                el.style.setProperty('--px', mx.toFixed(1) + 'px');
                el.style.setProperty('--py', my.toFixed(1) + 'px');
            }
            el.addEventListener('mousemove', function(e){
                var r = el.getBoundingClientRect();
                var nx = (e.clientX - (r.left + r.width / 2)) / (r.width / 2);
                var ny = (e.clientY - (r.top + r.height / 2)) / (r.height / 2);
                mx = nx * C.px; my = ny * C.px;
                if (!ticking) { ticking = true; requestAnimationFrame(apply); }
            });
            el.addEventListener('mouseleave', function(){ mx = 0; my = 0; if (!ticking) { ticking = true; requestAnimationFrame(apply); } });
        }
    }
    if (window.WF) { if (WF.ready) { WF.ready(boot); return; } }
    if (document.readyState !== 'loading') { boot(); } else { document.addEventListener('DOMContentLoaded', boot); }
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
