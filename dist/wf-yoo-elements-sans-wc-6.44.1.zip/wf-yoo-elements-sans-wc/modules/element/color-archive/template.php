<?php
defined('ABSPATH') || exit;
require_once __DIR__ . '/../../wf-motion-kit.php';
$p=wfmk_props('color-archive',$props);
$uid=wf_uid('wfmk_', $props);
$wfmkEl=(isset($this) && method_exists($this,'el'))?$this->el('div'):null;
if($wfmkEl)echo $wfmkEl($props,$attrs??[]);
?>
<?php $cfg=['loop'=>!empty($p['loop']),'drag'=>!empty($p['drag']),'sound'=>!empty($p['sound'])];?>
<div id="<?=esc_attr($uid)?>" class="wfmk wfmk-archive" data-wf-motion="archive" data-wf-config="<?=wfmk_json($cfg)?>" style="<?=wfmk_vars(['height'=>wfmk_n($p,'height',620,400,1000).'px','mobile-height'=>wfmk_n($p,'height_mobile',620,400,850).'px','size'=>wfmk_n($p,'font_size',46,20,90).'px','image-width'=>wfmk_n($p,'image_width',320,160,500).'px','radius'=>wfmk_n($p,'radius',10,0,80).'px'])?>">
 <div class="wfmk-archive__list" tabindex="0" role="group" aria-label="Projets — faites défiler ou utilisez les flèches">
 <?php foreach($children??[] as $i=>$child):$it=wfmk_props('color-archive-item',$child->props??[]);?>
  <button type="button" class="wfmk-archive__entry" data-index="<?=$i?>" data-bg="<?=esc_attr(wfmk_color($it['bg']))?>" data-ink="<?=esc_attr(wfmk_color($it['ink']))?>"><small><?=sprintf('%02d',$i+1)?></small><span><?=esc_html($it['title'])?></span></button>
 <?php endforeach;?>
 </div>
 <div class="wfmk-archive__previews">
 <?php foreach($children??[] as $i=>$child):$it=wfmk_props('color-archive-item',$child->props??[]);$src=wfmk_src($it['image']);?>
  <article class="wfmk-archive__preview" data-preview="<?=$i?>">
   <?php if($src):?><img src="<?=$src?>" alt="<?=esc_attr($it['image_alt'])?>" draggable="false" loading="lazy"><?php else:?><div class="wfmk-placeholder">Photo <?=$i+1?></div><?php endif;?>
   <small><?=esc_html($it['badge'])?></small><h3><?=esc_html($it['title'])?></h3><p><?=esc_html($it['text'])?></p>
   <?php if(esc_url($it['link'])):?><a href="<?=esc_url($it['link'])?>">Voir le projet →</a><?php endif;?>
  </article>
 <?php endforeach;?>
 </div>
 <div class="wfmk-controls"><button type="button" data-action="previous" aria-label="Projet précédent">←</button><span data-counter aria-live="polite"></span><button type="button" data-action="next" aria-label="Projet suivant">→</button><?php if($p['sound']):?><button type="button" data-action="sound" aria-pressed="false">Activer le son</button><?php endif;?></div>
</div>

<?php if($wfmkEl)echo $wfmkEl->end(); ?>
