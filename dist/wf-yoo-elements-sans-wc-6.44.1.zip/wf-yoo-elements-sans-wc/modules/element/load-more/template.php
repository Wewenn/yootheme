<?php
/**
 * WeFrame – Charger plus | template.php v1.0
 * Page 1 rendue par le serveur (visible sans JS et indexable), pages suivantes
 * via fetch(). Le rendu des cartes est partage avec l'endpoint AJAX
 * (modules/wf-load-more.php) : le balisage ne peut pas diverger.
 * Pas de "&&" ni de "||" dans le JS inline (regle interne du plugin).
 */
defined( 'ABSPATH' ) || exit;
if ( ! function_exists( 'wf_lm_sanitize_opts' ) ) { return; }

$pt = (string) ( $props['post_type'] ?? 'post' );
if ( 'custom' === $pt ) { $pt = trim( (string) ( $props['post_type_custom'] ?? '' ) ); }
if ( '' === $pt ) { $pt = 'post'; }

$o = wf_lm_sanitize_opts(
	array(
		'post_type'     => $pt,
		'taxonomy'      => $props['taxonomy'] ?? '',
		'terms'         => $props['terms'] ?? '',
		'search'        => $props['search'] ?? '',
		'author'        => $props['author'] ?? 0,
		'parent'        => $props['parent'] ?? 0,
		'include_ids'   => $props['include_ids'] ?? '',
		'exclude_ids'   => $props['exclude_ids'] ?? '',
		'meta_key'      => $props['meta_key'] ?? '',
		'meta_value'    => $props['meta_value'] ?? '',
		'meta_compare'  => $props['meta_compare'] ?? '=',
		'per_page'      => $props['per_page'] ?? 9,
		'orderby'       => $props['orderby'] ?? 'date',
		'order'         => $props['order'] ?? 'DESC',
		'paged'         => 1,
		'exclude'       => ! empty( $props['exclude_current'] ) ? get_the_ID() : 0,
		'img_ratio'     => $props['img_ratio'] ?? '16-9',
		'show_image'    => ! empty( $props['show_image'] ),
		'show_date'     => ! empty( $props['show_date'] ),
		'show_terms'    => ! empty( $props['show_terms'] ),
		'show_excerpt'  => ! empty( $props['show_excerpt'] ),
		'show_more'     => ! empty( $props['show_more'] ),
		'excerpt_words' => $props['excerpt_words'] ?? 22,
		'more_text'     => $props['more_text'] ?? '',
	)
);

$q     = new WP_Query( wf_lm_query_args( $o ) );
$cards = wf_lm_render_cards( $q, $o );
$max   = (int) $q->max_num_pages;
$total = (int) $q->found_posts;
wp_reset_postdata();

$mode   = (string) ( $props['mode'] ?? 'button' );
if ( ! in_array( $mode, array( 'button', 'infinite', 'hybrid' ), true ) ) { $mode = 'button'; }
$autoPg = max( 1, min( 10, (int) ( $props['auto_pages'] ?? 2 ) ) );

$btnText = trim( (string) ( $props['btn_text'] ?? '' ) );
if ( '' === $btnText ) { $btnText = __( 'Charger plus', 'weframe' ); }
$btnLoad = trim( (string) ( $props['btn_loading'] ?? '' ) );
if ( '' === $btnLoad ) { $btnLoad = __( 'Chargement…', 'weframe' ); }
$endText = trim( (string) ( $props['end_text'] ?? '' ) );

$cols  = max( 1, min( 6, (int) ( $props['columns'] ?? 3 ) ) );
$colsT = max( 1, min( 4, (int) ( $props['columns_tablet'] ?? 2 ) ) );
$colsM = max( 1, min( 2, (int) ( $props['columns_mobile'] ?? 1 ) ) );
$gap   = max( 0, (int) ( $props['gap'] ?? 24 ) );

$cBg   = trim( (string) ( $props['card_bg'] ?? '' ) );
$cCol  = trim( (string) ( $props['card_color'] ?? '' ) );
$cMut  = (string) ( $props['card_muted'] ?? '#6b7280' );
$cBd   = trim( (string) ( $props['card_border'] ?? '' ) );
$cRad  = max( 0, (int) ( $props['card_radius'] ?? 14 ) );
$cPad  = max( 0, (int) ( $props['card_padding'] ?? 20 ) );
$tSize = max( 13, (int) ( $props['title_size'] ?? 19 ) );
$acc   = (string) ( $props['accent_color'] ?? '#EA5C1C' );
$hover = (string) ( $props['hover'] ?? 'lift' );

$bStyle = (string) ( $props['btn_style'] ?? 'filled' );
$bBg    = (string) ( $props['btn_bg'] ?? '#EA5C1C' );
$bCol   = (string) ( $props['btn_color'] ?? '#ffffff' );
$bRad   = max( 0, (int) ( $props['btn_radius'] ?? 8 ) );
$bAlign = (string) ( $props['btn_align'] ?? 'center' );

$spinner = ! empty( $props['spinner'] );
$updUrl  = ! empty( $props['update_url'] );
$prefill = ! empty( $props['prefill'] );
$track   = ! empty( $props['track'] );

$uid   = wf_uid( 'wflm_', $props, $total );
$nonce = wp_create_nonce( 'wf_lm' );
$ajax  = admin_url( 'admin-ajax.php' );

// Options renvoyees a chaque appel : elles sont revalidees cote serveur.
$jsOpts = wp_json_encode( $o );

$alignMap = array( 'left' => 'flex-start', 'center' => 'center', 'right' => 'flex-end' );
$bJust    = $alignMap[ $bAlign ] ?? 'center';
$hasMore  = $max > 1;
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-lm wf-lm--hover-<?= esc_attr( $hover ) ?>"
	data-nonce="<?= esc_attr( $nonce ) ?>"
	data-ajax="<?= esc_url( $ajax ) ?>"
	data-max="<?= (int) $max ?>"
	data-opts="<?= esc_attr( $jsOpts ) ?>">

	<?php if ( '' === trim( $cards ) ) : ?>
		<p class="wf-lm__empty"><?= esc_html__( 'Aucun contenu à afficher pour le moment.', 'weframe' ) ?></p>
	<?php else : ?>
	<div class="wf-lm__grid"><?= $cards ?></div>

	<p class="wf-lm__status" role="status" aria-live="polite"></p>

	<div class="wf-lm__foot"<?= $hasMore ? '' : ' hidden' ?>>
		<button type="button" class="wf-lm__btn wf-lm__btn--<?= esc_attr( $bStyle ) ?>" data-label="<?= esc_attr( $btnText ) ?>" data-loading="<?= esc_attr( $btnLoad ) ?>">
			<?php if ( $spinner ) : ?><span class="wf-lm__spin" aria-hidden="true"></span><?php endif; ?>
			<span class="wf-lm__btn-txt"><?= esc_html( $btnText ) ?></span>
		</button>
	</div>
	<?php if ( '' !== $endText ) : ?>
	<p class="wf-lm__end" hidden><?= esc_html( $endText ) ?></p>
	<?php endif; ?>
	<div class="wf-lm__sentinel" aria-hidden="true"></div>
	<?php endif; ?>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?> .wf-lm__grid{
	display:grid;gap:<?= (int) $gap ?>px;
	grid-template-columns:repeat(<?= (int) $cols ?>,minmax(0,1fr));
}
#<?= esc_attr( $uid ) ?>{container-type:inline-size;}
@container (max-width: 900px){
	#<?= esc_attr( $uid ) ?> .wf-lm__grid{grid-template-columns:repeat(<?= (int) $colsT ?>,minmax(0,1fr));}
}
@container (max-width: 560px){
	#<?= esc_attr( $uid ) ?> .wf-lm__grid{grid-template-columns:repeat(<?= (int) $colsM ?>,minmax(0,1fr));}
}
#<?= esc_attr( $uid ) ?> .wf-lm-card{
	display:flex;flex-direction:column;overflow:hidden;min-width:0;
	border-radius:<?= (int) $cRad ?>px;
	<?= '' !== $cBg ? 'background:' . esc_attr( $cBg ) . ';' : '' ?>
	<?= '' !== $cCol ? 'color:' . esc_attr( $cCol ) . ';' : '' ?>
	<?= '' !== $cBd ? 'border:1px solid ' . esc_attr( $cBd ) . ';' : '' ?>
	transition:transform .25s ease,box-shadow .25s ease;
}
#<?= esc_attr( $uid ) ?> .wf-lm-card .__media{display:block;overflow:hidden;background:rgba(127,127,127,.12);}
#<?= esc_attr( $uid ) ?> .wf-lm-card .__media img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .4s ease;}
#<?= esc_attr( $uid ) ?> .wf-lm-card .__body{padding:<?= (int) $cPad ?>px;display:flex;flex-direction:column;gap:.5em;flex:1 1 auto;}
#<?= esc_attr( $uid ) ?> .wf-lm-card .__meta{
	display:flex;flex-wrap:wrap;gap:.6em;align-items:center;
	font-size:12px;letter-spacing:.06em;text-transform:uppercase;color:<?= esc_attr( $cMut ) ?>;
}
#<?= esc_attr( $uid ) ?> .wf-lm-card .__terms{color:<?= esc_attr( $acc ) ?>;font-weight:700;}
#<?= esc_attr( $uid ) ?> .wf-lm-card .__title{margin:0;font-size:<?= (int) $tSize ?>px;line-height:1.25;font-weight:700;}
#<?= esc_attr( $uid ) ?> .wf-lm-card .__title a{color:inherit;text-decoration:none;}
#<?= esc_attr( $uid ) ?> .wf-lm-card .__title a:hover{color:<?= esc_attr( $acc ) ?>;}
#<?= esc_attr( $uid ) ?> .wf-lm-card .__title a:focus-visible{outline:2px solid <?= esc_attr( $acc ) ?>;outline-offset:3px;}
#<?= esc_attr( $uid ) ?> .wf-lm-card .__excerpt{margin:0;font-size:14px;line-height:1.55;color:<?= esc_attr( $cMut ) ?>;}
#<?= esc_attr( $uid ) ?> .wf-lm-card .__link{margin-top:auto;font-size:14px;font-weight:700;color:<?= esc_attr( $acc ) ?>;text-decoration:none;}
<?php if ( 'lift' === $hover ) : ?>
#<?= esc_attr( $uid ) ?> .wf-lm-card:hover{transform:translateY(-4px);box-shadow:0 14px 34px rgba(0,0,0,.12);}
<?php elseif ( 'zoom' === $hover ) : ?>
#<?= esc_attr( $uid ) ?> .wf-lm-card:hover .__media img{transform:scale(1.06);}
<?php endif; ?>

#<?= esc_attr( $uid ) ?> .wf-lm__foot{display:flex;justify-content:<?= esc_attr( $bJust ) ?>;margin-top:<?= (int) max( 20, $gap ) ?>px;}
#<?= esc_attr( $uid ) ?> .wf-lm__btn{
	display:inline-flex;align-items:center;justify-content:center;gap:.6em;
	padding:12px 26px;font-size:15px;font-weight:600;font-family:inherit;line-height:1.2;
	border:1px solid transparent;border-radius:<?= (int) $bRad ?>px;cursor:pointer;
	transition:opacity .2s ease,background-color .2s ease,color .2s ease;
}
#<?= esc_attr( $uid ) ?> .wf-lm__btn--filled{background:<?= esc_attr( $bBg ) ?>;color:<?= esc_attr( $bCol ) ?>;}
#<?= esc_attr( $uid ) ?> .wf-lm__btn--outline{background:transparent;color:<?= esc_attr( $bBg ) ?>;border-color:<?= esc_attr( $bBg ) ?>;}
#<?= esc_attr( $uid ) ?> .wf-lm__btn--text{background:transparent;color:<?= esc_attr( $bBg ) ?>;padding-left:0;padding-right:0;}
#<?= esc_attr( $uid ) ?> .wf-lm__btn:hover{opacity:.88;}
#<?= esc_attr( $uid ) ?> .wf-lm__btn:focus-visible{outline:2px solid <?= esc_attr( $acc ) ?>;outline-offset:3px;}
#<?= esc_attr( $uid ) ?> .wf-lm__btn[disabled]{opacity:.6;cursor:default;}
@media (pointer:coarse){#<?= esc_attr( $uid ) ?> .wf-lm__btn{min-height:44px;}}

#<?= esc_attr( $uid ) ?> .wf-lm__spin{
	width:15px;height:15px;flex:0 0 auto;border-radius:50%;
	border:2px solid currentColor;border-top-color:transparent;
	opacity:0;animation:<?= esc_attr( $uid ) ?>-spin .7s linear infinite;
}
#<?= esc_attr( $uid ) ?> .wf-lm__btn.is-loading .wf-lm__spin{opacity:1;}
@keyframes <?= esc_attr( $uid ) ?>-spin{to{transform:rotate(360deg)}}
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?> .wf-lm__spin{animation-duration:1.6s;}
	#<?= esc_attr( $uid ) ?> .wf-lm-card{transition-duration:.001ms;}
}

#<?= esc_attr( $uid ) ?> .wf-lm__status,#<?= esc_attr( $uid ) ?> .wf-lm__end{
	margin:16px 0 0;text-align:center;font-size:14px;color:<?= esc_attr( $cMut ) ?>;
}
#<?= esc_attr( $uid ) ?> .wf-lm__status:empty{margin:0;}
#<?= esc_attr( $uid ) ?> .wf-lm__empty{margin:0;color:<?= esc_attr( $cMut ) ?>;}
#<?= esc_attr( $uid ) ?> .wf-lm__sentinel{height:1px;}
#<?= esc_attr( $uid ) ?> .wf-lm-card.is-new{animation:<?= esc_attr( $uid ) ?>-in .45s ease both;}
@keyframes <?= esc_attr( $uid ) ?>-in{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}
</style>

<script>
(function(){
	var root = document.getElementById('<?= esc_js( $uid ) ?>');
	if (!root) { return; }
	var grid = root.querySelector('.wf-lm__grid');
	if (!grid) { return; }

	var foot   = root.querySelector('.wf-lm__foot');
	var btn    = root.querySelector('.wf-lm__btn');
	var txt    = root.querySelector('.wf-lm__btn-txt');
	var status = root.querySelector('.wf-lm__status');
	var endMsg = root.querySelector('.wf-lm__end');
	var sentry = root.querySelector('.wf-lm__sentinel');

	var opts    = JSON.parse(root.getAttribute('data-opts'));
	var nonce   = root.getAttribute('data-nonce');
	var ajax    = root.getAttribute('data-ajax');
	var max     = parseInt(root.getAttribute('data-max'), 10);
	var page    = 1;
	var busy    = false;
	var autoLeft = <?= 'infinite' === $mode ? 999 : ( 'hybrid' === $mode ? (int) $autoPg : 0 ) ?>;
	var cache   = null;   // page prechargee
	var cachePg = 0;

	function announce(msg){
		if (!status) { return; }
		status.textContent = msg;
	}

	function finish(){
		if (foot) { foot.hidden = true; }
		if (endMsg) { endMsg.hidden = false; }
		if (observer) { observer.disconnect(); }
	}

	function request(p){
		var fd = new FormData();
		var o  = JSON.parse(JSON.stringify(opts));
		o.paged = p;
		fd.append('action', 'wf_lm_page');
		fd.append('nonce', nonce);
		fd.append('opts', JSON.stringify(o));
		return fetch(ajax, { method: 'POST', body: fd, credentials: 'same-origin' })
			.then(function(r){
				if (!r.ok) { throw new Error('HTTP ' + r.status); }
				return r.json();
			});
	}

	function inject(data, focusIt){
		var tmp = document.createElement('div');
		tmp.innerHTML = data.html;
		var added = tmp.children.length;
		var first = null;
		while (tmp.firstElementChild) {
			var node = tmp.firstElementChild;
			node.classList.add('is-new');
			if (!first) { first = node; }
			grid.appendChild(node);
		}
		page = data.page;
		announce(added + ' <?= esc_js( __( 'contenus ajoutés.', 'weframe' ) ) ?>');
		// Focus sur le premier nouvel element seulement si le clic vient du bouton :
		// en defilement infini, deplacer le focus tout seul desoriente.
		if (focusIt) { if (first) {
			var h = first.querySelector('.__title a');
			if (h) {
				h.setAttribute('tabindex', '-1');
				h.focus({ preventScroll: true });
			}
		} }
<?php if ( $updUrl ) : ?>
		try {
			var u = new URL(location.href);
			u.searchParams.set('page', String(page));
			history.replaceState(null, '', u.toString());
		} catch (err) {}
<?php endif; ?>
<?php if ( $track ) : ?>
		if (typeof gtag === 'function') { gtag('event', 'load_more', { page: page }); }
		if (window.dataLayer) {
			if (window.dataLayer.push) { window.dataLayer.push({ event: 'wf_load_more', page: page }); }
		}
<?php endif; ?>
		if (!data.more) { finish(); }
<?php if ( $prefill ) : ?>
		else { prefetch(page + 1); }
<?php endif; ?>
	}

	function prefetch(p){
		if (p > max) { return; }
		if (cachePg === p) { return; }
		cachePg = p;
		request(p).then(function(res){
			if (res.success) { cache = res.data; }
		}).catch(function(){ cachePg = 0; });
	}

	function setLoading(on){
		busy = on;
		if (!btn) { return; }
		btn.disabled = on;
		btn.classList.toggle('is-loading', on);
		btn.setAttribute('aria-busy', on ? 'true' : 'false');
		if (txt) { txt.textContent = on ? btn.getAttribute('data-loading') : btn.getAttribute('data-label'); }
	}

	function load(fromBtn){
		if (busy) { return; }
		var next = page + 1;
		if (next > max) { finish(); return; }

		if (cache) {
			if (cachePg === next) {
				var d = cache;
				cache = null; cachePg = 0;
				inject(d, fromBtn);
				return;
			}
		}

		setLoading(true);
		announce('<?= esc_js( __( 'Chargement en cours…', 'weframe' ) ) ?>');
		request(next).then(function(res){
			setLoading(false);
			if (!res.success) { throw new Error('bad response'); }
			inject(res.data, fromBtn);
		}).catch(function(){
			setLoading(false);
			announce('<?= esc_js( __( 'Le chargement a échoué. Réessayez.', 'weframe' ) ) ?>');
		});
	}

	if (btn) { btn.addEventListener('click', function(){ load(true); }); }

	var observer = null;
<?php if ( 'button' !== $mode ) : ?>
	if (window.IntersectionObserver) {
		if (sentry) {
			observer = new IntersectionObserver(function(entries){
				if (!entries[0].isIntersecting) { return; }
				if (autoLeft <= 0) { return; }
				if (busy) { return; }
				autoLeft = autoLeft - 1;
				load(false);
			}, { rootMargin: '320px 0px' });
			observer.observe(sentry);
		}
	}
<?php endif; ?>

<?php if ( $prefill ) : ?>
	if (max > 1) { prefetch(2); }
<?php endif; ?>
})();
</script>
