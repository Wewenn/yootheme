<?php
/**
 * WeFrame – Décor animé | template.php v1.0
 * Huit fonds animes en un seul element : particules, etoiles, meteores, rayons,
 * halo, grille clignotante, vagues, distorsion.
 *
 * Tout est en CSS. Les positions sont tirees cote serveur a partir d'une graine :
 * meme rendu a chaque chargement, et rien a calculer dans le navigateur.
 * Le decor est purement decoratif : aria-hidden, et fige si le visiteur a
 * demande moins d'animations.
 */
defined( 'ABSPATH' ) || exit;

$fx = (string) ( $props['effect'] ?? 'particles' );
$known = array( 'particles', 'stars', 'meteors', 'rays', 'backlight', 'grid', 'waves', 'warp' );
if ( ! in_array( $fx, $known, true ) ) { $fx = 'particles'; }

$place = ( 'backdrop' === ( $props['placement'] ?? 'block' ) ) ? 'backdrop' : 'block';
$count = max( 4, min( 160, (int) ( $props['count'] ?? 40 ) ) );
$size  = max( 1, min( 40, (int) ( $props['size'] ?? 3 ) ) );
$speed = max( 2, (int) ( $props['speed'] ?? 14 ) );
$op    = max( 5, min( 100, (int) ( $props['opacity'] ?? 70 ) ) );
$c1    = (string) ( $props['color_1'] ?? '#ffffff' );
$c2    = (string) ( $props['color_2'] ?? '#EA5C1C' );
$bg    = trim( (string) ( $props['bg'] ?? '' ) );

$h     = max( 120, (int) ( $props['height'] ?? 420 ) );
$rad   = max( 0, (int) ( $props['radius'] ?? 0 ) );
$pad   = max( 0, (int) ( $props['padding'] ?? 48 ) );
$alignV = (string) ( $props['content_align'] ?? 'center' );
if ( ! in_array( $alignV, array( 'center', 'start', 'end' ), true ) ) { $alignV = 'center'; }
$seed  = max( 1, (int) ( $props['seed'] ?? 6 ) );

$inner = '';
if ( ! empty( $children ) ) {
	foreach ( $children as $ci => $child ) {
		$inner .= $builder->render( $child, array( 'element' => $props, 'index' => $ci ) );
	}
}

$rngState = ( $seed * 69069 ) % 4294967296;
$rng = function () use ( &$rngState ) {
	$rngState = ( $rngState * 1103515245 + 12345 ) % 2147483648;
	return $rngState / 2147483648;
};

// Les effets a « semis » partagent la meme boucle ; les autres n'ont pas de points.
$dots = array();
$seeded = in_array( $fx, array( 'particles', 'stars', 'meteors', 'rays' ), true );
if ( $seeded ) {
	$n = ( 'rays' === $fx ) ? min( 24, $count ) : $count;
	for ( $i = 0; $i < $n; $i++ ) {
		$dots[] = array(
			'x'  => round( $rng() * 100, 2 ),
			'y'  => round( $rng() * 100, 2 ),
			'sz' => round( $size * ( 0.5 + $rng() * 1.3 ), 2 ),
			'dl' => round( -$rng() * $speed, 2 ),
			'du' => round( $speed * ( 0.6 + $rng() * 0.9 ), 2 ),
			'c'  => ( $rng() > 0.7 ) ? $c2 : $c1,
			'dx' => (int) round( ( $rng() * 2 - 1 ) * 40 ),
		);
	}
}

$uid = wf_uid( 'wfdc_', $props, $count );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-dc wf-dc--<?= esc_attr( $fx ) ?> wf-dc--<?= esc_attr( $place ) ?>">
	<div class="__fx" aria-hidden="true">
		<?php if ( $seeded ) : ?>
			<?php foreach ( $dots as $d ) : ?>
			<span class="__d" style="
				left:<?= esc_attr( $d['x'] ) ?>%;top:<?= esc_attr( $d['y'] ) ?>%;
				--sz:<?= esc_attr( $d['sz'] ) ?>px;--c:<?= esc_attr( $d['c'] ) ?>;
				--dx:<?= (int) $d['dx'] ?>px;
				animation-duration:<?= esc_attr( $d['du'] ) ?>s;
				animation-delay:<?= esc_attr( $d['dl'] ) ?>s;"></span>
			<?php endforeach; ?>
		<?php elseif ( 'waves' === $fx ) : ?>
			<span class="__wave __wave-1"></span>
			<span class="__wave __wave-2"></span>
			<span class="__wave __wave-3"></span>
		<?php elseif ( 'warp' === $fx ) : ?>
			<span class="__warp"></span>
		<?php elseif ( 'backlight' === $fx ) : ?>
			<span class="__halo __halo-1"></span>
			<span class="__halo __halo-2"></span>
		<?php else : ?>
			<span class="__grid"></span>
		<?php endif; ?>
	</div>
	<?php if ( '' !== trim( $inner ) && 'block' === $place ) : ?>
	<div class="__content"><?= $inner ?></div>
	<?php endif; ?>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
<?php if ( 'backdrop' === $place ) : ?>
#<?= esc_attr( $uid ) ?>{
	position:absolute;inset:0;z-index:0;pointer-events:none;overflow:hidden;
	<?= '' !== $bg ? 'background:' . esc_attr( $bg ) . ';' : '' ?>
	<?= $rad > 0 ? 'border-radius:' . (int) $rad . 'px;' : '' ?>
}
<?php else : ?>
#<?= esc_attr( $uid ) ?>{
	position:relative;isolation:isolate;overflow:hidden;
	min-height:<?= (int) $h ?>px;padding:<?= (int) $pad ?>px;border-radius:<?= (int) $rad ?>px;
	<?= '' !== $bg ? 'background:' . esc_attr( $bg ) . ';' : '' ?>
	display:flex;flex-direction:column;
	justify-content:<?= 'center' === $alignV ? 'center' : ( 'end' === $alignV ? 'flex-end' : 'flex-start' ) ?>;
}
#<?= esc_attr( $uid ) ?> .__content{position:relative;z-index:1;}
<?php endif; ?>
#<?= esc_attr( $uid ) ?> .__fx{
	position:absolute;inset:0;z-index:0;pointer-events:none;overflow:hidden;
	opacity:<?= esc_attr( round( $op / 100, 2 ) ) ?>;
}
#<?= esc_attr( $uid ) ?> .__d{position:absolute;display:block;will-change:transform,opacity;}

<?php if ( 'particles' === $fx ) : ?>
#<?= esc_attr( $uid ) ?> .__d{
	width:var(--sz);height:var(--sz);border-radius:50%;background:var(--c);
	animation-name:<?= esc_attr( $uid ) ?>-float;animation-timing-function:ease-in-out;
	animation-iteration-count:infinite;animation-direction:alternate;
}
@keyframes <?= esc_attr( $uid ) ?>-float{
	from{transform:translate(0,0);opacity:.35}
	to{transform:translate(var(--dx),-40px);opacity:1}
}
<?php elseif ( 'stars' === $fx ) : ?>
#<?= esc_attr( $uid ) ?> .__d{
	width:var(--sz);height:var(--sz);border-radius:50%;background:var(--c);
	box-shadow:0 0 calc(var(--sz) * 2) var(--c);
	animation-name:<?= esc_attr( $uid ) ?>-twinkle;animation-timing-function:ease-in-out;
	animation-iteration-count:infinite;
}
@keyframes <?= esc_attr( $uid ) ?>-twinkle{
	0%,100%{opacity:.15;transform:scale(.7)}
	50%{opacity:1;transform:scale(1)}
}
<?php elseif ( 'meteors' === $fx ) : ?>
#<?= esc_attr( $uid ) ?> .__d{
	width:var(--sz);height:var(--sz);border-radius:50%;background:var(--c);
	box-shadow:0 0 0 1px var(--c);
	animation-name:<?= esc_attr( $uid ) ?>-fall;animation-timing-function:linear;
	animation-iteration-count:infinite;
}
#<?= esc_attr( $uid ) ?> .__d::after{
	content:"";position:absolute;top:50%;right:calc(var(--sz) / 2);
	width:120px;height:1px;transform:translateY(-50%);
	background:linear-gradient(90deg,transparent,var(--c));
}
@keyframes <?= esc_attr( $uid ) ?>-fall{
	from{transform:translate(0,0) rotate(-35deg);opacity:0}
	10%{opacity:1}
	to{transform:translate(520px,420px) rotate(-35deg);opacity:0}
}
<?php elseif ( 'rays' === $fx ) : ?>
#<?= esc_attr( $uid ) ?> .__d{
	top:-20%;height:140%;width:calc(var(--sz) * 12);
	background:linear-gradient(180deg,var(--c),transparent);
	filter:blur(14px);transform-origin:50% 0;
	animation-name:<?= esc_attr( $uid ) ?>-ray;animation-timing-function:ease-in-out;
	animation-iteration-count:infinite;animation-direction:alternate;
}
@keyframes <?= esc_attr( $uid ) ?>-ray{
	from{transform:rotate(-8deg) scaleY(.85);opacity:.35}
	to{transform:rotate(8deg) scaleY(1.1);opacity:.9}
}
<?php elseif ( 'backlight' === $fx ) : ?>
#<?= esc_attr( $uid ) ?> .__halo{
	position:absolute;border-radius:50%;filter:blur(90px);
	width:<?= (int) max( 200, $size * 90 ) ?>px;height:<?= (int) max( 200, $size * 90 ) ?>px;
	animation:<?= esc_attr( $uid ) ?>-halo <?= (int) $speed ?>s ease-in-out infinite alternate;
}
#<?= esc_attr( $uid ) ?> .__halo-1{left:12%;top:8%;background:<?= esc_attr( $c1 ) ?>;}
#<?= esc_attr( $uid ) ?> .__halo-2{right:8%;bottom:6%;background:<?= esc_attr( $c2 ) ?>;animation-delay:-<?= (int) round( $speed / 2 ) ?>s;}
@keyframes <?= esc_attr( $uid ) ?>-halo{
	from{transform:translate(-6%,-4%) scale(.9)}
	to{transform:translate(6%,4%) scale(1.15)}
}
<?php elseif ( 'grid' === $fx ) : ?>
#<?= esc_attr( $uid ) ?> .__grid{
	position:absolute;inset:-2px;
	background-image:
		linear-gradient(<?= esc_attr( $c1 ) ?> 1px,transparent 1px),
		linear-gradient(90deg,<?= esc_attr( $c1 ) ?> 1px,transparent 1px);
	background-size:<?= (int) max( 12, $size * 10 ) ?>px <?= (int) max( 12, $size * 10 ) ?>px;
	animation:<?= esc_attr( $uid ) ?>-flick <?= (int) $speed ?>s steps(12) infinite;
	-webkit-mask-image:radial-gradient(ellipse at 50% 40%,#000 30%,transparent 78%);
	mask-image:radial-gradient(ellipse at 50% 40%,#000 30%,transparent 78%);
}
@keyframes <?= esc_attr( $uid ) ?>-flick{
	0%,100%{opacity:.35}25%{opacity:.8}50%{opacity:.2}75%{opacity:.6}
}
<?php elseif ( 'waves' === $fx ) : ?>
#<?= esc_attr( $uid ) ?> .__wave{
	position:absolute;left:-50%;right:-50%;bottom:-10%;height:60%;
	border-radius:44% 56% 52% 48% / 60% 55% 45% 40%;
	animation:<?= esc_attr( $uid ) ?>-roll <?= (int) $speed ?>s linear infinite;
}
#<?= esc_attr( $uid ) ?> .__wave-1{background:<?= esc_attr( $c1 ) ?>;opacity:.5;}
#<?= esc_attr( $uid ) ?> .__wave-2{background:<?= esc_attr( $c2 ) ?>;opacity:.45;animation-duration:<?= (int) round( $speed * 1.4 ) ?>s;bottom:-16%;}
#<?= esc_attr( $uid ) ?> .__wave-3{background:<?= esc_attr( $c1 ) ?>;opacity:.3;animation-duration:<?= (int) round( $speed * 1.9 ) ?>s;bottom:-22%;}
@keyframes <?= esc_attr( $uid ) ?>-roll{from{transform:rotate(0)}to{transform:rotate(360deg)}}
<?php else : ?>
#<?= esc_attr( $uid ) ?> .__warp{
	position:absolute;inset:0;
	background-image:
		linear-gradient(<?= esc_attr( $c1 ) ?> 1px,transparent 1px),
		linear-gradient(90deg,<?= esc_attr( $c2 ) ?> 1px,transparent 1px);
	background-size:<?= (int) max( 16, $size * 12 ) ?>px <?= (int) max( 16, $size * 12 ) ?>px;
	transform:perspective(320px) rotateX(62deg) scale(2.2);
	transform-origin:50% 100%;
	animation:<?= esc_attr( $uid ) ?>-warp <?= (int) $speed ?>s linear infinite;
	-webkit-mask-image:linear-gradient(180deg,transparent,#000 55%);
	mask-image:linear-gradient(180deg,transparent,#000 55%);
}
@keyframes <?= esc_attr( $uid ) ?>-warp{
	from{background-position:0 0}
	to{background-position:0 <?= (int) max( 16, $size * 12 ) ?>px}
}
<?php endif; ?>

/* Moins d'animations : le decor reste visible mais immobile. */
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?> .__fx *{animation:none !important;}
}
</style>
