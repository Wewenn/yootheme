<?php
defined('ABSPATH') || exit;
if (empty($children)) return;
$bh = (int)($props['bar_height']??12); $bbg = $props['bar_bg']??'#e5e5e5';
$br = (int)($props['bar_radius']??100); $dur = (int)($props['duration']??1500);
$gap = (int)($props['gap']??16);
$uid = 'wfcb_'.substr(md5(serialize($props).count($children)),0,8);
$html = '';
foreach ($children as $child) { $html .= $builder->render($child, ['element'=>$props]); }
if (!trim($html)) return;
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr($uid) ?>" class="wf-counter-bar" style="display:flex;flex-direction:column;gap:<?= $gap ?>px;">
<?= $html ?>
</div>
<script>
(function(){
    var el=document.getElementById('<?= esc_attr($uid) ?>');if(!el)return;
    WF.onVisible(el, function(){
        var fills=el.querySelectorAll('.wf-cb-fill');var j=0;
        while(j<fills.length){fills[j].style.width=fills[j].getAttribute('data-target')+'%';j++}
    }, 0.2);
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
