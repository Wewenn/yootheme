<?php
/**
 * WeFrame – Preloader | template.php
 * Full-screen intro overlay played on page load, then reveals the page.
 * Types: curtain (up), fade, split (two panels part), slide (left).
 * Config inlined (no <script type="application/json">), no "&&" in inline JS.
 */
defined( 'ABSPATH' ) || exit;

$props = is_array( $props ?? null ) ? $props : array();

$type    = (string) ( $props['type'] ?? 'curtain' );
$bg      = (string) ( $props['bg'] ?? '#0b0b0d' );
$ctype   = (string) ( $props['content_type'] ?? 'text' );
$logo    = trim( (string) ( $props['logo'] ?? '' ) );
$logo_w  = min( 400, max( 40, (int) ( $props['logo_width'] ?? 120 ) ) );
$text    = trim( (string) ( $props['text'] ?? '' ) );
$tcol    = (string) ( $props['text_color'] ?? '#ffffff' );
$tsize   = min( 90, max( 16, (int) ( $props['text_size'] ?? 32 ) ) );
$tweight = (string) ( $props['text_weight'] ?? '700' );
$tfont   = trim( (string) ( $props['text_font'] ?? '' ) );
$counter = ! empty( $props['show_counter'] );
$ccol    = (string) ( $props['counter_color'] ?? 'rgba(255,255,255,0.5)' );
$spinner = (string) ( $props['spinner'] ?? 'none' );
$min_dur = min( 5000, max( 300, (int) ( $props['min_duration'] ?? 1400 ) ) );
$out_dur = min( 2000, max( 300, (int) ( $props['out_duration'] ?? 900 ) ) );
$once    = ! empty( $props['once_session'] );

if ( $logo && ! preg_match( '#^https?://#i', $logo ) ) { $logo = '/' . ltrim( $logo, '/' ); }

$allowed_type = array( 'curtain', 'fade', 'split', 'slide' );
if ( ! in_array( $type, $allowed_type, true ) ) { $type = 'curtain'; }

$uid = wf_uid( 'wfpl_', $props );
$ff  = $tfont ? 'font-family:' . $tfont . ';' : '';

$cfg = wp_json_encode( array(
    'uid'     => $uid,
    'type'    => $type,
    'minDur'  => $min_dur,
    'outDur'  => $out_dur,
    'maxWait' => $min_dur + 3000,
    'counter' => $counter ? 1 : 0,
    'once'    => $once ? 1 : 0,
), JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE );

// Center content
$content = '';
if ( 'logo' === $ctype && $logo ) {
    $content = '<img src="' . esc_url( $logo ) . '" alt="" style="width:' . $logo_w . 'px;max-width:60vw;height:auto;display:block;">';
} elseif ( 'text' === $ctype && $text ) {
    $content = '<div style="color:' . esc_attr( $tcol ) . ';font-size:' . $tsize . 'px;font-weight:' . esc_attr( $tweight ) . ';letter-spacing:.01em;' . $ff . '">' . esc_html( $text ) . '</div>';
}
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-pl wf-pl--<?= esc_attr( $type ) ?>" role="presentation" style="position:fixed;inset:0;z-index:999999;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:22px;<?= 'split' === $type ? '' : 'background:' . esc_attr( $bg ) . ';' ?>">

    <?php if ( 'split' === $type ) : ?>
    <div class="wf-pl-half wf-pl-half--l" style="position:absolute;top:0;left:0;width:50%;height:100%;background:<?= esc_attr( $bg ) ?>;"></div>
    <div class="wf-pl-half wf-pl-half--r" style="position:absolute;top:0;right:0;width:50%;height:100%;background:<?= esc_attr( $bg ) ?>;"></div>
    <?php endif; ?>

    <div class="wf-pl-content" style="position:relative;z-index:2;display:flex;flex-direction:column;align-items:center;gap:22px;">
        <?php if ( $content ) : ?><?= $content ?><?php endif; ?>

        <?php if ( 'ring' === $spinner ) : ?>
        <div class="wf-pl-ring" style="width:34px;height:34px;border:3px solid rgba(255,255,255,.15);border-top-color:<?= esc_attr( $tcol ) ?>;border-radius:50%;animation:wf-pl-spin .8s linear infinite;"></div>
        <?php elseif ( 'bar' === $spinner ) : ?>
        <div style="width:160px;max-width:60vw;height:3px;background:rgba(255,255,255,.15);border-radius:3px;overflow:hidden;"><div class="wf-pl-bar" style="height:100%;width:0;background:<?= esc_attr( $tcol ) ?>;"></div></div>
        <?php endif; ?>

        <?php if ( $counter ) : ?>
        <div class="wf-pl-counter" style="color:<?= esc_attr( $ccol ) ?>;font-size:14px;font-variant-numeric:tabular-nums;letter-spacing:.05em;">0&#8201;%</div>
        <?php endif; ?>
    </div>
</div>

<style>
@keyframes wf-pl-spin { to { transform: rotate(360deg); } }
#<?= esc_attr( $uid ) ?> { transition: opacity <?= $out_dur ?>ms ease, transform <?= $out_dur ?>ms cubic-bezier(.76,0,.24,1); }
#<?= esc_attr( $uid ) ?> .wf-pl-half { transition: transform <?= $out_dur ?>ms cubic-bezier(.76,0,.24,1); }
#<?= esc_attr( $uid ) ?> .wf-pl-content { transition: opacity <?= (int) round( $out_dur * 0.5 ) ?>ms ease; }

#<?= esc_attr( $uid ) ?>.wf-pl-out.wf-pl--fade { opacity: 0; }
#<?= esc_attr( $uid ) ?>.wf-pl-out.wf-pl--curtain { transform: translateY(-100%); }
#<?= esc_attr( $uid ) ?>.wf-pl-out.wf-pl--slide { transform: translateX(-100%); }
#<?= esc_attr( $uid ) ?>.wf-pl-out.wf-pl--split .wf-pl-half--l { transform: translateX(-101%); }
#<?= esc_attr( $uid ) ?>.wf-pl-out.wf-pl--split .wf-pl-half--r { transform: translateX(101%); }
#<?= esc_attr( $uid ) ?>.wf-pl-out .wf-pl-content { opacity: 0; }
</style>

<script>
(function(){
    var C = <?= $cfg ?>;
    var el = document.getElementById(C.uid);
    if (!el) return;

    var KEY = 'wf_pl_' + C.uid;
    if (C.once) {
        var seen = false;
        try { seen = window.sessionStorage.getItem(KEY) === '1'; } catch(e) {}
        if (seen) { el.parentNode.removeChild(el); return; }
    }

    var root = document.documentElement;
    var prevOv = root.style.overflow;
    root.style.overflow = 'hidden';

    var start = Date.now();
    var triggered = false;

    function markSeen(){ try { window.sessionStorage.setItem(KEY, '1'); } catch(e) {} }

    function counter(){
        var node = el.querySelector('.wf-pl-counter');
        var bar = el.querySelector('.wf-pl-bar');
        if (!node) { if (!bar) { return; } }
        var t0 = null;
        function step(ts){
            if (t0 === null) { t0 = ts; }
            var p = (ts - t0) / C.minDur;
            if (p > 1) { p = 1; }
            var v = Math.round(p * 100);
            if (node) { node.textContent = v + ' %'; }
            if (bar) { bar.style.width = v + '%'; }
            if (p < 1) { requestAnimationFrame(step); }
        }
        requestAnimationFrame(step);
    }

    function hide(){
        if (triggered) { return; }
        triggered = true;
        el.classList.add('wf-pl-out');
        markSeen();
        setTimeout(function(){
            root.style.overflow = prevOv;
            if (el.parentNode) { el.parentNode.removeChild(el); }
        }, C.outDur + 120);
    }

    function ready(){
        var elapsed = Date.now() - start;
        var wait = C.minDur - elapsed;
        if (wait < 0) { wait = 0; }
        setTimeout(hide, wait);
    }

    counter();
    if (document.readyState === 'complete') { ready(); }
    else { window.addEventListener('load', ready); }
    // hard fallback so the page is never stuck behind the overlay
    setTimeout(hide, C.maxWait);
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
