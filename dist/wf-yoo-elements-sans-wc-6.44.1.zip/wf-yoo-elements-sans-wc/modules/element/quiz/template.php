<?php
/**
 * WeFrame – Questionnaire | template.php v1.0
 * Un parcours en etapes qui oriente le visiteur, puis un bouton d'action.
 *
 * Tout se passe dans le navigateur : aucune reponse n'est envoyee tant que le
 * visiteur ne clique pas sur le bouton final, et rien n'est stocke. Les reponses
 * sont alors ajoutees a l'adresse du lien, pour arriver dans le formulaire.
 * Les reponses sont de vrais boutons radio : navigation clavier et lecture
 * d'ecran fonctionnent sans code supplementaire.
 * Pas de "&&" ni de "||" dans le JS inline (regle interne du plugin).
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$showIntro = ! empty( $props['show_intro'] );
$iTitle = trim( (string) ( $props['intro_title'] ?? '' ) );
$iText  = trim( (string) ( $props['intro_text'] ?? '' ) );
$start  = trim( (string) ( $props['start_label'] ?? '' ) );
if ( '' === $start ) { $start = __( 'Commencer', 'weframe' ); }
$next   = trim( (string) ( $props['next_label'] ?? '' ) );
if ( '' === $next ) { $next = __( 'Suivant', 'weframe' ); }
$back   = trim( (string) ( $props['back_label'] ?? '' ) );
if ( '' === $back ) { $back = __( 'Retour', 'weframe' ); }

$rTitle = trim( (string) ( $props['result_title'] ?? '' ) );
$rText  = trim( (string) ( $props['result_text'] ?? '' ) );
$ctaLbl = trim( (string) ( $props['cta_label'] ?? '' ) );
$ctaUrl = $props['cta_link'] ?? '';
if ( is_array( $ctaUrl ) ) { $ctaUrl = $ctaUrl['url'] ?? ''; }
$ctaUrl = trim( (string) $ctaUrl );
$restart = trim( (string) ( $props['restart_label'] ?? '' ) );
if ( '' === $restart ) { $restart = __( 'Recommencer', 'weframe' ); }

$autoNext = ! empty( $props['auto_next'] );
$progress = ! empty( $props['show_progress'] );
$cols     = max( 1, min( 3, (int) ( $props['columns'] ?? 1 ) ) );

$bg   = (string) ( $props['card_bg'] ?? '#ffffff' );
$col  = (string) ( $props['card_color'] ?? '#111111' );
$mut  = (string) ( $props['card_muted'] ?? '#6b7280' );
$bd   = (string) ( $props['card_border'] ?? '#e8e8ec' );
$oBg  = (string) ( $props['option_bg'] ?? '#f6f6f8' );
$acc  = (string) ( $props['accent_color'] ?? '#EA5C1C' );
$rad  = max( 0, (int) ( $props['radius'] ?? 16 ) );
$pad  = max( 8, (int) ( $props['padding'] ?? 28 ) );
$tSz  = max( 14, (int) ( $props['title_size'] ?? 22 ) );

$steps = array();
foreach ( $children as $i => $child ) {
	$cp = (array) ( $child->props ?? array() );
	$q  = trim( (string) ( $cp['question'] ?? '' ) );
	if ( '' === $q ) { $q = sprintf( __( 'Question %d', 'weframe' ), $i + 1 ); }
	$opts = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) ( $cp['options'] ?? '' ) ) as $o ) {
		$o = trim( $o );
		if ( '' !== $o ) { $opts[] = $o; }
	}
	if ( empty( $opts ) ) { continue; }
	$steps[] = array(
		'q'    => $q,
		'help' => trim( (string) ( $cp['help'] ?? '' ) ),
		'key'  => sanitize_key( (string) ( $cp['key'] ?? '' ) ),
		'opts' => $opts,
	);
}
if ( empty( $steps ) ) { return; }
$n = count( $steps );

$uid = wf_uid( 'wfqz_', $props, $n );
$firstStep = $showIntro ? -1 : 0;
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-qz" data-count="<?= (int) $n ?>" data-auto="<?= $autoNext ? '1' : '0' ?>">

	<?php if ( $progress ) : ?>
	<div class="__bar" role="progressbar" aria-valuemin="0" aria-valuemax="<?= (int) $n ?>" aria-valuenow="0"
		aria-label="<?= esc_attr__( 'Avancement du questionnaire', 'weframe' ) ?>">
		<span class="__fill" style="width:0%"></span>
	</div>
	<p class="__count" aria-hidden="true"><span class="__cur">0</span> / <?= (int) $n ?></p>
	<?php endif; ?>

	<?php if ( $showIntro ) : ?>
	<section class="__step __intro" data-step="-1">
		<?php if ( '' !== $iTitle ) : ?><h3 class="__q"><?= esc_html( $iTitle ) ?></h3><?php endif; ?>
		<?php if ( '' !== $iText ) : ?><p class="__help"><?= nl2br( esc_html( $iText ) ) ?></p><?php endif; ?>
		<div class="__nav"><button type="button" class="__btn __btn--go" data-go="0"><?= esc_html( $start ) ?></button></div>
	</section>
	<?php endif; ?>

	<?php foreach ( $steps as $s => $st ) : ?>
	<section class="__step" data-step="<?= (int) $s ?>"<?= ( $s !== $firstStep ) ? ' hidden' : '' ?>>
		<fieldset class="__fs">
			<legend class="__q"><?= esc_html( $st['q'] ) ?></legend>
			<?php if ( '' !== $st['help'] ) : ?><p class="__help"><?= esc_html( $st['help'] ) ?></p><?php endif; ?>
			<div class="__opts">
				<?php foreach ( $st['opts'] as $o => $opt ) : ?>
				<label class="__opt">
					<input type="radio" name="<?= esc_attr( $uid ) ?>-q<?= (int) $s ?>" value="<?= esc_attr( $opt ) ?>">
					<span class="__mark" aria-hidden="true"></span>
					<span class="__txt"><?= esc_html( $opt ) ?></span>
				</label>
				<?php endforeach; ?>
			</div>
		</fieldset>
		<div class="__nav">
			<?php if ( $s > 0 || $showIntro ) : ?>
			<button type="button" class="__btn __btn--ghost" data-go="<?= (int) ( $s - 1 ) ?>"><?= esc_html( $back ) ?></button>
			<?php endif; ?>
			<button type="button" class="__btn __btn--next" data-go="<?= (int) ( $s + 1 ) ?>" disabled><?= esc_html( $s === $n - 1 ? __( 'Voir le résultat', 'weframe' ) : $next ) ?></button>
		</div>
	</section>
	<?php endforeach; ?>

	<section class="__step __result" data-step="<?= (int) $n ?>" hidden>
		<?php if ( '' !== $rTitle ) : ?><h3 class="__q"><?= esc_html( $rTitle ) ?></h3><?php endif; ?>
		<ul class="__recap"></ul>
		<?php if ( '' !== $rText ) : ?><p class="__help"><?= nl2br( esc_html( $rText ) ) ?></p><?php endif; ?>
		<div class="__nav">
			<button type="button" class="__btn __btn--ghost" data-go="0"><?= esc_html( $restart ) ?></button>
			<?php if ( '' !== $ctaUrl && '' !== $ctaLbl ) : ?>
			<a class="__btn __cta" href="<?= esc_url( $ctaUrl ) ?>" data-base="<?= esc_url( $ctaUrl ) ?>"><?= esc_html( $ctaLbl ) ?></a>
			<?php endif; ?>
		</div>
	</section>

	<p class="__live" role="status" aria-live="polite"></p>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?>{
	container-type:inline-size;
	background:<?= esc_attr( $bg ) ?>;color:<?= esc_attr( $col ) ?>;
	border:1px solid <?= esc_attr( $bd ) ?>;border-radius:<?= (int) $rad ?>px;
	padding:<?= (int) $pad ?>px;
}
#<?= esc_attr( $uid ) ?> .__bar{
	height:6px;border-radius:100px;background:<?= esc_attr( $oBg ) ?>;overflow:hidden;margin-bottom:8px;
}
#<?= esc_attr( $uid ) ?> .__fill{
	display:block;height:100%;background:<?= esc_attr( $acc ) ?>;
	transition:width .4s cubic-bezier(.2,.8,.2,1);
}
#<?= esc_attr( $uid ) ?> .__count{margin:0 0 <?= (int) max( 12, round( $pad * .6 ) ) ?>px;font-size:12px;color:<?= esc_attr( $mut ) ?>;}
#<?= esc_attr( $uid ) ?> .__fs{border:0;margin:0;padding:0;min-width:0;}
#<?= esc_attr( $uid ) ?> .__q{
	margin:0 0 .5em;font-size:<?= (int) $tSz ?>px;font-weight:700;line-height:1.25;padding:0;
}
#<?= esc_attr( $uid ) ?> .__help{margin:0 0 1em;color:<?= esc_attr( $mut ) ?>;font-size:14px;line-height:1.55;}
#<?= esc_attr( $uid ) ?> .__opts{
	display:grid;gap:10px;grid-template-columns:repeat(<?= (int) $cols ?>,minmax(0,1fr));
}
@container (max-width: 520px){#<?= esc_attr( $uid ) ?> .__opts{grid-template-columns:1fr;}}
#<?= esc_attr( $uid ) ?> .__opt{
	display:flex;align-items:center;gap:12px;cursor:pointer;min-height:48px;
	padding:12px 14px;border-radius:<?= (int) max( 6, round( $rad * .6 ) ) ?>px;
	background:<?= esc_attr( $oBg ) ?>;border:1px solid transparent;
	transition:border-color .2s ease,background-color .2s ease;
}
#<?= esc_attr( $uid ) ?> .__opt:hover{border-color:<?= esc_attr( $acc ) ?>66;}
#<?= esc_attr( $uid ) ?> .__opt input{position:absolute;opacity:0;width:0;height:0;}
#<?= esc_attr( $uid ) ?> .__mark{
	flex:0 0 auto;width:20px;height:20px;border-radius:50%;
	border:2px solid <?= esc_attr( $mut ) ?>;position:relative;transition:border-color .2s ease;
}
#<?= esc_attr( $uid ) ?> .__mark::after{
	content:"";position:absolute;inset:4px;border-radius:50%;
	background:<?= esc_attr( $acc ) ?>;transform:scale(0);transition:transform .2s ease;
}
#<?= esc_attr( $uid ) ?> .__opt input:checked ~ .__mark{border-color:<?= esc_attr( $acc ) ?>;}
#<?= esc_attr( $uid ) ?> .__opt input:checked ~ .__mark::after{transform:scale(1);}
#<?= esc_attr( $uid ) ?> .__opt:has(input:checked){border-color:<?= esc_attr( $acc ) ?>;background:<?= esc_attr( $acc ) ?>14;}
#<?= esc_attr( $uid ) ?> .__opt:focus-within{outline:2px solid <?= esc_attr( $acc ) ?>;outline-offset:2px;}
#<?= esc_attr( $uid ) ?> .__txt{font-size:15px;line-height:1.4;}

#<?= esc_attr( $uid ) ?> .__nav{display:flex;gap:10px;margin-top:<?= (int) max( 14, round( $pad * .7 ) ) ?>px;flex-wrap:wrap;}
#<?= esc_attr( $uid ) ?> .__btn{
	display:inline-flex;align-items:center;justify-content:center;min-height:44px;
	padding:11px 22px;border:0;border-radius:100px;cursor:pointer;font-family:inherit;
	font-size:15px;font-weight:700;text-decoration:none;
	background:<?= esc_attr( $acc ) ?>;color:#fff;
	transition:opacity .2s ease;
}
#<?= esc_attr( $uid ) ?> .__btn:hover{opacity:.88;}
#<?= esc_attr( $uid ) ?> .__btn:focus-visible{outline:2px solid <?= esc_attr( $acc ) ?>;outline-offset:3px;}
#<?= esc_attr( $uid ) ?> .__btn[disabled]{opacity:.45;cursor:not-allowed;}
#<?= esc_attr( $uid ) ?> .__btn--ghost{background:transparent;color:<?= esc_attr( $mut ) ?>;border:1px solid <?= esc_attr( $bd ) ?>;}
#<?= esc_attr( $uid ) ?> .__btn--next{margin-left:auto;}
#<?= esc_attr( $uid ) ?> .__recap{
	margin:0 0 1em;padding:0;list-style:none;display:flex;flex-direction:column;gap:6px;
}
#<?= esc_attr( $uid ) ?> .__recap li{font-size:14px;color:<?= esc_attr( $mut ) ?>;}
#<?= esc_attr( $uid ) ?> .__recap b{color:<?= esc_attr( $col ) ?>;font-weight:700;}
#<?= esc_attr( $uid ) ?> .__live{margin:10px 0 0;font-size:13px;color:<?= esc_attr( $mut ) ?>;}
#<?= esc_attr( $uid ) ?> .__live:empty{display:none;}
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?> .__fill,#<?= esc_attr( $uid ) ?> .__mark,#<?= esc_attr( $uid ) ?> .__mark::after{transition-duration:.001ms;}
}
</style>

<script>
(function(){
	var root = document.getElementById('<?= esc_js( $uid ) ?>');
	if (!root) { return; }
	var n = parseInt(root.getAttribute('data-count'), 10);
	var auto = root.getAttribute('data-auto') === '1';
	var steps = [].slice.call(root.querySelectorAll('.__step'));
	var fill = root.querySelector('.__fill');
	var bar = root.querySelector('.__bar');
	var cur = root.querySelector('.__cur');
	var live = root.querySelector('.__live');
	var recap = root.querySelector('.__recap');
	var cta = root.querySelector('.__cta');

	function stepEl(i){
		for (var k = 0; k < steps.length; k++) {
			if (parseInt(steps[k].getAttribute('data-step'), 10) === i) { return steps[k]; }
		}
		return null;
	}

	function answers(){
		var out = [];
		for (var i = 0; i < n; i++) {
			var el = stepEl(i);
			if (!el) { continue; }
			var q = el.querySelector('.__q');
			var picked = el.querySelector('input:checked');
			out.push({
				q: q ? q.textContent.trim() : ('Q' + (i + 1)),
				a: picked ? picked.value : ''
			});
		}
		return out;
	}

	function show(i){
		for (var k = 0; k < steps.length; k++) {
			var si = parseInt(steps[k].getAttribute('data-step'), 10);
			steps[k].hidden = (si !== i);
		}
		var done = i < 0 ? 0 : Math.min(i, n);
		if (fill) { fill.style.width = (n > 0 ? (done / n) * 100 : 0) + '%'; }
		if (bar) { bar.setAttribute('aria-valuenow', String(done)); }
		if (cur) { cur.textContent = String(done); }

		var el = stepEl(i);
		if (!el) { return; }
		// on amene le focus sur l'intitule : le lecteur d'ecran annonce la nouvelle etape
		var head = el.querySelector('.__q');
		if (head) {
			head.setAttribute('tabindex', '-1');
			head.focus({ preventScroll: true });
		}
		if (i === n) { finish(); }
	}

	function finish(){
		var list = answers();
		if (recap) {
			recap.innerHTML = '';
			list.forEach(function(x){
				if (!x.a) { return; }
				var li = document.createElement('li');
				li.textContent = x.q + ' : ';
				var b = document.createElement('b');
				b.textContent = x.a;
				li.appendChild(b);
				recap.appendChild(li);
			});
		}
		if (cta) {
			// Les reponses partent seulement quand le visiteur clique sur ce lien.
			try {
				var u = new URL(cta.getAttribute('data-base'), location.href);
				list.forEach(function(x, i){
					if (!x.a) { return; }
					u.searchParams.set('q' + (i + 1), x.a);
				});
				cta.setAttribute('href', u.toString());
			} catch (err) {}
		}
		if (live) { live.textContent = '<?= esc_js( __( 'Questionnaire terminé.', 'weframe' ) ) ?>'; }
	}

	root.addEventListener('click', function(e){
		if (!e.target.closest) { return; }
		var b = e.target.closest('[data-go]');
		if (!b) { return; }
		if (b.hasAttribute('disabled')) { return; }
		if (b.tagName === 'A') { return; }
		show(parseInt(b.getAttribute('data-go'), 10));
	});

	root.addEventListener('change', function(e){
		var input = e.target;
		if (input.type !== 'radio') { return; }
		var sec = input.closest('.__step');
		if (!sec) { return; }
		var nextBtn = sec.querySelector('.__btn--next');
		if (nextBtn) { nextBtn.removeAttribute('disabled'); }
		if (!auto) { return; }
		var i = parseInt(sec.getAttribute('data-step'), 10);
		// petit delai : on voit la reponse se cocher avant de changer d'ecran
		setTimeout(function(){ show(i + 1); }, 260);
	});
})();
</script>
