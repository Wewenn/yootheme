<?php
/**
 * WeFrame – Navbar sidebar : un lien (item). Titre de section optionnel (à mettre sur le 1er lien du groupe).
 */
defined( 'ABSPATH' ) || exit;

$label = trim( (string) ( $props['label'] ?? '' ) );
if ( '' === $label ) { return; }
$url     = trim( (string) ( $props['url'] ?? '' ) );
$section = trim( (string) ( $props['section'] ?? '' ) );
$info    = trim( (string) ( $props['info'] ?? '' ) );
$href    = ( '' !== $url ) ? $url : '#';
$submenu = array();
foreach ( preg_split( '/\R+/', trim( (string) ( $props['submenu'] ?? '' ) ) ) as $line ) {
	if ( '' === trim( $line ) ) { continue; }
	$bits = array_map( 'trim', explode( '|', $line, 2 ) );
	$submenu[] = array( $bits[0], $bits[1] ?? '#' );
}
?>
<?php if ( '' !== $section ) : ?><div class="wf-ns-section"><?= esc_html( $section ) ?></div><?php endif; ?>
<div class="wf-ns-entry<?= $submenu ? ' has-submenu' : '' ?>">
<?php if ( $submenu ) : ?><div class="wf-ns-link"><?php else : ?><a class="wf-ns-link" href="<?= esc_url( $href ) ?>"><?php endif; ?>
    <span class="wf-ns-link-txt"><?= esc_html( $label ) ?></span>
    <?php if ( $submenu ) : ?><button type="button" class="wf-ns-subtoggle" aria-expanded="false" aria-label="Ouvrir le sous-menu">⌄</button><?php elseif ( '' !== $info ) : ?><span class="wf-ns-link-info"><?= esc_html( $info ) ?></span><?php endif; ?>
<?php if ( $submenu ) : ?></div><?php else : ?></a><?php endif; ?>
<?php if ( $submenu ) : ?><div class="wf-ns-submenu" hidden><?php foreach ( $submenu as $sub ) : ?><a href="<?= esc_url( $sub[1] ) ?>"><?= esc_html( $sub[0] ) ?></a><?php endforeach; ?></div><?php endif; ?>
</div>
