<?php
/**
 * WeFrame – Récit collant : étape (item). Rendu dans la colonne de texte + image (mobile) + data-img (desktop swap).
 */
defined( 'ABSPATH' ) || exit;
$title = (string) ( $props['title'] ?? '' );
$text  = (string) ( $props['text'] ?? '' );
$img   = trim( (string) ( $props['image'] ?? '' ) );
if ( '' === $title && '' === $text && '' === $img ) { return; }
if ( $img && ! preg_match( '#^https?://#i', $img ) ) { $img = '/' . ltrim( $img, '/' ); }
$rad = (int) ( $props['element']['radius'] ?? 16 );
?>
<div class="wf-ss-step" data-img="<?= esc_attr( $img ) ?>">
    <?php if ( $img ) : ?>
    <div class="wf-ss-step-img" style="display:none;border-radius:<?= $rad ?>px;overflow:hidden;margin-bottom:16px;">
        <img src="<?= esc_url( $img ) ?>" alt="<?= esc_attr( $title ) ?>" loading="lazy" style="width:100%;height:auto;display:block;">
    </div>
    <?php endif; ?>
    <?php if ( '' !== $title ) : ?><div class="wf-ss-step-t" style="font-size:clamp(22px,3vw,34px);font-weight:800;letter-spacing:-.01em;line-height:1.1;"><?= esc_html( $title ) ?></div><?php endif; ?>
    <?php if ( '' !== $text ) : ?><p class="wf-ss-step-p" style="font-size:16px;line-height:1.6;color:#555;margin:12px 0 0;max-width:46ch;"><?= esc_html( $text ) ?></p><?php endif; ?>
</div>
