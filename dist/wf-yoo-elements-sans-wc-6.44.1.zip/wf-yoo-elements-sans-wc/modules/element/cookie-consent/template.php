<?php
defined('ABSPATH') || exit;
$title = $props['title']??''; $desc = $props['description']??'';
$ba = $props['btn_accept']??'Tout accepter'; $br2 = $props['btn_reject']??'Refuser';
$bs = $props['btn_settings']??'Paramétrer'; $showS = !empty($props['show_settings']);
$catA = !empty($props['cat_analytics']); $catAl = $props['cat_analytics_label']??'Analytiques';
$catAd = $props['cat_analytics_desc']??''; $catM = !empty($props['cat_marketing']);
$catMl = $props['cat_marketing_label']??'Marketing'; $catMd = $props['cat_marketing_desc']??'';
$pos = $props['position']??'bottom'; $sty = $props['style']??'banner';
$bgc = $props['bg_color']??'#fff'; $tc = $props['text_color']??'#333';
$bbg = $props['btn_bg']??'#EA5C1C'; $bbc = $props['btn_color']??'#fff'; $bbr = (int)($props['btn_radius']??8);
$cn = $props['cookie_name']??'wf_consent'; $cd = (int)($props['cookie_days']??365);
$pl = $props['privacy_link']??''; $pt = $props['privacy_text']??'Politique de confidentialité';
$uid = 'wfck_'.substr(md5(serialize($props)),0,8);

$pcss = '';
if ($pos === 'bottom') $pcss = 'position:fixed;bottom:0;left:0;right:0;z-index:99999;';
elseif ($pos === 'center') $pcss = 'position:fixed;top:0;left:0;right:0;bottom:0;z-index:99999;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.5);';
$card = ($sty === 'card') ? "max-width:480px;border-radius:16px;margin:20px auto;" : "max-width:100%;";
$cfg = json_encode(['uid'=>$uid,'cn'=>$cn,'cd'=>$cd], JSON_HEX_AMP|JSON_HEX_APOS);
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr($uid) ?>" class="wf-cookie" style="<?= $pcss ?>display:none;">
    <div style="background:<?= esc_attr($bgc) ?>;color:<?= esc_attr($tc) ?>;padding:24px 32px;<?= $card ?>box-shadow:0 -4px 20px rgba(0,0,0,.1);">
        <?php if ($title) : ?><div style="font-size:18px;font-weight:700;margin-bottom:8px;"><?= esc_html($title) ?></div><?php endif; ?>
        <?php if ($desc) : ?><p style="margin:0 0 16px;font-size:14px;line-height:1.6;opacity:.8;"><?= esc_html($desc) ?></p><?php endif; ?>

        <div class="wf-ck-cats" style="display:none;margin-bottom:16px;">
            <div style="padding:8px 0;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid rgba(0,0,0,.1);">
                <div><strong style="font-size:13px;">Essentiels</strong><br><span style="font-size:12px;opacity:.6;">Toujours actifs</span></div>
                <span style="font-size:12px;opacity:.5;">Requis</span>
            </div>
            <?php if ($catA) : ?>
            <label style="padding:8px 0;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid rgba(0,0,0,.1);cursor:pointer;">
                <div><strong style="font-size:13px;"><?= esc_html($catAl) ?></strong><?php if ($catAd) : ?><br><span style="font-size:12px;opacity:.6;"><?= esc_html($catAd) ?></span><?php endif; ?></div>
                <input type="checkbox" class="wf-ck-cat" data-cat="analytics" style="width:18px;height:18px;">
            </label>
            <?php endif; ?>
            <?php if ($catM) : ?>
            <label style="padding:8px 0;display:flex;align-items:center;justify-content:space-between;cursor:pointer;">
                <div><strong style="font-size:13px;"><?= esc_html($catMl) ?></strong><?php if ($catMd) : ?><br><span style="font-size:12px;opacity:.6;"><?= esc_html($catMd) ?></span><?php endif; ?></div>
                <input type="checkbox" class="wf-ck-cat" data-cat="marketing" style="width:18px;height:18px;">
            </label>
            <?php endif; ?>
        </div>

        <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
            <button class="wf-ck-accept" style="cursor:pointer;padding:10px 24px;border:none;border-radius:<?= $bbr ?>px;background:<?= esc_attr($bbg) ?>;color:<?= esc_attr($bbc) ?>;font-size:14px;font-weight:600;font-family:inherit;"><?= esc_html($ba) ?></button>
            <button class="wf-ck-reject" style="cursor:pointer;padding:10px 24px;border:1px solid rgba(0,0,0,.2);border-radius:<?= $bbr ?>px;background:transparent;color:inherit;font-size:14px;font-weight:600;font-family:inherit;"><?= esc_html($br2) ?></button>
            <?php if ($showS) : ?>
            <button class="wf-ck-settings" style="cursor:pointer;padding:10px 16px;border:none;background:transparent;color:inherit;font-size:13px;font-weight:500;text-decoration:underline;font-family:inherit;"><?= esc_html($bs) ?></button>
            <button class="wf-ck-save" style="display:none;cursor:pointer;padding:10px 24px;border:1px solid rgba(0,0,0,.2);border-radius:<?= $bbr ?>px;background:transparent;color:inherit;font-size:14px;font-weight:600;font-family:inherit;"><?= esc_html__( 'Enregistrer mes choix', 'weframe' ) ?></button>
            <?php endif; ?>
            <?php if ($pl) : ?><a href="<?= esc_url($pl) ?>" style="font-size:12px;opacity:.6;margin-left:auto;"><?= esc_html($pt) ?></a><?php endif; ?>
        </div>
    </div>
</div>
<script>
(function(){
    function boot(){
        
        var c = <?= $cfg ?>;
        var el=document.getElementById(c.uid);if(!el)return;
        var stored=null; try{ stored=localStorage.getItem(c.cn); }catch(e){}
        if(!stored){ el.style.display=''; }
        var cats=el.querySelector('.wf-ck-cats');
        var settingsBtn=el.querySelector('.wf-ck-settings');
        var saveBtn2=el.querySelector('.wf-ck-save');
        if(settingsBtn){settingsBtn.addEventListener('click',function(){
            var open=cats.style.display==='none';
            cats.style.display=open?'block':'none';
            if(saveBtn2) saveBtn2.style.display=open?'inline-block':'none';
        })}
        function currentChoice(){
            var out={essential:true,analytics:false,marketing:false};
            el.querySelectorAll('.wf-ck-cat').forEach(function(cb){
                out[cb.getAttribute('data-cat')]=!!cb.checked;
            });
            return out;
        }
        function save(choice){
            try{
                var exp=Date.now()+c.cd*86400000;
                localStorage.setItem(c.cn,JSON.stringify({v:choice,e:exp,t:Date.now()}));
            }catch(e){}
            // Broadcast to the rest of the page (GTM / analytics / scripts)
            document.body.dispatchEvent(new CustomEvent('wf_cookie_consent',{detail:choice}));
            el.style.display='none';
        }
        // RGPD : permettre de revenir sur son choix (retrait aussi simple que l'accord).
        function wfReopen(){
            try{
                var raw=localStorage.getItem(c.cn);
                if(raw){
                    var prev=JSON.parse(raw).v||{};
                    el.querySelectorAll('.wf-ck-cat').forEach(function(cb){
                        cb.checked=!!prev[cb.getAttribute('data-cat')];
                    });
                }
            }catch(e){}
            el.style.display='';
            if(cats){ cats.style.display='block'; }
            if(saveBtn2){ saveBtn2.style.display='inline-block'; }
        }
        if(window.WF){ WF.cookieSettings=wfReopen; }
        document.querySelectorAll('[data-wf-cookie-settings]').forEach(function(t){
            t.addEventListener('click',function(ev){ ev.preventDefault(); wfReopen(); });
        });

        el.querySelector('.wf-ck-accept').addEventListener('click',function(){
            save({essential:true,analytics:true,marketing:true});
        });
        el.querySelector('.wf-ck-reject').addEventListener('click',function(){
            save({essential:true,analytics:false,marketing:false});
        });
        // "Enregistrer mes choix" when settings panel open
        var saveBtn=el.querySelector('.wf-ck-save');
        if(saveBtn){saveBtn.addEventListener('click',function(){save(currentChoice())})}
    }
    WF.ready(boot)
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
