<?php
/**
 * WeFrame – Animated Image | template.php
 * Image with configurable entrance + exit animations driven by scroll position.
 * before (below viewport) -> in (visible) -> after (above viewport).
 * Config inlined (no <script type="application/json">), no "&&" in inline JS.
 */
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'wf_ai_state' ) ) {
    function wf_ai_state( $type, $dist ) {
        $d = (int) $dist;
        switch ( $type ) {
            case 'fade':        return array( 'o' => '0', 't' => 'none', 'f' => 'none' );
            case 'slide-up':    return array( 'o' => '0', 't' => 'translateY(' . $d . 'px)', 'f' => 'none' );
            case 'slide-down':  return array( 'o' => '0', 't' => 'translateY(-' . $d . 'px)', 'f' => 'none' );
            case 'slide-left':  return array( 'o' => '0', 't' => 'translateX(' . $d . 'px)', 'f' => 'none' );
            case 'slide-right': return array( 'o' => '0', 't' => 'translateX(-' . $d . 'px)', 'f' => 'none' );
            case 'scale-up':    return array( 'o' => '0', 't' => 'scale(.82)', 'f' => 'none' );
            case 'scale-down':  return array( 'o' => '0', 't' => 'scale(1.18)', 'f' => 'none' );
            case 'blur':        return array( 'o' => '0', 't' => 'none', 'f' => 'blur(14px)' );
            case 'rotate':      return array( 'o' => '0', 't' => 'rotate(-6deg) scale(.9)', 'f' => 'none' );
            case 'flip':        return array( 'o' => '0', 't' => 'perspective(900px) rotateX(35deg)', 'f' => 'none' );
            case 'none':
            default:            return array( 'o' => '1', 't' => 'none', 'f' => 'none' );
        }
    }
}

$props = is_array( $props ?? null ) ? $props : array();

$src = (string) ( $props['image'] ?? '' );
if ( '' === $src ) { return; }
if ( ! preg_match( '#^https?://#i', $src ) ) { $src = '/' . ltrim( $src, '/' ); }

$alt      = (string) ( $props['image_alt'] ?? '' );
$link     = (string) ( $props['link'] ?? '' );
$anim_in  = (string) ( $props['anim_in'] ?? 'slide-up' );
$anim_out = (string) ( $props['anim_out'] ?? 'fade' );
$dist     = min( 300, max( 0, (int) ( $props['distance'] ?? 60 ) ) );
$dur      = min( 2500, max( 100, (int) ( $props['duration'] ?? 800 ) ) );
$delay    = min( 2000, max( 0, (int) ( $props['delay'] ?? 0 ) ) );
$easing   = (string) ( $props['easing'] ?? 'cubic-bezier(.22,1,.36,1)' );
$once     = ! empty( $props['once'] );
$hover    = (string) ( $props['hover'] ?? 'none' );
$radius   = min( 60, max( 0, (int) ( $props['radius'] ?? 12 ) ) );
$ratio    = (string) ( $props['ratio'] ?? 'auto' );
$width    = max( 0, (int) ( $props['width']         ?? 0 ) );
$width_t  = max( 0, (int) ( $props['width_tablet']  ?? 0 ) );
$width_m  = max( 0, (int) ( $props['width_mobile']  ?? 0 ) );
$height   = max( 0, (int) ( $props['height']        ?? 0 ) );
$height_t = max( 0, (int) ( $props['height_tablet'] ?? 0 ) );
$height_m = max( 0, (int) ( $props['height_mobile'] ?? 0 ) );
$shadow   = ! empty( $props['shadow'] );
$caption  = trim( (string) ( $props['caption'] ?? '' ) );
$align    = (string) ( $props['align'] ?? 'center' );

$allowed_easing = array( 'cubic-bezier(.22,1,.36,1)', 'cubic-bezier(.34,1.56,.64,1)', 'linear', 'ease', 'ease-in-out' );
if ( ! in_array( $easing, $allowed_easing, true ) ) { $easing = 'cubic-bezier(.22,1,.36,1)'; }
$allowed_ratio = array( 'auto', '1/1', '4/3', '3/2', '16/9', '3/4', '9/16' );
if ( ! in_array( $ratio, $allowed_ratio, true ) ) { $ratio = 'auto'; }

$uid = 'wfai_' . substr( md5( $src . serialize( $props ) ), 0, 8 );

$in  = wf_ai_state( $anim_in, $dist );
$out = wf_ai_state( $anim_out, $dist );

// Image sizing
$img_css = 'display:block;width:100%;height:' . ( $height > 0 ? $height . 'px' : 'auto' ) . ';';
if ( $height > 0 ) {
    $img_css .= 'object-fit:cover;';
} elseif ( 'auto' !== $ratio ) {
    $img_css .= 'aspect-ratio:' . esc_attr( $ratio ) . ';object-fit:cover;';
}
$img_css .= 'border-radius:' . $radius . 'px;';
if ( $shadow ) { $img_css .= 'box-shadow:0 24px 60px -20px rgba(0,0,0,.35);'; }

$jc_map = array( 'left' => 'flex-start', 'center' => 'center', 'right' => 'flex-end' );
$jc     = $jc_map[ $align ] ?? 'center';
$wrap_w = ( $width > 0 ) ? 'width:' . $width . 'px;max-width:100%;' : 'width:100%;';

$cfg = wp_json_encode( array(
    'uid'  => $uid,
    'once' => $once ? 1 : 0,
), JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE );

$img_tag = '<img src="' . esc_url( $src ) . '" alt="' . esc_attr( $alt ) . '" loading="lazy" class="wf-ai-img" style="' . esc_attr( $img_css ) . '">';
if ( '' !== $link ) {
    $img_tag = '<a href="' . esc_url( $link ) . '" style="display:block;">' . $img_tag . '</a>';
}
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-ai" data-state="before" style="display:flex;justify-content:<?= esc_attr( $jc ) ?>;">
    <figure class="wf-ai-fig" style="margin:0;<?= $wrap_w ?>">
        <div class="wf-ai-inner"><?= $img_tag ?></div>
        <?php if ( '' !== $caption ) : ?>
        <figcaption style="margin-top:10px;font-size:13px;line-height:1.4;opacity:.7;text-align:<?= esc_attr( $align ) ?>;"><?= esc_html( $caption ) ?></figcaption>
        <?php endif; ?>
    </figure>
</div>

<style>
#<?= esc_attr( $uid ) ?> .wf-ai-inner {
    transition: opacity <?= $dur ?>ms <?= $easing ?> <?= $delay ?>ms,
                transform <?= $dur ?>ms <?= $easing ?> <?= $delay ?>ms,
                filter <?= $dur ?>ms <?= $easing ?> <?= $delay ?>ms;
    will-change: opacity, transform, filter;
}
#<?= esc_attr( $uid ) ?>[data-state="before"] .wf-ai-inner { opacity: <?= $in['o'] ?>; transform: <?= $in['t'] ?>; filter: <?= $in['f'] ?>; }
#<?= esc_attr( $uid ) ?>[data-state="in"] .wf-ai-inner    { opacity: 1; transform: none; filter: none; }
#<?= esc_attr( $uid ) ?>[data-state="after"] .wf-ai-inner { opacity: <?= $out['o'] ?>; transform: <?= $out['t'] ?>; filter: <?= $out['f'] ?>; }

#<?= esc_attr( $uid ) ?> .wf-ai-img { transition: transform .4s <?= $easing ?>; }
<?php if ( 'zoom' === $hover ) : ?>
#<?= esc_attr( $uid ) ?> .wf-ai-fig:hover .wf-ai-img { transform: scale(1.06); }
#<?= esc_attr( $uid ) ?> .wf-ai-inner { overflow: hidden; border-radius: <?= $radius ?>px; }
<?php elseif ( 'lift' === $hover ) : ?>
#<?= esc_attr( $uid ) ?> .wf-ai-fig { transition: transform .35s <?= $easing ?>; }
#<?= esc_attr( $uid ) ?> .wf-ai-fig:hover { transform: translateY(-8px); }
<?php elseif ( 'tilt' === $hover ) : ?>
#<?= esc_attr( $uid ) ?> .wf-ai-fig { transition: transform .3s ease; transform-style: preserve-3d; }
#<?= esc_attr( $uid ) ?> .wf-ai-fig:hover { transform: perspective(900px) rotateX(4deg) rotateY(-4deg) scale(1.02); }
<?php endif; ?>

<?php if ( $width_t > 0 || $height_t > 0 ) : ?>
@media (min-width:768px) and (max-width:1024px) {
    <?php if ( $width_t > 0 ) : ?>#<?= esc_attr( $uid ) ?> .wf-ai-fig { width: <?= $width_t ?>px !important; }<?php endif; ?>
    <?php if ( $height_t > 0 ) : ?>#<?= esc_attr( $uid ) ?> .wf-ai-img { height: <?= $height_t ?>px !important; object-fit: cover; }<?php endif; ?>
}
<?php endif; ?>
<?php if ( $width_m > 0 || $height_m > 0 ) : ?>
@media (max-width:767px) {
    <?php if ( $width_m > 0 ) : ?>#<?= esc_attr( $uid ) ?> .wf-ai-fig { width: <?= $width_m ?>px !important; max-width: 100%; }<?php endif; ?>
    <?php if ( $height_m > 0 ) : ?>#<?= esc_attr( $uid ) ?> .wf-ai-img { height: <?= $height_m ?>px !important; object-fit: cover; }<?php endif; ?>
}
<?php endif; ?>

@media (prefers-reduced-motion: reduce) {
    #<?= esc_attr( $uid ) ?> .wf-ai-inner { transition: none !important; opacity: 1 !important; transform: none !important; filter: none !important; }
}
</style>

<script>
(function(){
    var C = <?= $cfg ?>;
    function boot(){
        var el = document.getElementById(C.uid); if (!el) return;
        var locked = false;
        var ticking = false;

        function update(){
            ticking = false;
            if (locked) { return; }
            var r = el.getBoundingClientRect();
            var vh = window.innerHeight || document.documentElement.clientHeight;
            var margin = vh * 0.12;
            var st;
            if (r.top > vh - margin) { st = 'before'; }
            else if (r.bottom < margin) { st = 'after'; }
            else { st = 'in'; }
            el.setAttribute('data-state', st);
            if (C.once) { if (st === 'in') { locked = true; } }
        }
        function onScroll(){ if (!ticking) { ticking = true; requestAnimationFrame(update); } }

        window.addEventListener('scroll', onScroll, { passive: true });
        window.addEventListener('resize', onScroll, { passive: true });
        update();
    }
    if (window.WF) { if (WF.ready) { WF.ready(boot); return; } }
    if (document.readyState !== 'loading') { boot(); } else { document.addEventListener('DOMContentLoaded', boot); }
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
