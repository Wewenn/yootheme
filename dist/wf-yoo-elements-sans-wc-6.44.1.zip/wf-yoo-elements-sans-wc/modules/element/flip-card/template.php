<?php
/**
 * WeFrame – Flip Card | template.php v6.0
 * CSS 3D flip card — recto/verso. Hover ou clic. Zero dépendances.
 */
defined( 'ABSPATH' ) || exit;

$dir      = $props['flip_direction']   ?? 'horizontal';
$trigger  = $props['flip_trigger']     ?? 'hover';
$h        = (int) ( $props['height']        ?? 320 );
$hm       = (int) ( $props['height_mobile'] ?? 280 );
$rad      = (int) ( $props['radius']        ?? 16 );
$shadow   = ! empty( $props['shadow'] );
$persp    = (int) ( $props['perspective'] ?? 1000 );
$dur      = (int) ( $props['duration']    ?? 600 );

// Recto
$f_img    = $props['front_image']        ?? '';
$f_fit    = $props['front_image_fit']    ?? 'cover';
$f_bg     = $props['front_bg']           ?? '#1a1a1a';
$f_color  = $props['front_color']        ?? '#ffffff';
$f_over   = $props['front_overlay']      ?? 'rgba(0,0,0,0.35)';
$f_icon   = $props['front_icon']         ?? '';
$f_title  = $props['front_title']        ?? '';
$f_tsz    = (int) ( $props['front_title_size']   ?? 22 );
$f_tw     = $props['front_title_weight'] ?? '700';
$f_sub    = $props['front_subtitle']     ?? '';
$f_ssz    = (int) ( $props['front_subtitle_size'] ?? 14 );
$f_align  = $props['front_align']        ?? 'center';

// Verso
$b_bg     = $props['back_bg']            ?? '#EA5C1C';
$b_color  = $props['back_color']         ?? '#ffffff';
$b_title  = $props['back_title']         ?? '';
$b_tsz    = (int) ( $props['back_title_size']   ?? 20 );
$b_tw     = $props['back_title_weight']  ?? '700';
$b_text   = $props['back_text']          ?? '';
$b_txsz   = (int) ( $props['back_text_size']    ?? 14 );
$b_btxt   = $props['back_btn_text']      ?? '';
$b_burl   = $props['back_btn_url']       ?? '';
$b_bbg    = $props['back_btn_bg']        ?? '#ffffff';
$b_bc     = $props['back_btn_color']     ?? '#EA5C1C';
$b_brad   = (int) ( $props['back_btn_radius'] ?? 8 );
$b_align  = $props['back_align']         ?? 'center';
$b_pad    = (int) ( $props['back_padding'] ?? 32 );

$uid = wf_uid( 'wffc_', $props );

// Image processing
if ( $f_img && ! preg_match( '#^https?://#i', $f_img ) ) {
    $f_img = '/' . ltrim( $f_img, '/' );
}

$sh_css  = $shadow ? 'box-shadow:0 16px 48px rgba(0,0,0,.18);' : '';
$rot_in  = $dir === 'vertical' ? 'rotateX(-180deg)' : 'rotateY(180deg)';
$rot_out = $dir === 'vertical' ? 'rotateX(180deg)'  : 'rotateY(180deg)';

$is_click = ( $trigger === 'click' );
$role_attr = $is_click ? ' role="button" tabindex="0"' : '';
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-flip-card<?= $is_click ? ' wf-flip-click' : '' ?>"<?= $role_attr ?>
     style="perspective:<?= $persp ?>px;height:<?= $h ?>px;<?= $sh_css ?>border-radius:<?= $rad ?>px;cursor:<?= $is_click ? 'pointer' : 'default' ?>;">
    <div class="wf-flip-inner" style="position:relative;width:100%;height:100%;transform-style:preserve-3d;transition:transform <?= $dur ?>ms cubic-bezier(.4,0,.2,1);border-radius:<?= $rad ?>px;">

        <!-- Recto -->
        <div class="wf-flip-front" style="position:absolute;inset:0;border-radius:<?= $rad ?>px;overflow:hidden;-webkit-backface-visibility:hidden;backface-visibility:hidden;background:<?= esc_attr( $f_bg ) ?>;display:flex;flex-direction:column;align-items:<?= $f_align === 'center' ? 'center' : ( $f_align === 'right' ? 'flex-end' : 'flex-start' ) ?>;justify-content:flex-end;text-align:<?= esc_attr( $f_align ) ?>;">
            <?php if ( $f_img ) : ?>
            <div style="position:absolute;inset:0;background:url('<?= esc_url( $f_img ) ?>') center/<?= esc_attr( $f_fit ) ?> no-repeat;z-index:0;"></div>
            <div style="position:absolute;inset:0;background:<?= esc_attr( $f_over ) ?>;z-index:1;"></div>
            <?php endif; ?>
            <div style="position:relative;z-index:2;padding:24px;color:<?= esc_attr( $f_color ) ?>;width:100%;box-sizing:border-box;">
                <?php if ( $f_icon ) : ?>
                <div style="font-size:40px;line-height:1;margin-bottom:12px;"><?= esc_html( $f_icon ) ?></div>
                <?php endif; ?>
                <?php if ( $f_title ) : ?>
                <div style="font-size:<?= $f_tsz ?>px;font-weight:<?= esc_attr( $f_tw ) ?>;line-height:1.2;margin-bottom:8px;"><?= esc_html( $f_title ) ?></div>
                <?php endif; ?>
                <?php if ( $f_sub ) : ?>
                <div style="font-size:<?= $f_ssz ?>px;opacity:.8;line-height:1.4;"><?= esc_html( $f_sub ) ?></div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Verso -->
        <div class="wf-flip-back" style="position:absolute;inset:0;border-radius:<?= $rad ?>px;overflow:hidden;-webkit-backface-visibility:hidden;backface-visibility:hidden;background:<?= esc_attr( $b_bg ) ?>;display:flex;flex-direction:column;align-items:<?= $b_align === 'center' ? 'center' : ( $b_align === 'right' ? 'flex-end' : 'flex-start' ) ?>;justify-content:center;text-align:<?= esc_attr( $b_align ) ?>;padding:<?= $b_pad ?>px;box-sizing:border-box;color:<?= esc_attr( $b_color ) ?>;transform:<?= $rot_in ?>;">
            <?php if ( $b_title ) : ?>
            <div style="font-size:<?= $b_tsz ?>px;font-weight:<?= esc_attr( $b_tw ) ?>;line-height:1.2;margin-bottom:12px;"><?= esc_html( $b_title ) ?></div>
            <?php endif; ?>
            <?php if ( $b_text ) : ?>
            <div style="font-size:<?= $b_txsz ?>px;line-height:1.6;opacity:.9;margin-bottom:<?= $b_btxt ? '24px' : '0' ?>;"><?= nl2br( esc_html( $b_text ) ) ?></div>
            <?php endif; ?>
            <?php if ( $b_btxt ) : ?>
            <a href="<?= esc_url( $b_burl ?: '#' ) ?>" style="display:inline-block;background:<?= esc_attr( $b_bbg ) ?>;color:<?= esc_attr( $b_bc ) ?>;padding:10px 24px;border-radius:<?= $b_brad ?>px;font-size:14px;font-weight:700;text-decoration:none;line-height:1.4;" onclick="<?= $is_click ? 'event.stopPropagation()' : '' ?>"><?= esc_html( $b_btxt ) ?></a>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
<?php if ( ! $is_click ) : ?>
#<?= esc_attr( $uid ) ?>:hover .wf-flip-inner {
    transform: <?= $rot_out ?>;
}
<?php endif; ?>
#<?= esc_attr( $uid ) ?>.wf-flipped .wf-flip-inner {
    transform: <?= $rot_out ?>;
}
@media(max-width:767px){
    #<?= esc_attr( $uid ) ?>{ height:<?= $hm ?>px !important; }
}
</style>

<?php if ( $is_click ) : ?>
<script>
(function(){
    WF.ready(function(){
        var el = document.getElementById('<?= esc_attr( $uid ) ?>');
        if (!el) return;
        el.addEventListener('click', function(){ el.classList.toggle('wf-flipped'); });
        el.addEventListener('keydown', function(e){ if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); el.classList.toggle('wf-flipped'); } });
    });
})();
</script>
<?php endif; ?>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
