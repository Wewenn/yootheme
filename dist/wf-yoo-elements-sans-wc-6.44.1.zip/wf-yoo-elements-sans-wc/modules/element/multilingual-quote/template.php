<?php
/**
 * WeFrame – Citation multilingue | template.php v1.0 (JS sans &&)
 */
defined( 'ABSPATH' ) || exit;

$raw    = (string) ( $props['quotes'] ?? '' );
$author = (string) ( $props['author'] ?? '' );
$intv   = (float) ( $props['interval'] ?? 2.5 );
if ( $intv < 0.5 ) { $intv = 0.5; }
$size   = max( 12, (int) ( $props['size'] ?? 34 ) );
$col    = $props['color'] ?? '#111111';
$acol   = $props['author_color'] ?? '#c0272d';
$align  = $props['align'] ?? 'center';

$lines = array();
foreach ( preg_split( '/[\r\n]+/', $raw ) as $l ) {
    $l = trim( $l );
    if ( '' !== $l ) { $lines[] = $l; }
}
if ( empty( $lines ) ) { return; }

$uid = wf_uid( 'wfmq_', $props );
$cfg = wp_json_encode( array( 'lines' => $lines, 'intv' => (int) round( $intv * 1000 ) ), JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-mq" style="text-align:<?= esc_attr( $align ) ?>;">
    <div class="wf-mq-q" style="font-size:<?= $size ?>px;font-weight:800;line-height:1.2;color:<?= esc_attr( $col ) ?>;letter-spacing:-.01em;transition:opacity .4s ease, transform .4s ease;min-height:1.2em;"><?= esc_html( $lines[0] ) ?></div>
    <?php if ( '' !== $author ) : ?><div class="wf-mq-a" style="margin-top:10px;font-size:15px;font-weight:600;color:<?= esc_attr( $acol ) ?>;"><?= esc_html( $author ) ?></div><?php endif; ?>
</div>
<script>
(function(){
    var c = <?= $cfg ?>;
    var el = document.getElementById('<?= esc_js( $uid ) ?>'); if (!el) return;
    var q = el.querySelector('.wf-mq-q'); if (!q) return;
    if (c.lines.length < 2) return;
    var i = 0;
    setInterval(function(){
        q.style.opacity = '0';
        q.style.transform = 'translateY(-8px)';
        setTimeout(function(){
            i = (i + 1) % c.lines.length;
            q.textContent = c.lines[i];
            q.style.transform = 'translateY(8px)';
            q.style.opacity = '1';
            setTimeout(function(){ q.style.transform = 'translateY(0)'; }, 20);
        }, 400);
    }, c.intv);
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
