<?php
/**
 * WeFrame – Cartes empilées (carte enfant) | template.php v1.0
 * Le parent fournit l'enveloppe et le mode d'affichage ; ici on rend le contenu.
 * Un lien sur la carte devient un <div> si du contenu libre y a ete depose :
 * un <a> ne peut pas contenir d'autres liens.
 */
defined( 'ABSPATH' ) || exit;

$number = trim( (string) ( $props['number'] ?? '' ) );
$title  = trim( (string) ( $props['title'] ?? '' ) );
$desc   = trim( (string) ( $props['description'] ?? '' ) );
$icon   = (string) ( $props['icon'] ?? 'none' );

$icons = array(
	'star'   => '<path d="M239.2,97.29a16,16,0,0,0-13.81-11L166,81.17,142.72,25.81h0a15.95,15.95,0,0,0-29.44,0L90.07,81.17,30.61,86.32a16,16,0,0,0-9.11,28.06L66.61,153.8,53.09,212.34a16,16,0,0,0,23.84,17.34l51-31,51.11,31a16,16,0,0,0,23.84-17.34l-13.51-58.6,45.1-39.36A16,16,0,0,0,239.2,97.29Z"/>',
	'bolt'   => '<path d="M213.85,125.46l-112,120a8,8,0,0,1-13.69-7l14.66-73.29L45.19,143.49a8,8,0,0,1-3-13l112-120a8,8,0,0,1,13.69,7L153.18,90.9l57.63,21.61a8,8,0,0,1,3,12.95Z"/>',
	'target' => '<path d="M221.87,83.16A104.1,104.1,0,1,1,195.67,49l22.67-22.68a8,8,0,0,1,11.32,11.32l-96,96a8,8,0,0,1-11.32-11.32l27.72-27.72A40,40,0,1,0,168,128a8,8,0,0,1,16,0,56,56,0,1,1-21.31-44l17.34-17.34A79.79,79.79,0,0,0,128,48a80,80,0,1,0,80,80,78.72,78.72,0,0,0-2.32-19.17,8,8,0,0,1,15.51-3.87Z"/>',
	'shield' => '<path d="M208,40H48A16,16,0,0,0,32,56v58.78c0,89.61,75.82,119.34,91,124.39a15.53,15.53,0,0,0,10,0c15.2-5.05,91-34.78,91-124.39V56A16,16,0,0,0,208,40Zm0,74.79c0,78.42-66.35,104.62-80,109.18-13.53-4.51-80-30.69-80-109.18V56H208Z"/>',
	'bulb'   => '<path d="M176,232a8,8,0,0,1-8,8H88a8,8,0,0,1,0-16h80A8,8,0,0,1,176,232Zm40-128a87.55,87.55,0,0,1-33.64,69.21A16.24,16.24,0,0,0,176,186v6a16,16,0,0,1-16,16H96a16,16,0,0,1-16-16v-6a16,16,0,0,0-6.23-12.66A87.59,87.59,0,0,1,40,104.49C39.74,56.83,78.26,17.14,125.88,16A88,88,0,0,1,216,104Z"/>',
	'chart'  => '<path d="M224,200h-8V40a8,8,0,0,0-8-8H152a8,8,0,0,0-8,8V80H96a8,8,0,0,0-8,8v40H48a8,8,0,0,0-8,8v64H32a8,8,0,0,0,0,16H224a8,8,0,0,0,0-16Z"/>',
);

$link = $props['link'] ?? '';
if ( is_array( $link ) ) { $link = $link['url'] ?? ''; }
$link = trim( (string) $link );

$inner = '';
if ( ! empty( $children ) ) {
	foreach ( $children as $ci => $child ) {
		$inner .= $builder->render( $child, array( 'element' => $props, 'index' => $ci ) );
	}
}

// Les parametres passes par le parent arrivent comme variables ($element, $index).
$arrow = ( isset( $element ) && is_array( $element ) ) ? ! empty( $element['show_arrow'] ) : false;
$isLink = ( '' !== $link && '' === trim( $inner ) );
?>
<?php if ( '' !== $number ) : ?><span class="__num"><?= esc_html( $number ) ?></span><?php endif; ?>
<?php if ( 'none' !== $icon && isset( $icons[ $icon ] ) ) : ?>
<span class="__icon" aria-hidden="true"><svg viewBox="0 0 256 256" width="24" height="24" fill="currentColor"><?= $icons[ $icon ] ?></svg></span>
<?php endif; ?>
<?php if ( '' !== $title ) : ?>
<h3 class="__title"><?php if ( $isLink ) : ?><a href="<?= esc_url( $link ) ?>"><?= esc_html( $title ) ?></a><?php else : ?><?= esc_html( $title ) ?><?php endif; ?></h3>
<?php endif; ?>
<?php if ( '' !== $desc ) : ?><p class="__desc"><?= nl2br( esc_html( $desc ) ) ?></p><?php endif; ?>
<?php if ( '' !== trim( $inner ) ) : ?><div class="__free"><?= $inner ?></div><?php endif; ?>
<?php if ( '' !== $link && '' !== trim( $inner ) ) : ?>
<p class="__linkline"><a href="<?= esc_url( $link ) ?>"><?= esc_html__( 'En savoir plus', 'weframe' ) ?></a></p>
<?php endif; ?>
<?php if ( $arrow && '' !== $link ) : ?>
<span class="__arrow" aria-hidden="true"><svg viewBox="0 0 256 256" width="18" height="18" fill="currentColor"><path d="M221.66,133.66l-72,72a8,8,0,0,1-11.32-11.32L196.69,136H40a8,8,0,0,1,0-16H196.69L138.34,61.66a8,8,0,0,1,11.32-11.32l72,72A8,8,0,0,1,221.66,133.66Z"/></svg></span>
<?php endif; ?>
