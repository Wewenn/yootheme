<?php
/**
 * WeFrame – Liste animée | template.php v1.0
 * Les éléments arrivent un par un et poussent les précédents, comme un flux de
 * notifications.
 *
 * Tous les elements sont dans le DOM au chargement : sans JS on voit la liste
 * complete, et le contenu reste indexable. Le script ne fait que masquer ce qui
 * depasse et faire tourner l'ordre. Chaque arrivee est annoncee dans une zone
 * de statut, sinon un lecteur d'ecran ne verrait jamais le mouvement.
 * Pas de "&&" ni de "||" dans le JS inline (regle interne du plugin).
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$interval = max( 400, (int) ( $props['interval'] ?? 2200 ) );
$maxVis   = max( 2, min( 10, (int) ( $props['max_visible'] ?? 5 ) ) );
$dirTop   = ( 'bottom' !== ( $props['direction'] ?? 'top' ) );
$loop     = ! empty( $props['loop'] );
$pause    = ! empty( $props['pause_hover'] );
$dur      = max( 100, (int) ( $props['duration'] ?? 520 ) );
$gap      = max( 0, (int) ( $props['gap'] ?? 10 ) );

$cBg  = (string) ( $props['card_bg'] ?? '#ffffff' );
$cCol = (string) ( $props['card_color'] ?? '#111111' );
$cMut = (string) ( $props['card_muted'] ?? '#6b7280' );
$cBd  = trim( (string) ( $props['card_border'] ?? '' ) );
$acc  = (string) ( $props['accent_color'] ?? '#EA5C1C' );
$rad  = max( 0, (int) ( $props['radius'] ?? 14 ) );
$pad  = max( 4, (int) ( $props['padding'] ?? 14 ) );
$iSz  = max( 0, (int) ( $props['icon_size'] ?? 40 ) );

$items = array();
foreach ( $children as $i => $child ) {
	$cp = (array) ( $child->props ?? array() );
	$t  = trim( (string) ( $cp['title'] ?? '' ) );
	$x  = trim( (string) ( $cp['text'] ?? '' ) );
	if ( '' === $t && '' === $x ) { continue; }

	$img = $cp['image'] ?? '';
	if ( is_array( $img ) ) { $img = $img['src'] ?? ( $img['url'] ?? '' ); }

	$items[] = array(
		'title' => $t,
		'text'  => $x,
		'badge' => trim( (string) ( $cp['badge'] ?? '' ) ),
		'img'   => trim( (string) $img ),
		'color' => trim( (string) ( $cp['color'] ?? '' ) ),
	);
}
if ( empty( $items ) ) { return; }
$n = count( $items );

$uid = wf_uid( 'wfal_', $props, $n );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-al<?= $dirTop ? '' : ' wf-al--bottom' ?><?= $pause ? ' wf-al--pause' : '' ?>"
	data-interval="<?= (int) $interval ?>" data-max="<?= (int) $maxVis ?>" data-loop="<?= $loop ? '1' : '0' ?>">
	<ul class="__list">
		<?php foreach ( $items as $i => $it ) : ?>
		<li class="__item"<?= '' !== $it['color'] ? ' style="--ic:' . esc_attr( $it['color'] ) . '"' : '' ?>>
			<?php if ( $iSz > 0 ) : ?>
			<span class="__badge" aria-hidden="true">
				<?php if ( '' !== $it['img'] ) : ?>
				<img src="<?= esc_url( $it['img'] ) ?>" alt="" loading="lazy" decoding="async">
				<?php else : ?>
				<?= esc_html( '' !== $it['badge'] ? $it['badge'] : mb_substr( $it['title'], 0, 1 ) ) ?>
				<?php endif; ?>
			</span>
			<?php endif; ?>
			<span class="__body">
				<?php if ( '' !== $it['title'] ) : ?><span class="__title"><?= esc_html( $it['title'] ) ?></span><?php endif; ?>
				<?php if ( '' !== $it['text'] ) : ?><span class="__text"><?= esc_html( $it['text'] ) ?></span><?php endif; ?>
			</span>
		</li>
		<?php endforeach; ?>
	</ul>
	<p class="wf-sr" role="status" aria-live="polite"></p>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?>{container-type:inline-size;}
#<?= esc_attr( $uid ) ?> .__list{
	margin:0;padding:0;list-style:none;display:flex;flex-direction:column;gap:<?= (int) $gap ?>px;
}
#<?= esc_attr( $uid ) ?>.wf-al--bottom .__list{flex-direction:column-reverse;}
#<?= esc_attr( $uid ) ?> .__item{
	display:flex;align-items:center;gap:<?= (int) max( 8, round( $pad * .8 ) ) ?>px;
	background:<?= esc_attr( $cBg ) ?>;color:<?= esc_attr( $cCol ) ?>;
	border-radius:<?= (int) $rad ?>px;padding:<?= (int) $pad ?>px;
	<?= '' !== $cBd ? 'border:1px solid ' . esc_attr( $cBd ) . ';' : '' ?>
	box-shadow:0 8px 22px rgba(0,0,0,.06);
	transition:transform <?= (int) $dur ?>ms cubic-bezier(.2,.8,.2,1),opacity <?= (int) round( $dur * .7 ) ?>ms ease;
}
#<?= esc_attr( $uid ) ?> .__badge{
	flex:0 0 auto;display:flex;align-items:center;justify-content:center;overflow:hidden;
	width:<?= (int) $iSz ?>px;height:<?= (int) $iSz ?>px;border-radius:<?= (int) round( $iSz / 3 ) ?>px;
	background:var(--ic,<?= esc_attr( $acc ) ?>);color:#fff;
	font-weight:700;font-size:<?= (int) max( 12, round( $iSz / 2.4 ) ) ?>px;
}
#<?= esc_attr( $uid ) ?> .__badge img{width:100%;height:100%;object-fit:cover;}
#<?= esc_attr( $uid ) ?> .__body{display:flex;flex-direction:column;gap:2px;min-width:0;}
#<?= esc_attr( $uid ) ?> .__title{font-weight:700;font-size:15px;line-height:1.3;}
#<?= esc_attr( $uid ) ?> .__text{font-size:13.5px;line-height:1.4;color:<?= esc_attr( $cMut ) ?>;}
#<?= esc_attr( $uid ) ?> .wf-sr{
	position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;
	clip:rect(0,0,0,0);white-space:nowrap;border:0;
}
/* Etats poses par le script : sans lui, tous les elements restent visibles. */
#<?= esc_attr( $uid ) ?>.is-ready .__item[hidden]{display:none;}
#<?= esc_attr( $uid ) ?>.is-ready .__item.is-new{
	animation:<?= esc_attr( $uid ) ?>-in <?= (int) $dur ?>ms cubic-bezier(.2,.8,.2,1) both;
}
@keyframes <?= esc_attr( $uid ) ?>-in{
	from{opacity:0;transform:translateY(<?= $dirTop ? '-14px' : '14px' ?>) scale(.96)}
	to{opacity:1;transform:none}
}
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?> .__item{transition-duration:.001ms;}
	#<?= esc_attr( $uid ) ?>.is-ready .__item.is-new{animation-duration:.001ms;}
}
</style>

<script>
(function(){
	var root = document.getElementById('<?= esc_js( $uid ) ?>');
	if (!root) { return; }
	var list = root.querySelector('.__list');
	var items = [].slice.call(root.querySelectorAll('.__item'));
	var live = root.querySelector('.wf-sr');
	var n = items.length;
	if (n < 2) { return; }

	var interval = parseInt(root.getAttribute('data-interval'), 10);
	var maxVis = parseInt(root.getAttribute('data-max'), 10);
	var loop = root.getAttribute('data-loop') === '1';
	if (maxVis > n) { maxVis = n; }

	var reduced = false;
	if (window.matchMedia) {
		if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { reduced = true; }
	}
	if (reduced) { return; }

	// Au depart on n'affiche qu'un element : les suivants arrivent.
	root.classList.add('is-ready');
	for (var k = 1; k < n; k++) { items[k].hidden = true; }

	var shown = 1;
	var next = 1;

	function step(){
		var el = items[next % n];
		el.hidden = false;
		el.classList.remove('is-new');
		void el.offsetWidth;                 // relance l'animation
		el.classList.add('is-new');
		// le nouvel arrivant passe en tete
		list.insertBefore(el, list.firstChild);
		if (live) {
			var t = el.querySelector('.__title');
			live.textContent = t ? t.textContent : '';
		}
		next++;
		shown++;
		if (shown > maxVis) {
			var last = list.lastElementChild;
			if (last) { last.hidden = true; }
			shown = maxVis;
		}
		if (!loop) {
			if (next >= n) { stop(); }
		}
	}

	var timer = null;
	function start(){ stop(); timer = setInterval(step, interval); }
	function stop(){ if (timer) { clearInterval(timer); timer = null; } }
<?php if ( $pause ) : ?>
	root.addEventListener('mouseenter', stop);
	root.addEventListener('mouseleave', start);
	root.addEventListener('focusin', stop);
<?php endif; ?>
	if (typeof WF !== 'undefined') {
		if (WF.onVisible) { WF.onVisible(root, start, 0.3); return; }
	}
	start();
})();
</script>
