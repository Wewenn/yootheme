<?php
defined('ABSPATH') || exit;
require_once __DIR__ . '/../../wf-motion-kit.php';
$p=wfmk_props('elastic-avatars',$props);
$uid=wf_uid('wfmk_', $props);
$wfmkEl=(isset($this) && method_exists($this,'el'))?$this->el('div'):null;
if($wfmkEl)echo $wfmkEl($props,$attrs??[]);
?>
<?php $cfg=['push'=>wfmk_n($p,'push',22,0,70),'scale'=>wfmk_n($p,'scale',1.25,1,1.8),'tooltip'=>!empty($p['show_tooltip'])];?>
<div id="<?=esc_attr($uid)?>" class="wfmk wfmk-elastic" data-wf-motion="elastic" data-wf-config="<?=wfmk_json($cfg)?>" style="<?=wfmk_vars(['size'=>wfmk_n($p,'size',86,40,160).'px','overlap'=>wfmk_n($p,'size',86,40,160)*wfmk_n($p,'overlap',35,0,70)/100 .'px','radius'=>wfmk_n($p,'radius',50,0,50).'%','border'=>wfmk_color($p['border']),'bg'=>wfmk_color($p['bg']),'ink'=>wfmk_color($p['ink']),'align'=>wfmk_choice($p['align'],['left','center','right'],'center')])?>">
 <div class="wfmk-elastic__row">
 <?php foreach($children??[] as $i=>$child):$it=wfmk_props('elastic-avatars-item',$child->props??[]);$src=wfmk_src($it['image']);?>
 <div class="wfmk-elastic__item"><button type="button" class="wfmk-elastic__avatar" aria-expanded="false" aria-controls="<?=esc_attr($uid)?>-avatar-<?=$i?>" aria-label="<?=esc_attr($it['title']?:'Avatar '.($i+1))?>"><?php if($src):?><img src="<?=$src?>" alt="" loading="lazy"><?php else:echo esc_html($it['title']?:($i+1));endif;?></button><div class="wfmk-elastic__tooltip" id="<?=esc_attr($uid)?>-avatar-<?=$i?>" hidden><strong><?=esc_html($it['title'])?></strong><span><?=esc_html($it['text'])?></span><?php if(esc_url($it['link'])):?><a href="<?=esc_url($it['link'])?>">Découvrir →</a><?php endif;?></div></div>
 <?php endforeach;?>
 </div>
</div>

<?php if($wfmkEl)echo $wfmkEl->end(); ?>
