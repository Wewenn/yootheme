<?php
/**
 * WeFrame – List Reveal | template.php v1.0
 * Titre + image à gauche, liste à droite. Hover/click change l'image + déplie contenu + CTA.
 */
defined( 'ABSPATH' ) || exit;

$eyebrow  = $props['eyebrow'] ?? '';
$title    = $props['title'] ?? '';
$subtitle = $props['subtitle'] ?? '';
$def_img  = $props['default_image'] ?? '';
$trigger  = $props['trigger'] ?? 'hover';

$bg   = $props['bg_color'] ?? '#F3F4F3';
$tc   = $props['text_color'] ?? '#0F0F0F';
$ec   = $props['eyebrow_color'] ?? '#E8382C';
$mc   = $props['muted_color'] ?? '#6B7280';
$acc  = $props['accent_color'] ?? '#E8382C';
$lc   = $props['line_color'] ?? '#D1D5DB';

$es   = (int) ( $props['eyebrow_size'] ?? 13 );
$ts   = (int) ( $props['title_size'] ?? 48 );
$ss   = (int) ( $props['subtitle_size'] ?? 16 );
$is   = (int) ( $props['item_size'] ?? 18 );

$ratio = $props['image_ratio'] ?? '4/3';
$irad  = (int) ( $props['image_radius'] ?? 0 );
$gap   = (int) ( $props['gap'] ?? 60 );
$py    = (int) ( $props['padding_y'] ?? 80 );
$px    = (int) ( $props['padding_x'] ?? 40 );
$split = (int) ( $props['split'] ?? 50 );
$dur   = (int) ( $props['swap_duration'] ?? 500 );
$zoom  = ! empty( $props['smooth_zoom'] );

// Collect items
$items = [];
if ( isset( $children ) && is_array( $children ) ) {
    foreach ( $children as $child ) {
        $p = is_object( $child ) && isset( $child->props ) ? (array) $child->props : (array) $child;
        $items[] = $p;
    }
}
if ( empty( $items ) ) return;

// Find default active index
$active_idx = 0;
foreach ( $items as $i => $it ) {
    if ( ! empty( $it['active_default'] ) ) { $active_idx = $i; break; }
}

$uid = wf_uid( 'wflr_', $props, count( $items ) );
$right = 100 - $split;
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<section id="<?= esc_attr( $uid ) ?>" class="wf-lr-wrap" style="background:<?= esc_attr( $bg ) ?>;color:<?= esc_attr( $tc ) ?>;padding:<?= $py ?>px <?= $px ?>px;">
    <div class="wf-lr-inner" style="max-width:1280px;margin:0 auto;display:grid;grid-template-columns:<?= $split ?>fr <?= $right ?>fr;gap:<?= $gap ?>px;align-items:start;">

        <!-- COLONNE GAUCHE : titres + image -->
        <div class="wf-lr-left" style="display:flex;flex-direction:column;gap:28px;">
            <?php if ( $eyebrow ) : ?>
            <div style="font-size:<?= $es ?>px;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;color:<?= esc_attr( $ec ) ?>;"><?= esc_html( $eyebrow ) ?></div>
            <?php endif; ?>
            <?php if ( $title ) : ?>
            <h2 style="margin:0;font-size:<?= $ts ?>px;line-height:1.05;font-weight:700;letter-spacing:-0.02em;color:<?= esc_attr( $tc ) ?>;"><?= esc_html( $title ) ?></h2>
            <?php endif; ?>

            <div class="wf-lr-image" style="position:relative;width:100%;aspect-ratio:<?= esc_attr( $ratio ) ?>;overflow:hidden;border-radius:<?= $irad ?>px;background:#e9eae8;margin-top:12px;">
                <?php
                $imgs = [];
                if ( $def_img ) $imgs[] = [ 'src' => $def_img, 'idx' => -1 ];
                foreach ( $items as $i => $it ) {
                    if ( ! empty( $it['image'] ) ) $imgs[] = [ 'src' => $it['image'], 'idx' => $i ];
                }
                // Render all images stacked, opacity toggle
                foreach ( $imgs as $k => $im ) :
                    $is_active = ( $def_img ? ( $active_idx === -1 ? $im['idx'] === -1 : $im['idx'] === $active_idx || ( $k === 0 && $active_idx === -1 ) ) : $im['idx'] === $active_idx );
                ?>
                <img src="<?= esc_url( $im['src'] ) ?>" alt="" data-idx="<?= (int) $im['idx'] ?>"
                    class="wf-lr-img<?= $is_active ? ' is-active' : '' ?>"
                    style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;display:block;opacity:<?= $is_active ? 1 : 0 ?>;transition:opacity <?= (int) $dur ?>ms ease, transform <?= (int) $dur ?>ms ease;<?= $zoom ? 'transform:scale(' . ( $is_active ? '1' : '1.04' ) . ');' : '' ?>"
                    loading="lazy">
                <?php endforeach; ?>
            </div>
        </div>

        <!-- COLONNE DROITE : subtitle + liste -->
        <div class="wf-lr-right" style="display:flex;flex-direction:column;gap:22px;padding-top:<?= $eyebrow ? $es + 14 : 0 ?>px;">
            <?php if ( $subtitle ) : ?>
            <p style="margin:0 0 24px;font-size:<?= $ss ?>px;line-height:1.6;color:<?= esc_attr( $mc ) ?>;max-width:520px;"><?= esc_html( $subtitle ) ?></p>
            <?php endif; ?>

            <ul class="wf-lr-list" style="list-style:none;padding:0;margin:0;border-top:1px solid <?= esc_attr( $lc ) ?>;">
            <?php foreach ( $items as $i => $it ) :
                $is_active = ( $i === $active_idx );
                $label = $it['label'] ?? '';
                $content = $it['content'] ?? '';
                $cta_t   = $it['cta_text'] ?? '';
                $cta_u   = $it['cta_url'] ?? '';
            ?>
                <li class="wf-lr-item<?= $is_active ? ' is-active' : '' ?>" data-idx="<?= $i ?>" style="border-bottom:1px solid <?= esc_attr( $lc ) ?>;">
                    <button type="button" class="wf-lr-row" aria-expanded="<?= $is_active ? 'true' : 'false' ?>"
                        style="width:100%;display:flex;align-items:center;justify-content:space-between;gap:16px;background:transparent;border:0;padding:22px 2px;cursor:pointer;text-align:left;font:inherit;color:inherit;">
                        <span class="wf-lr-label" style="font-size:<?= $is ?>px;font-weight:500;color:<?= esc_attr( $is_active ? $acc : $tc ) ?>;transition:color .25s;"><?= esc_html( $label ) ?></span>
                        <span class="wf-lr-right-slot" style="display:inline-flex;align-items:center;gap:12px;flex-shrink:0;">
                            <?php if ( $cta_t ) : ?>
                            <span class="wf-lr-cta-hint" style="font-size:14px;color:<?= esc_attr( $mc ) ?>;opacity:<?= $is_active ? '1' : '0' ?>;transition:opacity .25s;"><?= esc_html( $cta_t ) ?></span>
                            <?php endif; ?>
                            <span class="wf-lr-arrow" aria-hidden="true" style="display:inline-flex;color:<?= esc_attr( $is_active ? $acc : $mc ) ?>;transition:color .25s, transform .25s;transform:<?= $is_active ? 'translate(2px,-2px)' : 'translate(0,0)' ?>;">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="7" y1="17" x2="17" y2="7"/><polyline points="8 7 17 7 17 16"/></svg>
                            </span>
                        </span>
                    </button>

                    <?php if ( $content || ( $cta_t && $cta_u ) ) : ?>
                    <div class="wf-lr-panel" style="overflow:hidden;max-height:<?= $is_active ? '800px' : '0' ?>;transition:max-height .45s ease;">
                        <div style="padding:0 2px 22px;display:flex;flex-direction:column;gap:16px;">
                            <?php if ( $content ) : ?>
                            <div class="wf-lr-content" style="font-size:15px;line-height:1.6;color:<?= esc_attr( $mc ) ?>;max-width:520px;"><?= wp_kses_post( $content ) ?></div>
                            <?php endif; ?>
                            <?php if ( $cta_t && $cta_u ) : ?>
                            <a href="<?= esc_url( $cta_u ) ?>" class="wf-lr-cta" style="align-self:flex-start;display:inline-flex;align-items:center;gap:8px;background:<?= esc_attr( $acc ) ?>;color:#fff;padding:10px 18px;border-radius:6px;text-decoration:none;font-size:14px;font-weight:600;transition:opacity .2s;">
                                <?= esc_html( $cta_t ) ?>
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </li>
            <?php endforeach; ?>
            </ul>
        </div>
    </div>
</section>

<style>
#<?= esc_attr( $uid ) ?> .wf-lr-item.is-active .wf-lr-row { background: linear-gradient(90deg, transparent, rgba(0,0,0,0)); }
#<?= esc_attr( $uid ) ?> .wf-lr-row:hover .wf-lr-label { color:<?= esc_attr( $acc ) ?>; }
#<?= esc_attr( $uid ) ?> .wf-lr-row:hover .wf-lr-arrow { color:<?= esc_attr( $acc ) ?>; transform: translate(2px,-2px); }
#<?= esc_attr( $uid ) ?> .wf-lr-cta:hover { opacity:0.88; }
#<?= esc_attr( $uid ) ?> .wf-lr-img.is-active { opacity:1 !important; <?= $zoom ? 'transform:scale(1) !important;' : '' ?> }
@media (max-width:900px){
    #<?= esc_attr( $uid ) ?> .wf-lr-inner { grid-template-columns:1fr !important; }
    #<?= esc_attr( $uid ) ?> .wf-lr-right { padding-top:0 !important; }
    #<?= esc_attr( $uid ) ?> h2 { font-size:<?= max( 28, (int) ( $ts * 0.6 ) ) ?>px !important; }
}
</style>

<script>
(function(){
    WF.ready(function(){
        var root = document.getElementById('<?= esc_attr( $uid ) ?>');
        if (!root) return;
        var items   = Array.prototype.slice.call(root.querySelectorAll('.wf-lr-item'));
        var images  = Array.prototype.slice.call(root.querySelectorAll('.wf-lr-img'));
        var trigger = '<?= esc_js( $trigger ) ?>';
        var active  = <?= (int) $active_idx ?>;

        function hasDef(){ return images.some(function(im){ return im.getAttribute('data-idx') === '-1'; }); }
        var defaultExists = hasDef();

        function paint(i) {
            active = i;
            items.forEach(function(el, idx){
                var is = idx === i;
                el.classList.toggle('is-active', is);
                var row = el.querySelector('.wf-lr-row');
                if (row) row.setAttribute('aria-expanded', is ? 'true' : 'false');
                var panel = el.querySelector('.wf-lr-panel');
                if (panel) panel.style.maxHeight = is ? (panel.scrollHeight + 'px') : '0';
                var hint = el.querySelector('.wf-lr-cta-hint');
                if (hint) hint.style.opacity = is ? '1' : '0';
            });
            // image swap
            var found = false;
            images.forEach(function(im){
                var idx = parseInt(im.getAttribute('data-idx'), 10);
                var on  = (idx === i);
                if (on) found = true;
                im.classList.toggle('is-active', on);
                im.style.opacity = on ? '1' : '0';
            });
            if (!found && defaultExists) {
                images.forEach(function(im){
                    var idx = parseInt(im.getAttribute('data-idx'), 10);
                    var on  = (idx === -1);
                    im.classList.toggle('is-active', on);
                    im.style.opacity = on ? '1' : '0';
                });
            }
        }
        // init : force initial max-height calculation
        paint(active);

        items.forEach(function(el, idx){
            var row = el.querySelector('.wf-lr-row');
            if (!row) return;
            if (trigger === 'hover') {
                el.addEventListener('mouseenter', function(){ paint(idx); });
                row.addEventListener('focus', function(){ paint(idx); });
            }
            row.addEventListener('click', function(e){
                e.preventDefault();
                paint(idx);
            });
        });

        // Recalc open panel height on resize (in case content wraps)
        window.addEventListener('resize', function(){
            var el = items[active];
            if (!el) return;
            var panel = el.querySelector('.wf-lr-panel');
            if (panel) panel.style.maxHeight = panel.scrollHeight + 'px';
        });
    });
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
