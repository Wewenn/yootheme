<?php
/**
 * WeFrame – Page Preloader | template.php v1.0
 * Overlay plein écran au chargement, sortie animée : curtain | wipe | sweep | blinds | pixel | fade
 * Pure CSS/JS (pas de dépendance). Scroll-lock + fallback timeout de sécurité.
 */
defined( 'ABSPATH' ) || exit;

$mode      = $props['mode']         ?? 'curtain';
$axis      = $props['curtain_axis'] ?? 'vertical';
$dir       = $props['direction']    ?? 'left';
$blinds    = max( 3, min( 16, (int) ( $props['blinds_count'] ?? 7 ) ) );
$bg_style  = $props['bg_style']     ?? 'solid';
$c1        = $props['color1']       ?? '#0f1117';
$c2        = $props['color2']       ?? '#2563eb';
$gang      = (int) ( $props['grad_angle'] ?? 135 );
$ctype     = $props['content_type'] ?? 'text';
$logo      = trim( (string) ( $props['logo'] ?? '' ) );
$logo_w    = (int) ( $props['logo_width'] ?? 120 );
$text      = $props['text']         ?? '';
$tcolor    = $props['text_color']   ?? '#ffffff';
$tsize     = (int) ( $props['text_size'] ?? 40 );
$tweight   = $props['text_weight']  ?? '700';
$tspace    = (int) ( $props['text_spacing'] ?? 2 );
$spinner   = $props['spinner']      ?? 'none';
$spcolor   = $props['spinner_color'] ?? '#ffffff';
$min_ms    = max( 0, (int) ( $props['min_duration'] ?? 700 ) );
$exit_ms   = max( 300, (int) ( $props['exit_duration'] ?? 900 ) );
$ease      = $props['exit_ease']    ?? 'cubic-bezier(0.76,0,0.24,1)';
$once      = ! empty( $props['once_session'] );
$zidx      = (int) ( $props['z_index'] ?? 2147483000 );

if ( $logo && ! preg_match( '#^https?://#i', $logo ) ) { $logo = '/' . ltrim( $logo, '/' ); }

$bg      = ( 'gradient' === $bg_style ) ? 'linear-gradient(' . $gang . 'deg,' . esc_attr( $c1 ) . ',' . esc_attr( $c2 ) . ')' : esc_attr( $c1 );
$exit_s  = round( $exit_ms / 1000, 3 );
$uid     = wf_uid( 'wfpl_', $props, $mode );
$k       = str_replace( 'wfpl_', '', $uid ); // keyframe suffix

// Direction -> transform for wipe / sweep
$dir_out = 'translateX(-101%)';
if ( 'right' === $dir ) { $dir_out = 'translateX(101%)'; }
elseif ( 'up' === $dir ) { $dir_out = 'translateY(-101%)'; }
elseif ( 'down' === $dir ) { $dir_out = 'translateY(101%)'; }
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-pl" data-mode="<?= esc_attr( $mode ) ?>" role="presentation" aria-hidden="true" style="position:fixed;inset:0;z-index:<?= $zidx ?>;overflow:hidden;pointer-events:none;">

    <div class="wf-pl-panels">
    <?php if ( 'curtain' === $mode ) : ?>
        <?php if ( 'horizontal' === $axis ) : ?>
        <div class="wf-pl-p wf-pl-p--l" style="background:<?= $bg ?>;"></div>
        <div class="wf-pl-p wf-pl-p--r" style="background:<?= $bg ?>;"></div>
        <?php else : ?>
        <div class="wf-pl-p wf-pl-p--t" style="background:<?= $bg ?>;"></div>
        <div class="wf-pl-p wf-pl-p--b" style="background:<?= $bg ?>;"></div>
        <?php endif; ?>

    <?php elseif ( 'blinds' === $mode ) : ?>
        <?php for ( $i = 0; $i < $blinds; $i++ ) :
            $bt  = round( $i * ( 100 / $blinds ), 4 );
            $bh  = round( 100 / $blinds, 4 ) + 0.2;
            $bd  = round( $i * ( $exit_ms * 0.45 / $blinds ) / 1000, 4 );
        ?>
        <div class="wf-pl-bar" style="background:<?= $bg ?>;top:<?= $bt ?>%;height:<?= $bh ?>%;transition-delay:<?= $bd ?>s;"></div>
        <?php endfor; ?>

    <?php elseif ( 'pixel' === $mode ) :
        $cols = 14; $rows = 9; $spread = $exit_ms * 0.6;
    ?>
        <div class="wf-pl-grid" style="grid-template-columns:repeat(<?= $cols ?>,1fr);grid-template-rows:repeat(<?= $rows ?>,1fr);">
        <?php for ( $r = 0; $r < $rows; $r++ ) : for ( $col = 0; $col < $cols; $col++ ) :
            $base = ( ( $col + $r ) / ( $cols + $rows ) ) * $spread;
            $del  = round( ( $base + mt_rand( 0, (int) ( $spread * 0.35 ) ) ) / 1000, 4 );
        ?><div class="wf-pl-cell" style="background:<?= esc_attr( $c1 ) ?>;transition-delay:<?= $del ?>s;"></div><?php endfor; endfor; ?>
        </div>

    <?php else : // wipe | sweep | fade ?>
        <div class="wf-pl-p wf-pl-p--full" style="background:<?= $bg ?>;"></div>
    <?php endif; ?>
    </div>

    <?php if ( 'none' !== $ctype || 'none' !== $spinner ) : ?>
    <div class="wf-pl-center">
        <?php if ( 'logo' === $ctype && $logo ) : ?>
        <img class="wf-pl-logo" src="<?= esc_url( $logo ) ?>" alt="" style="width:<?= $logo_w ?>px;max-width:60vw;height:auto;">
        <?php elseif ( 'text' === $ctype && $text ) : ?>
        <div class="wf-pl-text" style="color:<?= esc_attr( $tcolor ) ?>;font-size:<?= $tsize ?>px;font-weight:<?= esc_attr( $tweight ) ?>;letter-spacing:<?= $tspace ?>px;"><?= esc_html( $text ) ?></div>
        <?php endif; ?>

        <?php if ( 'ring' === $spinner ) : ?>
        <div class="wf-pl-ring" style="border-color:<?= esc_attr( $spcolor ) ?>33;border-top-color:<?= esc_attr( $spcolor ) ?>;"></div>
        <?php elseif ( 'dots' === $spinner ) : ?>
        <div class="wf-pl-dots"><span style="background:<?= esc_attr( $spcolor ) ?>;"></span><span style="background:<?= esc_attr( $spcolor ) ?>;"></span><span style="background:<?= esc_attr( $spcolor ) ?>;"></span></div>
        <?php elseif ( 'bar' === $spinner ) : ?>
        <div class="wf-pl-barwrap"><div class="wf-pl-barfill" style="background:<?= esc_attr( $spcolor ) ?>;"></div></div>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<style>
#<?= esc_attr( $uid ) ?> .wf-pl-panels, #<?= esc_attr( $uid ) ?> .wf-pl-grid { position:absolute; inset:0; }
#<?= esc_attr( $uid ) ?> .wf-pl-grid { display:grid; }
#<?= esc_attr( $uid ) ?> .wf-pl-p, #<?= esc_attr( $uid ) ?> .wf-pl-bar, #<?= esc_attr( $uid ) ?> .wf-pl-cell {
    position:absolute; will-change:transform,opacity;
}
#<?= esc_attr( $uid ) ?> .wf-pl-cell { position:relative; }

/* Curtain vertical */
#<?= esc_attr( $uid ) ?> .wf-pl-p--t { top:0; left:0; width:100%; height:50.5%; transition:transform <?= $exit_s ?>s <?= $ease ?>; }
#<?= esc_attr( $uid ) ?> .wf-pl-p--b { bottom:0; left:0; width:100%; height:50.5%; transition:transform <?= $exit_s ?>s <?= $ease ?>; }
#<?= esc_attr( $uid ) ?>.is-out .wf-pl-p--t { transform:translateY(-101%); }
#<?= esc_attr( $uid ) ?>.is-out .wf-pl-p--b { transform:translateY(101%); }
/* Curtain horizontal */
#<?= esc_attr( $uid ) ?> .wf-pl-p--l { top:0; left:0; height:100%; width:50.5%; transition:transform <?= $exit_s ?>s <?= $ease ?>; }
#<?= esc_attr( $uid ) ?> .wf-pl-p--r { top:0; right:0; height:100%; width:50.5%; transition:transform <?= $exit_s ?>s <?= $ease ?>; }
#<?= esc_attr( $uid ) ?>.is-out .wf-pl-p--l { transform:translateX(-101%); }
#<?= esc_attr( $uid ) ?>.is-out .wf-pl-p--r { transform:translateX(101%); }

/* Wipe / Fade (full panel) */
#<?= esc_attr( $uid ) ?> .wf-pl-p--full { inset:0; width:100%; height:100%; transition:transform <?= $exit_s ?>s <?= $ease ?>, opacity <?= $exit_s ?>s <?= $ease ?>; }
<?php if ( 'wipe' === $mode ) : ?>
#<?= esc_attr( $uid ) ?>.is-out .wf-pl-p--full { transform:<?= $dir_out ?>; }
<?php elseif ( 'sweep' === $mode ) : ?>
#<?= esc_attr( $uid ) ?> .wf-pl-p--full { width:140%; left:-20%; transform:skewX(-12deg); }
#<?= esc_attr( $uid ) ?>.is-out .wf-pl-p--full { transform:<?= $dir_out ?> skewX(-12deg); }
<?php else : /* fade */ ?>
#<?= esc_attr( $uid ) ?>.is-out .wf-pl-p--full { opacity:0; }
<?php endif; ?>

/* Blinds */
#<?= esc_attr( $uid ) ?> .wf-pl-bar { left:0; width:100%; transform-origin:top center; transition:transform <?= $exit_s ?>s <?= $ease ?>; }
#<?= esc_attr( $uid ) ?>.is-out .wf-pl-bar { transform:scaleY(0); }

/* Pixel */
#<?= esc_attr( $uid ) ?> .wf-pl-cell { width:100%; height:100%; transition:opacity <?= round( $exit_ms * 0.45 / 1000, 3 ) ?>s ease; }
#<?= esc_attr( $uid ) ?>.is-out .wf-pl-cell { opacity:0; }

/* Center content */
#<?= esc_attr( $uid ) ?> .wf-pl-center {
    position:absolute; inset:0; z-index:2;
    display:flex; flex-direction:column; align-items:center; justify-content:center; gap:22px;
    transition:opacity <?= round( $exit_ms * 0.4 / 1000, 3 ) ?>s ease, transform <?= round( $exit_ms * 0.4 / 1000, 3 ) ?>s ease;
}
#<?= esc_attr( $uid ) ?>.is-out .wf-pl-center { opacity:0; transform:translateY(-8px); }
#<?= esc_attr( $uid ) ?> .wf-pl-text { line-height:1.1; }

/* Spinners */
#<?= esc_attr( $uid ) ?> .wf-pl-ring { width:38px; height:38px; border:3px solid; border-radius:50%; animation:wfplspin_<?= $k ?> .8s linear infinite; }
@keyframes wfplspin_<?= $k ?> { to { transform:rotate(360deg); } }
#<?= esc_attr( $uid ) ?> .wf-pl-dots { display:flex; gap:8px; }
#<?= esc_attr( $uid ) ?> .wf-pl-dots span { width:10px; height:10px; border-radius:50%; display:inline-block; animation:wfplbounce_<?= $k ?> 1.2s ease-in-out infinite; }
#<?= esc_attr( $uid ) ?> .wf-pl-dots span:nth-child(2) { animation-delay:.15s; }
#<?= esc_attr( $uid ) ?> .wf-pl-dots span:nth-child(3) { animation-delay:.3s; }
@keyframes wfplbounce_<?= $k ?> { 0%,80%,100% { transform:scale(.4); opacity:.4; } 40% { transform:scale(1); opacity:1; } }
#<?= esc_attr( $uid ) ?> .wf-pl-barwrap { width:160px; max-width:50vw; height:4px; border-radius:4px; background:rgba(255,255,255,.18); overflow:hidden; }
#<?= esc_attr( $uid ) ?> .wf-pl-barfill { width:40%; height:100%; border-radius:4px; animation:wfplbar_<?= $k ?> 1.1s ease-in-out infinite; }
@keyframes wfplbar_<?= $k ?> { 0% { transform:translateX(-120%); } 100% { transform:translateX(320%); } }

@media (prefers-reduced-motion: reduce) {
    #<?= esc_attr( $uid ) ?> .wf-pl-p, #<?= esc_attr( $uid ) ?> .wf-pl-bar, #<?= esc_attr( $uid ) ?> .wf-pl-cell, #<?= esc_attr( $uid ) ?> .wf-pl-center { transition:opacity .3s ease !important; }
    #<?= esc_attr( $uid ) ?>.is-out .wf-pl { opacity:0; }
}
</style>

<script>
(function(){
    var id = <?= wp_json_encode( $uid ) ?>;
    var MIN = <?= (int) $min_ms ?>;
    var EXIT = <?= (int) $exit_ms ?>;
    var ONCE = <?= $once ? 'true' : 'false' ?>;
    var SKEY = 'wf_pl_seen';
    var el = document.getElementById(id);
    if (!el) return;

    var html = document.documentElement;
    var prevOverflow = html.style.overflow;

    function unlock(){ html.style.overflow = prevOverflow || ''; }
    function lock(){ html.style.overflow = 'hidden'; }

    // Already seen this session -> hide instantly, no lock
    if (ONCE) {
        var seen = false;
        try { seen = sessionStorage.getItem(SKEY) === '1'; } catch (e) {}
        if (seen) { el.style.display = 'none'; return; }
    }

    lock();
    var start = Date.now();
    var done = false;

    function exit(){
        if (done) return;
        done = true;
        if (ONCE) { try { sessionStorage.setItem(SKEY, '1'); } catch (e) {} }
        el.classList.add('is-out');
        setTimeout(function(){ el.style.display = 'none'; unlock(); }, EXIT + 60);
    }

    function trigger(){
        var wait = MIN - (Date.now() - start);
        if (wait < 0) { wait = 0; }
        setTimeout(exit, wait);
    }

    if (document.readyState === 'complete') {
        trigger();
    } else {
        window.addEventListener('load', trigger);
    }

    // Safety net: never trap the page
    setTimeout(exit, MIN + 8000);
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
