<?php
defined('ABSPATH') || exit; // Rendered by the parent.
