<?php
/**
 * WeFrame – Split Text Reveal | template.php v6.0
 * Mots/caractères/lignes animés au scroll (IntersectionObserver + CSS transitions).
 */
defined( 'ABSPATH' ) || exit;

$text     = trim( $props['text'] ?? '' );
if ( ! $text ) return;

$reveal   = $props['reveal_by']       ?? 'word';
/**
 * L'effet se lisait dans $props['animation'], une cle deja prise par le champ
 * « Animation » natif de YOOtheme : aucune des variantes n'etait donc
 * atteignable depuis le panneau. On lit maintenant un champ dedie, en gardant
 * l'ancienne cle en secours pour les pages deja en ligne.
 */
$anim     = $props['effect'] ?? ( $props['animation'] ?? 'slide-up' );
if ( ! in_array( $anim, array( 'slide-up', 'slide-down', 'fade', 'scale', 'blur', 'roll' ), true ) ) {
	$anim = 'slide-up';
}
$staggerFrom = (string) ( $props['stagger_from'] ?? 'start' );
if ( ! in_array( $staggerFrom, array( 'start', 'center', 'end' ), true ) ) { $staggerFrom = 'start'; }
$stagger  = (int) ( $props['stagger'] ?? 60 );
$dur      = (int) ( $props['duration'] ?? 600 );
$delay    = (int) ( $props['delay']    ?? 0 );
$ease     = $props['easing']          ?? 'cubic-bezier(.22,1,.36,1)';
$fs       = (int) ( $props['font_size']        ?? 48 );
$fsm      = (int) ( $props['font_size_mobile'] ?? 28 );
$fw       = $props['font_weight']     ?? '700';
$lh       = (int) ( $props['line_height']      ?? 115 );
$ls       = (float) ( $props['letter_spacing'] ?? -1 );
$tc       = $props['text_color']      ?? '#111111';
$ta       = $props['text_align']      ?? 'center';
$mw       = (int) ( $props['max_width']  ?? 0 );
$ff       = trim( $props['font_family']  ?? '' );

$uid = 'wfstr_' . substr( md5( $text . serialize( $props ) ), 0, 8 );

// ── Build tokens ────────────────────────────────────────────────
$tokens = '';

if ( $reveal === 'line' ) {
    $lines = array_values( array_filter( array_map( 'trim', explode( "\n", $text ) ) ) );
    foreach ( $lines as $li => $line ) {
        $tokens .= '<span class="wf-str-wrap" style="display:block;overflow:hidden;">'
            . '<span class="wf-str-t" data-i="' . $li . '">' . esc_html( $line ) . '</span>'
            . '</span>';
    }
} elseif ( $reveal === 'char' ) {
    $i = 0;
    $words = preg_split( '/\s+/', $text );
    foreach ( $words as $wi => $word ) {
        if ( $wi > 0 ) {
            $tokens .= '<span class="wf-str-sp"> </span>';
        }
        foreach ( mb_str_split( $word ) as $ch ) {
            $tokens .= '<span class="wf-str-wrap" style="display:inline-block;overflow:hidden;vertical-align:top;">'
                . '<span class="wf-str-t" data-i="' . $i . '">' . esc_html( $ch ) . '</span>'
                . '</span>';
            $i++;
        }
    }
} else {
    // word
    $words = preg_split( '/\s+/', $text );
    foreach ( $words as $wi => $word ) {
        if ( $wi > 0 ) {
            $tokens .= '<span class="wf-str-sp"> </span>';
        }
        $tokens .= '<span class="wf-str-wrap" style="display:inline-block;overflow:hidden;vertical-align:top;">'
            . '<span class="wf-str-t" data-i="' . $wi . '">' . esc_html( $word ) . '</span>'
            . '</span>';
    }
}

// ── Initial CSS transform ────────────────────────────────────────
$from_transform = 'translateY(100%)';
$from_opacity   = '0';
$from_filter    = '';

switch ( $anim ) {
    case 'slide-down':
        $from_transform = 'translateY(-100%)';
        $from_opacity   = '0';
        break;
    case 'fade':
        $from_transform = 'none';
        $from_opacity   = '0';
        break;
    case 'scale':
        $from_transform = 'scale(.6)';
        $from_opacity   = '0';
        break;
    case 'blur':
        $from_transform = 'translateY(40%)';
        $from_opacity   = '0';
        $from_filter    = 'blur(12px)';
        break;
    case 'roll':
        // La lettre bascule vers l'avant depuis le bas, comme sur un rouleau.
        $from_transform = 'translateY(85%) rotateX(-80deg)';
        $from_opacity   = '0';
        break;
    default: // slide-up
        $from_transform = 'translateY(100%)';
        $from_opacity   = '0';
}

$ff_css = $ff ? "font-family:{$ff};" : '';
$mw_css = $mw > 0 ? "max-width:{$mw}px;margin-left:auto;margin-right:auto;" : '';

$cfg = json_encode( [
    'uid'     => $uid,
    'stagger' => $stagger,
    'dur'     => $dur,
    'delay'   => $delay,
    'ease'    => $ease,
    'from'    => $staggerFrom,
], JSON_HEX_AMP | JSON_HEX_APOS );
?>
<?php $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( 'div' ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-split-text-reveal" style="text-align:<?= esc_attr( $ta ) ?>;<?= $mw_css ?>" aria-label="<?= esc_attr( $text ) ?>">
    <div class="wf-str-inner" style="font-size:<?= $fs ?>px;font-weight:<?= esc_attr( $fw ) ?>;line-height:<?= $lh ?>%;letter-spacing:<?= $ls ?>px;color:<?= esc_attr( $tc ) ?>;<?= $ff_css ?>word-break:keep-all;">
        <?= $tokens ?>
    </div>
</div>

<style>
#<?= esc_attr( $uid ) ?> .wf-str-inner{<?php if ( 'roll' === $anim ) : ?>perspective:600px;<?php endif; ?>}
#<?= esc_attr( $uid ) ?> .wf-str-t {
    display: inline-block;<?php if ( 'roll' === $anim ) : ?>transform-origin:center bottom;<?php endif; ?>
    transform: <?= $from_transform ?>;
    opacity: <?= $from_opacity ?>;
    <?php if ( $from_filter ) : ?>filter: <?= $from_filter ?>; -webkit-filter: <?= $from_filter ?>;<?php endif; ?>
    will-change: transform, opacity;
    vertical-align: top;
}
#<?= esc_attr( $uid ) ?>.wf-str-done .wf-str-t {
    transform: none !important;
    opacity: 1 !important;
    filter: none !important;
    -webkit-filter: none !important;
}
@media(max-width:767px){
    #<?= esc_attr( $uid ) ?> .wf-str-inner { font-size:<?= $fsm ?>px !important; }
}
</style>

<script>
(function(){
    function boot(){
        
        var c = <?= $cfg ?>;
        var el = document.getElementById(c.uid);
        if (!el) return;
        var tokens = el.querySelectorAll('.wf-str-t');
        if (!tokens.length) return;

        function animate() {
            tokens.forEach(function(t, i) {
                // Le rang decide du retard : depuis le debut, le centre, ou la fin.
                var n = tokens.length;
                var rank = parseInt(t.getAttribute('data-i') || i, 10);
                if (c.from === 'center') { rank = Math.abs(i - (n - 1) / 2); }
                if (c.from === 'end') { rank = n - 1 - i; }
                var d = c.delay + Math.round(rank * c.stagger);
                t.style.transition = 'transform ' + c.dur + 'ms ' + c.ease + ' ' + d + 'ms, '
                    + 'opacity ' + c.dur + 'ms ease ' + d + 'ms, '
                    + 'filter ' + c.dur + 'ms ease ' + d + 'ms';
                t.style.transform = 'none';
                t.style.opacity   = '1';
                t.style.filter    = 'none';
                t.style.webkitFilter = 'none';
            });
            // Mark as done after all transitions finish
            var maxDelay = c.delay + tokens.length * c.stagger + c.dur;
            setTimeout(function(){ el.classList.add('wf-str-done'); }, maxDelay + 50);
        }

        WF.onVisible(el, function() { animate(); });
    }
    WF.ready(boot);
})();
</script>

<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
