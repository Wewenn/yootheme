<?php
defined('ABSPATH') || exit;
$imgs_raw = trim($props['images']??'');
$images = array_values(array_filter(array_map('trim', explode("\n", $imgs_raw))));
if (empty($images)) return;
foreach ($images as &$img) { if (!preg_match('#^https?://#i', $img)) $img = '/'.ltrim($img, '/'); } unset($img);
$sh = $props['section_height']??'80vh'; $sbg = $props['section_bg']??'#0f1117';
$iw = (int)($props['image_width']??280); $iwm = (int)($props['image_width_mobile']??180);
$ir = (int)($props['image_radius']??12);
$fd = (int)($props['fade_duration']??800); $vd = (int)($props['visible_duration']??2000);
$mx = max(2,(int)($props['max_visible']??5));
$title = $props['title']??''; $ts = (int)($props['title_size']??64); $tsm = (int)($props['title_size_mobile']??32);
$tw = $props['title_weight']??'700'; $tc = $props['title_color']??'#ffffff';
$sub = $props['subtitle']??''; $ss = (int)($props['subtitle_size']??18); $sc = $props['subtitle_color']??'#888888';
$uid = 'wfcg_'.substr(md5(serialize($props)),0,8);
$cfg = json_encode(['uid'=>$uid,'images'=>$images,'iw'=>$iw,'ir'=>$ir,'fd'=>$fd,'vd'=>$vd,'mx'=>$mx], JSON_HEX_AMP|JSON_HEX_APOS);
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr($uid) ?>" class="wf-cursor-gallery" style="position:relative;height:<?= esc_attr($sh) ?>;background:<?= esc_attr($sbg) ?>;overflow:hidden;cursor:crosshair;display:flex;align-items:center;justify-content:center;">
    <div class="wf-cg-images" style="position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:1;"></div>
    <div style="position:relative;z-index:2;text-align:center;pointer-events:none;padding:0 24px;">
        <?php if ($title) : ?><div class="wf-cg-title" style="font-size:<?= $ts ?>px;font-weight:<?= esc_attr($tw) ?>;color:<?= esc_attr($tc) ?>;line-height:1.1;margin-bottom:12px;"><?= esc_html($title) ?></div><?php endif; ?>
        <?php if ($sub) : ?><div style="font-size:<?= $ss ?>px;color:<?= esc_attr($sc) ?>;line-height:1.5;"><?= esc_html($sub) ?></div><?php endif; ?>
    </div>
</div>
<style>
#<?= esc_attr($uid) ?> .wf-cg-img{position:absolute;width:<?= $iw ?>px;border-radius:<?= $ir ?>px;box-shadow:0 8px 32px rgba(0,0,0,.4);opacity:0;transition:opacity <?= $fd ?>ms ease,transform <?= $fd ?>ms ease;pointer-events:none;transform:translate(-50%,-50%) scale(.85);height:auto}
#<?= esc_attr($uid) ?> .wf-cg-img.wf-cg--show{opacity:1;transform:translate(-50%,-50%) scale(1)}
@media(max-width:767px){#<?= esc_attr($uid) ?> .wf-cg-img{width:<?= $iwm ?>px !important}#<?= esc_attr($uid) ?> .wf-cg-title{font-size:<?= $tsm ?>px !important}}
</style>
<script>
(function(){
    function boot(){
        
        var c = <?= $cfg ?>;
        var el=document.getElementById(c.uid);if(!el)return;
        var container=el.querySelector('.wf-cg-images');if(!container)return;
        var idx=0;var pool=[];var lastX=0;var lastY=0;var minDist=80;
        function spawn(x,y){
            var img=document.createElement('img');
            img.className='wf-cg-img';img.src=c.images[idx%c.images.length];img.draggable=false;idx++;
            var rot=(Math.random()-0.5)*16;
            img.style.left=x+'px';img.style.top=y+'px';
            container.appendChild(img);pool.push(img);
            requestAnimationFrame(function(){img.classList.add('wf-cg--show')});
            setTimeout(function(){
                img.classList.remove('wf-cg--show');
                setTimeout(function(){if(img.parentNode)img.parentNode.removeChild(img);var pi=pool.indexOf(img);if(pi>-1)pool.splice(pi,1)},c.fd);
            },c.vd);
            while(pool.length>c.mx){
                var old=pool.shift();old.classList.remove('wf-cg--show');
                setTimeout(function(o){return function(){if(o.parentNode)o.parentNode.removeChild(o)}}(old),c.fd);
            }
        }
        el.addEventListener('mousemove',function(e){
            var rect=el.getBoundingClientRect();
            var x=e.clientX-rect.left;var y=e.clientY-rect.top;
            var dx=x-lastX;var dy=y-lastY;
            if(Math.sqrt(dx*dx+dy*dy)<minDist)return;
            lastX=x;lastY=y;spawn(x,y);
        });
        el.addEventListener('touchmove',function(e){
            var t=e.touches[0];if(!t)return;
            var rect=el.getBoundingClientRect();
            var x=t.clientX-rect.left;var y=t.clientY-rect.top;
            var dx=x-lastX;var dy=y-lastY;
            if(Math.sqrt(dx*dx+dy*dy)<minDist)return;
            lastX=x;lastY=y;spawn(x,y);
        },{passive:true});
    }
    WF.ready(boot)
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
