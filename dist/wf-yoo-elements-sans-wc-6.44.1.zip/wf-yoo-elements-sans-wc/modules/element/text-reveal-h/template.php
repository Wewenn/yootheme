<?php
/**
 * WeFrame – Révélation horizontale | template.php v1.0
 *
 * La section reste figée pendant que le texte traverse l'écran de droite à
 * gauche. Chaque mot s'allume et se redresse en passant au centre, puis
 * s'éteint. Le défilement de la page pilote tout : rien n'est en boucle.
 *
 * Le texte est écrit une fois en clair pour les lecteurs d'écran ; la ligne
 * découpée en mots est marquée aria-hidden, sinon le texte serait lu mot par
 * mot comme autant de fragments.
 *
 * Pas de "&&" ni de "||" dans le JS inline (règle interne du plugin).
 */

defined( 'ABSPATH' ) || exit;

$text = trim( wp_strip_all_tags( (string) ( $props['text'] ?? '' ) ) );
$text = preg_replace( '/\s+/u', ' ', $text );
if ( '' === $text ) { return; }

$words = explode( ' ', $text );

$dwell   = max( 150, min( 600, (int) ( $props['dwell_vh'] ?? 300 ) ) );
$fs      = max( 20, min( 160, (int) ( $props['font_size'] ?? 64 ) ) );
$fsm     = max( 14, min( 80, (int) ( $props['font_size_mobile'] ?? 30 ) ) );
$fw      = (string) ( $props['font_weight'] ?? '700' );
$gap     = max( 4, min( 60, (int) ( $props['gap'] ?? 18 ) ) );
$col     = (string) ( $props['text_color'] ?? '#111111' );
$dimCol  = trim( (string) ( $props['dim_color'] ?? '' ) );
if ( '' === $dimCol ) { $dimCol = $col; }
$dimOp   = max( 0, min( 80, (int) ( $props['dim_opacity'] ?? 15 ) ) ) / 100;
$skew    = max( 0, min( 25, (int) ( $props['skew'] ?? 8 ) ) );
$focus   = max( 10, min( 100, (int) ( $props['focus_width'] ?? 35 ) ) ) / 100;
$bg      = trim( (string) ( $props['bg_color'] ?? '' ) );

$uid = wf_uid( 'wftrh_', $props );

$cfg = wp_json_encode(
	array(
		'uid'   => $uid,
		'dim'   => $dimOp,
		'skew'  => $skew,
		'focus' => $focus,
	),
	JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE
);
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-trh">
	<p class="wf-trh__sr"><?= esc_html( $text ) ?></p>
	<div class="wf-trh__stick">
		<div class="wf-trh__line" aria-hidden="true">
		<?php foreach ( $words as $w ) : ?>
			<span class="wf-trh__w"><?= esc_html( $w ) ?></span>
		<?php endforeach; ?>
		</div>
	</div>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?>{height:<?= (int) $dwell ?>vh;}
#<?= esc_attr( $uid ) ?> .wf-trh__sr{
	position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;
	clip-path:inset(50%);white-space:nowrap;border:0;
}
#<?= esc_attr( $uid ) ?> .wf-trh__stick{
	position:sticky;top:0;height:100vh;height:100svh;
	display:flex;align-items:center;overflow:hidden;
	<?php if ( '' !== $bg ) : ?>background:<?= esc_attr( $bg ) ?>;<?php endif; ?>
}
#<?= esc_attr( $uid ) ?> .wf-trh__line{
	display:flex;flex-wrap:nowrap;align-items:baseline;gap:<?= (int) $gap ?>px;
	white-space:nowrap;will-change:transform;
	font-size:<?= (int) $fs ?>px;font-weight:<?= esc_attr( $fw ) ?>;line-height:1.1;
	padding:0 50vw;
}
#<?= esc_attr( $uid ) ?> .wf-trh__w{
	display:inline-block;color:<?= esc_attr( $dimCol ) ?>;opacity:<?= esc_attr( $dimOp ) ?>;
	transform-origin:center bottom;
}
#<?= esc_attr( $uid ) ?> .wf-trh__w.is-lit{color:<?= esc_attr( $col ) ?>;}
@media (max-width:767px){
	#<?= esc_attr( $uid ) ?> .wf-trh__line{font-size:<?= (int) $fsm ?>px;}
}
/* Sans mouvement : le texte redevient un paragraphe ordinaire, lisible d'un bloc. */
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?>{height:auto;}
	#<?= esc_attr( $uid ) ?> .wf-trh__stick{position:static;height:auto;padding:8vh 0;}
	#<?= esc_attr( $uid ) ?> .wf-trh__line{flex-wrap:wrap;white-space:normal;padding:0;transform:none!important;}
	#<?= esc_attr( $uid ) ?> .wf-trh__w{opacity:1;color:<?= esc_attr( $col ) ?>;transform:none!important;}
}
</style>
<script>
(function(){
	function boot(){
		var c = <?= $cfg ?>;
		var root = document.getElementById(c.uid);
		if(!root){return;}
		if(root.getAttribute('data-wf-ready')){return;}
		root.setAttribute('data-wf-ready','1');

		var reduced = false;
		if(typeof matchMedia === 'function'){
			reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
		}
		if(reduced){return;}

		var stick = root.querySelector('.wf-trh__stick');
		var line  = root.querySelector('.wf-trh__line');
		if(!line){return;}
		var words = Array.prototype.slice.call(line.querySelectorAll('.wf-trh__w'));
		var ticking = false;
		var travel = 0;

		function measure(){
			// Les marges laterales valent la moitie de la zone visible : le premier
			// mot demarre donc au centre et le dernier s'y arrete. En 50vw fixes,
			// un element pose dans une colonne etroite decalait toute la course.
			var half = Math.round(stick.clientWidth / 2);
			// On retranche la demi-largeur du mot concerne : sans ca, c'est son
			// bord qui s'arrete au centre, pas le mot lui-meme.
			line.style.paddingLeft = '0px';
			line.style.paddingRight = '0px';
			var firstW = words.length ? words[0].offsetWidth : 0;
			var lastW = words.length ? words[words.length - 1].offsetWidth : 0;
			line.style.paddingLeft = Math.max(0, half - firstW / 2) + 'px';
			line.style.paddingRight = Math.max(0, half - lastW / 2) + 'px';
			travel = line.scrollWidth - stick.clientWidth;
			if(travel < 0){ travel = 0; }
		}

		function paint(){
			ticking = false;
			var r = root.getBoundingClientRect();
			var vh = window.innerHeight;
			if(!vh){ vh = document.documentElement.clientHeight; }
			var span = r.height - vh;
			var p = span > 0 ? (-r.top / span) : 0;
			if(p < 0){ p = 0; }
			if(p > 1){ p = 1; }

			line.style.transform = 'translateX(' + (-p * travel) + 'px)';

			// Chaque mot s'allume selon sa distance au centre de l'ecran.
			// getBoundingClientRect() donne des coordonnees de fenetre : le
			// centre doit etre pris dans le meme repere, pas en largeur seule.
			var sr = stick.getBoundingClientRect();
			var mid = sr.left + sr.width / 2;
			var reach = sr.width * c.focus / 2;
			if(reach < 1){ reach = 1; }
			var i = 0;
			while(i < words.length){
				var w = words[i];
				var wr = w.getBoundingClientRect();
				var d = Math.abs((wr.left + wr.width / 2) - mid);
				var t = 1 - d / reach;
				if(t < 0){ t = 0; }
				if(t > 1){ t = 1; }
				w.style.opacity = (c.dim + (1 - c.dim) * t).toFixed(3);
				if(c.skew > 0){
					w.style.transform = 'skewX(' + ((1 - t) * c.skew).toFixed(2) + 'deg)';
				}
				if(t > 0.55){ w.classList.add('is-lit'); }
				else { w.classList.remove('is-lit'); }
				i++;
			}
		}

		function onScroll(){
			if(ticking){return;}
			ticking = true;
			if(document.hidden){ paint(); return; }
			window.requestAnimationFrame(paint);
		}

		measure();
		paint();
		window.addEventListener('scroll', onScroll, {passive:true});
		window.addEventListener('resize', function(){ measure(); onScroll(); }, {passive:true});
		// Les polices arrivent souvent apres : la largeur change, il faut remesurer.
		if(document.fonts){
			if(document.fonts.ready){
				document.fonts.ready.then(function(){ measure(); paint(); });
			}
		}
	}
	if(document.readyState === 'loading'){
		document.addEventListener('DOMContentLoaded', boot);
	}else{
		boot();
	}
}());
</script>
