<?php
/**
 * WeFrame – Carte lumineuse | template.php v1.0
 * Cinq effets de lumiere sur une carte a contenu libre : faisceau qui parcourt
 * la bordure, bordure scintillante, halo qui suit la souris, reflet au survol,
 * neon. Quatre sur cinq sont en CSS pur ; seul le halo a besoin de la position
 * du curseur.
 * Pas de "&&" ni de "||" dans le JS inline (regle interne du plugin).
 */
defined( 'ABSPATH' ) || exit;

$fx = (string) ( $props['effect'] ?? 'beam' );
if ( ! in_array( $fx, array( 'beam', 'shine', 'spotlight', 'glare', 'neon', 'electric', 'mirror' ), true ) ) { $fx = 'beam'; }

$beamSz = max( 5, min( 80, (int) ( $props['beam_size'] ?? 30 ) ) );
$speed  = max( 1, (int) ( $props['speed'] ?? 6 ) );
$bw     = max( 1, min( 6, (int) ( $props['border_width'] ?? 1 ) ) );
$spot   = max( 80, (int) ( $props['spot_size'] ?? 320 ) );
$glow   = max( 0, min( 100, (int) ( $props['glow'] ?? 45 ) ) );
$always = ! empty( $props['always_on'] );
$tilt   = max( 0, min( 14, (int) ( $props['tilt'] ?? 6 ) ) );
$jitter = max( 0, min( 20, (int) ( $props['jitter'] ?? 8 ) ) );

$cBg  = (string) ( $props['card_bg'] ?? '#0e0e13' );
$cCol = (string) ( $props['card_color'] ?? '#ffffff' );
$bCol = (string) ( $props['border_color'] ?? '#2a2a35' );
$c1   = (string) ( $props['color_1'] ?? '#EA5C1C' );
$c2   = (string) ( $props['color_2'] ?? '#7C3AED' );

$rad  = max( 0, (int) ( $props['radius'] ?? 18 ) );
$pad  = max( 0, (int) ( $props['padding'] ?? 32 ) );
$minH = max( 0, (int) ( $props['min_height'] ?? 0 ) );

$inner = '';
if ( ! empty( $children ) ) {
	foreach ( $children as $ci => $child ) {
		$inner .= $builder->render( $child, array( 'element' => $props, 'index' => $ci ) );
	}
}
if ( '' === trim( $inner ) ) { return; }

$uid = wf_uid( 'wfgc_', $props );
$cls = 'wf-gc wf-gc--' . $fx;
if ( $always ) { $cls .= ' is-on'; }
$needJs = ( ( 'spotlight' === $fx ) || ( 'mirror' === $fx ) ) && ! $always;
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<?php if ( 'electric' === $fx && $jitter > 0 ) : ?>
<svg class="wf-gc__flt" width="0" height="0" aria-hidden="true" focusable="false" style="position:absolute">
	<filter id="<?= esc_attr( $uid ) ?>-e" x="-30%" y="-30%" width="160%" height="160%">
		<feTurbulence type="turbulence" baseFrequency="0.02 0.09" numOctaves="2" seed="7" result="n"/>
		<feDisplacementMap in="SourceGraphic" in2="n" scale="<?= (int) $jitter ?>" xChannelSelector="R" yChannelSelector="G"/>
	</filter>
</svg>
<?php endif; ?>
<div id="<?= esc_attr( $uid ) ?>" class="<?= esc_attr( $cls ) ?>">
	<span class="__fx" aria-hidden="true"></span>
	<div class="__inner"><?= $inner ?></div>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?>{
	position:relative;isolation:isolate;
	border-radius:<?= (int) $rad ?>px;
	background:<?= esc_attr( $cBg ) ?>;color:<?= esc_attr( $cCol ) ?>;
	border:<?= (int) $bw ?>px solid <?= esc_attr( $bCol ) ?>;
	<?= $minH > 0 ? 'min-height:' . (int) $minH . 'px;' : '' ?>
	overflow:hidden;
}
#<?= esc_attr( $uid ) ?> .__inner{position:relative;z-index:2;padding:<?= (int) $pad ?>px;}
#<?= esc_attr( $uid ) ?> .__fx{position:absolute;z-index:1;pointer-events:none;display:block;}

<?php if ( 'beam' === $fx ) : ?>
/* Faisceau : un degre conique tourne derriere la carte, un fond opaque la recouvre
   sauf sur l'epaisseur de bordure. */
#<?= esc_attr( $uid ) ?>{border-color:transparent;background:<?= esc_attr( $cBg ) ?>;}
#<?= esc_attr( $uid ) ?> .__fx{
	inset:-150%;
	background:conic-gradient(from 0deg,transparent 0 <?= (int) ( 100 - $beamSz ) ?>%,<?= esc_attr( $c2 ) ?> <?= (int) ( 100 - $beamSz / 2 ) ?>%,<?= esc_attr( $c1 ) ?> 97%,transparent 100%);
	animation:<?= esc_attr( $uid ) ?>-turn <?= (int) $speed ?>s linear infinite;
}
#<?= esc_attr( $uid ) ?>::before{
	content:"";position:absolute;inset:<?= (int) $bw ?>px;z-index:1;
	border-radius:<?= (int) max( 0, $rad - $bw ) ?>px;background:<?= esc_attr( $cBg ) ?>;
}
#<?= esc_attr( $uid ) ?>::after{
	content:"";position:absolute;inset:0;z-index:0;border-radius:<?= (int) $rad ?>px;
	box-shadow:0 0 <?= (int) round( $glow * .8 ) ?>px <?= esc_attr( $c1 ) ?>;
	opacity:<?= esc_attr( round( $glow / 160, 2 ) ) ?>;
}
@keyframes <?= esc_attr( $uid ) ?>-turn{to{transform:rotate(1turn)}}

<?php elseif ( 'shine' === $fx ) : ?>
/* Bordure scintillante : un degre lineaire glisse le long du contour. */
#<?= esc_attr( $uid ) ?>{border-color:transparent;}
#<?= esc_attr( $uid ) ?> .__fx{
	inset:0;border-radius:<?= (int) $rad ?>px;padding:<?= (int) $bw ?>px;
	background:linear-gradient(90deg,transparent,<?= esc_attr( $c1 ) ?>,<?= esc_attr( $c2 ) ?>,transparent);
	background-size:<?= (int) ( 400 - $beamSz * 3 ) ?>% 100%;
	-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);
	mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);
	-webkit-mask-composite:xor;mask-composite:exclude;
	animation:<?= esc_attr( $uid ) ?>-slide <?= (int) $speed ?>s linear infinite;
}
@keyframes <?= esc_attr( $uid ) ?>-slide{
	from{background-position:0% 0}
	to{background-position:<?= (int) ( 400 - $beamSz * 3 ) ?>% 0}
}

<?php elseif ( 'spotlight' === $fx ) : ?>
/* Halo : un cercle degrade centre sur --mx/--my, ecrit par le script. */
#<?= esc_attr( $uid ) ?>{--mx:50%;--my:0%;}
#<?= esc_attr( $uid ) ?> .__fx{
	inset:0;border-radius:<?= (int) $rad ?>px;
	background:radial-gradient(<?= (int) $spot ?>px circle at var(--mx) var(--my),<?= esc_attr( $c1 ) ?>,transparent 65%);
	opacity:0;transition:opacity .35s ease;
}
#<?= esc_attr( $uid ) ?>:hover .__fx,#<?= esc_attr( $uid ) ?>:focus-within .__fx,#<?= esc_attr( $uid ) ?>.is-on .__fx{
	opacity:<?= esc_attr( round( $glow / 100, 2 ) ) ?>;
}

<?php elseif ( 'electric' === $fx ) : ?>
/* Bordure electrique : un anneau degrade tourne, deforme par un bruit fige.
   La deformation ne bouge pas — c'est la lumiere qui court dessous — donc
   « animation reduite » suffit a tout arreter, sans SMIL a piloter. */
#<?= esc_attr( $uid ) ?>{border-color:transparent;}
#<?= esc_attr( $uid ) ?> .__fx{
	inset:0;border-radius:<?= (int) $rad ?>px;padding:<?= (int) max( 2, $bw ) ?>px;
	background:conic-gradient(from 0deg,<?= esc_attr( $c1 ) ?>,<?= esc_attr( $c2 ) ?>,<?= esc_attr( $c1 ) ?> 60%,transparent 78%,<?= esc_attr( $c1 ) ?>);
	-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);
	mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);
	-webkit-mask-composite:xor;mask-composite:exclude;
	<?php if ( $jitter > 0 ) : ?>filter:url(#<?= esc_attr( $uid ) ?>-e);<?php endif; ?>
	animation:<?= esc_attr( $uid ) ?>-turn <?= (int) $speed ?>s linear infinite;
}
#<?= esc_attr( $uid ) ?>::after{
	content:"";position:absolute;inset:0;z-index:0;border-radius:<?= (int) $rad ?>px;
	box-shadow:0 0 <?= (int) round( $glow * .7 ) ?>px <?= esc_attr( $c1 ) ?>;
	opacity:<?= esc_attr( round( $glow / 200, 2 ) ) ?>;
}
@keyframes <?= esc_attr( $uid ) ?>-turn{to{transform:rotate(1turn)}}

<?php elseif ( 'mirror' === $fx ) : ?>
/* Miroir : un reflet speculaire suit le pointeur et la carte se releve un peu.
   Deux couches : la tache large qui donne le verre, la bande oblique qui donne
   le poli. */
#<?= esc_attr( $uid ) ?>{
	--mx:50%;--my:50%;--rx:0deg;--ry:0deg;
	transform:perspective(900px) rotateX(var(--rx)) rotateY(var(--ry));
	transform-style:preserve-3d;transition:transform .25s ease-out;
}
#<?= esc_attr( $uid ) ?> .__fx{
	inset:0;border-radius:<?= (int) $rad ?>px;
	background:
		radial-gradient(<?= (int) $spot ?>px circle at var(--mx) var(--my),<?= esc_attr( $c1 ) ?>,transparent 60%),
		linear-gradient(115deg,transparent 34%,<?= esc_attr( $c2 ) ?> 47%,transparent 62%);
	opacity:0;transition:opacity .3s ease;
	mix-blend-mode:screen;
}
#<?= esc_attr( $uid ) ?>:hover .__fx,#<?= esc_attr( $uid ) ?>:focus-within .__fx,#<?= esc_attr( $uid ) ?>.is-on .__fx{
	opacity:<?= esc_attr( round( $glow / 130, 2 ) ) ?>;
}
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?>{transform:none;}
}

<?php elseif ( 'glare' === $fx ) : ?>
/* Reflet : une bande claire traverse la carte au survol. */
#<?= esc_attr( $uid ) ?> .__fx{
	top:0;bottom:0;left:-60%;width:45%;
	background:linear-gradient(105deg,transparent,<?= esc_attr( $c1 ) ?>,transparent);
	opacity:<?= esc_attr( round( $glow / 140, 2 ) ) ?>;
	transform:skewX(-16deg);
	transition:left .75s cubic-bezier(.2,.8,.2,1);
}
#<?= esc_attr( $uid ) ?>:hover .__fx,#<?= esc_attr( $uid ) ?>:focus-within .__fx,#<?= esc_attr( $uid ) ?>.is-on .__fx{left:120%;}

<?php else : ?>
/* Neon : bordure coloree et lueur au-dehors, qui respire. */
#<?= esc_attr( $uid ) ?>{
	border-color:<?= esc_attr( $c1 ) ?>;
	box-shadow:0 0 <?= (int) round( $glow * .5 ) ?>px <?= esc_attr( $c1 ) ?>,
		inset 0 0 <?= (int) round( $glow * .35 ) ?>px <?= esc_attr( $c2 ) ?>66;
	animation:<?= esc_attr( $uid ) ?>-breathe <?= (int) $speed ?>s ease-in-out infinite alternate;
}
#<?= esc_attr( $uid ) ?> .__fx{
	inset:0;border-radius:<?= (int) $rad ?>px;
	background:linear-gradient(135deg,<?= esc_attr( $c1 ) ?>22,transparent 55%,<?= esc_attr( $c2 ) ?>22);
}
@keyframes <?= esc_attr( $uid ) ?>-breathe{
	from{box-shadow:0 0 <?= (int) round( $glow * .3 ) ?>px <?= esc_attr( $c1 ) ?>,inset 0 0 <?= (int) round( $glow * .2 ) ?>px <?= esc_attr( $c2 ) ?>44;}
	to{box-shadow:0 0 <?= (int) round( $glow * .9 ) ?>px <?= esc_attr( $c1 ) ?>,inset 0 0 <?= (int) round( $glow * .5 ) ?>px <?= esc_attr( $c2 ) ?>88;}
}
<?php endif; ?>

@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?>,#<?= esc_attr( $uid ) ?> .__fx{animation:none !important;transition-duration:.001ms;}
}
</style>

<?php if ( $needJs ) : ?>
<script>
(function(){
	var el = document.getElementById('<?= esc_js( $uid ) ?>');
	if (!el) { return; }
	// Sans vrai pointeur, le halo n'a rien a suivre : on l'allume au centre.
	if (window.matchMedia) {
		if (!window.matchMedia('(hover: hover)').matches) {
			el.classList.add('is-on');
			return;
		}
	}
	var tilt = <?= (int) $tilt ?>;
	var mirror = <?= 'mirror' === $fx ? 'true' : 'false' ?>;
	el.addEventListener('pointermove', function(e){
		var r = el.getBoundingClientRect();
		var x = e.clientX - r.left;
		var y = e.clientY - r.top;
		el.style.setProperty('--mx', x + 'px');
		el.style.setProperty('--my', y + 'px');
		if (!mirror) { return; }
		if (tilt < 1) { return; }
		// Le releve suit le pointeur : haut de carte survole = elle se penche vers nous.
		el.style.setProperty('--ry', (((x / r.width) - 0.5) * 2 * tilt).toFixed(2) + 'deg');
		el.style.setProperty('--rx', (((0.5 - (y / r.height)) * 2 * tilt)).toFixed(2) + 'deg');
	});
	el.addEventListener('pointerleave', function(){
		el.style.setProperty('--rx', '0deg');
		el.style.setProperty('--ry', '0deg');
	});
})();
</script>
<?php endif; ?>
