<?php
/**
 * WeFrame – Transition de page | template.php v1.0
 * Voile plein écran qui se retire au chargement de la page (une fois), puis se supprime.
 */
defined( 'ABSPATH' ) || exit;

$style = $props['style'] ?? 'curtain';
if ( ! in_array( $style, array( 'curtain', 'wipe', 'fade', 'split' ), true ) ) { $style = 'curtain'; }
$col   = $props['color'] ?? '#111111';
$speed = max( 200, (int) ( $props['speed'] ?? 900 ) );
$logo  = (string) ( $props['logo'] ?? '' );

$uid   = wf_uid( 'wfpt_', $props, $style );
$dur   = $speed / 1000;
$logotag = '' !== $logo ? '<span class="wf-pt-logo" style="color:#fff;font-size:26px;font-weight:800;letter-spacing:.02em;">' . esc_html( $logo ) . '</span>' : '';
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-pt wf-pt--<?= esc_attr( $style ) ?>" aria-hidden="true" style="position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;pointer-events:none;">
    <?php if ( 'split' === $style ) : ?>
        <div class="wf-pt-half wf-pt-l" style="position:absolute;top:0;left:0;width:50%;height:100%;background:<?= esc_attr( $col ) ?>;"></div>
        <div class="wf-pt-half wf-pt-r" style="position:absolute;top:0;right:0;width:50%;height:100%;background:<?= esc_attr( $col ) ?>;"></div>
        <div class="wf-pt-mid" style="position:relative;z-index:2;"><?= $logotag ?></div>
    <?php else : ?>
        <div class="wf-pt-panel" style="position:absolute;inset:0;background:<?= esc_attr( $col ) ?>;display:flex;align-items:center;justify-content:center;"><?= $logotag ?></div>
    <?php endif; ?>
</div>
<style>
#<?= esc_attr( $uid ) ?> .wf-pt-logo{animation:wfpt-logo <?= $dur ?>s ease forwards;}
@keyframes wfpt-logo{0%{opacity:0;transform:translateY(6px)}35%{opacity:1;transform:translateY(0)}80%,100%{opacity:0}}
<?php if ( 'curtain' === $style ) : ?>
#<?= esc_attr( $uid ) ?> .wf-pt-panel{animation:wfpt-curtain <?= $dur ?>s cubic-bezier(.76,0,.24,1) forwards;}
@keyframes wfpt-curtain{0%,25%{transform:translateY(0)}100%{transform:translateY(-100%)}}
<?php elseif ( 'wipe' === $style ) : ?>
#<?= esc_attr( $uid ) ?> .wf-pt-panel{animation:wfpt-wipe <?= $dur ?>s cubic-bezier(.76,0,.24,1) forwards;}
@keyframes wfpt-wipe{0%,25%{transform:translateX(0)}100%{transform:translateX(100%)}}
<?php elseif ( 'fade' === $style ) : ?>
#<?= esc_attr( $uid ) ?> .wf-pt-panel{animation:wfpt-fade <?= $dur ?>s ease forwards;}
@keyframes wfpt-fade{0%,25%{opacity:1}100%{opacity:0}}
<?php else : ?>
#<?= esc_attr( $uid ) ?> .wf-pt-l{animation:wfpt-sl <?= $dur ?>s cubic-bezier(.76,0,.24,1) forwards;}
#<?= esc_attr( $uid ) ?> .wf-pt-r{animation:wfpt-sr <?= $dur ?>s cubic-bezier(.76,0,.24,1) forwards;}
@keyframes wfpt-sl{0%,25%{transform:translateX(0)}100%{transform:translateX(-100%)}}
@keyframes wfpt-sr{0%,25%{transform:translateX(0)}100%{transform:translateX(100%)}}
<?php endif; ?>
@media(prefers-reduced-motion:reduce){#<?= esc_attr( $uid ) ?>{display:none!important;}}
</style>
<script>
(function(){
    var el = document.getElementById('<?= esc_js( $uid ) ?>'); if (!el) return;
    setTimeout(function(){ el.style.display = 'none'; }, <?= (int) $speed + 120 ?>);
})();
</script>

<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
