<?php
/**
 * WeFrame – Tiroir (Drawer) | template.php v1.0
 *
 * Panneau glissant depuis un des quatre côtés, au contenu libre (sublayout).
 * Deux usages en un : tiroir sur mobile, panneau épinglé en permanence
 * au-delà d'un seuil — c'est ce que fait le « drawer » de daisyUI, et c'est
 * ce qui manque au constructeur de YOOtheme.
 *
 * Le panneau est déplacé dans <body> au démarrage : sinon une section animée
 * (transform) casserait son position:fixed. Conséquence assumée, documentée
 * dans le panneau : le CSS personnalisé de l'élément ne l'atteint plus.
 *
 * Pas de "&&" ni de "||" dans le JS inline (règle interne du plugin).
 */

defined( 'ABSPATH' ) || exit;

$trigger = (string) ( $props['trigger_type'] ?? 'button' );
if ( ! in_array( $trigger, array( 'button', 'icon', 'selector', 'none' ), true ) ) { $trigger = 'button'; }

$btnText = trim( (string) ( $props['btn_text'] ?? '' ) );
$btnIcon = (string) ( $props['btn_icon'] ?? 'burger' );
$btnAlign = (string) ( $props['btn_align'] ?? 'left' );
$selector = trim( (string) ( $props['trigger_selector'] ?? '' ) );

$title    = trim( (string) ( $props['drawer_title'] ?? '' ) );
$showX    = ! empty( $props['show_close'] );
$xLabel   = trim( (string) ( $props['close_label'] ?? '' ) );
if ( '' === $xLabel ) { $xLabel = 'Fermer le panneau'; }

$side = (string) ( $props['side'] ?? 'left' );
if ( ! in_array( $side, array( 'left', 'right', 'top', 'bottom' ), true ) ) { $side = 'left'; }

$size   = max( 160, min( 900, (int) ( $props['size'] ?? 320 ) ) );
$bg     = (string) ( $props['panel_bg'] ?? '#ffffff' );
$fg     = (string) ( $props['panel_color'] ?? '#111111' );
$rad    = max( 0, min( 48, (int) ( $props['panel_radius'] ?? 0 ) ) );
$pad    = max( 0, min( 80, (int) ( $props['panel_pad'] ?? 24 ) ) );
$shadow = (string) ( $props['panel_shadow'] ?? 'strong' );

$bdCol  = (string) ( $props['backdrop_color'] ?? '#000000' );
$bdOp   = max( 0, min( 100, (int) ( $props['backdrop_opacity'] ?? 55 ) ) );
$bdBlur = max( 0, min( 20, (int) ( $props['backdrop_blur'] ?? 2 ) ) );

$bgClose   = ! empty( $props['bg_close'] );
$escClose  = ! empty( $props['esc_close'] );
$swipe     = ! empty( $props['swipe_close'] );
$linkClose = ! empty( $props['link_close'] );
$dur       = max( 0, min( 1200, (int) ( $props['duration'] ?? 320 ) ) );

$pinFrom = (string) ( $props['pin_from'] ?? '' );
if ( ! in_array( $pinFrom, array( '', '640', '768', '960', '1200' ), true ) ) { $pinFrom = ''; }
$pinOffset = ! empty( $props['pin_offset'] );
$pinTop    = max( 0, min( 400, (int) ( $props['pin_top'] ?? 0 ) ) );

// Ancre : celle saisie si elle est utilisable comme id, sinon une générée.
$anchor = preg_replace( '/[^A-Za-z0-9_-]/', '', (string) ( $props['anchor_id'] ?? '' ) );
if ( '' === $anchor || ! preg_match( '/^[A-Za-z]/', $anchor ) ) {
	$anchor = wf_uid( 'wfdr_', $props );
}
$host = $anchor . '_host';

$inner = '';
if ( ! empty( $children ) ) {
	foreach ( $children as $child ) { $inner .= $builder->render( $child ); }
}

$icons = array(
	'burger' => '<path d="M4 7h16M4 12h16M4 17h16"/>',
	'filter' => '<path d="M4 6h16M7 12h10M10 18h4"/>',
	'cart'   => '<circle cx="9" cy="20" r="1.4"/><circle cx="18" cy="20" r="1.4"/><path d="M3 4h2l2.4 11.2a1.6 1.6 0 0 0 1.6 1.3h8.6a1.6 1.6 0 0 0 1.6-1.3L21 8H6"/>',
	'user'   => '<circle cx="12" cy="8" r="3.6"/><path d="M4.5 20a7.5 7.5 0 0 1 15 0"/>',
	'search' => '<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/>',
);
$iconSvg = '';
if ( isset( $icons[ $btnIcon ] ) ) {
	$iconSvg = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $icons[ $btnIcon ] . '</svg>';
}

$alignCss = 'flex-start';
if ( 'center' === $btnAlign ) { $alignCss = 'center'; }
if ( 'right' === $btnAlign ) { $alignCss = 'flex-end'; }

$shadowCss = 'none';
if ( 'soft' === $shadow ) { $shadowCss = '0 4px 24px rgba(0,0,0,.12)'; }
if ( 'strong' === $shadow ) { $shadowCss = '0 0 60px rgba(0,0,0,.28)'; }

$rgb = array( 0, 0, 0 );
if ( preg_match( '/^#([0-9a-fA-F]{6})$/', $bdCol, $m ) ) {
	$rgb = array( hexdec( substr( $m[1], 0, 2 ) ), hexdec( substr( $m[1], 2, 2 ) ), hexdec( substr( $m[1], 4, 2 ) ) );
}
$bdRgba = 'rgba(' . $rgb[0] . ',' . $rgb[1] . ',' . $rgb[2] . ',' . round( $bdOp / 100, 2 ) . ')';

// Axe et sens du geste de fermeture : vers l'extérieur, du côté du panneau.
$axis = in_array( $side, array( 'left', 'right' ), true ) ? 'x' : 'y';
$sign = in_array( $side, array( 'left', 'top' ), true ) ? -1 : 1;

$aria = '' !== $title ? $title : ( '' !== $btnText ? $btnText : 'Panneau' );

// Un bouton réduit à une icône n'a pas de texte : il lui faut un nom accessible.
$btnAria = '';
if ( 'icon' === $trigger ) {
	$label   = '' !== $btnText ? $btnText : $aria;
	$btnAria = ' aria-label="' . esc_attr( $label ) . '"';
}

// Épinglage : position du bloc racine et réserve de place dans la page.
$pinInset = 'inset:' . $pinTop . 'px auto 0 0;width:' . $size . 'px;';
$pinPad   = 'padding-left:' . $size . 'px;';
if ( 'right' === $side ) {
	$pinInset = 'inset:' . $pinTop . 'px 0 0 auto;width:' . $size . 'px;';
	$pinPad   = 'padding-right:' . $size . 'px;';
} elseif ( 'top' === $side ) {
	$pinInset = 'inset:' . $pinTop . 'px 0 auto 0;height:' . $size . 'px;';
	$pinPad   = 'padding-top:' . $size . 'px;';
} elseif ( 'bottom' === $side ) {
	$pinInset = 'inset:auto 0 0 0;height:' . $size . 'px;';
	$pinPad   = 'padding-bottom:' . $size . 'px;';
}

$cfg = wp_json_encode(
	array(
		'id'    => $anchor,
		'host'  => $host,
		'sel'   => $selector,
		'esc'   => $escClose,
		'bgc'   => $bgClose,
		'swipe' => $swipe,
		'link'  => $linkClose,
		'axis'  => $axis,
		'sign'  => $sign,
		'size'  => $size,
		'pin'   => '' === $pinFrom ? 0 : (int) $pinFrom,
	),
	JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE
);
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $host ) ?>" class="wf-dr-host">
<?php if ( 'button' === $trigger || 'icon' === $trigger ) : ?>
	<div class="wf-dr__triggerwrap">
		<button type="button" class="wf-dr__trigger" data-wf-dr-open="<?= esc_attr( $anchor ) ?>" aria-controls="<?= esc_attr( $anchor ) ?>" aria-expanded="false"<?= $btnAria ?>>
			<?= $iconSvg ?>
			<?php if ( 'button' === $trigger && '' !== $btnText ) : ?><span><?= esc_html( $btnText ) ?></span><?php endif; ?>
		</button>
	</div>
<?php endif; ?>

	<div id="<?= esc_attr( $anchor ) ?>" class="wf-dr">
		<div class="wf-dr__backdrop" hidden></div>
		<aside class="wf-dr__panel" role="dialog" aria-modal="true" aria-label="<?= esc_attr( $aria ) ?>">
			<?php if ( '' !== $title || $showX ) : ?>
			<header class="wf-dr__head">
				<?php if ( '' !== $title ) : ?><span class="wf-dr__title"><?= esc_html( $title ) ?></span><?php endif; ?>
				<?php if ( $showX ) : ?>
				<button type="button" class="wf-dr__close" aria-label="<?= esc_attr( $xLabel ) ?>">
					<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>
				</button>
				<?php endif; ?>
			</header>
			<?php endif; ?>
			<div class="wf-dr__body"><?= $inner ?></div>
		</aside>
	</div>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $host ) ?> .wf-dr__triggerwrap{display:flex;justify-content:<?= esc_attr( $alignCss ) ?>;}
#<?= esc_attr( $host ) ?> .wf-dr__trigger{
	display:inline-flex;align-items:center;gap:.55em;cursor:pointer;
	min-height:44px;padding:.6em 1.1em;font:inherit;font-weight:600;line-height:1.2;
	color:inherit;background:transparent;border:1px solid currentColor;border-radius:8px;
}
#<?= esc_attr( $host ) ?> .wf-dr__trigger:hover{opacity:.75;}
#<?= esc_attr( $anchor ) ?>{position:fixed;inset:0;z-index:1010;visibility:hidden;pointer-events:none;}
#<?= esc_attr( $anchor ) ?> .wf-dr__backdrop{
	position:absolute;inset:0;background:<?= esc_attr( $bdRgba ) ?>;
	<?php if ( $bdBlur > 0 ) : ?>backdrop-filter:blur(<?= (int) $bdBlur ?>px);-webkit-backdrop-filter:blur(<?= (int) $bdBlur ?>px);<?php endif; ?>
	opacity:0;transition:opacity <?= (int) $dur ?>ms ease;
}
#<?= esc_attr( $anchor ) ?> .wf-dr__panel{
	position:absolute;display:flex;flex-direction:column;
	background:<?= esc_attr( $bg ) ?>;color:<?= esc_attr( $fg ) ?>;box-shadow:<?= esc_attr( $shadowCss ) ?>;
	overscroll-behavior:contain;will-change:transform;
	transition:transform <?= (int) $dur ?>ms cubic-bezier(.4,0,.2,1);
}
<?php if ( 'left' === $side ) : ?>
#<?= esc_attr( $anchor ) ?> .wf-dr__panel{top:0;bottom:0;left:0;width:<?= (int) $size ?>px;max-width:calc(100vw - 48px);transform:translateX(-100%);border-radius:0 <?= (int) $rad ?>px <?= (int) $rad ?>px 0;}
<?php elseif ( 'right' === $side ) : ?>
#<?= esc_attr( $anchor ) ?> .wf-dr__panel{top:0;bottom:0;right:0;width:<?= (int) $size ?>px;max-width:calc(100vw - 48px);transform:translateX(100%);border-radius:<?= (int) $rad ?>px 0 0 <?= (int) $rad ?>px;}
<?php elseif ( 'top' === $side ) : ?>
#<?= esc_attr( $anchor ) ?> .wf-dr__panel{left:0;right:0;top:0;height:<?= (int) $size ?>px;max-height:calc(100vh - 48px);transform:translateY(-100%);border-radius:0 0 <?= (int) $rad ?>px <?= (int) $rad ?>px;}
<?php else : ?>
#<?= esc_attr( $anchor ) ?> .wf-dr__panel{left:0;right:0;bottom:0;height:<?= (int) $size ?>px;max-height:calc(100vh - 48px);transform:translateY(100%);border-radius:<?= (int) $rad ?>px <?= (int) $rad ?>px 0 0;}
<?php endif; ?>
#<?= esc_attr( $anchor ) ?>.is-open{visibility:visible;pointer-events:auto;}
#<?= esc_attr( $anchor ) ?>.is-open .wf-dr__backdrop{opacity:1;}
#<?= esc_attr( $anchor ) ?>.is-open .wf-dr__panel{transform:none;}
#<?= esc_attr( $anchor ) ?> .wf-dr__head{
	display:flex;align-items:center;justify-content:space-between;gap:1em;
	padding:<?= (int) $pad ?>px <?= (int) $pad ?>px 0;
}
#<?= esc_attr( $anchor ) ?> .wf-dr__title{font-size:1.05rem;font-weight:700;line-height:1.3;}
#<?= esc_attr( $anchor ) ?> .wf-dr__close{
	flex:0 0 auto;display:inline-flex;align-items:center;justify-content:center;
	width:44px;height:44px;margin:-10px -10px -10px 0;cursor:pointer;
	color:inherit;background:transparent;border:0;border-radius:8px;
}
#<?= esc_attr( $anchor ) ?> .wf-dr__close:hover{background:rgba(127,127,127,.14);}
#<?= esc_attr( $anchor ) ?> .wf-dr__body{flex:1 1 auto;min-height:0;overflow:auto;padding:<?= (int) $pad ?>px;}
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $anchor ) ?> .wf-dr__panel,#<?= esc_attr( $anchor ) ?> .wf-dr__backdrop{transition:none;}
}
<?php if ( '' !== $pinFrom ) : ?>
@media (min-width: <?= (int) $pinFrom ?>px){
	#<?= esc_attr( $host ) ?> .wf-dr__triggerwrap{display:none;}
	#<?= esc_attr( $anchor ) ?>{visibility:visible;pointer-events:auto;<?= $pinInset ?>max-width:100vw;}
	#<?= esc_attr( $anchor ) ?> .wf-dr__backdrop{display:none;}
	#<?= esc_attr( $anchor ) ?> .wf-dr__close{display:none;}
	#<?= esc_attr( $anchor ) ?> .wf-dr__panel{
		inset:0;width:auto;height:auto;max-width:none;max-height:none;transform:none;
	}
	<?php if ( $pinOffset ) : ?>
	body{<?= $pinPad ?>}
	<?php endif; ?>
}
<?php endif; ?>
</style>
<script>
(function(){
	function boot(){
		var c = <?= $cfg ?>;
		var root = document.getElementById(c.id);
		if(!root){return;}
		if(root.getAttribute('data-wf-ready')){return;}
		root.setAttribute('data-wf-ready','1');

		// Sorti du flux : une section animée (transform) casserait le position:fixed.
		if(root.parentNode !== document.body){document.body.appendChild(root);}

		var panel = root.querySelector('.wf-dr__panel');
		var back  = root.querySelector('.wf-dr__backdrop');
		var host  = document.getElementById(c.host);
		if(!panel){return;}

		var opened = false;
		var release = null;
		var pinned = false;
		var mq = c.pin ? window.matchMedia('(min-width:' + c.pin + 'px)') : null;

		function btns(){
			var out = [];
			function push(list){var i=0;while(i<list.length){out.push(list[i]);i++;}}
			push(document.querySelectorAll('[data-wf-dr-open="' + c.id + '"]'));
			push(document.querySelectorAll('a[href="#' + c.id + '"]'));
			if(c.sel){try{push(document.querySelectorAll(c.sel));}catch(e){}}
			return out;
		}

		function mark(v){
			var list = btns(), i = 0;
			while(i < list.length){
				if(list[i].setAttribute){list[i].setAttribute('aria-expanded', v ? 'true' : 'false');}
				i++;
			}
		}

		function open(){
			if(pinned){return;}
			if(opened){return;}
			opened = true;
			if(back){back.hidden = false;}
			root.classList.add('is-open');
			mark(true);
			if(window.WF){if(WF.lockScroll){WF.lockScroll();}}
			if(window.WF){if(WF.trapFocus){release = WF.trapFocus(panel);}}
		}

		function close(){
			if(!opened){return;}
			opened = false;
			root.classList.remove('is-open');
			mark(false);
			if(window.WF){if(WF.unlockScroll){WF.unlockScroll();}}
			if(release){release();release = null;}
			if(back){window.setTimeout(function(){if(!opened){back.hidden = true;}}, 400);}
		}

		function bindTriggers(){
			var list = btns(), i = 0;
			while(i < list.length){
				(function(b){
					if(b.getAttribute('data-wf-dr-bound')){return;}
					b.setAttribute('data-wf-dr-bound','1');
					b.setAttribute('aria-controls', c.id);
					b.addEventListener('click', function(e){e.preventDefault();open();});
				}(list[i]));
				i++;
			}
		}
		bindTriggers();

		var x = root.querySelector('.wf-dr__close');
		if(x){x.addEventListener('click', close);}
		if(c.bgc){if(back){back.addEventListener('click', close);}}
		if(c.esc){
			document.addEventListener('keydown', function(e){
				if(e.key !== 'Escape'){return;}
				if(!opened){return;}
				close();
			});
		}
		if(c.link){
			panel.addEventListener('click', function(e){
				var a = e.target.closest ? e.target.closest('a[href]') : null;
				if(!a){return;}
				if(a.getAttribute('href').charAt(0) === '#'){close();return;}
				close();
			});
		}

		// Épinglé : ce n'est plus une boîte de dialogue, on retire le rôle et
		// on rend le contenu accessible en permanence.
		function syncPin(){
			pinned = mq ? mq.matches : false;
			if(pinned){
				close();
				panel.removeAttribute('role');
				panel.removeAttribute('aria-modal');
			}else{
				panel.setAttribute('role','dialog');
				panel.setAttribute('aria-modal','true');
			}
		}
		if(mq){
			syncPin();
			if(mq.addEventListener){mq.addEventListener('change', syncPin);}
			else if(mq.addListener){mq.addListener(syncPin);}
		}

		if(c.swipe){
			var sx = 0, sy = 0, drag = false, lock = '', delta = 0;
			panel.addEventListener('pointerdown', function(e){
				if(pinned){return;}
				if(!opened){return;}
				if(e.pointerType === 'mouse'){return;}
				drag = true; lock = ''; delta = 0; sx = e.clientX; sy = e.clientY;
			});
			panel.addEventListener('pointermove', function(e){
				if(!drag){return;}
				var dx = e.clientX - sx, dy = e.clientY - sy;
				if(lock === ''){
					if(Math.abs(dx) + Math.abs(dy) < 8){return;}
					lock = Math.abs(dx) > Math.abs(dy) ? 'x' : 'y';
					// Geste sur l'autre axe : c'est un défilement, on ne s'en mêle pas.
					if(lock !== c.axis){drag = false;return;}
					panel.style.transition = 'none';
				}
				var d = c.axis === 'x' ? dx : dy;
				d = c.sign < 0 ? Math.min(0, d) : Math.max(0, d);
				delta = d;
				panel.style.transform = c.axis === 'x' ? 'translateX(' + d + 'px)' : 'translateY(' + d + 'px)';
			});
			function endDrag(){
				if(!drag){return;}
				drag = false;
				panel.style.transition = '';
				panel.style.transform = '';
				if(Math.abs(delta) > c.size * 0.35){close();}
			}
			panel.addEventListener('pointerup', endDrag);
			panel.addEventListener('pointercancel', endDrag);
		}

		// Un lien vers l'ancre ajouté après coup (menu, autre élément) reste actif.
		document.addEventListener('click', function(e){
			var a = e.target.closest ? e.target.closest('a[href="#' + c.id + '"]') : null;
			if(!a){return;}
			if(a.getAttribute('data-wf-dr-bound')){return;}
			e.preventDefault();
			open();
		});

		if(host){host.setAttribute('data-wf-dr-live','1');}
	}
	WF.ready(boot);
}());
</script>
