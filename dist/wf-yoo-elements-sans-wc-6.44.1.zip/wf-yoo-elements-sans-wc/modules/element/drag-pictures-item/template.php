<?php
defined( 'ABSPATH' ) || exit;
// Data-only element, rendered by parent
