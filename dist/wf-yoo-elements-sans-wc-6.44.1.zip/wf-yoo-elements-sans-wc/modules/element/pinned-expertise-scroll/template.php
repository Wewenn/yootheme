<?php
/**
 * WeFrame – Expertise Scroll (conteneur) | template.php v2.2
 *
 * Motif « stacking cards » (CSS-Tricks / scroll-driven-animations.style) :
 *   - chaque ÉTAPE est `sticky` et enfant direct du conteneur → les cartes
 *     S'ACCUMULENT au lieu de se succéder ;
 *   - `padding-top: index * décalage` → le haut des précédentes reste visible ;
 *   - distance de défilement par carte = `min-height` de l'étape, exprimée en
 *     % d'écran avec un PLANCHER : jamais plus courte que la carte, sinon la
 *     suivante recouvre avant qu'on ait pu lire.
 *
 * ZÉRO JavaScript. Largeur gérée par CONTAINER QUERY (l'élément peut vivre
 * dans une colonne). Effets (échelle, assombrissement, flou, fondu d'arrivée)
 * via les animations liées au défilement, sous @supports + reduced-motion.
 *
 * Rendu 100 % serveur, style scopé par un id unique.
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$offset   = max( 0, (int) ( $props['offset'] ?? 90 ) );
$dwellVh  = max( 40, min( 140, (int) ( $props['dwell_vh'] ?? 70 ) ) );
$cardMinH = max( 0, (int) ( $props['card_min_height'] ?? 240 ) );
$stackOff = max( 0, (int) ( $props['stack_offset'] ?? 18 ) );
$stackSc  = max( 0.8, min( 1, (float) ( $props['stack_scale'] ?? 0.94 ) ) );
$stackDim = max( 0.4, min( 1, (float) ( $props['stack_dim'] ?? 0.8 ) ) );
$gap      = max( 0, (int) ( $props['card_gap'] ?? 24 ) );

$valign  = ( 'top' === ( $props['valign'] ?? 'center' ) ) ? 'top' : 'center';
$enter   = (string) ( $props['enter'] ?? 'fade' );
if ( ! in_array( $enter, array( 'none', 'fade', 'fade-up' ), true ) ) { $enter = 'fade'; }
$shadow  = ! empty( $props['shadow'] );
$blur    = ! empty( $props['blur'] );
$autoNum = ! empty( $props['auto_number'] );

// Plancher : la reserve de defilement doit depasser la carte + une marge de lecture.
$dwellFloor = $cardMinH + 120;

$cBg   = $props['card_bg']      ?? '#0b2f52';
$cCol  = $props['card_color']   ?? '#ffffff';
$cMut  = $props['card_muted']   ?? '#9db4cc';
$acc   = $props['accent']       ?? '#e3b23c';
$cBd   = trim( (string) ( $props['card_border'] ?? '' ) );
$tagBd = trim( (string) ( $props['tag_border'] ?? '#2c5580' ) );
$tagC  = $props['tag_color']    ?? '#cfe0f0';
$tagBg = trim( (string) ( $props['tag_bg'] ?? '' ) );
$rad   = max( 0, (int) ( $props['card_radius'] ?? 0 ) );
$pad   = max( 0, (int) ( $props['card_padding'] ?? 40 ) );
$tSize = max( 12, (int) ( $props['title_size'] ?? 30 ) );
$nSize = max( 8, (int) ( $props['num_size'] ?? 18 ) );

$iPos   = (string) ( $props['intro_position'] ?? 'none' );
if ( ! in_array( $iPos, array( 'none', 'left', 'right', 'top', 'bottom' ), true ) ) { $iPos = 'none'; }
$iEye   = trim( (string) ( $props['intro_eyebrow'] ?? '' ) );
$iTitle = trim( (string) ( $props['intro_title'] ?? '' ) );
$iText  = trim( (string) ( $props['intro_text'] ?? '' ) );
$iW     = max( 20, min( 60, (int) ( $props['intro_width'] ?? 38 ) ) );
$iGap   = max( 0, (int) ( $props['intro_gap'] ?? 60 ) );
$iStick = ! empty( $props['intro_sticky'] );
$eyeCol = $props['eyebrow_color']      ?? '#e3b23c';
$iTSize = max( 18, (int) ( $props['intro_title_size'] ?? 44 ) );
$iTCol  = $props['intro_title_color']  ?? '#ffffff';
$iXCol  = $props['intro_text_color']   ?? '#9db4cc';

$hasIntro = ( 'none' !== $iPos );
if ( '' === $iEye ) { if ( '' === $iTitle ) { if ( '' === $iText ) { $hasIntro = false; } } }
$side = ( 'left' === $iPos ) || ( 'right' === $iPos );

$uid = function_exists( 'wp_unique_id' ) ? wp_unique_id( 'wfpe_' ) : 'wfpe_' . substr( md5( serialize( $props ) ), 0, 8 );

$html  = '';
$count = 0;
foreach ( $children as $i => $child ) {
	$html .= $builder->render( $child, array( 'element' => $props, 'index' => $i ) );
	$count++;
}
if ( ! trim( $html ) ) { return; }

// Centrage SANS transform : `translateY(-50%)` sortait la carte de sa boite de
// flux, donc elle debordait au-dessus avant de coller et remontait apres. On
// decale plutot le point d'accroche, en s'appuyant sur la hauteur mini connue.
$halfCard = (int) round( $cardMinH / 2 );
$stickTop = ( 'center' === $valign )
	? 'max(' . $offset . 'px, calc(50vh - ' . $halfCard . 'px))'
	: $offset . 'px';
$stackT  = 'scale(' . $stackSc . ')';
$filters = 'brightness(' . $stackDim . ')' . ( $blur ? ' blur(2px)' : '' );

$cls = 'wf-pinned-expertise';
if ( $hasIntro ) { $cls .= ' wfpe--intro wfpe--intro-' . $iPos; }
if ( $autoNum )  { $cls .= ' wfpe--autonum'; }
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="<?= esc_attr( $cls ) ?>" style="--wfpe-n:<?= (int) $count ?>;">
	<div class="__layout">
		<?php if ( $hasIntro ) : ?>
		<div class="__intro">
			<?php if ( '' !== $iEye ) : ?><span class="__eyebrow"><?= esc_html( $iEye ) ?></span><?php endif; ?>
			<?php if ( '' !== $iTitle ) : ?><h2 class="__introtitle"><?= nl2br( esc_html( $iTitle ) ) ?></h2><?php endif; ?>
			<?php if ( '' !== $iText ) : ?><p class="__introtext"><?= nl2br( esc_html( $iText ) ) ?></p><?php endif; ?>
		</div>
		<?php endif; ?>

		<div class="__steps">
			<?= $html ?>
		</div>
	</div>
</div>

<style>
#<?= esc_attr( $uid ) ?>{container-type:inline-size;}
#<?= esc_attr( $uid ) ?> .__layout{display:block;}
#<?= esc_attr( $uid ) ?> .__steps{display:flex;flex-direction:column;gap:<?= $gap ?>px;counter-reset:wfpe;}

/* L'etape colle et fournit la distance de defilement. */
#<?= esc_attr( $uid ) ?> .wf-pinned-expertise__step{
	position:sticky;
	top:<?= $stickTop ?>;
	min-height:max(<?= $dwellVh ?>vh, <?= $dwellFloor ?>px);
	padding-top:calc(var(--wfpe-i, 0) * <?= $stackOff ?>px);
	counter-increment:wfpe;
	display:block;
}
/* La derniere garde une reserve COMPLETE : c'est le temps pendant lequel la
   pile terminee reste visible a l'ecran. La raccourcir faisait disparaitre
   tout l'empilement des que la derniere carte arrivait. */

#<?= esc_attr( $uid ) ?> .__sticky{
	background:<?= esc_attr( $cBg ) ?>;
	color:<?= esc_attr( $cCol ) ?>;
	<?= '' !== $cBd ? 'border:1px solid ' . esc_attr( $cBd ) . ';' : '' ?>
	border-radius:<?= $rad ?>px;
	padding:<?= $pad ?>px;
	<?= $cardMinH > 0 ? 'min-height:' . $cardMinH . 'px;' : '' ?>
	box-sizing:border-box;
	transform-origin:50% 0;
	<?= $shadow ? 'box-shadow:0 18px 40px rgba(0,0,0,.28);' : '' ?>
	display:flex;flex-direction:column;justify-content:center;
}

@supports (animation-timeline: view()) {
	@media (prefers-reduced-motion: no-preference) {
		#<?= esc_attr( $uid ) ?> .__steps{view-timeline-name:--wfpe-<?= esc_attr( $uid ) ?>;}
		#<?= esc_attr( $uid ) ?> .__sticky{
			animation:wfpe-stack-<?= esc_attr( $uid ) ?> linear forwards;
			animation-timeline:--wfpe-<?= esc_attr( $uid ) ?>;
			animation-range:exit-crossing calc(var(--wfpe-i, 0) / var(--wfpe-n) * 100%)
			                exit-crossing calc((var(--wfpe-i, 0) + 1) / var(--wfpe-n) * 100%);
		}
		@keyframes wfpe-stack-<?= esc_attr( $uid ) ?>{
			to{transform:<?= $stackT ?>;filter:<?= $filters ?>;}
		}
<?php if ( 'none' !== $enter ) : ?>
		/* Arrivee portee par .__inner : sinon conflit avec la transform d'empilement. */
		#<?= esc_attr( $uid ) ?> .__inner{
			animation:wfpe-enter-<?= esc_attr( $uid ) ?> linear both;
			animation-timeline:view();
			animation-range:entry 10% entry 70%;
		}
		@keyframes wfpe-enter-<?= esc_attr( $uid ) ?>{
			from{opacity:0;<?= 'fade-up' === $enter ? 'transform:translateY(26px);' : '' ?>}
			to{opacity:1;<?= 'fade-up' === $enter ? 'transform:none;' : '' ?>}
		}
<?php endif; ?>
	}
}

#<?= esc_attr( $uid ) ?> .__num:empty{display:none;}
<?php if ( $autoNum ) : ?>
#<?= esc_attr( $uid ) ?>.wfpe--autonum .__num,
#<?= esc_attr( $uid ) ?>.wfpe--autonum .__num:empty{font-size:0;display:block;}
#<?= esc_attr( $uid ) ?>.wfpe--autonum .__num::after{
	content:counter(wfpe, decimal-leading-zero);
	font-size:<?= $nSize ?>px;font-weight:800;color:<?= esc_attr( $acc ) ?>;
	font-variant-numeric:tabular-nums;letter-spacing:.02em;
}
<?php endif; ?>

#<?= esc_attr( $uid ) ?> .__inner{display:flex;gap:28px;align-items:flex-start;}
#<?= esc_attr( $uid ) ?> .__num{
	flex:0 0 auto;font-size:<?= $nSize ?>px;line-height:1.2;font-weight:800;
	color:<?= esc_attr( $acc ) ?>;font-variant-numeric:tabular-nums;letter-spacing:.02em;
}
#<?= esc_attr( $uid ) ?> .__body{flex:1 1 auto;min-width:0;}
#<?= esc_attr( $uid ) ?> .__head{display:flex;align-items:baseline;justify-content:space-between;gap:18px;flex-wrap:wrap;}
#<?= esc_attr( $uid ) ?> .__heading{display:flex;align-items:baseline;gap:14px;flex-wrap:wrap;min-width:0;}
#<?= esc_attr( $uid ) ?> .__title{
	margin:0;font-size:<?= $tSize ?>px;line-height:1.15;font-weight:800;
	letter-spacing:-.01em;color:<?= esc_attr( $cCol ) ?>;
}
#<?= esc_attr( $uid ) ?> .__title a{color:inherit;text-decoration:none;}
#<?= esc_attr( $uid ) ?> .__title a:hover{text-decoration:underline;}
#<?= esc_attr( $uid ) ?> .__role{font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:.12em;color:<?= esc_attr( $cMut ) ?>;}
#<?= esc_attr( $uid ) ?> .__date{font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:.14em;color:<?= esc_attr( $cMut ) ?>;white-space:nowrap;}
#<?= esc_attr( $uid ) ?> .__media{margin:16px 0 0;}
#<?= esc_attr( $uid ) ?> .__media img{max-width:100%;height:auto;display:block;border-radius:<?= max( 0, $rad - 2 ) ?>px;}
#<?= esc_attr( $uid ) ?> .__desc{margin:14px 0 0;color:<?= esc_attr( $cMut ) ?>;line-height:1.65;max-width:64ch;}
#<?= esc_attr( $uid ) ?> .__tags{list-style:none;margin:22px 0 0;padding:0;display:flex;flex-wrap:wrap;gap:10px;}
#<?= esc_attr( $uid ) ?> .__tags li{
	<?= '' !== $tagBg ? 'background:' . esc_attr( $tagBg ) . ';' : 'background:transparent;' ?>
	<?= '' !== $tagBd ? 'border:1px solid ' . esc_attr( $tagBd ) . ';' : '' ?>
	color:<?= esc_attr( $tagC ) ?>;
	font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;
	padding:7px 14px;border-radius:<?= $rad > 0 ? 100 : 0 ?>px;
}

<?php if ( $hasIntro ) : ?>
#<?= esc_attr( $uid ) ?> .__intro{min-width:0;}
#<?= esc_attr( $uid ) ?> .__eyebrow{
	display:block;font-size:13px;font-weight:700;text-transform:uppercase;
	letter-spacing:.14em;color:<?= esc_attr( $eyeCol ) ?>;margin-bottom:16px;
}
#<?= esc_attr( $uid ) ?> .__introtitle{
	margin:0;font-size:<?= $iTSize ?>px;line-height:1.12;font-weight:800;
	letter-spacing:-.02em;color:<?= esc_attr( $iTCol ) ?>;text-wrap:balance;
}
#<?= esc_attr( $uid ) ?> .__introtext{margin:18px 0 0;color:<?= esc_attr( $iXCol ) ?>;line-height:1.7;max-width:52ch;}
<?php if ( $side ) : ?>
#<?= esc_attr( $uid ) ?> .__layout{
	display:flex;gap:<?= $iGap ?>px;align-items:flex-start;
	flex-direction:<?= 'right' === $iPos ? 'row-reverse' : 'row' ?>;
}
#<?= esc_attr( $uid ) ?> .__intro{flex:0 0 <?= $iW ?>%;max-width:<?= $iW ?>%;}
#<?= esc_attr( $uid ) ?> .__steps{flex:1 1 auto;min-width:0;}
<?php if ( $iStick ) : ?>
/* Meme point d'accroche que les cartes, sinon l'intro et la pile ne sont pas alignees. */
#<?= esc_attr( $uid ) ?> .__intro{position:sticky;top:<?= $stickTop ?>;}
<?php endif; ?>
<?php else : ?>
#<?= esc_attr( $uid ) ?> .__layout{display:flex;flex-direction:<?= 'bottom' === $iPos ? 'column-reverse' : 'column' ?>;gap:<?= $iGap ?>px;}
<?php endif; ?>
<?php endif; ?>

@container (max-width: 780px){
	#<?= esc_attr( $uid ) ?> .__layout{flex-direction:column;gap:<?= max( 24, (int) round( $iGap * 0.6 ) ) ?>px;}
	#<?= esc_attr( $uid ) ?> .__intro{flex:0 0 auto;max-width:100%;position:static;}
	#<?= esc_attr( $uid ) ?> .__introtitle{font-size:<?= max( 22, (int) round( $iTSize * 0.68 ) ) ?>px;}
	#<?= esc_attr( $uid ) ?> .__inner{flex-direction:column;gap:12px;}
	#<?= esc_attr( $uid ) ?> .__head{flex-direction:column;align-items:flex-start;gap:6px;}
	#<?= esc_attr( $uid ) ?> .__title{font-size:<?= max( 20, (int) round( $tSize * 0.78 ) ) ?>px;}
	#<?= esc_attr( $uid ) ?> .__sticky{padding:<?= max( 20, (int) round( $pad * 0.66 ) ) ?>px;}
}

/* Ecrans etroits : plus d'empilement, lecture a la suite. */
@media (max-width: 639px){
	#<?= esc_attr( $uid ) ?> .wf-pinned-expertise__step{position:static;min-height:0;padding-top:0;}
	#<?= esc_attr( $uid ) ?> .__sticky{min-height:0;}
	#<?= esc_attr( $uid ) ?> .__intro{position:static;}
}
</style>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
