<?php
defined( 'ABSPATH' ) || exit;
// The parent renders the photo collection.
