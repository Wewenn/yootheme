<?php
defined('ABSPATH') || exit;
$title = $props['title']??''; $sub = $props['subtitle']??''; $price = $props['price']??'';
$priceY = $props['price_yearly']??'';
$curr = $props['currency']??'€'; $period = $props['period']??''; $pop = !empty($props['is_popular']);
$features = $props['features']??''; $cta_t = $props['cta_text']??''; $cta_l = $props['cta_link']??'';
$cta_s = $props['cta_style']??'filled';
if (!$title) return;
$bg = $element['card_bg']??'#ffffff'; $border = !empty($element['card_border']);
$bc = $element['card_border_color']??'#e5e5e5'; $r = (int)($element['card_radius']??16);
$pad = (int)($element['card_padding']??32); $shadow = !empty($element['card_shadow']);
$pop_bg = $element['popular_bg']??'#0f1117'; $pop_c = $element['popular_color']??'#ffffff';
$badge_bg = $element['badge_bg']??'#EA5C1C'; $badge_c = $element['badge_color']??'#ffffff';
$badge_t = $element['badge_text']??'Populaire';
$ps = (int)($element['price_size']??48); $pw = $element['price_weight']??'700';
$cbg = $pop ? $pop_bg : $bg; $cc = $pop ? $pop_c : 'inherit';
$bdr = $border ? "border:1px solid {$bc};" : '';
$shd = $shadow ? 'box-shadow:0 4px 24px rgba(0,0,0,.08);' : '';
$lines = array_filter(array_map('trim', explode("\n", $features)));
$check = '<svg width="16" height="16" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 10 8 14 16 6"/></svg>';
$cross = '<svg width="16" height="16" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" opacity=".3"><line x1="5" y1="5" x2="15" y2="15"/><line x1="15" y1="5" x2="5" y2="15"/></svg>';
$priceDisplay = $curr.$price;
?>
<div style="background:<?= esc_attr($cbg) ?>;color:<?= esc_attr($cc) ?>;<?= $bdr ?><?= $shd ?>border-radius:<?= $r ?>px;padding:<?= $pad ?>px;display:flex;flex-direction:column;position:relative;overflow:hidden;">
    <?php if ($pop) : ?><div style="position:absolute;top:16px;right:16px;background:<?= esc_attr($badge_bg) ?>;color:<?= esc_attr($badge_c) ?>;padding:4px 14px;border-radius:100px;font-size:11px;font-weight:700;text-transform:uppercase;"><?= esc_html($badge_t) ?></div><?php endif; ?>
    <?php if ($title) : ?><div style="font-size:18px;font-weight:600;margin-bottom:4px;"><?= esc_html($title) ?></div><?php endif; ?>
    <?php if ($sub) : ?><div style="font-size:14px;opacity:.6;margin-bottom:16px;"><?= esc_html($sub) ?></div><?php endif; ?>
    <div style="margin:16px 0 20px;display:flex;align-items:baseline;gap:4px;">
        <span class="wf-pr-price" style="font-size:<?= $ps ?>px;font-weight:<?= esc_attr($pw) ?>;line-height:1;" data-monthly="<?= esc_attr($priceDisplay) ?>" data-yearly="<?= esc_attr($priceY ? $curr.$priceY : '') ?>"><?= esc_html($priceDisplay) ?></span>
        <?php if ($period) : ?><span style="font-size:15px;opacity:.6;"><?= esc_html($period) ?></span><?php endif; ?>
    </div>
    <?php if ($lines) : ?><ul style="margin:0 0 24px;padding:0;list-style:none;display:flex;flex-direction:column;gap:10px;flex:1;">
        <?php foreach ($lines as $line) :
            $striked = ( '' !== $line && '-' === $line[0] ); $txt = $striked ? ltrim(substr($line, 1)) : $line;
            $op = $striked ? 'opacity:.4;text-decoration:line-through;' : '';
            $icon = $striked ? $cross : $check;
        ?><li style="display:flex;align-items:center;gap:8px;font-size:14px;line-height:1.4;<?= $op ?>"><?= $icon ?><span><?= esc_html($txt) ?></span></li>
        <?php endforeach; ?></ul><?php endif; ?>
    <?php if ($cta_t) :
        $cs = ($cta_s === 'outline') ? "background:transparent;color:inherit;border:2px solid currentColor;" : "background:".esc_attr($pop?$pop_c:'#000').";color:".esc_attr($pop?$pop_bg:'#fff').";border:none;";
    ?><a href="<?= esc_url($cta_l) ?>" style="display:block;text-align:center;padding:12px 24px;border-radius:<?= $r ?>px;font-size:15px;font-weight:600;text-decoration:none;<?= $cs ?>transition:opacity .2s;"><?= esc_html($cta_t) ?></a><?php endif; ?>
</div>
