<?php
/**
 * WeFrame – Countdown Timer | template.php v6.0
 */
defined( 'ABSPATH' ) || exit;

$target  = $props['target_date'] ?? '2026-12-31T23:59:59';
$expired = $props['expired_text'] ?? 'Evenement termine !';
$show_d  = ! empty( $props['show_days'] );
$show_h  = ! empty( $props['show_hours'] );
$show_m  = ! empty( $props['show_minutes'] );
$show_s  = ! empty( $props['show_seconds'] );
$style   = $props['style'] ?? 'cards';
$ns      = (int) ( $props['number_size'] ?? 48 );
$nsm     = (int) ( $props['number_size_mobile'] ?? 32 );
$ls      = (int) ( $props['label_size'] ?? 12 );
$nc      = $props['number_color'] ?? '#000';
$lc      = $props['label_color'] ?? '#666';
$cbg     = $props['card_bg'] ?? '#f5f5f5';
$cr      = (int) ( $props['card_radius'] ?? 12 );
$accent  = $props['accent_color'] ?? '#EA5C1C';
$gap     = (int) ( $props['gap'] ?? 16 );
$sep     = ! empty( $props['separator'] );

$uid = 'wfcd_' . substr( md5( $target . serialize( $props ) ), 0, 8 );

$units = [];
if ( $show_d ) { $units[] = [ 'key' => 'd', 'label' => 'Jours' ]; }
if ( $show_h ) { $units[] = [ 'key' => 'h', 'label' => 'Heures' ]; }
if ( $show_m ) { $units[] = [ 'key' => 'm', 'label' => 'Minutes' ]; }
if ( $show_s ) { $units[] = [ 'key' => 's', 'label' => 'Secondes' ]; }

$card_style = $style === 'cards' ? "background:{$cbg};border-radius:{$cr}px;padding:16px 24px;" : ( $style === 'circles' ? "background:{$cbg};border-radius:50%;width:" . ( $ns * 2 + 24 ) . "px;height:" . ( $ns * 2 + 24 ) . "px;display:flex;flex-direction:column;align-items:center;justify-content:center;" : '' );

$cfg = json_encode( [ 'uid' => $uid, 'target' => $target, 'expired' => $expired, 'units' => array_column( $units, 'key' ) ], JSON_HEX_AMP | JSON_HEX_APOS );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-countdown" style="display:flex;align-items:center;justify-content:center;gap:<?= $gap ?>px;flex-wrap:wrap;">
    <?php foreach ( $units as $i => $u ) : ?>
        <?php if ( $sep && $i > 0 && $style !== 'circles' ) : ?>
        <span class="wf-cd-sep" style="font-size:<?= $ns ?>px;font-weight:700;color:<?= esc_attr( $accent ) ?>;line-height:1;">:</span>
        <?php endif; ?>
        <div class="wf-cd-unit" style="text-align:center;<?= $card_style ?>">
            <div class="wf-cd-num" data-unit="<?= $u['key'] ?>" style="font-size:<?= $ns ?>px;font-weight:800;color:<?= esc_attr( $nc ) ?>;line-height:1;font-variant-numeric:tabular-nums;">00</div>
            <div style="font-size:<?= $ls ?>px;color:<?= esc_attr( $lc ) ?>;text-transform:uppercase;letter-spacing:.08em;margin-top:4px;font-weight:600;"><?= esc_html( $u['label'] ) ?></div>
        </div>
    <?php endforeach; ?>
    <div class="wf-cd-expired" style="display:none;font-size:<?= $ns ?>px;font-weight:700;color:<?= esc_attr( $accent ) ?>;"><?= esc_html( $expired ) ?></div>
</div>

<?php if ( $nsm !== $ns ) : ?>
<style>
@media(max-width:767px){
    #<?= esc_attr( $uid ) ?> .wf-cd-num, #<?= esc_attr( $uid ) ?> .wf-cd-sep { font-size: <?= $nsm ?>px !important; }
    <?php if ( $style === 'circles' ) : ?>
    #<?= esc_attr( $uid ) ?> .wf-cd-unit { width: <?= $nsm * 2 + 24 ?>px !important; height: <?= $nsm * 2 + 24 ?>px !important; }
    <?php endif; ?>
}
</style>
<?php endif; ?>

<script>
(function(){
    
    var c = <?= $cfg ?>;
    var el=document.getElementById(c.uid);if(!el)return;
    var end=new Date(c.target).getTime();
    var nums={};c.units.forEach(function(u){nums[u]=el.querySelector('[data-unit="'+u+'"]')});
    var exp=el.querySelector('.wf-cd-expired');
    function pad(n){return n<10?'0'+n:''+n}
    function tick(){
        var now=Date.now(),diff=end-now;
        if(diff<=0){
            el.querySelectorAll('.wf-cd-unit,.wf-cd-sep').forEach(function(e){e.style.display='none'});
            if(exp)exp.style.display='';return;
        }
        var d=Math.floor(diff/86400000);diff%=86400000;
        var h=Math.floor(diff/3600000);diff%=3600000;
        var m=Math.floor(diff/60000);diff%=60000;
        var s=Math.floor(diff/1000);
        if(nums.d)nums.d.textContent=pad(d);
        if(nums.h)nums.h.textContent=pad(h);
        if(nums.m)nums.m.textContent=pad(m);
        if(nums.s)nums.s.textContent=pad(s);
    }
    tick();setInterval(tick,1000);
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
