<?php
/**
 * WeFrame – Testimonial Wall | template.php v1.0
 */
defined( 'ABSPATH' ) || exit;

$title    = $props['title'] ?? 'Wall of love';
$sparkles = ! empty( $props['show_sparkles'] );
$heart    = ! empty( $props['show_heart'] );
$items_raw= $props['items'] ?? '';
$cols     = (int) ( $props['columns'] ?? 3 );
$gap      = (int) ( $props['gap'] ?? 20 );
$cbg      = $props['card_bg'] ?? '#FAFAFA';
$cbd      = $props['card_border'] ?? '#EEEEEE';
$crad     = (int) ( $props['card_radius'] ?? 16 );
$cpad     = (int) ( $props['card_padding'] ?? 28 );
$tc       = $props['text_color'] ?? '#111111';
$rc       = $props['role_color'] ?? '#6B7280';
$ts       = (int) ( $props['title_size'] ?? 56 );
$titc     = $props['title_color'] ?? '#0F0F0F';
$acc      = $props['accent_color'] ?? '#3B82F6';
$bg       = $props['bg_color'] ?? '#FFFFFF';

$items = [];
foreach ( preg_split( "/\r?\n\r?\n/", trim( $items_raw ) ) as $block ) {
    $block = trim( $block );
    if ( ! $block ) continue;
    $parts = array_map( 'trim', explode( '||', $block ) );
    $items[] = [
        'text'   => $parts[0] ?? '',
        'author' => $parts[1] ?? '',
        'role'   => $parts[2] ?? '',
        'logo'   => $parts[3] ?? '',
    ];
}
if ( empty( $items ) ) return;
$uid = wf_uid( 'wftw_', $props );

// SEO: output Review schema.org JSON-LD (opt-in via field "schema")
if ( ! empty( $props['schema'] ) ) {
    $schema_items = array_map( function( $it ){
        return [ 'author' => $it['author'], 'body' => $it['text'] ];
    }, $items );
    wf_testimonial_schema( $schema_items );
}
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<section id="<?= esc_attr( $uid ) ?>" class="wf-tw-wrap" style="background:<?= esc_attr( $bg ) ?>;padding:60px 20px;">
    <?php if ( $title ) : ?>
    <div class="wf-tw-header" style="position:relative;text-align:center;margin:0 auto 48px;max-width:1000px;">
        <?php if ( $sparkles ) : ?>
        <svg style="position:absolute;top:10px;left:calc(50% - 180px);opacity:0.4;" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="<?= esc_attr( $rc ) ?>" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M5.6 18.4l2.8-2.8M15.6 8.4l2.8-2.8"/></svg>
        <?php endif; ?>
        <?php if ( $heart ) : ?>
        <svg style="position:absolute;top:-10px;right:calc(50% - 210px);" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="<?= esc_attr( $rc ) ?>" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>
        <?php endif; ?>
        <div style="display:flex;align-items:center;justify-content:center;gap:20px;">
            <span style="flex:1;height:1px;background:<?= esc_attr( $cbd ) ?>;max-width:180px;"></span>
            <h2 style="margin:0;font-size:<?= $ts ?>px;font-weight:800;color:<?= esc_attr( $titc ) ?>;letter-spacing:-0.02em;line-height:1;"><?= esc_html( $title ) ?></h2>
            <span style="flex:1;height:1px;background:<?= esc_attr( $cbd ) ?>;max-width:180px;"></span>
        </div>
    </div>
    <?php endif; ?>

    <div class="wf-tw-grid" style="column-count:<?= (int) $cols ?>;column-gap:<?= $gap ?>px;max-width:1200px;margin:0 auto;">
    <?php foreach ( $items as $it ) : ?>
        <div class="wf-tw-card" style="break-inside:avoid;background:<?= esc_attr( $cbg ) ?>;border:1px solid <?= esc_attr( $cbd ) ?>;border-radius:<?= $crad ?>px;padding:<?= $cpad ?>px;margin-bottom:<?= $gap ?>px;display:inline-block;width:100%;">
            <div style="font-size:15px;line-height:1.55;color:<?= esc_attr( $tc ) ?>;margin-bottom:18px;">
                <?= wp_kses_post( wpautop( $it['text'] ) ) ?>
            </div>
            <?php if ( $it['author'] || $it['logo'] ) : ?>
            <div style="display:flex;align-items:center;gap:12px;">
                <?php if ( $it['logo'] ) : ?>
                <img src="<?= esc_url( $it['logo'] ) ?>" alt="<?= esc_attr( $it['role'] ?: $it['author'] ) ?>" style="width:40px;height:40px;border-radius:50%;object-fit:contain;background:#fff;border:1px solid <?= esc_attr( $cbd ) ?>;padding:4px;flex-shrink:0;" loading="lazy">
                <?php endif; ?>
                <div style="line-height:1.3;">
                    <?php if ( $it['author'] ) : ?><div style="font-weight:700;font-size:14px;color:<?= esc_attr( $tc ) ?>;"><?= esc_html( $it['author'] ) ?></div><?php endif; ?>
                    <?php if ( $it['role'] ) : ?><div style="font-size:13px;color:<?= esc_attr( $rc ) ?>;"><?= esc_html( $it['role'] ) ?></div><?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
    </div>
</section>
<style>
#<?= esc_attr( $uid ) ?> a { color: <?= esc_attr( $acc ) ?>; text-decoration: underline; text-underline-offset:3px; }
@media (max-width:900px) { #<?= esc_attr( $uid ) ?> .wf-tw-grid { column-count:2 !important; } }
@media (max-width:600px) { #<?= esc_attr( $uid ) ?> .wf-tw-grid { column-count:1 !important; } }
</style>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
