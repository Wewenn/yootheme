<?php
/**
 * WeFrame – Shape Divider | template.php v1.0
 * Séparateur SVG plein largeur, motif répété, défilement horizontal seamless (background-position).
 * Motifs : scallops | waves | zigzag | triangles | tilt (statique).
 */
defined( 'ABSPATH' ) || exit;

$style   = $props['style']    ?? 'scallops';
$color   = $props['color']    ?? '#2563eb';
$height  = max( 12, (int) ( $props['height'] ?? 60 ) );
$period  = max( 40, (int) ( $props['period'] ?? 120 ) );
$pos     = $props['position'] ?? 'bottom';
$flip_x  = ! empty( $props['flip_x'] );
$animate = ! empty( $props['animate'] );
$dir     = $props['direction'] ?? 'left';
$speed   = max( 3, (int) ( $props['speed'] ?? 18 ) );

$is_tilt = ( 'tilt' === $style );

$paths = array(
    'scallops'  => 'M0,50 A50,50 0 0 1 100,50 L100,100 L0,100 Z',
    'waves'     => 'M0,40 C16.6,10 33.3,10 50,40 C66.6,70 83.3,70 100,40 L100,100 L0,100 Z',
    'zigzag'    => 'M0,20 L50,80 L100,20 L100,100 L0,100 Z',
    'triangles' => 'M0,70 L50,20 L100,70 L100,100 L0,100 Z',
    'tilt'      => 'M0,20 L100,80 L100,100 L0,100 Z',
);
$d = isset( $paths[ $style ] ) ? $paths[ $style ] : $paths['scallops'];

$svg = "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100' preserveAspectRatio='none'><path d='" . $d . "' fill='" . $color . "'/></svg>";
$uri = 'data:image/svg+xml,' . rawurlencode( $svg );

$uid = wf_uid( 'wfsd_', $props );

// Transforms (flip)
$tf = array();
if ( 'top' === $pos ) { $tf[] = 'scaleY(-1)'; }
if ( $flip_x )        { $tf[] = 'scaleX(-1)'; }
$tf_css = empty( $tf ) ? '' : 'transform:' . implode( ' ', $tf ) . ';';

$dx  = ( 'left' === $dir ) ? -$period : $period;
$do_anim = ( $animate && ! $is_tilt );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-sd<?= $do_anim ? ' wf-sd-anim' : '' ?>" role="presentation" aria-hidden="true"
     style="width:100%;height:<?= $height ?>px;line-height:0;background-image:url(&quot;<?= esc_attr( $uri ) ?>&quot;);<?= $is_tilt ? 'background-repeat:no-repeat;background-size:100% 100%;' : 'background-repeat:repeat-x;background-size:' . $period . 'px 100%;' ?>background-position:0 0;<?= $tf_css ?>"></div>

<?php if ( $do_anim ) : ?>
<style>
@keyframes wfsdk_<?= substr( $uid, 5 ) ?> { from { background-position:0 0; } to { background-position:<?= (int) $dx ?>px 0; } }
#<?= esc_attr( $uid ) ?>.wf-sd-anim { animation:wfsdk_<?= substr( $uid, 5 ) ?> <?= $speed ?>s linear infinite; }
@media (prefers-reduced-motion: reduce) { #<?= esc_attr( $uid ) ?>.wf-sd-anim { animation:none; } }
</style>
<?php endif; ?>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
