<?php

/**

 * WeFrame – Contact Rapide | template.php v2.0

 * Style : rond (fixe flottant) | carré (avec texte, positionnable).

 * Mode  : call | form | dual (les deux empilés).

 */

defined( 'ABSPATH' ) || exit;



// ── Props ────────────────────────────────────────────────────────────────────

$style       = $props['style']     ?? 'rond';

$mode        = $props['mode']      ?? 'call';

$phone       = trim( $props['phone']    ?? '' );

$icon_call   = $props['icon_call'] ?? 'phone';

$cf7_id      = trim( $props['cf7_id']  ?? '' );

$cf7_ttl     = $props['cf7_title'] ?? 'Nous contacter';

$icon_form   = $props['icon_form'] ?? 'mail';

$label_call  = $props['label_call']  ?? 'Nous appeler';

$label_form  = $props['label_form']  ?? 'Nous écrire';

$tip_call    = $props['tooltip_call'] ?? '';

$tip_form    = $props['tooltip_form'] ?? '';

$bg_call     = $props['bg_call']   ?? '#1E3A8A';

$bg_form     = $props['bg_form']   ?? '#1E3A8A';

$color       = $props['color']     ?? '#ffffff';

$size        = (int) ( $props['size'] ?? 56 );

$shadow      = ! empty( $props['shadow'] );

$pulse       = ! empty( $props['pulse'] );

$gap         = (int) ( $props['gap'] ?? 12 );

$c_w         = (int) ( $props['carre_width']       ?? 200 );

$c_r         = (int) ( $props['carre_radius']      ?? 0 );

$c_fs        = (int) ( $props['carre_font_size']   ?? 15 );

$c_fw        = $props['carre_font_weight'] ?? '700';

$c_hover     = $props['carre_hover']       ?? 'slide';

$pos_h       = $props['position']    ?? 'right';

$v_mode      = $props['v_mode']      ?? 'bottom';

$obot        = (int) ( $props['offset_bottom'] ?? 28 );

$top_pct     = (int) ( $props['top_pct']  ?? 40 );

$oside       = (int) ( $props['offset_side'] ?? 28 );

$hide_m      = ! empty( $props['hide_mobile'] );

$mw          = (int) ( $props['modal_width']   ?? 560 );

$mr_mod      = (int) ( $props['modal_radius']  ?? 16 );

$mp          = (int) ( $props['modal_padding'] ?? 36 );

$mbg         = $props['modal_bg'] ?? '#ffffff';



// ── Validations ──────────────────────────────────────────────────────────────

$has_call = ( $mode === 'call' || $mode === 'dual' ) && $phone;

$has_form = ( $mode === 'form' || $mode === 'dual' ) && $cf7_id;

if ( ! $has_call && ! $has_form ) {

    return;

}



if ( $has_form && ! function_exists( 'wpcf7' ) ) {

    if ( current_user_can( 'manage_options' ) ) {

        echo '<p style="color:red;font-size:12px;padding:8px;">⚠ Contact Form 7 non activé.</p>';

    }

    $has_form = false;

    if ( ! $has_call ) { return; }

}



$uid      = wf_uid( 'wfcr_', $props );

$icon_sz  = (int) round( $size * 0.44 );

$shadow_v = $shadow ? '0 4px 20px rgba(0,0,0,0.22)' : 'none';

$phone_e  = esc_attr( preg_replace( '/\s+/', '', $phone ) );



// ── Position CSS ─────────────────────────────────────────────────────────────

$pos_css = 'position:fixed;z-index:9998;';

$pos_css .= ( $pos_h === 'left' ) ? 'left:' . $oside . 'px;' : 'right:' . $oside . 'px;';

if ( $v_mode === 'bottom' ) {

    $pos_css .= 'bottom:' . $obot . 'px;';

} elseif ( $v_mode === 'top_pct' ) {

    $pos_css .= 'top:' . $top_pct . '%;';

} else { // center

    $pos_css .= 'top:50%;transform:translateY(-50%);';

}



// ── SVG icons ────────────────────────────────────────────────────────────────

$icons = [

    'phone'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 10.8 19.79 19.79 0 011 2.18 2 2 0 013 0h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L7.09 7.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 14.92z"/></svg>',

    'mail'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>',

    'whatsapp' => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>',

    'chat'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>',

    'plus'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',

    'info'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>',

    'calendar' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>',

    'location' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>',

];



// ── Pulse color per-instance (hex→rgba) ──────────────────────────────────────

// Uses first button color; generates specific @keyframes to avoid shared orange

$pulse_rgba_call = function_exists( 'wf_hex_rgba' ) ? wf_hex_rgba( $bg_call, 45 ) : 'rgba(0,0,0,0.3)';

$pulse_rgba_form = function_exists( 'wf_hex_rgba' ) ? wf_hex_rgba( $bg_form, 45 ) : 'rgba(0,0,0,0.3)';



// ── Helper: render one button ─────────────────────────────────────────────────

// Returns HTML string for rond or carré

if ( ! function_exists( 'wfcr_btn' ) ) :

function wfcr_btn( $type, $uid, $style, $size, $icon_sz, $svg, $bg, $color, $label,

                   $tooltip, $shadow_v, $pulse, $pos_h, $c_w, $c_r, $c_fs, $c_fw, $phone_e = '', $cf7_modal_id = '' ) {

    $is_call  = ( $type === 'call' );

    $btn_id   = $uid . '_' . $type;

    $pulse_cl = ( $pulse && $style === 'rond' ) ? ' wfcr-pulse-' . $type : '';

    $shadow_s = $shadow_v !== 'none' ? 'box-shadow:' . $shadow_v . ';' : '';



    if ( $style === 'rond' ) {

        $btn_style = 'width:' . $size . 'px;height:' . $size . 'px;border-radius:50%;background:' . esc_attr( $bg ) . ';color:' . esc_attr( $color ) . ';' . $shadow_s . 'display:inline-flex;align-items:center;justify-content:center;text-decoration:none;border:0;cursor:pointer;position:relative;overflow:visible;';

        $inner = '<span style="width:' . $icon_sz . 'px;height:' . $icon_sz . 'px;display:flex;align-items:center;justify-content:center;pointer-events:none;">' . $svg . '</span>';

        if ( $tooltip ) {

            $tip_side = ( $pos_h === 'left' ) ? 'left:calc(100% + 10px);' : 'right:calc(100% + 10px);';

            $inner .= '<span class="wfcr-tip" style="position:absolute;' . $tip_side . 'top:50%;transform:translateY(-50%);background:rgba(0,0,0,0.78);color:#fff;font-size:13px;font-weight:500;white-space:nowrap;padding:5px 10px;border-radius:6px;opacity:0;pointer-events:none;transition:opacity .2s;">' . esc_html( $tooltip ) . '</span>';

        }

    } else {

        // Carré — collapsed (icon only), expands on hover

        // Icon anchored to the edge side, text slides in from behind

        $pad = (int) round( $size * 0.28 ); // icon centered in collapsed state

        $btn_style = 'width:' . $size . 'px;height:' . $size . 'px;border-radius:' . $c_r . 'px;background:' . esc_attr( $bg ) . ';color:' . esc_attr( $color ) . ';' . $shadow_s . 'display:inline-flex;align-items:center;justify-content:center;text-decoration:none;border:0;cursor:pointer;overflow:hidden;position:relative;transition:width .32s cubic-bezier(.4,0,.2,1),border-radius .32s;white-space:nowrap;';

        // Icon always visible; right-pos = icon on right (flex-row-reverse), left-pos = icon on left (flex-row)

        $flex_dir = ( $pos_h === 'right' ) ? 'row-reverse' : 'row';

        $inner = '<span class="wfcr-sq-inner" style="display:flex;flex-direction:' . $flex_dir . ';align-items:center;gap:10px;padding:0 ' . $pad . 'px;width:100%;box-sizing:border-box;">'

               . '<span class="wfcr-icon" style="width:' . $icon_sz . 'px;height:' . $icon_sz . 'px;display:flex;align-items:center;justify-content:center;flex-shrink:0;">' . $svg . '</span>'

               . '<span class="wfcr-label" style="font-size:' . $c_fs . 'px;font-weight:' . esc_attr( $c_fw ) . ';white-space:nowrap;opacity:0;transform:translateX(' . ( $pos_h === 'right' ? '-8' : '8' ) . 'px);transition:opacity .25s .08s,transform .28s .06s cubic-bezier(.4,0,.2,1);pointer-events:none;">' . esc_html( $label ) . '</span>'

               . '</span>';

    }



    if ( $is_call ) {

        return '<a id="' . esc_attr( $btn_id ) . '" href="tel:' . $phone_e . '" class="wfcr-btn' . $pulse_cl . '" aria-label="' . esc_attr( $label ?: 'Appeler' ) . '" style="' . $btn_style . '">' . $inner . '</a>';

    } else {

        return '<button id="' . esc_attr( $btn_id ) . '" type="button" class="wfcr-btn' . $pulse_cl . '" aria-label="' . esc_attr( $label ?: 'Formulaire' ) . '" uk-toggle="target: #' . esc_attr( $cf7_modal_id ) . '" style="' . $btn_style . '">' . $inner . '</button>';

    }

}

endif;



// ── CF7 HTML ─────────────────────────────────────────────────────────────────

$cf7_html = '';

if ( $has_form ) {

    // Only pass id — no title= attribute to avoid CF7 lookup mismatch

    $cf7_html = do_shortcode( '[contact-form-7 id="' . esc_attr( $cf7_id ) . '"]' );

}



$modal_id = $uid . '_modal';

?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>




<div id="<?= esc_attr( $uid ) ?>-wrap" class="wfcr-wrap" style="<?= $pos_css ?>display:flex;flex-direction:column;align-items:<?= $pos_h === 'left' ? 'flex-start' : 'flex-end' ?>;gap:<?= $gap ?>px;">



    <?php if ( $has_call ) :

        echo wfcr_btn( 'call', $uid, $style, $size, $icon_sz,

            $icons[ $icon_call ] ?? $icons['phone'],

            $bg_call, $color, $label_call, $tip_call, $shadow_v, $pulse, $pos_h,

            $c_w, $c_r, $c_fs, $c_fw, $phone_e );

    endif; ?>



    <?php if ( $has_form ) :

        echo wfcr_btn( 'form', $uid, $style, $size, $icon_sz,

            $icons[ $icon_form ] ?? $icons['mail'],

            $bg_form, $color, $label_form, $tip_form, $shadow_v, $pulse, $pos_h,

            $c_w, $c_r, $c_fs, $c_fw, '', $modal_id );

    endif; ?>



</div>



<?php if ( $has_form ) : ?>

<div id="<?= esc_attr( $modal_id ) ?>" uk-modal>

    <div class="uk-modal-dialog" style="max-width:<?= $mw ?>px;margin:auto;border-radius:<?= $mr_mod ?>px;background:<?= esc_attr( $mbg ) ?>;">

        <div class="uk-modal-header" style="border-radius:<?= $mr_mod ?>px <?= $mr_mod ?>px 0 0;background:<?= esc_attr( $mbg ) ?>;">

            <h3 class="uk-modal-title" style="font-size:20px;font-weight:700;"><?= esc_html( $cf7_ttl ) ?></h3>

            <button class="uk-modal-close-default" type="button" uk-close></button>

        </div>

        <div class="uk-modal-body" style="padding:<?= $mp ?>px;background:<?= esc_attr( $mbg ) ?>;border-radius:0 0 <?= $mr_mod ?>px <?= $mr_mod ?>px;">

            <?= $cf7_html ?>

        </div>

    </div>

</div>

<?php endif; ?>



<style>

/* ── Wrap position ── */

#<?= esc_attr( $uid ) ?>-wrap { z-index:9998; }



/* ── Button base ── */

.wfcr-btn { transition: transform .18s ease, box-shadow .18s ease, filter .18s ease; }

.wfcr-btn:hover { transform: scale(1.07); }

.wfcr-btn:active { transform: scale(0.94); }

.wfcr-btn:hover .wfcr-tip { opacity:1 !important; }



<?php if ( $style === 'carre' ) : ?>

/* Carré : expand on hover → reveal label */

.wfcr-btn:hover { width: <?= $c_w ?>px !important; transform: none; }

.wfcr-btn:hover .wfcr-label { opacity:1 !important; transform:translateX(0) !important; }

.wfcr-btn:active { filter: brightness(0.88); transform:none; }

<?php endif; ?>



<?php if ( $hide_m ) : ?>

@media (max-width:767px) { #<?= esc_attr( $uid ) ?>-wrap { display:none !important; } }

<?php endif; ?>



<?php if ( $pulse && $style === 'rond' ) :

    // Per-instance pulse using actual button colors (not shared orange)

    if ( $has_call ) : ?>

@keyframes wfcr_pulse_call_<?= $uid ?> {

    0%   { box-shadow: 0 0 0 0 <?= $pulse_rgba_call ?>; }

    70%  { box-shadow: 0 0 0 14px rgba(0,0,0,0); }

    100% { box-shadow: 0 0 0 0 rgba(0,0,0,0); }

}

#<?= esc_attr( $uid ) ?>_call { animation: wfcr_pulse_call_<?= $uid ?> 2s ease-out infinite; }

#<?= esc_attr( $uid ) ?>_call:hover { animation: none; }

/* La regle globale du plugin ne couvre que les racines en .wf-* : ces deux
   pastilles sont ciblees par leur id, il leur faut donc leur propre garde. */
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?>_call,#<?= esc_attr( $uid ) ?>_form { animation: none !important; }
}

<?php   endif;

    if ( $has_form ) : ?>

@keyframes wfcr_pulse_form_<?= $uid ?> {

    0%   { box-shadow: 0 0 0 0 <?= $pulse_rgba_form ?>; }

    70%  { box-shadow: 0 0 0 14px rgba(0,0,0,0); }

    100% { box-shadow: 0 0 0 0 rgba(0,0,0,0); }

}

#<?= esc_attr( $uid ) ?>_form { animation: wfcr_pulse_form_<?= $uid ?> 2s ease-out infinite 0.6s; }

#<?= esc_attr( $uid ) ?>_form:hover { animation: none; }

<?php   endif; ?>

<?php endif; ?>



/* CF7 modal */

#<?= esc_attr( $modal_id ) ?> .wpcf7-form { display:flex;flex-direction:column;gap:14px; }

#<?= esc_attr( $modal_id ) ?> .wpcf7-form-control { width:100%;box-sizing:border-box; }

#<?= esc_attr( $modal_id ) ?> .wpcf7-submit { cursor:pointer; }

</style>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
