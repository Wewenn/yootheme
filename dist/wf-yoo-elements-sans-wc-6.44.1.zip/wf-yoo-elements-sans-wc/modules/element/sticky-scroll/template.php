<?php
/**
 * WeFrame – Récit collant (parent) | média sticky qui change selon l'étape active + texte qui défile.
 * Chaque étape = un item (image médiathèque + titre + texte).
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$side = ( 'right' === ( $props['side'] ?? 'left' ) ) ? 'right' : 'left';
$rad  = max( 0, (int) ( $props['radius'] ?? 16 ) );

$html = '';
foreach ( $children as $child ) {
    $html .= $builder->render( $child, array( 'element' => $props ) );
}
if ( ! trim( $html ) ) { return; }

$uid = wf_uid( 'wfss_', $props, count( $children ) );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-ss wf-ss--<?= esc_attr( $side ) ?>" style="display:grid;grid-template-columns:1fr 1fr;gap:44px;align-items:start;">
    <div class="wf-ss-media" style="position:sticky;top:12vh;height:76vh;border-radius:<?= $rad ?>px;overflow:hidden;background:#f0f0f0;<?= 'right' === $side ? 'order:2;' : '' ?>"></div>
    <div class="wf-ss-steps"><?= $html ?></div>
</div>
<style>
#<?= esc_attr( $uid ) ?> .wf-ss-step{min-height:74vh;display:flex;flex-direction:column;justify-content:center;opacity:.28;transition:opacity .4s ease,transform .4s ease;transform:translateY(12px);}
#<?= esc_attr( $uid ) ?> .wf-ss-step.on{opacity:1;transform:translateY(0);}
@media(max-width:782px){
    #<?= esc_attr( $uid ) ?>{grid-template-columns:1fr !important;gap:8px !important;}
    #<?= esc_attr( $uid ) ?> .wf-ss-media{display:none !important;}
    #<?= esc_attr( $uid ) ?> .wf-ss-step{min-height:auto !important;padding:26px 0;opacity:1 !important;transform:none !important;}
    #<?= esc_attr( $uid ) ?> .wf-ss-step-img{display:block !important;}
}
</style>
<script>
(function(){
    var root = document.getElementById('<?= esc_js( $uid ) ?>'); if (!root) return;
    var media = root.querySelector('.wf-ss-media');
    var steps = root.querySelectorAll('.wf-ss-step');
    if (!media) return; if (!steps.length) return;
    var imgs = [];
    for (var i = 0; i < steps.length; i++){
        var u = steps[i].getAttribute('data-img');
        var im = document.createElement('div');
        im.style.cssText = 'position:absolute;inset:0;background-size:cover;background-position:center;opacity:0;transition:opacity .5s ease;';
        if (u) im.style.backgroundImage = 'url(' + u + ')';
        media.appendChild(im); imgs.push(im);
    }
    if (imgs[0]) imgs[0].style.opacity = '1';
    var ticking = false;
    function upd(){
        ticking = false;
        var vh = window.innerHeight || document.documentElement.clientHeight, mid = vh / 2;
        var best = 0, bd = 1e9;
        for (var i = 0; i < steps.length; i++){
            var r = steps[i].getBoundingClientRect();
            var c = r.top + r.height / 2, d = Math.abs(c - mid);
            if (d < bd) { bd = d; best = i; }
        }
        for (var j = 0; j < steps.length; j++){
            if (j === best) { steps[j].classList.add('on'); } else { steps[j].classList.remove('on'); }
            if (imgs[j]) { imgs[j].style.opacity = (j === best) ? '1' : '0'; }
        }
    }
    function onS(){ if (!ticking) { ticking = true; requestAnimationFrame(upd); } }
    window.addEventListener('scroll', onS, { passive: true });
    window.addEventListener('resize', onS, { passive: true });
    upd();
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
