<?php
defined('ABSPATH') || exit;
if (empty($children)) return;
$layout = $props['layout']??'horizontal'; $gap = (int)($props['gap']??32); $gm = (int)($props['gap_mobile']??16);
$div = !empty($props['divider']); $dc = $props['divider_color']??'#e5e5e5'; $al = $props['align']??'center';
$uid = 'wftb_'.substr(md5(serialize($props).count($children)),0,8);
$html = '';
foreach ($children as $child) { $html .= $builder->render($child, ['element'=>$props]); }
if (!trim($html)) return;
$dir = ($layout === 'horizontal') ? 'row' : 'column';
$jc = ($al === 'center') ? 'justify-content:center;' : '';
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr($uid) ?>" style="display:flex;flex-direction:<?= $dir ?>;gap:<?= $gap ?>px;flex-wrap:wrap;align-items:center;<?= $jc ?>">
<?= $html ?>
</div>
<style>
<?php if ($div) : ?>
#<?= esc_attr($uid) ?> .wf-tb-item+.wf-tb-item{<?= $layout==='horizontal'?"border-left:1px solid ".esc_attr($dc).";padding-left:{$gap}px;":"border-top:1px solid ".esc_attr($dc).";padding-top:{$gap}px;" ?>}
<?php endif; ?>
@media(max-width:767px){#<?= esc_attr($uid) ?>{flex-direction:column !important;gap:<?= $gm ?>px !important}
<?php if ($div) : ?>#<?= esc_attr($uid) ?> .wf-tb-item+.wf-tb-item{border-left:none !important;padding-left:0 !important;border-top:1px solid <?= esc_attr($dc) ?>;padding-top:<?= $gm ?>px}<?php endif; ?>
}
</style>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
