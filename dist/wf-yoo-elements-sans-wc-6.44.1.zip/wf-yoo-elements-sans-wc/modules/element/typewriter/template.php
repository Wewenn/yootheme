<?php
/**
 * WeFrame – Typewriter | template.php v6.0
 */
defined( 'ABSPATH' ) || exit;

$prefix  = $props['prefix'] ?? '';
$words_r = trim( $props['words'] ?? '' );
$suffix  = $props['suffix'] ?? '';
if ( ! $words_r ) { return; }

$words   = array_values( array_filter( array_map( 'trim', explode( "\n", $words_r ) ) ) );
if ( empty( $words ) ) { return; }

$ts      = (int) ( $props['type_speed'] ?? 80 );
$ds      = (int) ( $props['delete_speed'] ?? 40 );
$pause   = (int) ( $props['pause'] ?? 2000 );
$loop    = ! empty( $props['loop'] );
$cursor  = ! empty( $props['cursor'] );
$cc      = $props['cursor_char'] ?? '|';
$fs      = (int) ( $props['font_size'] ?? 48 );
$fsm     = (int) ( $props['font_size_mobile'] ?? 28 );
$fw      = $props['font_weight'] ?? '700';
$tc      = $props['text_color'] ?? '#000';
$wc      = $props['word_color'] ?? '#EA5C1C';
$align   = $props['align'] ?? 'center';

$uid = wf_uid( 'wftw_', $props );

$cfg = json_encode( [
    'uid' => $uid, 'words' => $words, 'ts' => $ts, 'ds' => $ds,
    'pause' => $pause, 'loop' => $loop,
], JSON_HEX_AMP | JSON_HEX_APOS );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-typewriter" style="text-align:<?= esc_attr( $align ) ?>;font-size:<?= $fs ?>px;font-weight:<?= esc_attr( $fw ) ?>;color:<?= esc_attr( $tc ) ?>;line-height:1.3;">
    <?php if ( $prefix ) : ?><span class="wf-tw-prefix"><?= esc_html( $prefix ) ?></span><?php endif; ?>
    <span class="wf-tw-word" style="color:<?= esc_attr( $wc ) ?>;"></span>
    <?php if ( $cursor ) : ?><span class="wf-tw-cursor" style="color:<?= esc_attr( $wc ) ?>;animation:wf-tw-blink .7s step-end infinite;"><?= esc_html( $cc ) ?></span><?php endif; ?>
    <?php if ( $suffix ) : ?><span class="wf-tw-suffix"><?= esc_html( $suffix ) ?></span><?php endif; ?>
</div>

<style>
@keyframes wf-tw-blink{0%,100%{opacity:1}50%{opacity:0}}
@media(max-width:767px){#<?= esc_attr( $uid ) ?>{font-size:<?= $fsm ?>px !important}}
</style>

<script>
(function(){
    
    var c = <?= $cfg ?>;
    var el=document.getElementById(c.uid);if(!el)return;
    var span=el.querySelector('.wf-tw-word');if(!span)return;
    if (typeof WF !== 'undefined' && WF.reducedMotion && WF.reducedMotion()) { span.textContent = c.words[0] || ''; return; } // reduced-motion : mot entier, pas de frappe
    var wi=0,ci=0,deleting=false;
    function tick(){
        var word=c.words[wi];
        if(!deleting){
            span.textContent=word.substring(0,ci+1);ci++;
            if(ci>=word.length){
                if(!c.loop&&wi>=c.words.length-1)return;
                setTimeout(function(){deleting=true;tick()},c.pause);return;
            }
            setTimeout(tick,c.ts);
        }else{
            span.textContent=word.substring(0,ci);ci--;
            if(ci<0){ci=0;deleting=false;wi=(wi+1)%c.words.length;setTimeout(tick,300);return}
            setTimeout(tick,c.ds);
        }
    }
    WF.onVisible(el,function(){tick()});
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
