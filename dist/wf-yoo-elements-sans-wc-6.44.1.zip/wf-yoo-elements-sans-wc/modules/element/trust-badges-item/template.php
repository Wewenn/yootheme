<?php
defined('ABSPATH') || exit;
$icon = $props['icon']??''; $img = $props['image']??''; $title = $props['title']??''; $desc = $props['description']??'';
if (!$title) return;
if ($img) { if (!preg_match('#^https?://#i',$img)) $img='/'.ltrim($img,'/'); }
$is = (int)($element['icon_size']??28); $ic = $element['icon_color']??'#EA5C1C';
$ts = (int)($element['title_size']??14); $tw = $element['title_weight']??'700';
$ds = (int)($element['desc_size']??13); $dsc = $element['desc_color']??'#666';
$al = $element['align']??'center';
$icons = [
    'check'=>'<svg width="'.$is.'" height="'.$is.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
    'truck'=>'<svg width="'.$is.'" height="'.$is.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>',
    'lock'=>'<svg width="'.$is.'" height="'.$is.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>',
    'headphones'=>'<svg width="'.$is.'" height="'.$is.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/></svg>',
    'refresh'=>'<svg width="'.$is.'" height="'.$is.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>',
    'star'=>'<svg width="'.$is.'" height="'.$is.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
    'heart'=>'<svg width="'.$is.'" height="'.$is.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78L12 21.23l8.84-8.84a5.5 5.5 0 0 0 0-7.78z"/></svg>',
    'shield'=>'<svg width="'.$is.'" height="'.$is.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
    'clock'=>'<svg width="'.$is.'" height="'.$is.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
];
?>
<div class="wf-tb-item" style="display:flex;align-items:center;gap:12px;text-align:<?= esc_attr($al) ?>;<?= $al==='center'?'flex-direction:column;':'' ?>">
    <?php if ($img) : ?>
    <img src="<?= esc_url($img) ?>" alt="" loading="lazy" style="width:<?= $is ?>px;height:<?= $is ?>px;object-fit:contain;">
    <?php elseif ($icon && isset($icons[$icon])) : ?>
    <div style="color:<?= esc_attr($ic) ?>;flex-shrink:0;"><?= $icons[$icon] ?></div>
    <?php endif; ?>
    <div>
        <div style="font-size:<?= $ts ?>px;font-weight:<?= esc_attr($tw) ?>;line-height:1.3;"><?= esc_html($title) ?></div>
        <?php if ($desc) : ?><div style="font-size:<?= $ds ?>px;color:<?= esc_attr($dsc) ?>;line-height:1.4;margin-top:2px;"><?= esc_html($desc) ?></div><?php endif; ?>
    </div>
</div>
