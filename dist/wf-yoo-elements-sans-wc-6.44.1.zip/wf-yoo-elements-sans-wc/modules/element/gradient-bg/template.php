<?php
/**
 * WeFrame – Gradient Background | template.php v6.0
 * Animated mesh gradient — pure CSS, zero JS.
 */
defined( 'ABSPATH' ) || exit;

$c1      = $props['color_1'] ?? '#EA5C1C';
$c2      = $props['color_2'] ?? '#8B5CF6';
$c3      = $props['color_3'] ?? '#06B6D4';
$c4      = $props['color_4'] ?? '#10B981';
$speed   = max( 3, (int) ( $props['speed'] ?? 8 ) );
$minh    = (int) ( $props['min_height'] ?? 400 );
$pad     = (int) ( $props['padding'] ?? 64 );
$overlay = ! empty( $props['overlay'] );
$ov_c    = $props['overlay_color'] ?? 'rgba(0,0,0,0.3)';
$radius  = (int) ( $props['radius'] ?? 0 );

$uid = wf_uid( 'wfgb_', $props );

$inner = '';
if ( ! empty( $children ) ) {
    foreach ( $children as $child ) {
        $inner .= $builder->render( $child, [ 'element' => $props ] );
    }
}
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-gradient-bg" style="position:relative;min-height:<?= $minh ?>px;padding:<?= $pad ?>px;border-radius:<?= $radius ?>px;overflow:hidden;background:linear-gradient(-45deg,<?= esc_attr( $c1 ) ?>,<?= esc_attr( $c2 ) ?>,<?= esc_attr( $c3 ) ?>,<?= esc_attr( $c4 ) ?>);background-size:400% 400%;animation:wf-gb-shift <?= $speed ?>s ease infinite;">
    <?php if ( $overlay ) : ?>
    <div style="position:absolute;inset:0;background:<?= esc_attr( $ov_c ) ?>;border-radius:<?= $radius ?>px;pointer-events:none;"></div>
    <?php endif; ?>
    <?php if ( $inner ) : ?>
    <div style="position:relative;z-index:1;"><?= $inner ?></div>
    <?php endif; ?>
</div>

<style>
@keyframes wf-gb-shift{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}
@media(prefers-reduced-motion:reduce){#<?= esc_attr( $uid ) ?>{animation:none}}
</style>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
