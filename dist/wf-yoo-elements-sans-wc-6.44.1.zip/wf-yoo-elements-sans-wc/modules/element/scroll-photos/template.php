<?php
/**
 * WeFrame – Scroll Photos | template.php
 * Two scroll modes:
 *   - flyin : sticky centered title, side photos fly in progressively
 *   - pin   : Framer-style pinned section, photos scroll horizontally,
 *             section locked until all photos are seen
 * Config inlined as a JS object (no <script type="application/json"> block)
 * and no "&&" in the inline JS — avoids WordPress ampersand-encoding that
 * breaks inline scripts on this setup. All string ops are guarded.
 */
defined( 'ABSPATH' ) || exit;

// Defensive: container context must be present.
if ( ! isset( $children ) || ! is_array( $children ) || empty( $children ) ) { return; }
if ( ! isset( $builder ) || ! is_object( $builder ) ) { return; }

$props = is_array( $props ?? null ) ? $props : array();

// ── Common props ───────────────────────────────────────
$mode       = $props['mode'] ?? 'flyin';
$title      = trim( (string) ( $props['title'] ?? '' ) );
$t_size     = (int) ( $props['title_size']          ?? 64 );
$t_size_t   = (int) ( $props['title_size_tablet']   ?? 48 );
$t_size_m   = (int) ( $props['title_size_mobile']   ?? 32 );
$t_weight   = (string) ( $props['title_weight']     ?? '700' );
$t_lh       = (int) ( $props['title_line_height']   ?? 108 );
$t_ls       = (float) ( $props['title_letter_spacing'] ?? -1.5 );
$t_color    = (string) ( $props['title_color']      ?? '#111111' );
$t_maxw     = (int) ( $props['title_max_width']     ?? 640 );
$t_font     = trim( (string) ( $props['title_font'] ?? '' ) );
$bg         = trim( (string) ( $props['bg'] ?? '' ) );
$offset     = min( 300, max( 0, (int) ( $props['sticky_offset'] ?? 0 ) ) );

// ── Render children once ───────────────────────────────
$items = array();
foreach ( $children as $i => $child ) {
    $inner = '';
    try {
        $inner = (string) $builder->render( $child, array( 'element' => $props ) );
    } catch ( \Throwable $e ) {
        $inner = '';
    }
    if ( ! trim( $inner ) ) { continue; }
    $cp = ( is_array( $child ) && isset( $child['props'] ) && is_array( $child['props'] ) ) ? $child['props'] : array();
    $items[] = array( 'html' => $inner, 'cp' => $cp );
}
if ( empty( $items ) ) { return; }

$uid = wf_uid( 'wfsp_', $props, count( $items ) );
$ff  = $t_font ? 'font-family:' . $t_font . ';' : '';
$bgc = $bg ? 'background:' . esc_attr( $bg ) . ';' : '';
$n   = count( $items );

/* =======================================================================
 * MODE: PIN — horizontal pinned gallery (Framer style)
 * ===================================================================== */
if ( $mode === 'pin' ) :

    $per_photo   = min( 120, max( 30, (int) ( $props['pin_scroll_per_photo'] ?? 70 ) ) );
    $card_ratio  = (string) ( $props['card_ratio'] ?? '3/4' );
    $card_gap    = min( 80, max( 0, (int) ( $props['card_gap'] ?? 24 ) ) );
    $card_height = min( 100, max( 40, (int) ( $props['card_height'] ?? 78 ) ) );
    $show_prog   = ! empty( $props['show_progress'] );
    $prog_color  = (string) ( $props['progress_color'] ?? '#111111' );
    $total_vh    = max( 120, $n * $per_photo + 40 );

    $cfg = wp_json_encode( array(
        'uid'  => $uid,
        'mode' => 'pin',
    ), JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE );

    $allowed_ratio = array( '1/1', '3/4', '4/5', '2/3', '4/3', '3/2', '16/9', '9/16' );
    if ( ! in_array( $card_ratio, $allowed_ratio, true ) ) { $card_ratio = '3/4'; }
    ?>
<?php $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( 'div' ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
    <div id="<?= esc_attr( $uid ) ?>" class="wf-sp wf-sp--pin" style="position:relative;height:<?= $total_vh ?>vh;<?= $bgc ?>">
        <div class="wf-sp-pin-sticky" style="position:sticky;top:<?= $offset ?>px;height:calc(100vh - <?= $offset ?>px);overflow:hidden;display:flex;flex-direction:column;justify-content:center;">
            <?php if ( $title ) : ?>
            <div class="wf-sp-pin-head" style="flex:0 0 auto;padding:32px 5vw 20px;color:<?= esc_attr( $t_color ) ?>;font-size:<?= $t_size ?>px;font-weight:<?= esc_attr( $t_weight ) ?>;line-height:<?= $t_lh ?>%;letter-spacing:<?= $t_ls ?>px;max-width:<?= $t_maxw ?>px;<?= $ff ?>"><?= nl2br( esc_html( $title ) ) ?></div>
            <?php endif; ?>

            <?php if ( $show_prog ) : ?>
            <div class="wf-sp-pbar-wrap" style="flex:0 0 auto;margin:0 5vw 16px;height:3px;background:rgba(0,0,0,.08);border-radius:3px;overflow:hidden;">
                <div class="wf-sp-pbar" style="height:100%;width:0;background:<?= esc_attr( $prog_color ) ?>;transition:width .05s linear;"></div>
            </div>
            <?php endif; ?>

            <div class="wf-sp-track" style="display:flex;align-items:center;gap:<?= $card_gap ?>px;padding:0 5vw;height:<?= $card_height ?>%;will-change:transform;">
                <?php foreach ( $items as $it ) : ?>
                <div class="wf-sp-slide" style="flex:0 0 auto;height:100%;aspect-ratio:<?= esc_attr( $card_ratio ) ?>;"><?= $it['html'] ?></div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <style>
    #<?= esc_attr( $uid ) ?> .wf-sp-slide .wf-sp-fig { height: 100%; }
    #<?= esc_attr( $uid ) ?> .wf-sp-slide .wf-sp-fig img { width: 100%; height: 100%; object-fit: cover; }
    @media (min-width:768px) and (max-width:1024px) { #<?= esc_attr( $uid ) ?> .wf-sp-pin-head { font-size:<?= $t_size_t ?>px !important; } }
    @media (max-width:767px) {
        #<?= esc_attr( $uid ) ?> .wf-sp-pin-head { font-size:<?= $t_size_m ?>px !important; padding:20px 20px 12px !important; }
        #<?= esc_attr( $uid ) ?> .wf-sp-track { padding:0 20px !important; height:70% !important; }
    }
    @media (prefers-reduced-motion: reduce) {
        #<?= esc_attr( $uid ) ?> { height:auto !important; }
        #<?= esc_attr( $uid ) ?> .wf-sp-pin-sticky { position:static !important; height:auto !important; }
        #<?= esc_attr( $uid ) ?> .wf-sp-track { flex-wrap:wrap !important; transform:none !important; height:auto !important; }
        #<?= esc_attr( $uid ) ?> .wf-sp-slide { height:auto !important; width:280px; }
    }
    </style>

    <script>
    (function(){
        var C = <?= $cfg ?>;
        function boot(){
            var el = document.getElementById(C.uid); if (!el) return;
            var sticky = el.querySelector('.wf-sp-pin-sticky'); if (!sticky) return;
            var track = el.querySelector('.wf-sp-track'); if (!track) return;
            var bar = el.querySelector('.wf-sp-pbar');
            var ticking = false;

            function clamp(v){ if (v < 0) return 0; if (v > 1) return 1; return v; }

            function update(){
                ticking = false;
                var range = el.offsetHeight - sticky.offsetHeight;
                if (range <= 0) { track.style.transform = 'none'; return; }
                var p = clamp((window.pageYOffset - el.offsetTop) / range);
                var maxMove = track.scrollWidth - sticky.clientWidth;
                if (maxMove < 0) { maxMove = 0; }
                track.style.transform = 'translateX(-' + (p * maxMove).toFixed(1) + 'px)';
                if (bar) { bar.style.width = (p * 100).toFixed(1) + '%'; }
            }
            function onScroll(){ if (!ticking) { ticking = true; requestAnimationFrame(update); } }

            window.addEventListener('scroll', onScroll, { passive: true });
            window.addEventListener('resize', update, { passive: true });
            update();
        }
        if (window.WF) { if (WF.ready) { WF.ready(boot); return; } }
        if (document.readyState !== 'loading') { boot(); } else { document.addEventListener('DOMContentLoaded', boot); }
    })();
    </script>
    <?php
    return;
endif;

/* =======================================================================
 * MODE: FLYIN — sticky title + side photos fly in
 * ===================================================================== */
$scroll_len = min( 600, max( 150, (int) ( $props['scroll_length'] ?? 320 ) ) );
$span       = min( 60, max( 10, (int) ( $props['reveal_span'] ?? 32 ) ) ) / 100;
$dist       = min( 300, max( 0, (int) ( $props['slide_distance'] ?? 110 ) ) );
$rise       = min( 200, max( 0, (int) ( $props['rise'] ?? 40 ) ) );
$pw         = min( 520, max( 120, (int) ( $props['photo_width'] ?? 300 ) ) );
$mobile_stack = ( ( $props['mobile_mode'] ?? 'stack' ) === 'stack' );

$photos   = '';
$k        = 0;
$left_ct  = 0;
$right_ct = 0;
foreach ( $items as $it ) {
    $cp   = $it['cp'];
    $side = isset( $cp['side'] ) ? $cp['side'] : 'auto';
    if ( $side !== 'left' && $side !== 'right' ) {
        $side = ( $k % 2 === 0 ) ? 'left' : 'right';
    }
    if ( $side === 'left' ) {
        $side_idx = $left_ct; $left_ct++; $dir = -1; $extra_top = 0;
    } else {
        $side_idx = $right_ct; $right_ct++; $dir = 1; $extra_top = 16;
    }
    $top_pct = 12 + ( $side_idx * 34 ) + $extra_top;
    if ( $top_pct > 82 ) { $top_pct = 82; }
    $inset_pct = 3 + ( $side_idx * 2 );
    if ( $inset_pct > 9 ) { $inset_pct = 9; }
    $wov = (int) ( isset( $cp['width_override'] ) ? $cp['width_override'] : 0 );
    $w   = $wov > 0 ? $wov : $pw;
    $edge = ( $side === 'left' ) ? 'left' : 'right';

    $photos .= '<div class="wf-sp-photo" data-i="' . $k . '" data-dir="' . $dir . '" '
        . 'style="position:absolute;top:' . $top_pct . '%;' . $edge . ':' . $inset_pct . '%;'
        . 'width:' . $w . 'px;max-width:42%;opacity:0;z-index:1;will-change:transform,opacity;">'
        . $it['html'] . '</div>';
    $k++;
}

$cfg = wp_json_encode( array(
    'uid'    => $uid,
    'mode'   => 'flyin',
    'n'      => $k,
    'span'   => $span,
    'dist'   => $dist,
    'rise'   => $rise,
    'mStack' => $mobile_stack ? 1 : 0,
), JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE );
?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-sp wf-sp--flyin" style="position:relative;height:<?= $scroll_len ?>vh;<?= $bgc ?>">
    <div class="wf-sp-sticky" style="position:sticky;top:<?= $offset ?>px;height:calc(100vh - <?= $offset ?>px);overflow:hidden;">
        <div class="wf-sp-inner" style="position:relative;width:100%;height:100%;display:flex;align-items:center;justify-content:center;padding:0 5vw;box-sizing:border-box;">
            <?php if ( $title ) : ?>
            <div class="wf-sp-title" style="position:relative;z-index:2;max-width:<?= $t_maxw ?>px;text-align:center;color:<?= esc_attr( $t_color ) ?>;font-size:<?= $t_size ?>px;font-weight:<?= esc_attr( $t_weight ) ?>;line-height:<?= $t_lh ?>%;letter-spacing:<?= $t_ls ?>px;<?= $ff ?>"><?= nl2br( esc_html( $title ) ) ?></div>
            <?php endif; ?>
            <?= $photos ?>
        </div>
    </div>
</div>

<style>
#<?= esc_attr( $uid ) ?> .wf-sp-photo { transition: opacity .05s linear; }
#<?= esc_attr( $uid ) ?> .wf-sp-fig img { pointer-events: none; }
@media (min-width: 768px) and (max-width: 1024px) { #<?= esc_attr( $uid ) ?> .wf-sp-title { font-size: <?= $t_size_t ?>px !important; } }
@media (max-width: 767px) {
    #<?= esc_attr( $uid ) ?> .wf-sp-title { font-size: <?= $t_size_m ?>px !important; }
    <?php if ( $mobile_stack ) : ?>
    #<?= esc_attr( $uid ) ?> { height: auto !important; }
    #<?= esc_attr( $uid ) ?> .wf-sp-sticky { position: static !important; height: auto !important; overflow: visible !important; }
    #<?= esc_attr( $uid ) ?> .wf-sp-inner { display: block !important; padding: 0 20px !important; }
    #<?= esc_attr( $uid ) ?> .wf-sp-title { margin: 0 auto 32px !important; max-width: 100% !important; }
    #<?= esc_attr( $uid ) ?> .wf-sp-photo { position: static !important; width: 100% !important; max-width: 420px !important; margin: 0 auto 24px !important; opacity: 1 !important; transform: none !important; }
    <?php endif; ?>
}
@media (prefers-reduced-motion: reduce) { #<?= esc_attr( $uid ) ?> .wf-sp-photo { opacity: 1 !important; transform: none !important; } }
</style>

<script>
(function(){
    var C = <?= $cfg ?>;
    function boot(){
        var el = document.getElementById(C.uid); if (!el) return;
        var photos = el.querySelectorAll('.wf-sp-photo');
        if (photos.length < 1) return;

        function showAll(){
            var i = 0;
            while (i < photos.length) { photos[i].style.opacity = '1'; photos[i].style.transform = 'none'; i++; }
        }
        if (C.mStack) { if (window.innerWidth <= 767) { showAll(); return; } }

        var ticking = false;
        function clamp(v){ if (v < 0) return 0; if (v > 1) return 1; return v; }
        function update(){
            ticking = false;
            var range = el.offsetHeight - window.innerHeight;
            if (range <= 0) { showAll(); return; }
            var p = clamp((window.pageYOffset - el.offsetTop) / range);
            var i = 0;
            while (i < photos.length) {
                var start = (i / C.n) * (1 - C.span);
                var rev = clamp((p - start) / C.span);
                var dir = parseFloat(photos[i].getAttribute('data-dir')) || 1;
                var x = dir * C.dist * (1 - rev);
                var y = C.rise * (1 - rev);
                var s = 0.92 + 0.08 * rev;
                photos[i].style.opacity = '' + rev;
                photos[i].style.transform = 'translate(' + x.toFixed(1) + 'px,' + y.toFixed(1) + 'px) scale(' + s.toFixed(3) + ')';
                i++;
            }
        }
        function onScroll(){ if (!ticking) { ticking = true; requestAnimationFrame(update); } }
        window.addEventListener('scroll', onScroll, { passive: true });
        window.addEventListener('resize', function(){
            if (C.mStack) { if (window.innerWidth <= 767) { showAll(); return; } }
            update();
        }, { passive: true });
        update();
    }
    if (window.WF) { if (WF.ready) { WF.ready(boot); return; } }
    if (document.readyState !== 'loading') { boot(); } else { document.addEventListener('DOMContentLoaded', boot); }
})();
</script>

<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
