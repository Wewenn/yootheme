<?php
/**
 * WeFrame – Logos en orbite | template.php v1.0
 * Un centre, des logos qui tournent autour sur une a trois orbites.
 *
 * Zero JS : chaque logo est place sur son orbite par une rotation CSS, et
 * contre-tourne a la meme vitesse pour rester droit. Les noms restent dans le
 * DOM meme s'ils ne sont pas affiches : la liste des partenaires est lisible
 * par un lecteur d'ecran et par un moteur de recherche.
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$centerLabel = trim( (string) ( $props['center_label'] ?? '' ) );
$centerImg   = $props['center_image'] ?? '';
if ( is_array( $centerImg ) ) { $centerImg = $centerImg['src'] ?? ( $centerImg['url'] ?? '' ); }
$centerImg = trim( (string) $centerImg );

$size    = max( 240, (int) ( $props['size'] ?? 460 ) );
$orbits  = max( 1, min( 3, (int) ( $props['orbits'] ?? 2 ) ) );
$radii   = array(
	max( 15, min( 50, (int) ( $props['radius_1'] ?? 34 ) ) ),
	max( 15, min( 50, (int) ( $props['radius_2'] ?? 48 ) ) ),
	max( 15, min( 50, (int) ( $props['radius_3'] ?? 60 ) ) ),
);
$speed   = max( 5, (int) ( $props['speed'] ?? 26 ) );
$revAlt  = ! empty( $props['reverse_alt'] );
$pause   = ! empty( $props['pause_hover'] );

$iSize   = max( 24, (int) ( $props['item_size'] ?? 54 ) );
$cSize   = max( 40, (int) ( $props['center_size'] ?? 96 ) );
$labels  = ! empty( $props['show_labels'] );
$paths   = ! empty( $props['show_paths'] );

$pCol  = (string) ( $props['path_color'] ?? '#e5e5ea' );
$iBg   = (string) ( $props['item_bg'] ?? '#ffffff' );
$iBd   = (string) ( $props['item_border'] ?? '#e8e8ec' );
$cBg   = (string) ( $props['center_bg'] ?? '#111111' );
$cCol  = (string) ( $props['center_color'] ?? '#ffffff' );
$lCol  = (string) ( $props['label_color'] ?? '#6b7280' );

$list = array();
foreach ( $children as $i => $child ) {
	$cp  = (array) ( $child->props ?? array() );
	$img = $cp['image'] ?? '';
	if ( is_array( $img ) ) { $img = $img['src'] ?? ( $img['url'] ?? '' ); }
	$label = trim( (string) ( $cp['label'] ?? '' ) );
	if ( '' === $label ) { $label = sprintf( __( 'Logo %d', 'weframe' ), $i + 1 ); }

	$link = $cp['link'] ?? '';
	if ( is_array( $link ) ) { $link = $link['url'] ?? ''; }

	$list[] = array(
		'label' => $label,
		'img'   => trim( (string) $img ),
		'link'  => trim( (string) $link ),
	);
}
$n = count( $list );

// Repartition : on remplit orbite par orbite, dans l'ordre de la liste.
// Angles et vitesses calcules ici, pas dans le corps du gabarit : c'est plus
// simple a relire, et le rendu reste testable hors WordPress.
$buckets = array();
for ( $o = 0; $o < $orbits; $o++ ) { $buckets[ $o ] = array(); }
foreach ( $list as $k => $it ) { $buckets[ $k % $orbits ][] = $it; }

$rings = array();
foreach ( $buckets as $o => $bucket ) {
	if ( empty( $bucket ) ) { continue; }
	$cnt = count( $bucket );
	$slots = array();
	foreach ( $bucket as $k => $it ) {
		$it['angle'] = round( $k * 360 / $cnt, 2 );
		$slots[] = $it;
	}
	$rings[] = array(
		'r'     => $radii[ $o ],
		'dur'   => $speed + $o * 6,
		'rev'   => ( $revAlt && 1 === $o % 2 ),
		'slots' => $slots,
	);
}

$uid = wf_uid( 'wfor_', $props, $n );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-or<?= $pause ? ' wf-or--pause' : '' ?>">
	<div class="__stage">
		<?php if ( $paths ) : ?>
			<?php for ( $o = 0; $o < $orbits; $o++ ) : ?>
			<span class="__path" style="width:<?= (int) ( $radii[ $o ] * 2 ) ?>%;height:<?= (int) ( $radii[ $o ] * 2 ) ?>%;" aria-hidden="true"></span>
			<?php endfor; ?>
		<?php endif; ?>

		<div class="__center">
			<?php if ( '' !== $centerImg ) : ?>
			<img src="<?= esc_url( $centerImg ) ?>" alt="<?= esc_attr( $centerLabel ) ?>" loading="lazy" decoding="async">
			<?php elseif ( '' !== $centerLabel ) : ?>
			<span><?= esc_html( $centerLabel ) ?></span>
			<?php endif; ?>
		</div>

		<?php foreach ( $rings as $ring ) : ?>
		<ul class="__ring" style="--r:<?= (int) $ring['r'] ?>;--dur:<?= (int) $ring['dur'] ?>s;--dir:<?= $ring['rev'] ? 'reverse' : 'normal' ?>;--dirr:<?= $ring['rev'] ? 'normal' : 'reverse' ?>;">
			<?php foreach ( $ring['slots'] as $it ) : ?>
			<li class="__slot" style="--a:<?= esc_attr( $it['angle'] ) ?>deg;">
				<span class="__anti"><span class="__spin">
					<?php if ( '' !== $it['link'] ) : ?>
					<a class="__logo" href="<?= esc_url( $it['link'] ) ?>">
					<?php else : ?>
					<span class="__logo">
					<?php endif; ?>
						<?php if ( '' !== $it['img'] ) : ?>
						<img src="<?= esc_url( $it['img'] ) ?>" alt="<?= esc_attr( $it['label'] ) ?>" loading="lazy" decoding="async">
						<?php else : ?>
						<span class="__initial" aria-hidden="true"><?= esc_html( mb_substr( $it['label'], 0, 1 ) ) ?></span>
						<span class="wf-sr"><?= esc_html( $it['label'] ) ?></span>
						<?php endif; ?>
					<?php if ( '' !== $it['link'] ) : ?>
					</a>
					<?php else : ?>
					</span>
					<?php endif; ?>
					<?php if ( $labels ) : ?><span class="__name"><?= esc_html( $it['label'] ) ?></span><?php endif; ?>
				</span></span>
			</li>
			<?php endforeach; ?>
		</ul>
		<?php endforeach; ?>
	</div>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?>{display:flex;justify-content:center;container-type:inline-size;}
#<?= esc_attr( $uid ) ?> .__stage{
	position:relative;width:min(<?= (int) $size ?>px,100%);aspect-ratio:1 / 1;
}
#<?= esc_attr( $uid ) ?> .__path{
	position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);
	border:1px dashed <?= esc_attr( $pCol ) ?>;border-radius:50%;
}
#<?= esc_attr( $uid ) ?> .__center{
	position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);
	width:<?= (int) $cSize ?>px;height:<?= (int) $cSize ?>px;border-radius:50%;
	background:<?= esc_attr( $cBg ) ?>;color:<?= esc_attr( $cCol ) ?>;
	display:flex;align-items:center;justify-content:center;text-align:center;
	font-weight:700;font-size:<?= (int) max( 11, round( $cSize / 7 ) ) ?>px;padding:8px;
	z-index:2;
}
#<?= esc_attr( $uid ) ?> .__center img{width:70%;height:70%;object-fit:contain;}

#<?= esc_attr( $uid ) ?> .__ring{
	position:absolute;inset:0;margin:0;padding:0;list-style:none;
	animation:<?= esc_attr( $uid ) ?>-turn var(--dur) linear infinite var(--dir);
}
#<?= esc_attr( $uid ) ?> .__slot{
	position:absolute;left:50%;top:50%;width:0;height:0;
	/* rotation vers l'angle du logo, puis on s'ecarte du centre du rayon voulu */
	transform:rotate(var(--a)) translateY(calc(var(--r) * -1%));
}
/* .__anti place et redresse (statique), .__spin ne fait que tourner :
   une keyframe sur `transform` remplace toute la valeur, elle ne doit donc
   jamais partager la propriete avec le placement. */
#<?= esc_attr( $uid ) ?> .__anti{
	position:absolute;left:0;top:0;
	transform:translate(-50%,-50%) rotate(calc(var(--a) * -1));
}
#<?= esc_attr( $uid ) ?> .__spin{
	display:flex;flex-direction:column;align-items:center;gap:6px;
	animation:<?= esc_attr( $uid ) ?>-turn var(--dur) linear infinite var(--dirr,reverse);
}
#<?= esc_attr( $uid ) ?> .__logo{
	display:flex;align-items:center;justify-content:center;
	width:<?= (int) $iSize ?>px;height:<?= (int) $iSize ?>px;border-radius:50%;
	background:<?= esc_attr( $iBg ) ?>;border:1px solid <?= esc_attr( $iBd ) ?>;
	box-shadow:0 6px 16px rgba(0,0,0,.08);overflow:hidden;text-decoration:none;
	transition:transform .25s ease,box-shadow .25s ease;
}
#<?= esc_attr( $uid ) ?> .__logo img{width:64%;height:64%;object-fit:contain;}
#<?= esc_attr( $uid ) ?> .__initial{font-weight:700;color:<?= esc_attr( $lCol ) ?>;font-size:<?= (int) max( 12, round( $iSize / 2.6 ) ) ?>px;}
#<?= esc_attr( $uid ) ?> a.__logo:hover{transform:scale(1.12);box-shadow:0 10px 24px rgba(0,0,0,.16);}
#<?= esc_attr( $uid ) ?> a.__logo:focus-visible{outline:2px solid <?= esc_attr( $cBg ) ?>;outline-offset:3px;}
#<?= esc_attr( $uid ) ?> .__name{
	font-size:11px;color:<?= esc_attr( $lCol ) ?>;white-space:nowrap;font-weight:600;
}
#<?= esc_attr( $uid ) ?> .wf-sr{
	position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;
	clip:rect(0,0,0,0);white-space:nowrap;border:0;
}
@keyframes <?= esc_attr( $uid ) ?>-turn{to{transform:rotate(1turn)}}
<?php if ( $pause ) : ?>
#<?= esc_attr( $uid ) ?>.wf-or--pause:hover .__ring,
#<?= esc_attr( $uid ) ?>.wf-or--pause:hover .__spin,
#<?= esc_attr( $uid ) ?>.wf-or--pause:focus-within .__ring,
#<?= esc_attr( $uid ) ?>.wf-or--pause:focus-within .__spin{animation-play-state:paused;}
<?php endif; ?>
@container (max-width: 420px){
	#<?= esc_attr( $uid ) ?> .__name{display:none;}
}
/* Moins d'animations : les logos restent en place, la ronde s'arrete. */
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?> .__ring,#<?= esc_attr( $uid ) ?> .__spin{animation:none;}
}
</style>
