<?php
/**
 * WeFrame – Tabs Pro | template.php v6.0 (UIkit)
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$style  = $props['tab_style']  ?? 'underline';
$align  = $props['tab_align']  ?? 'center';
$accent = $props['accent_color'] ?? '#EA5C1C';
$tc     = $props['tab_color']    ?? '#666';
$tac    = $props['tab_active_color'] ?? '#000';
$cpad   = (int)( $props['content_padding'] ?? 24 );

$uid = wf_uid( 'wftabs_', $props, count( $children ) );

$tabs = [];
$panels = [];
foreach ( $children as $i => $child ) {
    $cp     = (array)( $child->props ?? [] );
    $tabs[]   = $cp['tab_label'] ?? ( 'Onglet ' . ( $i + 1 ) );
    $panels[] = $builder->render( $child, [ 'element' => $props ] );
}

// UIkit tab alignment
$uk_align = match( $align ) {
    'center'  => ' uk-flex-center',
    'stretch' => ' uk-child-width-expand',
    'right'   => ' uk-flex-right',
    default   => '',
};
?>
<?php $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( 'div' ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>">

    <ul class="<?= $style === 'underline' ? 'uk-tab' : 'uk-subnav uk-subnav-pill' ?><?= $uk_align ?>" uk-tab="connect: #<?= esc_attr( $uid ) ?>-panels; animation: uk-animation-fade">
        <?php foreach ( $tabs as $i => $label ) : ?>
        <li<?= $i === 0 ? ' class="uk-active"' : '' ?>><a href="#"><?= esc_html( $label ) ?></a></li>
        <?php endforeach; ?>
    </ul>

    <ul id="<?= esc_attr( $uid ) ?>-panels" class="uk-switcher uk-margin" style="<?= $cpad ? "padding-top:{$cpad}px;" : '' ?>">
        <?php foreach ( $panels as $content ) : ?>
        <li><?= $content ?></li>
        <?php endforeach; ?>
    </ul>

</div>
<?php if ( $accent !== '#EA5C1C' || $tc !== '#666' || $tac !== '#000' ) : ?>
<style>
#<?= esc_attr( $uid ) ?> .uk-tab > .uk-active > a { color: <?= esc_attr( $tac ) ?>; border-color: <?= esc_attr( $accent ) ?>; }
#<?= esc_attr( $uid ) ?> .uk-tab > li > a { color: <?= esc_attr( $tc ) ?>; }
<?php if ( $style === 'pill' ) : ?>
#<?= esc_attr( $uid ) ?> .uk-subnav-pill > .uk-active > a { background-color: <?= esc_attr( $accent ) ?>; }
<?php endif; ?>
</style>
<?php endif; ?>

<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
