<?php
defined('ABSPATH') || exit;

$text = trim($props['text'] ?? '');
if (!$text) return;

// ── Props ────────────────────────────────────────────────────────────
$mode  = $props['reveal_mode']  ?? 'word';
$cmode = $props['color_mode']   ?? 'solid';
$c_off = $props['color_inactive'] ?? '#c8c8c8';
$c_on  = $props['color_active']   ?? '#000000';
$c_on2 = $props['color_active_2'] ?? '#EA5C1C';
$hlbg  = $props['highlight_bg']   ?? '#FFEB3B';
$sc_s  = max(0, min(100, (int)($props['scroll_start'] ?? 85))) / 100;
$sc_e  = max(0, min(100, (int)($props['scroll_end']   ?? 25))) / 100;

$ts    = (int)($props['title_size']           ?? 72);
$ts_t  = (int)($props['title_size_tablet']    ?? 52);
$tsm   = (int)($props['title_size_mobile']    ?? 36);
$tw    = $props['title_weight']               ?? '700';
$tlh   = (int)($props['title_line_height']        ?? 110);
$tlhm  = (int)($props['title_line_height_mobile'] ?? 110);
$tls   = (float)($props['title_letter_spacing']        ?? -2);
$tlsm  = (float)($props['title_letter_spacing_mobile'] ?? -1);
$tmw   = (int)($props['title_max_width'] ?? 0);
$tf    = trim($props['title_font']   ?? '');
$ta    = $props['title_align']        ?? 'center';
$tam   = $props['title_align_mobile'] ?? 'center';
$dis_mob = !empty($props['disable_animation_mobile']);

$show_tag  = !empty($props['show_tag']);
$tag_label = $props['tag_label']   ?? '';
$tag_pos   = $props['tag_position'] ?? 'above';
$tgs       = (int)($props['tag_size']   ?? 12);
$tgw       = $props['tag_weight']       ?? '700';
$tgc       = $props['tag_color']        ?? '#000';

// ── UID & token build ─────────────────────────────────────────────────
$uid   = 'wfsr_' . substr(md5($text . serialize($props)), 0, 8);
$words = preg_split('/\s+/', $text);
$ff    = $tf  ? "font-family:{$tf};"      : '';
$mw    = $tmw > 0 ? "max-width:{$tmw}px;" : '';

$tokens = '';
if ($mode === 'char') {
    foreach ($words as $wi => $w) {
        if ($wi > 0) $tokens .= '<span class="wf-sr-s"> </span>';
        foreach (mb_str_split($w) as $ch) {
            $tokens .= '<span class="wf-sr-t">' . esc_html($ch) . '</span>';
        }
    }
} else {
    foreach ($words as $wi => $w) {
        if ($wi > 0) $tokens .= '<span class="wf-sr-s"> </span>';
        $tokens .= '<span class="wf-sr-t">' . esc_html($w) . '</span>';
    }
}

$cfg = json_encode([
    'uid'     => $uid,
    'cOff'    => $c_off,
    'cOn'     => $c_on,
    'cOn2'    => $c_on2,
    'hlBg'    => $hlbg,
    'cmode'   => $cmode,
    'scS'     => $sc_s,
    'scE'     => $sc_e,
    'disMob'  => $dis_mob,
], JSON_HEX_AMP | JSON_HEX_APOS);

$tag_jc = ($ta === 'center') ? 'justify-content:center;' : ($ta === 'right' ? 'justify-content:flex-end;' : '');
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>


<div id="<?= esc_attr($uid) ?>" class="wf-scroll-reveal" style="text-align:<?= esc_attr($ta) ?>;">
    <?php if ($show_tag && $tag_pos === 'above') : ?>
    <div style="margin-bottom:16px;font-size:<?= $tgs ?>px;font-weight:<?= esc_attr($tgw) ?>;color:<?= esc_attr($tgc) ?>;letter-spacing:.08em;text-transform:uppercase;display:flex;gap:12px;<?= $tag_jc ?>">
        <?php if ($tag_label) : ?><span><?= esc_html($tag_label) ?></span><?php endif; ?>
    </div>
    <?php endif; ?>
    <div class="wf-sr-title" style="<?= $mw ?>font-size:<?= $ts ?>px;font-weight:<?= esc_attr($tw) ?>;line-height:<?= $tlh ?>%;letter-spacing:<?= $tls ?>px;<?= $ff ?><?= $tmw ? 'margin-left:auto;margin-right:auto;' : '' ?>" aria-label="<?= esc_attr($text) ?>"><?= $tokens ?></div>
</div>

<style>
#<?= esc_attr($uid) ?> .wf-sr-t { color:<?= esc_attr($c_off) ?>;transition:color .15s ease,background .15s ease;display:inline;padding:0 1px;border-radius:3px; }
#<?= esc_attr($uid) ?> .wf-sr-s { display:inline; }

@media(min-width:768px) and (max-width:1024px) {
    #<?= esc_attr($uid) ?> .wf-sr-title { font-size:<?= $ts_t ?>px !important; }
}

@media(max-width:767px) {
    #<?= esc_attr($uid) ?> { text-align:<?= esc_attr($tam) ?> !important; }
    #<?= esc_attr($uid) ?> .wf-sr-title {
        font-size:<?= $tsm ?>px !important;
        line-height:<?= $tlhm ?>% !important;
        letter-spacing:<?= $tlsm ?>px !important;
    }
    <?php if ($dis_mob) : ?>
    #<?= esc_attr($uid) ?> .wf-sr-t {
        color:<?= esc_attr($c_on) ?> !important;
        <?php if ($cmode === 'highlight') : ?>background:<?= esc_attr($hlbg) ?> !important;<?php endif; ?>
    }
    <?php endif; ?>
}
</style>

<script>
(function(){
    var c = <?= $cfg ?>;
    function boot(){
        var el = document.getElementById(c.uid); if (!el) return;
        var title = el.querySelector('.wf-sr-title'); if (!title) return;
        var tks = title.querySelectorAll('.wf-sr-t'); if (tks.length < 1) return;

        // Disable animation on mobile if option set
        if (c.disMob) { if (window.innerWidth <= 767) return; }

        var n = tks.length, tick = false;
        var rgb1 = WF.hexToRgb(c.cOn); var rgb2 = WF.hexToRgb(c.cOn2);

        function up(){
            var r = title.getBoundingClientRect(), vh = window.innerHeight;
            var rng = vh * (c.scS - c.scE), pos = vh * c.scS - r.top, p = 0;
            if (rng > 0) { p = pos / rng; if (p < 0) p = 0; if (p > 1) p = 1; }
            var a = Math.round(p * n), i = 0;
            while (i < n) {
                if (i < a) {
                    if (c.cmode === 'gradient') {
                        var t = n > 1 ? i / (n - 1) : 0;
                        var rr = WF.lerpi(rgb1[0], rgb2[0], t);
                        var gg = WF.lerpi(rgb1[1], rgb2[1], t);
                        var bb = WF.lerpi(rgb1[2], rgb2[2], t);
                        tks[i].style.color = 'rgb(' + rr + ',' + gg + ',' + bb + ')';
                        tks[i].style.background = 'transparent';
                    } else if (c.cmode === 'highlight') {
                        tks[i].style.color = c.cOn; tks[i].style.background = c.hlBg;
                    } else {
                        tks[i].style.color = c.cOn; tks[i].style.background = 'transparent';
                    }
                } else {
                    tks[i].style.color = c.cOff; tks[i].style.background = 'transparent';
                }
                i++;
            }
            tick = false;
        }

        function sc() { if (!tick) { tick = true; requestAnimationFrame(up); } }
        var on = false;
        if ('IntersectionObserver' in window) {
            new IntersectionObserver(function(es) {
                var i = 0; while (i < es.length) {
                    if (es[i].isIntersecting) { if (!on) { on = true; window.addEventListener('scroll', sc, {passive:true}); up(); } }
                    else { if (on) { on = false; window.removeEventListener('scroll', sc); } }
                    i++;
                }
            }, {rootMargin:'200px'}).observe(title);
        } else {
            window.addEventListener('scroll', sc, {passive:true});
        }
        up();
    }
    WF.ready(boot);
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
