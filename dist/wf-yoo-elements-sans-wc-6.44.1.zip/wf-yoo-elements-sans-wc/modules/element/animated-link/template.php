<?php
/**
 * WeFrame – Lien animé | template.php v1.0 (CSS pur)
 */
defined( 'ABSPATH' ) || exit;

$text  = (string) ( $props['text'] ?? 'Lien' );
$eff   = $props['effect'] ?? 'underline';
if ( ! in_array( $eff, array( 'underline', 'slide', 'bracket', 'highlight', 'underline-rl', 'underline-center', 'fill-up', 'roll' ), true ) ) { $eff = 'underline'; }
$col   = $props['color'] ?? '#111111';
$hcol  = $props['hover_color'] ?? '#c0272d';
$size  = max( 10, (int) ( $props['size'] ?? 16 ) );
$w     = $props['weight'] ?? '600';
$arrow = ! empty( $props['arrow'] );
$align = $props['align'] ?? 'left';

$link = $props['link'] ?? '';
if ( is_array( $link ) ) { $link = $link['url'] ?? ''; }
$link = (string) $link;
if ( '' === $link ) { $link = '#'; }

$uid = wf_uid( 'wfal_', $props );
$ar  = $arrow ? '<span class="wf-al-arrow" style="display:inline-block;transition:transform .25s ease;">&rarr;</span>' : '';

$rollStagger = max( 0, min( 80, (int) ( $props['roll_stagger'] ?? 22 ) ) );

/**
 * Roulement : chaque lettre est doublee dans une fenetre a hauteur fixe. Le
 * texte visible devient donc une suite de lettres isolees — on le masque aux
 * lecteurs d'ecran et on remet le vrai libelle en aria-label sur le lien.
 */
$rollHtml = '';
if ( 'roll' === $eff ) {
	$chars = preg_split( '//u', $text, -1, PREG_SPLIT_NO_EMPTY );
	foreach ( $chars as $ci => $ch ) {
		$glyph = ( ' ' === $ch ) ? '&nbsp;' : esc_html( $ch );
		$rollHtml .= '<span class="wf-al-c" style="--i:' . (int) $ci . '">'
			. '<span class="wf-al-c1">' . $glyph . '</span>'
			. '<span class="wf-al-c2">' . $glyph . '</span>'
			. '</span>';
	}
}
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div style="text-align:<?= esc_attr( $align ) ?>;">
<a id="<?= esc_attr( $uid ) ?>" class="wf-al wf-al--<?= esc_attr( $eff ) ?>" href="<?= esc_url( $link ) ?>"<?php if ( 'roll' === $eff ) : ?> aria-label="<?= esc_attr( $text ) ?>"<?php endif; ?> style="display:inline-flex;align-items:center;gap:7px;position:relative;text-decoration:none;font-size:<?= $size ?>px;font-weight:<?= esc_attr( $w ) ?>;color:<?= esc_attr( $col ) ?>;line-height:1.4;">
    <?php if ( 'roll' === $eff ) : ?><span class="wf-al-txt wf-al-txt--roll" aria-hidden="true"><?= $rollHtml ?></span><?php else : ?><span class="wf-al-txt"><?= esc_html( $text ) ?></span><?php endif; ?><?= $ar ?>
</a>
</div>
<style>
#<?= esc_attr( $uid ) ?>{transition:color .25s ease;}
#<?= esc_attr( $uid ) ?>:hover{color:<?= esc_attr( $hcol ) ?>;}
#<?= esc_attr( $uid ) ?>:hover .wf-al-arrow{transform:translateX(4px);}
#<?= esc_attr( $uid ) ?>:focus-visible{outline:2px solid <?= esc_attr( $hcol ) ?>;outline-offset:3px;}
<?php if ( 'underline' === $eff ) : ?>
#<?= esc_attr( $uid ) ?> .wf-al-txt{background-image:linear-gradient(<?= esc_attr( $hcol ) ?>,<?= esc_attr( $hcol ) ?>);background-size:0% 2px;background-position:left bottom;background-repeat:no-repeat;transition:background-size .3s ease;padding-bottom:2px;}
#<?= esc_attr( $uid ) ?>:hover .wf-al-txt{background-size:100% 2px;}
<?php elseif ( 'slide' === $eff ) : ?>
#<?= esc_attr( $uid ) ?> .wf-al-txt{position:relative;overflow:hidden;display:inline-block;}
#<?= esc_attr( $uid ) ?> .wf-al-txt::after{content:attr(data-t);position:absolute;left:0;top:100%;color:<?= esc_attr( $hcol ) ?>;}
<?php else : ?>
<?php endif; ?>
<?php if ( 'bracket' === $eff ) : ?>
#<?= esc_attr( $uid ) ?> .wf-al-txt::before,#<?= esc_attr( $uid ) ?> .wf-al-txt::after{opacity:0;transition:all .25s ease;color:<?= esc_attr( $hcol ) ?>;}
#<?= esc_attr( $uid ) ?> .wf-al-txt::before{content:"[";margin-right:4px;transform:translateX(6px);}
#<?= esc_attr( $uid ) ?> .wf-al-txt::after{content:"]";margin-left:4px;transform:translateX(-6px);}
#<?= esc_attr( $uid ) ?>:hover .wf-al-txt::before,#<?= esc_attr( $uid ) ?>:hover .wf-al-txt::after{opacity:1;transform:translateX(0);}
<?php endif; ?>
<?php if ( 'underline-rl' === $eff ) : ?>
#<?= esc_attr( $uid ) ?> .wf-al-txt{background-image:linear-gradient(<?= esc_attr( $hcol ) ?>,<?= esc_attr( $hcol ) ?>);background-size:0% 2px;background-position:right bottom;background-repeat:no-repeat;transition:background-size .3s ease;padding-bottom:2px;}
#<?= esc_attr( $uid ) ?>:hover .wf-al-txt{background-size:100% 2px;}
<?php endif; ?>
<?php if ( 'underline-center' === $eff ) : ?>
#<?= esc_attr( $uid ) ?> .wf-al-txt{background-image:linear-gradient(<?= esc_attr( $hcol ) ?>,<?= esc_attr( $hcol ) ?>);background-size:0% 2px;background-position:center bottom;background-repeat:no-repeat;transition:background-size .3s ease;padding-bottom:2px;}
#<?= esc_attr( $uid ) ?>:hover .wf-al-txt{background-size:100% 2px;}
<?php endif; ?>
<?php if ( 'fill-up' === $eff ) : ?>
/* Le fond monte du bas : hauteur 0 vers pleine hauteur, pas la largeur. */
#<?= esc_attr( $uid ) ?> .wf-al-txt{background-image:linear-gradient(<?= esc_attr( $hcol ) ?>,<?= esc_attr( $hcol ) ?>);background-size:100% 0%;background-position:left bottom;background-repeat:no-repeat;transition:background-size .28s ease;padding:2px 4px;border-radius:3px;}
#<?= esc_attr( $uid ) ?>:hover .wf-al-txt{background-size:100% 100%;color:#fff;}
<?php endif; ?>
<?php if ( 'roll' === $eff ) : ?>
/* Chaque lettre est une fenetre a hauteur fixe : la copie du dessous remonte. */
#<?= esc_attr( $uid ) ?> .wf-al-txt--roll{display:inline-flex;}
#<?= esc_attr( $uid ) ?> .wf-al-c{position:relative;display:inline-block;overflow:hidden;height:1.25em;line-height:1.25em;}
#<?= esc_attr( $uid ) ?> .wf-al-c1,#<?= esc_attr( $uid ) ?> .wf-al-c2{
	display:block;transition:transform .34s cubic-bezier(.2,.8,.2,1);
	transition-delay:calc(var(--i) * <?= (int) $rollStagger ?>ms);
}
#<?= esc_attr( $uid ) ?> .wf-al-c2{position:absolute;left:0;top:100%;color:<?= esc_attr( $hcol ) ?>;}
#<?= esc_attr( $uid ) ?>:hover .wf-al-c1,#<?= esc_attr( $uid ) ?>:focus-visible .wf-al-c1,
#<?= esc_attr( $uid ) ?>:hover .wf-al-c2,#<?= esc_attr( $uid ) ?>:focus-visible .wf-al-c2{transform:translateY(-100%);}
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?> .wf-al-c1,#<?= esc_attr( $uid ) ?> .wf-al-c2{transition:none;}
}
<?php endif; ?>
<?php if ( 'highlight' === $eff ) : ?>
#<?= esc_attr( $uid ) ?> .wf-al-txt{background-image:linear-gradient(<?= esc_attr( $hcol ) ?>22,<?= esc_attr( $hcol ) ?>22);background-size:0% 100%;background-position:left center;background-repeat:no-repeat;transition:background-size .3s ease;padding:2px 3px;border-radius:3px;}
#<?= esc_attr( $uid ) ?>:hover .wf-al-txt{background-size:100% 100%;}
<?php endif; ?>
</style>
<?php if ( 'slide' === $eff ) : ?>
<script>(function(){var e=document.getElementById('<?= esc_js( $uid ) ?>');if(!e)return;var t=e.querySelector('.wf-al-txt');if(t)t.setAttribute('data-t',t.textContent);var w=t?t.offsetHeight:0;e.addEventListener('mouseenter',function(){if(t)t.style.transform='translateY(-'+w+'px)';});e.addEventListener('mouseleave',function(){if(t)t.style.transform='';});if(t){t.style.transition='transform .28s cubic-bezier(.6,0,.2,1)';}})();</script>
<?php endif; ?>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
