<?php
/**
 * WeFrame – Stack Cards | template.php
 * Sticky stacking cards that overlap on scroll
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$sticky_top  = max( 0, (int)( $props['sticky_top']       ?? 80 ) );
$increment   = max( 0, (int)( $props['offset_increment']  ?? 16 ) );
$gap         = max( 0, (int)( $props['card_gap']           ?? 24 ) );
$radius      = (int)( $props['card_radius']       ?? 24 );
$pad         = (int)( $props['card_padding']       ?? 48 );
$pad_mob     = (int)( $props['card_padding_mobile'] ?? 28 );
$min_h       = (int)( $props['card_min_height']         ?? 400 );
$min_h_mob   = (int)( $props['card_min_height_mobile']   ?? 0 );
$shadow      = ! empty( $props['shadow'] );
$img_pos     = $props['image_position'] ?? 'right';
$img_radius  = (int)( $props['image_radius'] ?? 16 );
$img_width   = (int)( $props['image_width']  ?? 45 );
$show_step   = ! empty( $props['show_step'] );
$step_label  = $props['step_label']      ?? 'STEP';
$badge_size  = (int)( $props['step_badge_size']  ?? 36 );
$badge_bg    = $props['step_badge_bg']    ?? '#000000';
$badge_color = $props['step_badge_color'] ?? '#ffffff';
$t_size      = (int)( $props['title_size']        ?? 48 );
$t_size_tab  = (int)( $props['title_size_tablet'] ?? 38 );
$t_size_mob  = (int)( $props['title_size_mobile']  ?? 28 );
$t_weight    = $props['title_weight']     ?? '700';
$t_color     = trim( (string)( $props['title_color'] ?? '' ) );
$t_font      = trim( (string)( $props['title_font'] ?? '' ) );
$t_lh        = (int)( $props['title_line_height'] ?? 112 );
$t_ls        = (float)( $props['title_letter_spacing'] ?? -2 );
$d_size      = (int)( $props['desc_size']         ?? 16 );
$d_size_tab  = (int)( $props['desc_size_tablet']  ?? 15 );
$d_size_mob  = (int)( $props['desc_size_mobile']   ?? 14 );
$d_color     = trim( (string)( $props['desc_color'] ?? '' ) );
$c_align     = ( ( $props['content_align'] ?? 'left' ) === 'center' ) ? 'center' : 'left';
$img_fit     = (string)( $props['image_fit'] ?? 'contain' );
$badge_shape = (string)( $props['badge_shape'] ?? 'circle' );
$anim_in     = (string)( $props['anim_in'] ?? 'none' );

$badge_rad = ( 'square' === $badge_shape ) ? '8px' : ( 'pill' === $badge_shape ? '100px' : '50%' );
$fit_val   = ( 'cover' === $img_fit || 'full' === $img_fit ) ? 'cover' : 'contain';

$uid = wf_uid( 'wfsc_', $props, count( $children ) );

$html = '';
foreach ( $children as $i => $child ) {
    $card_top = $sticky_top + ( $i * $increment );
    $html .= $builder->render( $child, [
        'element' => $props,
        'index'   => $i,
        'top'     => $card_top,
    ] );
}
if ( ! trim( $html ) ) { return; }

$shadow_css = $shadow ? 'box-shadow:0 8px 40px rgba(0,0,0,.15),0 0 0 1px rgba(0,0,0,.05);' : '';
$text_w     = 100 - $img_width;

?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-stack-cards" style="display:flex;flex-direction:column;gap:<?= $gap ?>px;">
    <?= $html ?>
</div>

<style>
/* ── Card base ── */
#<?= esc_attr( $uid ) ?> .wf-sc-card {
    position: sticky;
    border-radius: <?= $radius ?>px;
    overflow: hidden;
    padding: <?= $pad ?>px;
    <?= $shadow_css ?>
    <?= $min_h ? "min-height:{$min_h}px;" : '' ?>
    display: grid;
    grid-template-columns: <?= $img_pos === 'left' ? "{$img_width}% 1fr" : "1fr {$img_width}%" ?>;
    gap: <?= $pad ?>px;
    align-items: center;
    transition: opacity .6s ease;
}
#<?= esc_attr( $uid ) ?> .wf-sc-text { text-align: <?= $c_align ?>; }
<?php if ( 'fade' === $anim_in ) : ?>
#<?= esc_attr( $uid ) ?> .wf-sc-card { opacity: 0; }
#<?= esc_attr( $uid ) ?> .wf-sc-card.is-in { opacity: 1; }
<?php endif; ?>

/* ── Step badge ── */
<?php if ( $show_step ) : ?>
#<?= esc_attr( $uid ) ?> .wf-sc-badge {
    <?= 'pill' === $badge_shape ? "min-width:{$badge_size}px;height:{$badge_size}px;padding:0 12px;" : "width:{$badge_size}px;height:{$badge_size}px;" ?>
    border-radius: <?= $badge_rad ?>;
    background: <?= esc_attr( $badge_bg ) ?>;
    color: <?= esc_attr( $badge_color ) ?>;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: <?= (int)( $badge_size * 0.42 ) ?>px;
    font-weight: 700;
    flex-shrink: 0;
}
#<?= esc_attr( $uid ) ?> .wf-sc-step-row {
    display: flex;
    align-items: center;
    justify-content: <?= 'center' === $c_align ? 'center' : 'flex-start' ?>;
    gap: 12px;
    margin-bottom: 24px;
}
#<?= esc_attr( $uid ) ?> .wf-sc-step-label {
    font-size: 13px;
    font-weight: 700;
    letter-spacing: .08em;
    text-transform: uppercase;
}
<?php endif; ?>

/* ── Typography ── */
#<?= esc_attr( $uid ) ?> .wf-sc-title {
    font-size: <?= $t_size ?>px;
    font-weight: <?= esc_attr( $t_weight ) ?>;
    line-height: <?= $t_lh ?>%;
    letter-spacing: <?= $t_ls ?>px;
    margin: 0 0 16px;
    <?= $t_color ? 'color:' . esc_attr( $t_color ) . ';' : '' ?>
    <?= $t_font ? 'font-family:' . esc_attr( $t_font ) . ';' : '' ?>
}
#<?= esc_attr( $uid ) ?> .wf-sc-desc {
    font-size: <?= $d_size ?>px;
    line-height: 1.65;
    opacity: .85;
    margin: 0;
    <?= $d_color ? 'color:' . esc_attr( $d_color ) . ';' : '' ?>
}

/* ── Image area ── */
#<?= esc_attr( $uid ) ?> .wf-sc-media {
    border-radius: <?= 'full' === $img_fit ? '0' : $img_radius . 'px' ?>;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: <?= 'contain' === $img_fit ? (int)( $pad * 0.6 ) : 0 ?>px;
    min-height: 240px;
    <?= $img_pos === 'left' ? 'order:-1;' : '' ?>
    <?php if ( 'full' === $img_fit ) : ?>align-self:stretch;margin:<?= $img_pos === 'left' ? "-{$pad}px 0 -{$pad}px -{$pad}px" : "-{$pad}px -{$pad}px -{$pad}px 0" ?>;<?php endif; ?>
}
#<?= esc_attr( $uid ) ?> .wf-sc-media img {
    <?= ( 'cover' === $img_fit || 'full' === $img_fit ) ? 'width:100%;height:100%;object-fit:cover;' : 'max-width:100%;max-height:100%;object-fit:contain;' ?>
}

/* ── Tablette ── */
@media (min-width: 768px) and (max-width: 1024px) {
    #<?= esc_attr( $uid ) ?> .wf-sc-title { font-size: <?= $t_size_tab ?>px !important; }
    #<?= esc_attr( $uid ) ?> .wf-sc-desc { font-size: <?= $d_size_tab ?>px !important; }
}

/* ── Mobile ── */
@media (max-width: 767px) {
    #<?= esc_attr( $uid ) ?> .wf-sc-card {
        grid-template-columns: 1fr !important;
        padding: <?= $pad_mob ?>px !important;
        <?= $min_h_mob ? "min-height:{$min_h_mob}px !important;" : 'min-height:auto !important;' ?>
        gap: <?= (int)( $pad_mob * 0.75 ) ?>px !important;
    }
    #<?= esc_attr( $uid ) ?> .wf-sc-media {
        order: 0 !important;
        min-height: 160px;
        padding: <?= (int)( $pad_mob * 0.5 ) ?>px;
        margin: 0 !important;
        border-radius: <?= $img_radius ?>px !important;
        align-self: auto !important;
    }
    #<?= esc_attr( $uid ) ?> .wf-sc-title {
        font-size: <?= $t_size_mob ?>px !important;
    }
    #<?= esc_attr( $uid ) ?> .wf-sc-desc {
        font-size: <?= $d_size_mob ?>px !important;
    }
}

/* ── Reduced motion ── */
@media (prefers-reduced-motion: reduce) {
    #<?= esc_attr( $uid ) ?> .wf-sc-card { position: relative !important; top: auto !important; opacity: 1 !important; }
}
</style>

<?php if ( 'fade' === $anim_in ) : ?>
<script>
(function(){
    function boot(){
        var el = document.getElementById('<?= esc_js( $uid ) ?>'); if (!el) return;
        var cards = el.querySelectorAll('.wf-sc-card');
        if ('IntersectionObserver' in window) {
            var obs = new IntersectionObserver(function(es){
                var i = 0; while (i < es.length) { if (es[i].isIntersecting) { es[i].target.classList.add('is-in'); obs.unobserve(es[i].target); } i++; }
            }, { threshold: 0.15 });
            var k = 0; while (k < cards.length) { obs.observe(cards[k]); k++; }
        } else {
            var j = 0; while (j < cards.length) { cards[j].classList.add('is-in'); j++; }
        }
    }
    if (window.WF) { if (WF.ready) { WF.ready(boot); return; } }
    if (document.readyState !== 'loading') { boot(); } else { document.addEventListener('DOMContentLoaded', boot); }
})();
</script>
<?php endif; ?>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
