<?php
/**
 * WeFrame – Fond aurore (barres) | template.php v1.0
 * Des barres colorees et tres floutees se balancent : l'effet aurore boreale.
 * Zero JS, zero canvas — uniquement des degrades et deux animations CSS.
 *
 * Deux placements :
 *  - Bloc autonome : l'element occupe sa place, le contenu depose vient dessus.
 *  - Fond de section : l'element se colle en absolu derriere toute la section
 *    qui le contient (les sections YOOtheme sont en position:relative).
 *    Il faut alors le deposer en premier dans la section.
 */
defined( 'ABSPATH' ) || exit;

$place = ( 'backdrop' === ( $props['placement'] ?? 'block' ) ) ? 'backdrop' : 'block';

$bars  = max( 3, min( 24, (int) ( $props['bars'] ?? 9 ) ) );
$bw    = max( 10, (int) ( $props['bar_width'] ?? 60 ) );
$blur  = max( 0, (int) ( $props['blur'] ?? 70 ) );
$speed = max( 2, (int) ( $props['speed'] ?? 9 ) );
$amp   = max( 0, min( 100, (int) ( $props['amplitude'] ?? 45 ) ) );
$op    = max( 10, min( 100, (int) ( $props['opacity'] ?? 70 ) ) );

$c1 = (string) ( $props['color_1'] ?? '#7C3AED' );
$c2 = (string) ( $props['color_2'] ?? '#EA5C1C' );
$c3 = (string) ( $props['color_3'] ?? '#22D3EE' );
$bg = trim( (string) ( $props['bg'] ?? '' ) );

$h    = max( 120, (int) ( $props['height'] ?? 460 ) );
$rad  = max( 0, (int) ( $props['radius'] ?? 0 ) );
$pad  = max( 0, (int) ( $props['padding'] ?? 48 ) );
$fade = ! empty( $props['fade_edges'] );
$seed = max( 1, (int) ( $props['seed'] ?? 4 ) );

$inner = '';
if ( ! empty( $children ) ) {
	foreach ( $children as $ci => $child ) {
		$inner .= $builder->render( $child, array( 'element' => $props, 'index' => $ci ) );
	}
}

// Tirage reproductible : la meme graine redonne le meme rideau.
$rngState = ( $seed * 40503 ) % 4294967296;
$rng = function () use ( &$rngState ) {
	$rngState = ( $rngState * 1103515245 + 12345 ) % 2147483648;
	return $rngState / 2147483648;
};

$cols = array( $c1, $c2, $c3 );
$list = array();
for ( $i = 0; $i < $bars; $i++ ) {
	$list[] = array(
		'x'  => round( ( $i + 0.5 ) / $bars * 100, 2 ),
		'c'  => $cols[ $i % 3 ],
		'w'  => (int) round( $bw * ( 0.6 + $rng() * 0.9 ) ),
		'dl' => round( -$rng() * $speed * 2, 2 ),
		'du' => round( $speed * ( 0.7 + $rng() * 0.8 ), 2 ),
		'sk' => round( ( $rng() * 2 - 1 ) * 14, 1 ),
	);
}

$uid = wf_uid( 'wfab_', $props, $bars );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-ab wf-ab--<?= esc_attr( $place ) ?>">
	<div class="__sky" aria-hidden="true">
		<?php foreach ( $list as $b ) : ?>
		<span class="__bar" style="
			left:<?= esc_attr( $b['x'] ) ?>%;
			width:<?= (int) $b['w'] ?>px;
			background:linear-gradient(180deg,transparent,<?= esc_attr( $b['c'] ) ?> 35%,<?= esc_attr( $b['c'] ) ?> 65%,transparent);
			animation-duration:<?= esc_attr( $b['du'] ) ?>s;
			animation-delay:<?= esc_attr( $b['dl'] ) ?>s;
			--sk:<?= esc_attr( $b['sk'] ) ?>deg;"></span>
		<?php endforeach; ?>
	</div>
	<?php if ( '' !== trim( $inner ) && 'block' === $place ) : ?>
	<div class="__content"><?= $inner ?></div>
	<?php endif; ?>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
<?php if ( 'backdrop' === $place ) : ?>
/* Fond de section : on sort du flux et on se glisse derriere tout le reste. */
#<?= esc_attr( $uid ) ?>{
	position:absolute;inset:0;z-index:0;pointer-events:none;overflow:hidden;
	<?= '' !== $bg ? 'background:' . esc_attr( $bg ) . ';' : '' ?>
	<?= $rad > 0 ? 'border-radius:' . (int) $rad . 'px;' : '' ?>
}
<?php else : ?>
#<?= esc_attr( $uid ) ?>{
	position:relative;isolation:isolate;overflow:hidden;
	min-height:<?= (int) $h ?>px;padding:<?= (int) $pad ?>px;
	border-radius:<?= (int) $rad ?>px;
	<?= '' !== $bg ? 'background:' . esc_attr( $bg ) . ';' : '' ?>
	display:flex;flex-direction:column;justify-content:center;
}
#<?= esc_attr( $uid ) ?> .__content{position:relative;z-index:1;}
<?php endif; ?>

#<?= esc_attr( $uid ) ?> .__sky{
	position:absolute;inset:-10% -5%;z-index:0;pointer-events:none;
	filter:blur(<?= (int) $blur ?>px);
	opacity:<?= esc_attr( round( $op / 100, 2 ) ) ?>;
<?php if ( $fade ) : ?>
	-webkit-mask-image:linear-gradient(180deg,transparent,#000 18%,#000 82%,transparent);
	mask-image:linear-gradient(180deg,transparent,#000 18%,#000 82%,transparent);
<?php endif; ?>
}
#<?= esc_attr( $uid ) ?> .__bar{
	position:absolute;top:-10%;height:120%;display:block;
	transform:translateX(-50%) skewX(var(--sk,0deg));
	animation-name:<?= esc_attr( $uid ) ?>-sway;
	animation-timing-function:ease-in-out;
	animation-iteration-count:infinite;
	animation-direction:alternate;
	will-change:transform;
}
@keyframes <?= esc_attr( $uid ) ?>-sway{
	from{transform:translateX(-50%) translateY(-<?= (int) $amp ?>px) skewX(var(--sk,0deg)) scaleY(.9);}
	to{transform:translateX(-50%) translateY(<?= (int) $amp ?>px) skewX(calc(var(--sk,0deg) * -1)) scaleY(1.1);}
}
/* Moins d'animations : le rideau reste, il ne bouge plus. */
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?> .__bar{animation:none;}
}
</style>
