<?php
defined('ABSPATH') || exit;
if (empty($children)) return;
$cols = max(1,(int)($props['columns']??3)); $cm = max(1,(int)($props['columns_mobile']??1));
$gap = (int)($props['gap']??24); $toggle = !empty($props['billing_toggle']);
$lm = $props['label_monthly']??'Mensuel'; $ly = $props['label_yearly']??'Annuel';
$spct = (int)($props['save_pct']??20); $sbadge = $props['save_badge']??'Économisez {X}%';
$uid = 'wfpr_'.substr(md5(serialize($props).count($children)),0,8);
$html = '';
foreach ($children as $child) { $html .= $builder->render($child, ['element'=>$props]); }
if (!trim($html)) return;
$cfg = json_encode(['uid'=>$uid], JSON_HEX_AMP|JSON_HEX_APOS);
$badgeTxt = str_replace('{X}', (string)$spct, $sbadge);
$sw_on = $props['switch_on']??'#EA5C1C'; $sw_off = $props['switch_off']??'#dddddd';
$sw_kb = $props['switch_knob']??'#ffffff'; $sv_bg = $props['save_bg']??'#16a34a'; $sv_c = $props['save_color']??'#ffffff';
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<?php if ($toggle) : ?>
<div id="<?= esc_attr($uid) ?>_toggle" style="display:flex;align-items:center;justify-content:center;gap:12px;margin-bottom:32px;">
    <span class="wf-pr-lbl wf-pr-lbl--m" style="font-size:15px;font-weight:600;transition:opacity .2s;"><?= esc_html($lm) ?></span>
    <button class="wf-pr-switch" type="button" style="cursor:pointer;position:relative;width:52px;height:28px;border-radius:100px;border:none;background:<?= esc_attr($sw_off) ?>;padding:0;transition:background .3s;" aria-label="<?= esc_attr__( 'Basculer entre tarif mensuel et annuel', 'weframe' ) ?>" aria-pressed="false">
        <span style="position:absolute;top:3px;left:3px;width:22px;height:22px;border-radius:50%;background:<?= esc_attr($sw_kb) ?>;box-shadow:0 1px 4px rgba(0,0,0,.2);transition:transform .3s;"></span>
    </button>
    <span class="wf-pr-lbl wf-pr-lbl--y" style="font-size:15px;font-weight:600;opacity:.5;transition:opacity .2s;"><?= esc_html($ly) ?></span>
    <span class="wf-pr-save" style="display:none;background:<?= esc_attr($sv_bg) ?>;color:<?= esc_attr($sv_c) ?>;font-size:11px;font-weight:700;padding:3px 10px;border-radius:100px;"><?= esc_html($badgeTxt) ?></span>
</div>
<?php endif; ?>
<div id="<?= esc_attr($uid) ?>" style="display:grid;grid-template-columns:repeat(<?= $cols ?>,1fr);gap:<?= $gap ?>px;align-items:stretch;">
    <?= $html ?>
</div>
<style>@media(max-width:767px){#<?= esc_attr($uid) ?>{grid-template-columns:repeat(<?= $cm ?>,1fr) !important}}</style>
<?php if ($toggle) : ?>
<script>
(function(){
    function boot(){
        
        var c = <?= $cfg ?>;
        var wrap=document.getElementById(c.uid+'_toggle');if(!wrap)return;
        var sw=wrap.querySelector('.wf-pr-switch');if(!sw)return;
        var dot=sw.querySelector('span');var lblM=wrap.querySelector('.wf-pr-lbl--m');
        var lblY=wrap.querySelector('.wf-pr-lbl--y');var save=wrap.querySelector('.wf-pr-save');
        var prices=document.querySelectorAll('#'+c.uid+' .wf-pr-price');
        var yearly=false;
        sw.addEventListener('click',function(){
            yearly=!yearly;
            if(yearly){dot.style.transform='translateX(24px)';sw.style.background='<?= esc_js($sw_on) ?>';lblM.style.opacity='.5';lblY.style.opacity='1';save.style.display=''}
            else{dot.style.transform='translateX(0)';sw.style.background='<?= esc_js($sw_off) ?>';lblM.style.opacity='1';lblY.style.opacity='.5';save.style.display='none'}
            sw.setAttribute('aria-pressed',yearly?'true':'false');
            prices.forEach(function(p){
                var pm=p.getAttribute('data-monthly');
                var py=p.getAttribute('data-yearly');
                if(!py) return;
                p.style.transition='opacity .15s';p.style.opacity='0';
                setTimeout(function(){p.textContent=yearly?py:pm;p.style.opacity='1';},160);
            });
        });
    }
    WF.ready(boot)
})();
</script>
<?php endif; ?>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
