<?php
/**
 * WeFrame – Kinetic Headline | template.php
 * Variable-weight kinetic typography. Effects: scroll sweep, hover magnetic, wave.
 * Config inlined (no <script type="application/json">), no "&&" in inline JS.
 */
defined( 'ABSPATH' ) || exit;

$props = is_array( $props ?? null ) ? $props : array();

$text = trim( (string) ( $props['text'] ?? '' ) );
if ( '' === $text ) { return; }

$effect  = (string) ( $props['effect'] ?? 'scroll' );
$size    = (int) ( $props['size']         ?? 72 );
$size_t  = (int) ( $props['size_tablet']  ?? 52 );
$size_m  = (int) ( $props['size_mobile']  ?? 34 );
$w_min   = min( 900, max( 100, (int) ( $props['weight_min'] ?? 200 ) ) );
$w_max   = min( 900, max( $w_min, (int) ( $props['weight_max'] ?? 800 ) ) );
$color   = (string) ( $props['color'] ?? '#111111' );
$lh      = (int) ( $props['line_height'] ?? 104 );
$ls      = (float) ( $props['letter_spacing'] ?? -1 );
$font    = trim( (string) ( $props['font'] ?? '' ) );
$align   = (string) ( $props['align'] ?? 'left' );
$maxw    = (int) ( $props['max_width'] ?? 0 );
$radius  = min( 400, max( 20, (int) ( $props['hover_radius'] ?? 120 ) ) );
$w_speed = min( 6, max( 1, (int) ( $props['wave_speed'] ?? 2 ) ) );

$uid = 'wfkh_' . substr( md5( $text . serialize( $props ) ), 0, 8 );

// Build char spans, keeping words unbreakable
$parts = preg_split( '/(\s+)/u', $text, -1, PREG_SPLIT_DELIM_CAPTURE );
$html  = '';
foreach ( $parts as $part ) {
    if ( '' === $part ) { continue; }
    if ( preg_match( '/^\s+$/u', $part ) ) { $html .= '<span class="wf-kh-sp"> </span>'; continue; }
    $chars = function_exists( 'mb_str_split' ) ? mb_str_split( $part ) : str_split( $part );
    $html .= '<span class="wf-kh-word" style="display:inline-block;white-space:nowrap;">';
    foreach ( $chars as $ch ) {
        $html .= '<span class="wf-kh-c" style="display:inline-block;font-weight:' . $w_min . ';transition:font-weight .12s linear,transform .14s ease;">' . esc_html( $ch ) . '</span>';
    }
    $html .= '</span>';
}

$cfg = wp_json_encode( array(
    'uid'    => $uid,
    'effect' => $effect,
    'wMin'   => $w_min,
    'wMax'   => $w_max,
    'radius' => $radius,
    'wSpeed' => $w_speed,
), JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE );

$ff = $font ? 'font-family:' . $font . ';' : '';
$mw = ( $maxw > 0 ) ? 'max-width:' . $maxw . 'px;' . ( 'center' === $align ? 'margin-left:auto;margin-right:auto;' : '' ) : '';
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-kh" style="text-align:<?= esc_attr( $align ) ?>;<?= $mw ?>font-size:<?= $size ?>px;line-height:<?= $lh ?>%;letter-spacing:<?= $ls ?>px;color:<?= esc_attr( $color ) ?>;<?= $ff ?>"><?= $html ?></div>

<style>
#<?= esc_attr( $uid ) ?> .wf-kh-c { will-change: font-weight, transform; }
@media (min-width:768px) and (max-width:1024px) { #<?= esc_attr( $uid ) ?> { font-size:<?= $size_t ?>px !important; } }
@media (max-width:767px) { #<?= esc_attr( $uid ) ?> { font-size:<?= $size_m ?>px !important; } }
@media (prefers-reduced-motion: reduce) { #<?= esc_attr( $uid ) ?> .wf-kh-c { transition:none !important; } }
</style>

<script>
(function(){
    var C = <?= $cfg ?>;
    function boot(){
        var el = document.getElementById(C.uid); if (!el) return;
        var cs = el.querySelectorAll('.wf-kh-c');
        var n = cs.length; if (n < 1) return;
        var span = C.wMax - C.wMin;

        function setW(i, w){ cs[i].style.fontWeight = Math.round(w); }

        if (C.effect === 'hover') {
            var rects = null;
            function measure(){
                rects = [];
                var i = 0;
                while (i < n) {
                    var r = cs[i].getBoundingClientRect();
                    rects.push({ x: r.left + r.width / 2, y: r.top + r.height / 2 });
                    i++;
                }
            }
            function onMove(e){
                if (!rects) { measure(); }
                var mx = e.clientX, my = e.clientY, i = 0;
                while (i < n) {
                    var dx = rects[i].x - mx, dy = rects[i].y - my;
                    var d = Math.sqrt(dx * dx + dy * dy);
                    var t = 1 - (d / C.radius);
                    if (t < 0) { t = 0; }
                    if (t > 1) { t = 1; }
                    setW(i, C.wMin + span * t);
                    cs[i].style.transform = 'translateY(' + (-6 * t).toFixed(1) + 'px)';
                    i++;
                }
            }
            function reset(){
                var i = 0; while (i < n) { setW(i, C.wMin); cs[i].style.transform = 'none'; i++; }
            }
            el.addEventListener('mousemove', onMove);
            el.addEventListener('mouseleave', reset);
            window.addEventListener('resize', function(){ rects = null; }, { passive: true });
            window.addEventListener('scroll', function(){ rects = null; }, { passive: true });
            return;
        }

        if (C.effect === 'wave') {
            var start = null, amp = C.wSpeed;
            function frame(ts){
                if (start === null) { start = ts; }
                var t = (ts - start) / 1000;
                var i = 0;
                while (i < n) {
                    var phase = t * amp - i * 0.35;
                    var v = 0.5 + 0.5 * Math.sin(phase);
                    setW(i, C.wMin + span * v);
                    i++;
                }
                requestAnimationFrame(frame);
            }
            requestAnimationFrame(frame);
            return;
        }

        // default: scroll sweep — a heavy zone travels across letters as you scroll
        var ticking = false;
        function update(){
            ticking = false;
            var r = el.getBoundingClientRect();
            var vh = window.innerHeight;
            var p = (vh - r.top) / (vh + r.height);
            if (p < 0) { p = 0; }
            if (p > 1) { p = 1; }
            var head = p * (n - 1);
            var i = 0;
            while (i < n) {
                var dist = Math.abs(i - head);
                var t = 1 - (dist / 6);
                if (t < 0) { t = 0; }
                setW(i, C.wMin + span * t);
                i++;
            }
        }
        function onScroll(){ if (!ticking) { ticking = true; requestAnimationFrame(update); } }
        window.addEventListener('scroll', onScroll, { passive: true });
        window.addEventListener('resize', onScroll, { passive: true });
        update();
    }
    if (window.WF) { if (WF.ready) { WF.ready(boot); return; } }
    if (document.readyState !== 'loading') { boot(); } else { document.addEventListener('DOMContentLoaded', boot); }
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
