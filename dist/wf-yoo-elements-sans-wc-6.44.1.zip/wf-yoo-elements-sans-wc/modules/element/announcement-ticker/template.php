<?php
defined('ABSPATH') || exit;
if (empty($children)) return;
$speed = max(1000,(int)($props['speed']??4000)); $anim = $props['animation']??'slide-up';
$hover = !empty($props['pause_on_hover']);
$bgc = $props['bg_color']??'#EA5C1C'; $tc = $props['text_color']??'#fff';
$fs = (int)($props['font_size']??14); $fw = $props['font_weight']??'600';
$pad = (int)($props['padding']??10); $al = $props['align']??'center';
$uid = 'wfat_'.substr(md5(serialize($props).count($children)),0,8);
$msgs = [];
foreach ($children as $child) {
    $cp = (array)($child->props ?? []);
    $t = $cp['text']??''; $l = esc_url_raw($cp['link']??'');
    if ($t) $msgs[] = ['text'=>$t, 'link'=>$l];
}
if (empty($msgs)) return;
$h = $fs + $pad * 2 + 8;
$jc = ($al === 'center') ? 'justify-content:center;text-align:center;' : 'text-align:left;';
$cfg = json_encode(['uid'=>$uid,'msgs'=>$msgs,'speed'=>$speed,'anim'=>$anim,'hover'=>$hover,'h'=>$h], JSON_HEX_AMP|JSON_HEX_APOS);
?>
<?php $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( 'div' ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr($uid) ?>" class="wf-announce" style="background:<?= esc_attr($bgc) ?>;color:<?= esc_attr($tc) ?>;overflow:hidden;height:<?= $h ?>px;position:relative;margin:0;box-sizing:border-box;width:100%;">
    <div class="wf-at-current" style="position:absolute;top:0;left:0;right:0;height:100%;box-sizing:border-box;display:flex;align-items:center;<?= $jc ?>padding:<?= $pad ?>px 20px;font-size:<?= $fs ?>px;font-weight:<?= esc_attr($fw) ?>;transition:all .4s ease;"></div>
    <div class="wf-at-next" style="position:absolute;top:100%;left:0;right:0;height:100%;box-sizing:border-box;display:flex;align-items:center;<?= $jc ?>padding:<?= $pad ?>px 20px;font-size:<?= $fs ?>px;font-weight:<?= esc_attr($fw) ?>;transition:all .4s ease;"></div>
</div>
<style>#<?= esc_attr($uid) ?> a{color:inherit;text-decoration:none}#<?= esc_attr($uid) ?> a:hover{text-decoration:underline}</style>
<script>
(function(){
    function boot(){
        
        var c = <?= $cfg ?>;
        var el=document.getElementById(c.uid);if(!el)return;
        var cur=el.querySelector('.wf-at-current');var nxt=el.querySelector('.wf-at-next');
        if(!cur)return;if(!nxt)return;
        var idx=0;var n=c.msgs.length;var paused=false;
        function render(target,i){
            var m=c.msgs[i];
            if(m.link){
                var a=document.createElement('a');
                a.setAttribute('href',m.link);
                a.textContent=m.text;
                target.textContent='';
                target.appendChild(a);
            } else {
                target.textContent=m.text;
            }
        }
        render(cur,0);
        if(n<2)return;
        if(c.hover){
            el.addEventListener('mouseenter',function(){paused=true});
            el.addEventListener('mouseleave',function(){paused=false});
        }
        setInterval(function(){
            if(paused)return;
            idx=(idx+1)%n;
            render(nxt,idx);
            nxt.style.transition='none';
            nxt.style.top=c.h+'px';nxt.style.opacity='1';
            requestAnimationFrame(function(){
                nxt.style.transition='all .4s ease';
                cur.style.top='-'+c.h+'px';
                nxt.style.top='0';
            });
            setTimeout(function(){
                render(cur,idx);
                cur.style.transition='none';
                cur.style.top='0';
                nxt.style.transition='none';
                nxt.style.top=c.h+'px';
                requestAnimationFrame(function(){
                    cur.style.transition='all .4s ease';
                    nxt.style.transition='all .4s ease';
                });
            },450);
        },c.speed);
    }
    WF.ready(boot)
})();
</script>

<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
