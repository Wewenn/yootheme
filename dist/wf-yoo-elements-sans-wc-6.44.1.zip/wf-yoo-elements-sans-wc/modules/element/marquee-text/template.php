<?php
/**
 * WeFrame – Marquee Text | template.php v6.0 (UIkit)
 * Uses shared keyframes wf-scroll-fwd/rev from weframe-shared.css.
 */
defined('ABSPATH') || exit;
$text = $props['text']??''; $sep = $props['separator']??''; $rows = max(1,min(3,(int)($props['rows']??1)));
$text2 = $props['text_2']??''; $text3 = $props['text_3']??'';
if (!trim($text)) return;
$speed = max(1,(int)($props['speed']??25)); $rev = !empty($props['reverse']); $hover = !empty($props['pause_on_hover']);
$fs = (int)($props['font_size']??64); $fsm = (int)($props['font_size_mobile']??32);
$fw = $props['font_weight']??'700'; $ff = trim($props['font_family']??'');
$ls = (float)($props['letter_spacing']??-2); $tt = $props['text_transform']??'none';
$color = $props['color']??'#000'; $stroke = !empty($props['stroke_mode']);
$sc = $props['stroke_color']??'#000'; $sw = (float)($props['stroke_width']??2);
$bgc = $props['bg_color']??''; $bgp = (int)($props['bg_padding']??20); $bga = (int)($props['bg_angle']??0);
$uid = 'wfmq_'.substr(md5(serialize($props)),0,8);
$fcss = $ff ? "font-family:{$ff};" : '';
$scss = $stroke ? "-webkit-text-stroke:{$sw}px {$sc};color:transparent;" : "color:".esc_attr($color).";";
$bg_style = '';
if ($bgc) { $bg_style = "background:".esc_attr($bgc).";padding:{$bgp}px 0;"; if ($bga != 0) $bg_style .= "transform:rotate({$bga}deg);margin:0 -5%;width:110%;"; }

function wf_marquee_row($txt, $sep, $uid, $suffix, $speed, $reverse, $hover, $fs, $fw, $fcss, $ls, $tt, $scss, $fsm) {
    $chunk = esc_html($txt);
    if ($sep) $chunk .= ' <span style="opacity:.4;padding:0 .3em;">'.esc_html($sep).'</span> ';
    $track = str_repeat('<span class="wf-mq-chunk">'.$chunk.'</span>', 8);
    // Use shared keyframes from weframe-shared.css
    $anim = $reverse ? 'wf-scroll-rev' : 'wf-scroll-fwd';
    echo '<div class="wf-mq-row" style="overflow:hidden;'.($suffix!=='_0'?'margin-top:8px;':'').'">';
    echo '<div class="wf-mq-track wf-mq-track'.$suffix.'" style="display:inline-flex;width:max-content;font-size:'.$fs.'px;font-weight:'.esc_attr($fw).';'.$fcss.'letter-spacing:'.$ls.'px;text-transform:'.esc_attr($tt).';'.$scss.'line-height:1.2;white-space:nowrap;">';
    echo $track;
    echo '</div></div>';
    echo '<style>';
    echo '#'.esc_attr($uid).' .wf-mq-track'.$suffix.'{animation:'.$anim.' '.$speed.'s linear infinite}';
    if ($hover) echo '#'.esc_attr($uid).':hover .wf-mq-track'.$suffix.'{animation-play-state:paused}';
    echo '@media(max-width:767px){#'.esc_attr($uid).' .wf-mq-track'.$suffix.'{font-size:'.$fsm.'px !important}}';
    echo '</style>';
}
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr($uid) ?>" class="wf-marquee" style="<?= $bg_style ?>overflow:hidden;">
<?php
    wf_marquee_row($text, $sep, $uid, '_0', $speed, $rev, $hover, $fs, $fw, $fcss, $ls, $tt, $scss, $fsm);
    if ($rows >= 2 && $text2) { wf_marquee_row($text2, $sep, $uid, '_1', $speed, !$rev, $hover, $fs, $fw, $fcss, $ls, $tt, $scss, $fsm); }
    if ($rows >= 3 && $text3) { wf_marquee_row($text3, $sep, $uid, '_2', $speed, $rev, $hover, $fs, $fw, $fcss, $ls, $tt, $scss, $fsm); }
?>
</div>
<style>@media(prefers-reduced-motion:reduce){#<?= esc_attr($uid) ?> .wf-mq-track{animation-play-state:paused !important}}</style>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
