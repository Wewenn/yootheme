<?php
/**
 * WeFrame – Contact Form | template.php v1.0
 * Formulaire AJAX (handler wf_contact_send dans bootstrap.php). Honeypot + nonce + envoi à l'admin.
 */
defined( 'ABSPATH' ) || exit;

$title   = (string) ( $props['title'] ?? 'Contactez-nous' );
$intro   = (string) ( $props['intro'] ?? '' );
$s_name  = ! empty( $props['show_name'] );
$s_phone = ! empty( $props['show_phone'] );
$s_subj  = ! empty( $props['show_subject'] );
$rows    = max( 2, (int) ( $props['message_rows'] ?? 5 ) );
$btn     = (string) ( $props['button_text'] ?? 'Envoyer' );
$consent = ! empty( $props['consent_enable'] );
$c_text  = (string) ( $props['consent_text'] ?? '' );
$accent  = $props['accent'] ?? '#111111';
$radius  = (int) ( $props['radius'] ?? 10 );
$mw      = (int) ( $props['max_width'] ?? 560 );

$uid   = wf_uid( 'wfcf_', $props );
$nonce = wp_create_nonce( 'wf_contact' );
$ajax  = admin_url( 'admin-ajax.php' );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-cf" style="max-width:<?= $mw ?>px;">
    <?php if ( $title ) : ?><h3 class="wf-cf-title" style="margin:0 0 8px;font-size:26px;font-weight:700;letter-spacing:-.01em;"><?= esc_html( $title ) ?></h3><?php endif; ?>
    <?php if ( $intro ) : ?><p class="wf-cf-intro" style="margin:0 0 18px;opacity:.8;line-height:1.5;"><?= esc_html( $intro ) ?></p><?php endif; ?>

    <form class="wf-cf-form" novalidate>
        <div style="position:absolute;left:-9999px;" aria-hidden="true"><label>Ne pas remplir<input type="text" name="wf_hp" tabindex="-1" autocomplete="off"></label></div>

        <?php if ( $s_name ) : ?>
        <input class="wf-cf-in" type="text" name="name" placeholder="Votre nom" autocomplete="name">
        <?php endif; ?>
        <input class="wf-cf-in" type="email" name="email" placeholder="Votre email *" required autocomplete="email">
        <?php if ( $s_phone ) : ?>
        <input class="wf-cf-in" type="tel" name="phone" placeholder="Téléphone" autocomplete="tel">
        <?php endif; ?>
        <?php if ( $s_subj ) : ?>
        <input class="wf-cf-in" type="text" name="subject" placeholder="Sujet">
        <?php endif; ?>
        <textarea class="wf-cf-in" name="message" rows="<?= $rows ?>" placeholder="Votre message *" required></textarea>

        <?php if ( $consent ) : ?>
        <label class="wf-cf-consent"><input type="checkbox" name="consent" required> <span><?= esc_html( $c_text ) ?></span></label>
        <?php endif; ?>

        <button class="wf-cf-btn" type="submit" style="background:<?= esc_attr( $accent ) ?>;border-radius:<?= $radius ?>px;"><?= esc_html( $btn ) ?></button>
        <p class="wf-cf-msg" role="status" aria-live="polite" style="margin:12px 0 0;display:none;"></p>
    </form>
</div>

<style>
#<?= esc_attr( $uid ) ?> .wf-cf-form{display:flex;flex-direction:column;gap:12px}
#<?= esc_attr( $uid ) ?> .wf-cf-in{width:100%;padding:13px 15px;border:1px solid #d8dade;border-radius:<?= $radius ?>px;font-size:15px;font-family:inherit;background:#fff;color:#111;transition:border-color .15s}
#<?= esc_attr( $uid ) ?> .wf-cf-in:focus{outline:none;border-color:<?= esc_attr( $accent ) ?>}
#<?= esc_attr( $uid ) ?> textarea.wf-cf-in{resize:vertical}
#<?= esc_attr( $uid ) ?> .wf-cf-consent{display:flex;gap:8px;align-items:flex-start;font-size:13px;opacity:.85;line-height:1.4}
#<?= esc_attr( $uid ) ?> .wf-cf-btn{color:#fff;border:none;padding:14px 22px;font-size:15px;font-weight:600;cursor:pointer;transition:opacity .2s;font-family:inherit}
#<?= esc_attr( $uid ) ?> .wf-cf-btn:hover{opacity:.88}
#<?= esc_attr( $uid ) ?> .wf-cf-btn[disabled]{opacity:.5;cursor:default}
#<?= esc_attr( $uid ) ?> .wf-cf-msg.ok{color:#0a7d32}
#<?= esc_attr( $uid ) ?> .wf-cf-msg.err{color:#b32d2e}
</style>

<script>
(function(){
    var id = <?= wp_json_encode( $uid ) ?>;
    var AJAX = <?= wp_json_encode( $ajax ) ?>;
    var NONCE = <?= wp_json_encode( $nonce ) ?>;
    function boot(){
        var root = document.getElementById(id); if (!root) return;
        var form = root.querySelector('.wf-cf-form');
        var btn = root.querySelector('.wf-cf-btn');
        var msg = root.querySelector('.wf-cf-msg');
        form.addEventListener('submit', function(e){
            e.preventDefault();
            msg.style.display = 'none'; msg.className = 'wf-cf-msg';
            var data = new FormData(form);
            data.append('action', 'wf_contact_send');
            data.append('nonce', NONCE);
            btn.setAttribute('disabled', 'disabled');
            fetch(AJAX, { method: 'POST', body: data, credentials: 'same-origin' })
                .then(function(r){ return r.json(); })
                .then(function(res){
                    btn.removeAttribute('disabled');
                    msg.style.display = 'block';
                    if (res.success) { msg.className = 'wf-cf-msg ok'; msg.textContent = res.data; form.reset(); }
                    else { msg.className = 'wf-cf-msg err'; msg.textContent = res.data || 'Erreur.'; }
                })
                .catch(function(){ btn.removeAttribute('disabled'); msg.style.display='block'; msg.className='wf-cf-msg err'; msg.textContent='Erreur réseau.'; });
        });
    }
    if (window.WF) { if (WF.ready) { WF.ready(boot); return; } }
    if (document.readyState !== 'loading') { boot(); } else { document.addEventListener('DOMContentLoaded', boot); }
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
