<?php
/**
 * WeFrame – Image dévoilée au scroll | clip-path piloté par le scroll.
 */
defined( 'ABSPATH' ) || exit;
$img = trim( (string) ( $props['image'] ?? '' ) );
if ( '' === $img ) { return; }
if ( ! preg_match( '#^https?://#i', $img ) ) { $img = '/' . ltrim( $img, '/' ); }
$dir = $props['direction'] ?? 'left';
if ( ! in_array( $dir, array( 'left', 'right', 'up', 'down', 'center' ), true ) ) { $dir = 'left'; }
$h   = max( 120, (int) ( $props['height'] ?? 460 ) );
$r   = max( 0, (int) ( $props['radius'] ?? 16 ) );
$uid = wf_uid( 'wfrs_', $props );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-rs" style="overflow:hidden;border-radius:<?= $r ?>px;height:<?= $h ?>px;">
    <img src="<?= esc_url( $img ) ?>" alt="" loading="lazy" style="width:100%;height:100%;object-fit:cover;display:block;will-change:clip-path;">
</div>
<script>
(function(){
    var el = document.getElementById('<?= esc_js( $uid ) ?>'); if (!el) return;
    var img = el.querySelector('img'); if (!img) return;
    var dir = '<?= esc_js( $dir ) ?>', ticking = false;
    if (window.matchMedia) if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    function clip(q){
        var v = (q * 100).toFixed(1) + '%';
        var h = (q * 50).toFixed(1) + '%';
        if (dir === 'left')  return 'inset(0 ' + v + ' 0 0)';
        if (dir === 'right') return 'inset(0 0 0 ' + v + ')';
        if (dir === 'up')    return 'inset(' + v + ' 0 0 0)';
        if (dir === 'down')  return 'inset(0 0 ' + v + ' 0)';
        return 'inset(' + h + ' ' + h + ' ' + h + ' ' + h + ')';
    }
    function upd(){
        ticking = false;
        var r = el.getBoundingClientRect(), vh = window.innerHeight || document.documentElement.clientHeight;
        var p = (vh - r.top) / (vh * 0.85);
        if (p < 0) p = 0; if (p > 1) p = 1;
        img.style.clipPath = clip(1 - p);
        img.style.webkitClipPath = clip(1 - p);
    }
    function onS(){ if (!ticking) { ticking = true; requestAnimationFrame(upd); } }
    window.addEventListener('scroll', onS, { passive: true });
    window.addEventListener('resize', onS, { passive: true });
    upd();
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
