<?php
/**
 * WeFrame – Tilt Card | template.php v6.0
 * 3D parallax tilt effect on mouse hover.
 */
defined( 'ABSPATH' ) || exit;

$content  = $props['content'] ?? '';
$tilt     = (int) ( $props['max_tilt'] ?? 15 );
$speed    = (int) ( $props['speed'] ?? 400 );
$glare    = ! empty( $props['glare'] );
$mg       = (float) ( $props['max_glare'] ?? 0.3 );
$persp    = (int) ( $props['perspective'] ?? 1000 );
$bg       = $props['bg_color'] ?? '#ffffff';
$rad      = (int) ( $props['radius'] ?? 16 );
$pad      = (int) ( $props['padding'] ?? 32 );
$shadow   = ! empty( $props['shadow'] );

$uid = wf_uid( 'wftc_', $props );

// Render children if container, otherwise use content field
$inner = '';
if ( ! empty( $children ) ) {
    foreach ( $children as $child ) {
        $inner .= $builder->render( $child, [ 'element' => $props ] );
    }
}
if ( ! trim( $inner ) ) { $inner = wp_kses_post( $content ); }
if ( ! trim( $inner ) ) { return; }

$shadow_css = $shadow ? 'box-shadow:0 10px 40px rgba(0,0,0,.1);' : '';
$cfg = json_encode( [ 'uid' => $uid, 'tilt' => $tilt, 'speed' => $speed, 'glare' => $glare, 'mg' => $mg, 'persp' => $persp ], JSON_HEX_AMP | JSON_HEX_APOS );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-tilt" style="perspective:<?= $persp ?>px;display:inline-block;width:100%;">
    <div class="wf-tilt-inner" style="background:<?= esc_attr( $bg ) ?>;border-radius:<?= $rad ?>px;padding:<?= $pad ?>px;<?= $shadow_css ?>transition:transform <?= $speed ?>ms ease-out;transform-style:preserve-3d;position:relative;overflow:hidden;">
        <div style="transform:translateZ(30px);"><?= $inner ?></div>
        <?php if ( $glare ) : ?>
        <div class="wf-tilt-glare" style="position:absolute;inset:0;border-radius:<?= $rad ?>px;pointer-events:none;opacity:0;background:linear-gradient(135deg,rgba(255,255,255,<?= $mg ?>),transparent 60%);transition:opacity <?= $speed ?>ms;"></div>
        <?php endif; ?>
    </div>
</div>

<script>
(function(){
    
    var c = <?= $cfg ?>;
    var el=document.getElementById(c.uid);if(!el)return;
    var card=el.querySelector('.wf-tilt-inner');if(!card)return;
    var glare=el.querySelector('.wf-tilt-glare');

    card.addEventListener('mousemove',function(e){
        var r=card.getBoundingClientRect();
        var x=(e.clientX-r.left)/r.width;
        var y=(e.clientY-r.top)/r.height;
        var rx=(y-.5)*-c.tilt*2;
        var ry=(x-.5)*c.tilt*2;
        card.style.transform='rotateX('+rx+'deg) rotateY('+ry+'deg)';
        if(glare){glare.style.opacity='1';glare.style.background='linear-gradient('+Math.round(x*360)+'deg,rgba(255,255,255,'+c.mg+'),transparent 60%)'}
    });
    card.addEventListener('mouseleave',function(){
        card.style.transform='rotateX(0) rotateY(0)';
        if(glare)glare.style.opacity='0';
    });
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
