<?php
/**
 * WeFrame – Image zoom au scroll | template.php v2.0
 *
 * Trois déroulements :
 *   - centré  : le maximum est atteint quand l'image occupe l'écran ;
 *   - bloqué  : la section reste figée et le défilement pilote le zoom ;
 *   - traversée : l'ancien calcul, où le maximum tombe une fois l'image sortie
 *     par le haut. Gardé tel quel pour les pages déjà en ligne.
 *
 * Une échelle sous 100 % rendrait l'image plus petite que son cadre et
 * laisserait des bords vides : la plage entière est alors remontée pour que le
 * minimum vaille 100 %. Le mouvement reste exactement le même.
 *
 * Pas de "&&" ni de "||" dans le JS inline (règle interne du plugin).
 */

defined( 'ABSPATH' ) || exit;

$img = trim( (string) ( $props['image'] ?? '' ) );
if ( '' === $img ) { return; }
if ( ! preg_match( '#^https?://#i', $img ) ) { $img = '/' . ltrim( $img, '/' ); }

$progress = (string) ( $props['progress'] ?? 'centered' );
if ( ! in_array( $progress, array( 'centered', 'hold', 'pinned', 'travel' ), true ) ) { $progress = 'centered'; }

$dirOut = ( 'out' === ( $props['direction'] ?? 'in' ) );

/**
 * Un champ nombre vide arrive en chaine vide, pas en null : « ?? » ne le
 * rattrape pas et (int) '' vaut 0. Les deux echelles tombaient alors sur leur
 * minimum, devenaient egales, et l'image restait figee a 100 %.
 */
$wfNum = static function ( $v, $default ) {
	if ( is_string( $v ) ) { $v = trim( $v ); }
	if ( null === $v ) { return $default; }
	if ( '' === $v ) { return $default; }
	if ( ! is_numeric( $v ) ) { return $default; }
	return (int) $v;
};

$s0 = max( 50, min( 150, $wfNum( $props['start_scale'] ?? null, 88 ) ) );
$s1 = max( 50, min( 200, $wfNum( $props['end_scale'] ?? null, 112 ) ) );
if ( $dirOut ) {
	$tmp = $s0;
	$s0  = $s1;
	$s1  = $tmp;
}

// Aucune échelle ne doit descendre sous 100 % : sinon l'image ne remplit plus
// son cadre. On remonte la plage entière, le rapport entre début et fin ne
// bouge pas.
$floor = min( $s0, $s1 );
if ( $floor < 100 ) {
	$k  = 100 / $floor;
	$s0 = (int) round( $s0 * $k );
	$s1 = (int) round( $s1 * $k );
}

$h      = max( 120, min( 1200, $wfNum( $props['height'] ?? null, 480 ) ) );
$r      = max( 0, min( 60, $wfNum( $props['radius'] ?? null, 16 ) ) );
$dwell  = max( 100, min( 400, $wfNum( $props['dwell_vh'] ?? null, 200 ) ) );
$bleed  = ! empty( $props['full_bleed'] ) && ( 'pinned' === $progress );
$ovl    = max( 0, min( 90, $wfNum( $props['overlay'] ?? null, 0 ) ) );
$ovlCol = (string) ( $props['overlay_color'] ?? '#000000' );
$alt    = trim( (string) ( $props['alt'] ?? '' ) );

$pinned = ( 'pinned' === $progress );
$inert  = ( $s0 === $s1 );

$uid = wf_uid( 'wfizs_', $props );

$cfg = wp_json_encode(
	array(
		'uid'  => $uid,
		'mode' => $progress,
		's0'   => $s0,
		's1'   => $s1,
	),
	JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE
);
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-izs wf-izs--<?= esc_attr( $progress ) ?>" data-wf-zoom="<?= (int) $s0 ?>-<?= (int) $s1 ?>"<?php if ( $inert ) : ?> data-wf-warn="echelles identiques : aucun zoom"<?php endif; ?>>
	<div class="wf-izs__stick">
		<div class="wf-izs__frame">
			<img class="wf-izs__img" src="<?= esc_url( $img ) ?>" alt="<?= esc_attr( $alt ) ?>" loading="lazy" decoding="async">
			<?php if ( $ovl > 0 ) : ?><span class="wf-izs__ovl" aria-hidden="true"></span><?php endif; ?>
		</div>
	</div>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?>{--s:<?= esc_attr( round( $s0 / 100, 4 ) ) ?>;}
#<?= esc_attr( $uid ) ?> .wf-izs__frame{
	position:relative;overflow:hidden;border-radius:<?= (int) $r ?>px;
	<?php if ( $pinned ) : ?>height:100%;<?php else : ?>height:<?= (int) $h ?>px;<?php endif; ?>
}
#<?= esc_attr( $uid ) ?> .wf-izs__img{
	display:block;width:100%;height:100%;object-fit:cover;
	transform:scale(var(--s));transform-origin:center center;will-change:transform;
}
<?php if ( $ovl > 0 ) : ?>
#<?= esc_attr( $uid ) ?> .wf-izs__ovl{
	position:absolute;inset:0;pointer-events:none;
	background:<?= esc_attr( $ovlCol ) ?>;opacity:<?= esc_attr( round( $ovl / 100, 2 ) ) ?>;
}
<?php endif; ?>
<?php if ( $pinned ) : ?>
/* Blocage : la piste donne la distance de défilement, l'intérieur reste collé
   en haut de l'écran pendant toute sa traversée. */
#<?= esc_attr( $uid ) ?>{height:<?= (int) $dwell ?>vh;}
#<?= esc_attr( $uid ) ?> .wf-izs__stick{
	position:sticky;top:0;height:100vh;height:100svh;overflow:hidden;
}
<?php if ( $bleed ) : ?>
/* Pleine page : on deborde la colonne jusqu'aux bords de la fenetre.
   --wf-vw est la largeur reelle, sans la barre de defilement (WF.viewportVar). */
#<?= esc_attr( $uid ) ?> .wf-izs__frame{
	width:var(--wf-vw,100vw);margin-left:calc(50% - var(--wf-vw,100vw) / 2);border-radius:0;
}
<?php endif; ?>
<?php endif; ?>
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?>{--s:<?= esc_attr( round( max( $s0, $s1 ) / 100, 4 ) ) ?>;}
	<?php if ( $pinned ) : ?>
	#<?= esc_attr( $uid ) ?>{height:auto;}
	#<?= esc_attr( $uid ) ?> .wf-izs__stick{position:static;height:<?= (int) $h ?>px;}
	<?php endif; ?>
}
</style>
<script>
(function(){
	function boot(){
		var c = <?= $cfg ?>;
		var el = document.getElementById(c.uid);
		if(!el){return;}
		if(el.getAttribute('data-wf-ready')){return;}
		el.setAttribute('data-wf-ready','1');

		// Pas de dependance dure a WF : si le fichier partage n'est pas charge
		// (cache, conflit de plugin), le zoom doit quand meme fonctionner.
		var reduced = false;
		if(typeof matchMedia === 'function'){
			reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
		}
		if(reduced){return;}
		if(window.WF){ if(WF.viewportVar){ WF.viewportVar(); } }

		var ticking = false;

		function ratio(){
			var r = el.getBoundingClientRect();
			var vh = window.innerHeight;
			if(!vh){ vh = document.documentElement.clientHeight; }

			if(c.mode === 'pinned'){
				// La piste défile derrière un intérieur figé : la progression est
				// la part de piste déjà passée sous le haut de l'écran.
				var travel = r.height - vh;
				if(travel <= 0){ return 0; }
				return -r.top / travel;
			}

			var mid = r.top + r.height / 2;
			var span = (vh + r.height) / 2;

			if(c.mode === 'centered'){
				// 1 quand le centre de l'image est au centre de l'ecran : le
				// maximum tombe pendant qu'on la regarde, pas une fois sortie.
				// Symetrique : ca redescend quand elle repart.
				if(span <= 0){ return 0; }
				return 1 - Math.abs(mid - vh / 2) / span;
			}

			if(c.mode === 'hold'){
				// Meme montee, mais une fois le centre atteint on n'en bouge plus.
				if(span <= 0){ return 0; }
				return 1 - (mid - vh / 2) / span;
			}

			// Traversée : comportement d'origine, conservé tel quel.
			return (vh - r.top) / (vh + r.height);
		}

		function paint(){
			ticking = false;
			var p = ratio();
			if(p < 0){ p = 0; }
			if(p > 1){ p = 1; }
			el.style.setProperty('--s', ((c.s0 + (c.s1 - c.s0) * p) / 100).toFixed(4));
		}

		function onScroll(){
			if(ticking){return;}
			ticking = true;
			// Un onglet en arriere-plan ne declenche aucun rAF : on peint alors
			// tout de suite plutot que de rester fige.
			if(document.hidden){ paint(); return; }
			window.requestAnimationFrame(paint);
		}

		window.addEventListener('scroll', onScroll, {passive:true});
		window.addEventListener('resize', onScroll, {passive:true});
		paint();
	}
	if(document.readyState === 'loading'){
		document.addEventListener('DOMContentLoaded', boot);
	}else{
		boot();
	}
}());
</script>
