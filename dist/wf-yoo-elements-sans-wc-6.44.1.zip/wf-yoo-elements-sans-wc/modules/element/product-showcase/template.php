<?php
defined('ABSPATH') || exit;
if (empty($children)) return;
$mh = (int)($props['main_height']??400); $mhm = (int)($props['main_height_mobile']??250);
$mbg = $props['main_bg']??'#f5f5f5'; $mr = (int)($props['main_radius']??16);
$ths = (int)($props['thumb_size']??72); $thr = (int)($props['thumb_radius']??8);
$thg = (int)($props['thumb_gap']??8); $zoom = !empty($props['zoom_on_hover']);
$lb = !empty($props['lightbox']);
$uid = 'wfps_'.substr(md5(serialize($props).count($children)),0,8);
$images = [];
foreach ($children as $child) {
    $cp = (array)($child->props ?? []);
    $src = $cp['image']??'';
    if ($src) { if (!preg_match('#^https?://#i',$src)) $src='/'.ltrim($src,'/'); }
    if ($src) $images[] = ['src'=>$src, 'alt'=>$cp['image_alt']??''];
}
if (!$images) return;
$cfg = json_encode(['uid'=>$uid,'images'=>$images,'zoom'=>$zoom,'lightbox'=>$lb], JSON_HEX_AMP|JSON_HEX_APOS);
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr($uid) ?>" class="wf-showcase">
    <div class="wf-ps-main" style="background:<?= esc_attr($mbg) ?>;border-radius:<?= $mr ?>px;height:<?= $mh ?>px;display:flex;align-items:center;justify-content:center;overflow:hidden;cursor:<?= $zoom?'zoom-in':'default' ?>;position:relative;">
        <img class="wf-ps-img" src="<?= esc_url($images[0]['src']) ?>" alt="<?= esc_attr($images[0]['alt']) ?>" style="max-width:90%;max-height:90%;object-fit:contain;transition:transform .3s;">
    </div>
    <?php if (count($images)>1) : ?>
    <div style="display:flex;gap:<?= $thg ?>px;margin-top:<?= $thg ?>px;justify-content:center;flex-wrap:wrap;">
        <?php foreach ($images as $i => $img) : ?>
        <button class="wf-ps-thumb<?= $i===0?' wf-ps-thumb--active':'' ?>" data-idx="<?= $i ?>" style="cursor:pointer;border:2px solid <?= $i===0?'#333':'transparent' ?>;border-radius:<?= $thr ?>px;overflow:hidden;padding:0;background:<?= esc_attr($mbg) ?>;width:<?= $ths ?>px;height:<?= $ths ?>px;display:flex;align-items:center;justify-content:center;transition:border-color .2s;">
            <img src="<?= esc_url($img['src']) ?>" alt="<?= esc_attr($img['alt']) ?>" loading="lazy" style="max-width:85%;max-height:85%;object-fit:contain;">
        </button>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>
<style>
@media(max-width:767px){#<?= esc_attr($uid) ?> .wf-ps-main{height:<?= $mhm ?>px !important}}
<?php if ($zoom) : ?>#<?= esc_attr($uid) ?> .wf-ps-main:hover .wf-ps-img{transform:scale(1.5)}<?php endif; ?>
</style>
<?php if (count($images)>1) : ?>
<script>
(function(){
    function boot(){
        
        var c = <?= $cfg ?>;
        var el=document.getElementById(c.uid);if(!el)return;
        var main=el.querySelector('.wf-ps-img');
        var thumbs=el.querySelectorAll('.wf-ps-thumb');
        var i=0;while(i<thumbs.length){
            (function(idx){
                thumbs[idx].addEventListener('click',function(){
                    main.src=c.images[idx].src;main.alt=c.images[idx].alt;
                    var j=0;while(j<thumbs.length){thumbs[j].style.borderColor='transparent';thumbs[j].classList.remove('wf-ps-thumb--active');j++}
                    thumbs[idx].style.borderColor='#333';thumbs[idx].classList.add('wf-ps-thumb--active');
                });
            })(i);
            i++;
        }
        if(c.lightbox){
            main.parentElement.addEventListener('click',function(){
                var overlay=document.createElement('div');
                overlay.style.cssText='position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.9);z-index:99999;display:flex;align-items:center;justify-content:center;cursor:zoom-out;';
                var img=document.createElement('img');
                img.src=main.src;img.alt=main.alt;img.style.cssText='max-width:90vw;max-height:90vh;object-fit:contain;';
                overlay.appendChild(img);
                overlay.addEventListener('click',function(){document.body.removeChild(overlay)});
                document.body.appendChild(overlay);
            });
        }
    }
    WF.ready(boot)
})();
</script>
<?php endif; ?>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
