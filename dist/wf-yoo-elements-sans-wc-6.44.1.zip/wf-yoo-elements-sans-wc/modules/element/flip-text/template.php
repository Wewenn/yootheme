<?php
/**
 * WeFrame – Mots qui basculent (3D) | template.php v1.0
 * Un texte fixe, et un mot qui bascule sur une face de cube vers le suivant.
 *
 * Les mots sont tous dans le DOM : la phrase reste complete pour un moteur de
 * recherche, et lisible si le script ne tourne pas. Une zone de statut annonce
 * le changement, sinon un lecteur d'ecran ne verrait rien bouger.
 * Pas de "&&" ni de "||" dans le JS inline (regle interne du plugin).
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$prefix = trim( (string) ( $props['prefix'] ?? '' ) );
$suffix = trim( (string) ( $props['suffix'] ?? '' ) );
$interval = max( 600, (int) ( $props['interval'] ?? 2400 ) );
$dur   = max( 150, (int) ( $props['duration'] ?? 700 ) );
$axis  = ( 'y' === ( $props['axis'] ?? 'x' ) ) ? 'y' : 'x';
$persp = max( 200, (int) ( $props['perspective'] ?? 600 ) );
$pause = ! empty( $props['pause_hover'] );

$fs    = max( 16, (int) ( $props['font_size'] ?? 48 ) );
$fsMin = max( 14, (int) ( $props['font_size_min'] ?? 26 ) );
if ( $fsMin > $fs ) { $fsMin = $fs; }
$fw    = (string) ( $props['weight'] ?? '700' );
$align = (string) ( $props['align'] ?? 'center' );
if ( ! in_array( $align, array( 'left', 'center', 'right' ), true ) ) { $align = 'center'; }
$col   = (string) ( $props['color'] ?? '#111111' );
$wCol  = (string) ( $props['word_color'] ?? '#EA5C1C' );

$words = array();
foreach ( $children as $child ) {
	$cp = (array) ( $child->props ?? array() );
	$w  = trim( (string) ( $cp['word'] ?? '' ) );
	if ( '' === $w ) { continue; }
	$words[] = array( 'w' => $w, 'c' => trim( (string) ( $cp['color'] ?? '' ) ) );
}
if ( empty( $words ) ) { return; }
$n = count( $words );

$just = array( 'left' => 'flex-start', 'center' => 'center', 'right' => 'flex-end' );
$uid  = wf_uid( 'wfft_', $props, $n );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-ft wf-ft--<?= esc_attr( $axis ) ?><?= $pause ? ' wf-ft--pause' : '' ?>" data-count="<?= (int) $n ?>">
	<p class="__line">
		<?php if ( '' !== $prefix ) : ?><span class="__fix"><?= esc_html( $prefix ) ?></span><?php endif; ?>
		<span class="__slot">
			<?php foreach ( $words as $i => $w ) : ?>
			<span class="__w<?= 0 === $i ? ' is-in' : '' ?>"<?= '' !== $w['c'] ? ' style="--wc:' . esc_attr( $w['c'] ) . '"' : '' ?>><?= esc_html( $w['w'] ) ?></span>
			<?php endforeach; ?>
		</span>
		<?php if ( '' !== $suffix ) : ?><span class="__fix"><?= esc_html( $suffix ) ?></span><?php endif; ?>
	</p>
	<p class="wf-sr" role="status" aria-live="polite"></p>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?>{container-type:inline-size;}
#<?= esc_attr( $uid ) ?> .__line{
	margin:0;display:flex;flex-wrap:wrap;align-items:baseline;gap:.3em;
	justify-content:<?= esc_attr( $just[ $align ] ) ?>;
	font-size:clamp(<?= (int) $fsMin ?>px, 7cqw, <?= (int) $fs ?>px);
	font-weight:<?= esc_attr( $fw ) ?>;line-height:1.2;color:<?= esc_attr( $col ) ?>;
}
#<?= esc_attr( $uid ) ?> .__slot{
	position:relative;display:inline-block;min-width:0;
	perspective:<?= (int) $persp ?>px;
	transform-style:preserve-3d;
}
#<?= esc_attr( $uid ) ?> .__w{
	display:block;white-space:nowrap;color:var(--wc,<?= esc_attr( $wCol ) ?>);
	backface-visibility:hidden;
	transition:transform <?= (int) $dur ?>ms cubic-bezier(.2,.8,.2,1),opacity <?= (int) round( $dur * .6 ) ?>ms ease;
}
/* Le premier mot occupe la place et donne sa largeur au bloc ; les suivants se
   superposent en absolu, sinon la phrase sauterait a chaque bascule. */
#<?= esc_attr( $uid ) ?> .__w + .__w{position:absolute;left:0;top:0;}
#<?= esc_attr( $uid ) ?>.wf-ft--x .__w{transform-origin:50% 50% -0.5em;}
#<?= esc_attr( $uid ) ?>.wf-ft--x .__w.is-out{transform:rotateX(-90deg);opacity:0;}
#<?= esc_attr( $uid ) ?>.wf-ft--x .__w.is-next{transform:rotateX(90deg);opacity:0;}
#<?= esc_attr( $uid ) ?>.wf-ft--y .__w.is-out{transform:rotateY(-90deg);opacity:0;}
#<?= esc_attr( $uid ) ?>.wf-ft--y .__w.is-next{transform:rotateY(90deg);opacity:0;}
#<?= esc_attr( $uid ) ?> .__w.is-in{transform:none;opacity:1;}
#<?= esc_attr( $uid ) ?> .wf-sr{
	position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;
	clip:rect(0,0,0,0);white-space:nowrap;border:0;
}
/* Sans script, tous les mots sont visibles : la phrase garde du sens. */
#<?= esc_attr( $uid ) ?>.is-ready .__w:not(.is-in){opacity:0;}
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?> .__w{transition-duration:.001ms;}
}
</style>

<script>
(function(){
	var root = document.getElementById('<?= esc_js( $uid ) ?>');
	if (!root) { return; }
	var words = [].slice.call(root.querySelectorAll('.__w'));
	var live = root.querySelector('.wf-sr');
	var n = words.length;
	if (n < 2) { return; }

	var reduced = false;
	if (window.matchMedia) {
		if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { reduced = true; }
	}

	// Largeur figee sur le plus long mot : la phrase ne bouge pas d'un cran.
	var slot = root.querySelector('.__slot');
	function sizeSlot(){
		var w = 0;
		for (var k = 0; k < n; k++) {
			var r = words[k].getBoundingClientRect();
			if (r.width > w) { w = r.width; }
		}
		if (w > 0) { slot.style.minWidth = Math.ceil(w) + 'px'; }
	}

	var cur = 0;
	function go(next){
		if (next >= n) { next = 0; }
		if (next === cur) { return; }
		words[cur].classList.remove('is-in');
		words[cur].classList.add('is-out');
		words[next].classList.remove('is-next');
		words[next].classList.remove('is-out');
		words[next].classList.add('is-in');
		var prev = cur;
		cur = next;
		setTimeout(function(){
			words[prev].classList.remove('is-out');
			words[prev].classList.add('is-next');
		}, <?= (int) $dur ?>);
		if (live) { live.textContent = words[next].textContent; }
	}

	for (var k = 1; k < n; k++) { words[k].classList.add('is-next'); }
	root.classList.add('is-ready');
	sizeSlot();
	window.addEventListener('resize', sizeSlot);

	if (reduced) { return; }
	var timer = null;
	function start(){ stop(); timer = setInterval(function(){ go(cur + 1); }, <?= (int) $interval ?>); }
	function stop(){ if (timer) { clearInterval(timer); timer = null; } }
<?php if ( $pause ) : ?>
	root.addEventListener('mouseenter', stop);
	root.addEventListener('mouseleave', start);
	root.addEventListener('focusin', stop);
<?php endif; ?>
	if (typeof WF !== 'undefined') {
		if (WF.onVisible) { WF.onVisible(root, start, 0.3); return; }
	}
	start();
})();
</script>
