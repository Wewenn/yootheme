<?php
/**
 * WeFrame – Testimonial Video | template.php v1.0
 * Supporte YouTube / Vimeo (embed url) ou MP4 (url directe).
 */
defined( 'ABSPATH' ) || exit;

$title    = $props['title'] ?? '';
$tsize    = (int) ( $props['section_title_size'] ?? 28 );
$items_raw= $props['items'] ?? '';
$cols     = (int) ( $props['columns'] ?? 3 );
$gap      = (int) ( $props['gap'] ?? 20 );
$ratio    = $props['ratio'] ?? '16/9';
$crad     = (int) ( $props['card_radius'] ?? 14 );
$ov       = $props['bg_overlay'] ?? '#000000';
$ovo      = (int) ( $props['overlay_opacity'] ?? 30 );
$pbg      = $props['play_bg'] ?? '#EA5C1C';
$pc       = $props['play_color'] ?? '#ffffff';
$tc       = $props['text_color'] ?? '#111111';
$rc       = $props['role_color'] ?? '#6B7280';

$items = [];
foreach ( preg_split( "/\r?\n\r?\n/", trim( $items_raw ) ) as $block ) {
    $block = trim( $block );
    if ( ! $block ) continue;
    $parts = array_map( 'trim', explode( '||', $block ) );
    if ( count( $parts ) < 2 ) continue;
    $items[] = [
        'thumb'  => $parts[0],
        'video'  => $parts[1],
        'author' => $parts[2] ?? '',
        'role'   => $parts[3] ?? '',
    ];
}
if ( empty( $items ) ) return;
$uid = wf_uid( 'wftv_', $props );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-tv-wrap" style="margin:24px 0;">
    <?php if ( $title ) : ?>
    <h3 style="margin:0 0 24px;font-size:<?= $tsize ?>px;font-weight:700;color:<?= esc_attr( $tc ) ?>;text-align:center;"><?= esc_html( $title ) ?></h3>
    <?php endif; ?>
    <div class="wf-tv-grid" style="display:grid;grid-template-columns:repeat(<?= (int) $cols ?>,1fr);gap:<?= $gap ?>px;">
    <?php foreach ( $items as $i => $it ) : ?>
        <div class="wf-tv-card">
            <button type="button" class="wf-tv-thumb" data-video="<?= esc_attr( $it['video'] ) ?>" aria-label="Lire la vidéo<?= $it['author'] ? ' : ' . esc_attr( $it['author'] ) : '' ?>"
                style="position:relative;display:block;width:100%;border:0;padding:0;background:#000;border-radius:<?= $crad ?>px;overflow:hidden;cursor:pointer;aspect-ratio:<?= esc_attr( $ratio ) ?>;">
                <img src="<?= esc_url( $it['thumb'] ) ?>" alt="<?= esc_attr( $it['author'] ) ?>" style="width:100%;height:100%;object-fit:cover;display:block;transition:transform .4s;" loading="lazy">
                <span style="position:absolute;inset:0;background:<?= esc_attr( $ov ) ?>;opacity:<?= $ovo / 100 ?>;transition:opacity .25s;"></span>
                <span class="wf-tv-play" style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:64px;height:64px;background:<?= esc_attr( $pbg ) ?>;color:<?= esc_attr( $pc ) ?>;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;box-shadow:0 8px 24px rgba(0,0,0,0.3);transition:transform .2s;">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><polygon points="6 4 20 12 6 20 6 4"/></svg>
                </span>
            </button>
            <?php if ( $it['author'] || $it['role'] ) : ?>
            <div style="margin-top:12px;line-height:1.35;">
                <?php if ( $it['author'] ) : ?><div style="font-weight:700;font-size:14px;color:<?= esc_attr( $tc ) ?>;"><?= esc_html( $it['author'] ) ?></div><?php endif; ?>
                <?php if ( $it['role'] ) : ?><div style="font-size:13px;color:<?= esc_attr( $rc ) ?>;"><?= esc_html( $it['role'] ) ?></div><?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
    </div>

    <div class="wf-tv-modal" role="dialog" aria-modal="true" style="display:none;position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,0.85);align-items:center;justify-content:center;padding:20px;">
        <button type="button" class="wf-tv-close" aria-label="Fermer" style="position:absolute;top:20px;right:24px;background:transparent;border:0;color:#fff;font-size:40px;line-height:1;cursor:pointer;">&times;</button>
        <div class="wf-tv-player" style="width:100%;max-width:1000px;aspect-ratio:<?= esc_attr( $ratio ) ?>;background:#000;border-radius:12px;overflow:hidden;"></div>
    </div>
</div>
<style>
#<?= esc_attr( $uid ) ?> .wf-tv-thumb:hover img { transform: scale(1.05); }
#<?= esc_attr( $uid ) ?> .wf-tv-thumb:hover .wf-tv-play { transform: translate(-50%,-50%) scale(1.08); }
#<?= esc_attr( $uid ) ?> .wf-tv-modal.is-open { display:flex !important; }
@media (max-width:900px) { #<?= esc_attr( $uid ) ?> .wf-tv-grid { grid-template-columns:repeat(2,1fr) !important; } }
@media (max-width:600px) { #<?= esc_attr( $uid ) ?> .wf-tv-grid { grid-template-columns:1fr !important; } }
</style>
<script>
(function(){
    WF.ready(function(){
        var root = document.getElementById('<?= esc_attr( $uid ) ?>');
        if (!root) return;
        var modal = root.querySelector('.wf-tv-modal');
        var player = root.querySelector('.wf-tv-player');
        var close  = root.querySelector('.wf-tv-close');
        if (modal.parentNode !== document.body) document.body.appendChild(modal);

        function isVideoFile(u){ return /\.(mp4|webm|ogg)(\?|$)/i.test(u); }

        function open(url){
            if (isVideoFile(url)) {
                player.innerHTML = '<video src="' + url + '" controls autoplay playsinline style="width:100%;height:100%;display:block;background:#000;"></video>';
            } else {
                var sep = url.indexOf('?') === -1 ? '?' : '&';
                player.innerHTML = '<iframe src="' + url + sep + 'autoplay=1" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen style="width:100%;height:100%;border:0;display:block;"></iframe>';
            }
            modal.classList.add('is-open');
            document.body.style.overflow = 'hidden';
        }
        function closeIt(){
            modal.classList.remove('is-open');
            player.innerHTML = '';
            document.body.style.overflow = '';
        }
        root.querySelectorAll('.wf-tv-thumb').forEach(function(btn){
            btn.addEventListener('click', function(){ open(btn.getAttribute('data-video')); });
        });
        close.addEventListener('click', closeIt);
        modal.addEventListener('click', function(e){ if (e.target === modal) closeIt(); });
        document.addEventListener('keydown', function(e){ if (e.key === 'Escape' && modal.classList.contains('is-open')) closeIt(); });
    });
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
