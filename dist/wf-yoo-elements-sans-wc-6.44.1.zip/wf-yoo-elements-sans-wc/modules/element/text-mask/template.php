<?php
/**
 * WeFrame – Text Mask | template.php
 * Text filled with an image or gradient (background-clip:text).
 * Config inlined (no <script type="application/json">), no "&&" in inline JS.
 */
defined( 'ABSPATH' ) || exit;

$props = is_array( $props ?? null ) ? $props : array();

$text = trim( (string) ( $props['text'] ?? '' ) );
if ( '' === $text ) { return; }

$fill   = (string) ( $props['fill_type'] ?? 'image' );
$image  = trim( (string) ( $props['image'] ?? '' ) );
$c1     = (string) ( $props['grad_c1'] ?? '#ff5b1e' );
$c2     = (string) ( $props['grad_c2'] ?? '#7b2ff7' );
$angle  = (int) ( $props['grad_angle'] ?? 90 );
$anim   = (string) ( $props['animate'] ?? 'none' );
$size   = (int) ( $props['size'] ?? 120 );
$size_t = (int) ( $props['size_tablet'] ?? 84 );
$size_m = (int) ( $props['size_mobile'] ?? 52 );
$weight = (string) ( $props['weight'] ?? '800' );
$lh     = (int) ( $props['line_height'] ?? 100 );
$ls     = (float) ( $props['letter_spacing'] ?? -2 );
$font   = trim( (string) ( $props['font'] ?? '' ) );
$align  = (string) ( $props['align'] ?? 'center' );
$maxw   = (int) ( $props['max_width'] ?? 0 );
$upper  = ! empty( $props['uppercase'] );
$fb     = (string) ( $props['fallback_color'] ?? '#111111' );

if ( 'image' === $fill && $image && ! preg_match( '#^https?://#i', $image ) ) { $image = '/' . ltrim( $image, '/' ); }

$uid = 'wftm_' . substr( md5( $text . serialize( $props ) ), 0, 8 );

// Build the fill background
if ( 'image' === $fill && $image ) {
    $bg = 'background-image:url(' . esc_url( $image ) . ');background-size:cover;background-position:center;';
} else {
    if ( 'shine' === $anim ) {
        $bg = 'background-image:linear-gradient(' . $angle . 'deg,' . esc_attr( $c1 ) . ',' . esc_attr( $c2 ) . ',' . esc_attr( $c1 ) . ');background-size:200% auto;';
    } else {
        $bg = 'background-image:linear-gradient(' . $angle . 'deg,' . esc_attr( $c1 ) . ',' . esc_attr( $c2 ) . ');';
    }
}

$ff  = $font ? 'font-family:' . $font . ';' : '';
$mw  = ( $maxw > 0 ) ? 'max-width:' . $maxw . 'px;' . ( 'center' === $align ? 'margin-left:auto;margin-right:auto;' : '' ) : '';
$upc = $upper ? 'text-transform:uppercase;' : '';

$parallax = ( 'parallax' === $anim && 'image' === $fill && $image );

$cfg = wp_json_encode( array(
    'uid'      => $uid,
    'parallax' => $parallax ? 1 : 0,
), JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div class="wf-tm-wrap" style="text-align:<?= esc_attr( $align ) ?>;<?= $mw ?>">
    <span id="<?= esc_attr( $uid ) ?>" class="wf-tm" style="display:inline-block;<?= $bg ?>-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;color:transparent;font-size:<?= $size ?>px;font-weight:<?= esc_attr( $weight ) ?>;line-height:<?= $lh ?>%;letter-spacing:<?= $ls ?>px;<?= $upc ?><?= $ff ?><?= 'shine' === $anim ? 'animation:wf-tm-shine 5s linear infinite;' : '' ?>"><?= nl2br( esc_html( $text ) ) ?></span>
</div>

<style>
@keyframes wf-tm-shine { 0% { background-position: 0% center; } 100% { background-position: -200% center; } }
@media (min-width:768px) and (max-width:1024px) { #<?= esc_attr( $uid ) ?> { font-size: <?= $size_t ?>px !important; } }
@media (max-width:767px) { #<?= esc_attr( $uid ) ?> { font-size: <?= $size_m ?>px !important; } }
@supports not ((-webkit-background-clip: text) or (background-clip: text)) {
    #<?= esc_attr( $uid ) ?> { -webkit-text-fill-color: <?= esc_attr( $fb ) ?> !important; color: <?= esc_attr( $fb ) ?> !important; background: none !important; }
}
@media (prefers-reduced-motion: reduce) { #<?= esc_attr( $uid ) ?> { animation: none !important; } }
</style>

<?php if ( $parallax ) : ?>
<script>
(function(){
    var C = <?= $cfg ?>;
    function boot(){
        var el = document.getElementById(C.uid); if (!el) return;
        var ticking = false;
        function update(){
            ticking = false;
            var r = el.getBoundingClientRect();
            var vh = window.innerHeight || 1;
            var p = (vh - r.top) / (vh + r.height);
            if (p < 0) { p = 0; }
            if (p > 1) { p = 1; }
            el.style.backgroundPosition = 'center ' + (p * 100).toFixed(1) + '%';
        }
        function onScroll(){ if (!ticking) { ticking = true; requestAnimationFrame(update); } }
        window.addEventListener('scroll', onScroll, { passive: true });
        window.addEventListener('resize', onScroll, { passive: true });
        update();
    }
    if (window.WF) { if (WF.ready) { WF.ready(boot); return; } }
    if (document.readyState !== 'loading') { boot(); } else { document.addEventListener('DOMContentLoaded', boot); }
})();
</script>
<?php endif; ?>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
