<?php
/**
 * WeFrame – Hero Zoom-Out | l'image plein cadre rétrécit dans un cadre arrondi au scroll.
 */
defined( 'ABSPATH' ) || exit;
$img = trim( (string) ( $props['image'] ?? '' ) );
if ( '' === $img ) { return; }
if ( ! preg_match( '#^https?://#i', $img ) ) { $img = '/' . ltrim( $img, '/' ); }
$title = (string) ( $props['title'] ?? '' );
$sub   = (string) ( $props['subtitle'] ?? '' );
$s0    = max( 100, min( 200, (int) ( $props['start_scale'] ?? 118 ) ) );
$rad   = max( 0, (int) ( $props['end_radius'] ?? 24 ) );
$ovl   = max( 0, min( 90, (int) ( $props['overlay'] ?? 20 ) ) );
$h     = max( 200, (int) ( $props['height'] ?? 560 ) );
$uid   = wf_uid( 'wfhzo_', $props );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-hzo" style="height:<?= $h ?>px;">
    <div class="wf-hzo-frame" style="position:relative;width:100%;height:100%;overflow:hidden;border-radius:0;will-change:transform,border-radius;">
        <img src="<?= esc_url( $img ) ?>" alt="<?= esc_attr( $title ) ?>" loading="lazy" style="width:100%;height:100%;object-fit:cover;display:block;transform:scale(<?= $s0 / 100 ?>);will-change:transform;">
        <?php if ( $ovl > 0 ) : ?><span style="position:absolute;inset:0;background:rgba(0,0,0,<?= $ovl / 100 ?>);"></span><?php endif; ?>
        <?php if ( '' !== $title || '' !== $sub ) : ?>
        <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;color:#fff;padding:20px;">
            <?php if ( '' !== $title ) : ?><div style="font-size:clamp(28px,5vw,54px);font-weight:800;letter-spacing:-.02em;line-height:1.05;"><?= esc_html( $title ) ?></div><?php endif; ?>
            <?php if ( '' !== $sub ) : ?><div style="font-size:clamp(15px,2vw,20px);opacity:.9;margin-top:10px;"><?= esc_html( $sub ) ?></div><?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</div>
<script>
(function(){
    var el = document.getElementById('<?= esc_js( $uid ) ?>'); if (!el) return;
    var frame = el.querySelector('.wf-hzo-frame'), img = el.querySelector('img');
    if (!frame) return;
    if (window.matchMedia) if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    var s0 = <?= (int) $s0 ?>, rad = <?= (int) $rad ?>, ticking = false;
    function upd(){
        ticking = false;
        var r = el.getBoundingClientRect(), vh = window.innerHeight || document.documentElement.clientHeight;
        var p = (vh - r.top) / (vh + r.height);
        if (p < 0) p = 0; if (p > 1) p = 1;
        if (img) img.style.transform = 'scale(' + ((s0 - (s0 - 100) * p) / 100) + ')';
        frame.style.borderRadius = (rad * p) + 'px';
    }
    function onS(){ if (!ticking) { ticking = true; requestAnimationFrame(upd); } }
    window.addEventListener('scroll', onS, { passive: true });
    window.addEventListener('resize', onS, { passive: true });
    upd();
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
