<?php
/**
 * WeFrame – Scroll Progress | template.php v7.0
 *
 * Trois formes : la barre fixe en haut ou en bas (comportement d'origine),
 * un rail vertical avec un repère chiffré qui descend, et le même rail gradué
 * en petits traits.
 *
 * Les rails sont posés au milieu de la hauteur d'écran, décalés d'un bord.
 * Rien n'est animé en boucle : la position suit le défilement, donc
 * « animations réduites » n'a rien à couper.
 *
 * Pas de "&&" ni de "||" dans le JS inline (règle interne du plugin).
 */

defined( 'ABSPATH' ) || exit;

$style = (string) ( $props['style'] ?? 'bar' );
if ( ! in_array( $style, array( 'bar', 'rail', 'ruler' ), true ) ) { $style = 'bar'; }

/**
 * La cle « position » etait celle du champ natif de YOOtheme : le choix
 * haut/bas n'etait donc jamais lu. On lit maintenant bar_position, en gardant
 * l'ancienne valeur en secours pour les pages deja en ligne.
 */
$pos = (string) ( $props['bar_position'] ?? '' );
if ( ! in_array( $pos, array( 'top', 'bottom' ), true ) ) {
	$legacy = (string) ( $props['position'] ?? '' );
	$pos    = ( 'bottom' === $legacy ) ? 'bottom' : 'top';
}
$h     = max( 1, min( 20, (int) ( $props['height'] ?? 4 ) ) );
$color = (string) ( $props['color'] ?? '#EA5C1C' );
$bg    = (string) ( $props['bg_color'] ?? 'transparent' );
$zi    = max( 1, (int) ( $props['z_index'] ?? 9999 ) );

$side    = ( 'right' === ( $props['side'] ?? 'left' ) ) ? 'right' : 'left';
$offset  = max( 0, min( 200, (int) ( $props['offset'] ?? 40 ) ) );
$railLen = max( 80, min( 600, (int) ( $props['rail_length'] ?? 240 ) ) );
$railW   = max( 2, min( 24, (int) ( $props['rail_width'] ?? 6 ) ) );
$showNum = ! empty( $props['show_number'] );
$trackOp = max( 5, min( 60, (int) ( $props['track_opacity'] ?? 15 ) ) ) / 100;

$uid = wf_uid( 'wfsp_', $props );

$cssPos = ( 'bottom' === $pos ) ? 'bottom:0;' : 'top:0;';

$cfg = wp_json_encode(
	array(
		'uid'   => $uid,
		'style' => $style,
		'num'   => $showNum,
	),
	JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE
);
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<?php if ( 'bar' === $style ) : ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-sp wf-sp--bar" role="progressbar" aria-hidden="true" style="position:fixed;<?= $cssPos ?>left:0;right:0;height:<?= (int) $h ?>px;background:<?= esc_attr( $bg ) ?>;z-index:<?= (int) $zi ?>;pointer-events:none;">
	<div class="wf-sp-bar" style="height:100%;width:0%;background:<?= esc_attr( $color ) ?>;transition:width .1s linear;"></div>
</div>
<?php else : ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-sp wf-sp--<?= esc_attr( $style ) ?>" aria-hidden="true">
	<span class="wf-sp__track"></span>
	<span class="wf-sp__fill"></span>
	<span class="wf-sp__cursor"><?php if ( $showNum ) : ?><span class="wf-sp__num">0</span><?php endif; ?></span>
</div>
<?php endif; ?>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<?php if ( 'bar' !== $style ) : ?>
<style>
#<?= esc_attr( $uid ) ?>{
	position:fixed;top:50%;<?= esc_attr( $side ) ?>:<?= (int) $offset ?>px;
	transform:translateY(-50%);
	width:<?= (int) $railW ?>px;height:<?= (int) $railLen ?>px;
	z-index:<?= (int) $zi ?>;pointer-events:none;
	--p:0;
}
#<?= esc_attr( $uid ) ?> .wf-sp__track,#<?= esc_attr( $uid ) ?> .wf-sp__fill{
	position:absolute;inset:0;display:block;border-radius:<?= (int) $railW ?>px;
}
<?php if ( 'rail' === $style ) : ?>
#<?= esc_attr( $uid ) ?> .wf-sp__track{background:currentColor;opacity:<?= esc_attr( $trackOp ) ?>;}
#<?= esc_attr( $uid ) ?> .wf-sp__fill{background:<?= esc_attr( $color ) ?>;}
<?php else : ?>
/* Gradué : la piste est une échelle de petits traits, le remplissage la reprend
   en couleur — d'où deux dégradés identiques, un seul étant découpé. */
#<?= esc_attr( $uid ) ?> .wf-sp__track{
	background-image:repeating-linear-gradient(to bottom,currentColor 0,currentColor 1px,transparent 1px,transparent 5px);
	opacity:<?= esc_attr( $trackOp ) ?>;border-radius:0;
}
#<?= esc_attr( $uid ) ?> .wf-sp__fill{
	background-image:repeating-linear-gradient(to bottom,<?= esc_attr( $color ) ?> 0,<?= esc_attr( $color ) ?> 1px,transparent 1px,transparent 5px);
	border-radius:0;
}
<?php endif; ?>
/* Le remplissage est decoupe par le bas : aucune hauteur a animer, donc pas de
   saccade quand la page est longue. */
#<?= esc_attr( $uid ) ?> .wf-sp__fill{
	clip-path:inset(calc(100% - var(--p) * 100%) 0 0 0);
}
#<?= esc_attr( $uid ) ?> .wf-sp__cursor{
	position:absolute;left:50%;top:0;display:block;
	width:<?= (int) ( $railW * 2.6 ) ?>px;height:1px;
	transform:translate(-50%,calc(var(--p) * <?= (int) $railLen ?>px));
	background:<?= esc_attr( $color ) ?>;
}
#<?= esc_attr( $uid ) ?> .wf-sp__num{
	position:absolute;<?= 'left' === $side ? 'left' : 'right' ?>:<?= (int) ( $railW * 3 ) ?>px;
	top:50%;transform:translateY(-50%);
	font-size:12px;font-weight:600;font-variant-numeric:tabular-nums;line-height:1;
	color:<?= esc_attr( $color ) ?>;
}
@media (max-width:640px){
	#<?= esc_attr( $uid ) ?>{display:none;}
}
</style>
<?php endif; ?>
<script>
(function(){
	function boot(){
		var c = <?= $cfg ?>;
		var el = document.getElementById(c.uid);
		if(!el){return;}
		if(el.getAttribute('data-wf-ready')){return;}
		el.setAttribute('data-wf-ready','1');

		var bar = el.querySelector('.wf-sp-bar');
		var num = el.querySelector('.wf-sp__num');
		var ticking = false;

		function update(){
			ticking = false;
			var doc = document.documentElement;
			var h = doc.scrollHeight - window.innerHeight;
			var p = h > 0 ? window.scrollY / h : 0;
			if(p < 0){ p = 0; }
			if(p > 1){ p = 1; }
			if(bar){
				bar.style.width = (p * 100).toFixed(1) + '%';
				return;
			}
			el.style.setProperty('--p', p.toFixed(4));
			if(num){ num.textContent = Math.round(p * 100); }
		}

		window.addEventListener('scroll', function(){
			if(ticking){return;}
			ticking = true;
			// Onglet en arriere-plan : aucun rAF, on peint directement.
			if(document.hidden){ update(); return; }
			window.requestAnimationFrame(update);
		}, {passive:true});
		window.addEventListener('resize', update, {passive:true});
		update();
	}
	if(document.readyState === 'loading'){
		document.addEventListener('DOMContentLoaded', boot);
	}else{
		boot();
	}
}());
</script>
