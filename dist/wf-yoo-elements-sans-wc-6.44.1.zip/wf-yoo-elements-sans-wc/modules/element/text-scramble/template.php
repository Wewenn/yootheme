<?php
/**
 * WeFrame – Text Scramble | template.php
 * "Decrypt" reveal — characters scramble then settle. Trigger: view / hover / loop.
 * Config inlined (no <script type="application/json">), no "&&" in inline JS.
 * Scramble output is written via textContent (XSS-safe).
 */
defined( 'ABSPATH' ) || exit;

$props = is_array( $props ?? null ) ? $props : array();

$text = trim( (string) ( $props['text'] ?? '' ) );
if ( '' === $text ) { return; }

$trigger = (string) ( $props['trigger'] ?? 'view' );
$charset = (string) ( $props['charset'] ?? '!<>-_\\/[]{}=+*^?#0123456789' );
if ( '' === trim( $charset ) ) { $charset = '!<>-_/[]{}=+*^?#'; }
$speed   = min( 4, max( 1, (int) ( $props['speed'] ?? 1 ) ) );
$loop_d  = min( 10, max( 1, (int) ( $props['loop_delay'] ?? 3 ) ) );

$size    = (int) ( $props['size']        ?? 48 );
$size_t  = (int) ( $props['size_tablet'] ?? 38 );
$size_m  = (int) ( $props['size_mobile'] ?? 26 );
$weight  = (string) ( $props['weight'] ?? '700' );
$color   = (string) ( $props['color'] ?? '#111111' );
$accent  = trim( (string) ( $props['accent_color'] ?? '' ) );
$lh      = (int) ( $props['line_height'] ?? 120 );
$ls      = (float) ( $props['letter_spacing'] ?? 0 );
$font    = trim( (string) ( $props['font'] ?? '' ) );
$align   = (string) ( $props['align'] ?? 'left' );
$upper   = ! empty( $props['uppercase'] );
$maxw    = (int) ( $props['max_width'] ?? 0 );

$uid = 'wfts_' . substr( md5( $text . serialize( $props ) ), 0, 8 );

$cfg = wp_json_encode( array(
    'uid'     => $uid,
    'text'    => $text,
    'trigger' => $trigger,
    'chars'   => $charset,
    'speed'   => $speed,
    'loopD'   => $loop_d,
    'accent'  => $accent,
    'baseCol' => $color,
), JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE );

$ff  = $font ? 'font-family:' . $font . ';' : '';
$mw  = ( $maxw > 0 ) ? 'max-width:' . $maxw . 'px;' . ( 'center' === $align ? 'margin-left:auto;margin-right:auto;' : '' ) : '';
$upc = $upper ? 'text-transform:uppercase;' : '';
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-ts" style="text-align:<?= esc_attr( $align ) ?>;<?= $mw ?>font-size:<?= $size ?>px;line-height:<?= $lh ?>%;letter-spacing:<?= $ls ?>px;font-weight:<?= esc_attr( $weight ) ?>;color:<?= esc_attr( $color ) ?>;<?= $upc ?><?= $ff ?>white-space:pre-wrap;"><?= esc_html( $text ) ?></div>

<style>
@media (min-width:768px) and (max-width:1024px) { #<?= esc_attr( $uid ) ?> { font-size:<?= $size_t ?>px !important; } }
@media (max-width:767px) { #<?= esc_attr( $uid ) ?> { font-size:<?= $size_m ?>px !important; } }
</style>

<script>
(function(){
    var C = <?= $cfg ?>;
    function boot(){
        var el = document.getElementById(C.uid); if (!el) return;
        var chars = C.chars;
        var running = false;

        function rnd(){ return chars.charAt(Math.floor(Math.random() * chars.length)); }

        function scramble(done){
            if (running) { return; }
            running = true;
            if (C.accent) { el.style.color = C.accent; }
            var target = C.text;
            var length = target.length;
            var queue = [];
            var i = 0;
            while (i < length) {
                var startf = Math.floor(Math.random() * 20 / C.speed);
                var endf = startf + Math.floor(Math.random() * 20 / C.speed) + 4;
                queue.push({ to: target.charAt(i), start: startf, end: endf, ch: '' });
                i++;
            }
            var frame = 0;
            function step(){
                var out = '';
                var done_ct = 0;
                var j = 0;
                while (j < queue.length) {
                    var q = queue[j];
                    if (frame >= q.end) {
                        done_ct++;
                        out += q.to;
                    } else if (frame >= q.start) {
                        if (q.to === ' ') {
                            out += ' ';
                        } else {
                            if (q.ch === '') { q.ch = rnd(); }
                            else if (Math.random() < 0.3) { q.ch = rnd(); }
                            out += q.ch;
                        }
                    } else {
                        out += '';
                    }
                    j++;
                }
                el.textContent = out;
                if (done_ct === queue.length) {
                    el.style.color = C.baseCol;
                    running = false;
                    if (done) { done(); }
                    return;
                }
                frame++;
                requestAnimationFrame(step);
            }
            step();
        }

        if (C.trigger === 'hover') {
            el.addEventListener('mouseenter', function(){ scramble(); });
            return;
        }

        if (C.trigger === 'loop') {
            function cycle(){ scramble(function(){ setTimeout(cycle, C.loopD * 1000); }); }
            if ('IntersectionObserver' in window) {
                var started = false;
                new IntersectionObserver(function(es){
                    var k = 0; while (k < es.length) {
                        if (es[k].isIntersecting) { if (!started) { started = true; cycle(); } }
                        k++;
                    }
                }, { threshold: 0.2 }).observe(el);
            } else { cycle(); }
            return;
        }

        // default: view — decrypt once when scrolled into view
        if ('IntersectionObserver' in window) {
            var fired = false;
            new IntersectionObserver(function(es){
                var k = 0; while (k < es.length) {
                    if (es[k].isIntersecting) { if (!fired) { fired = true; scramble(); } }
                    k++;
                }
            }, { threshold: 0.25 }).observe(el);
        } else {
            scramble();
        }
    }
    if (window.WF) { if (WF.ready) { WF.ready(boot); return; } }
    if (document.readyState !== 'loading') { boot(); } else { document.addEventListener('DOMContentLoaded', boot); }
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
