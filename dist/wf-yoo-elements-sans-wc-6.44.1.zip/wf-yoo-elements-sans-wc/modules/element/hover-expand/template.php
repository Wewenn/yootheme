<?php
/**
 * WeFrame – Lignes qui s'ouvrent | template.php v1.0
 * Liste de bandes : la ligne survolee (ou ciblee au clavier) s'ouvre sur sa photo
 * et decouvre son texte. Le survol seul exclurait le clavier et le tactile :
 * chaque ligne est donc un bouton, le focus ouvre aussi, et un appui bascule.
 * Aucune dependance : hauteur animee en CSS, etat porte par une classe.
 * Pas de "&&" ni de "||" dans le JS inline (regle interne du plugin).
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$hC   = max( 44, (int) ( $props['collapsed_height'] ?? 68 ) );
$hE   = max( 120, (int) ( $props['expanded_height'] ?? 320 ) );
if ( $hE <= $hC ) { $hE = $hC + 120; }
$gap  = max( 0, (int) ( $props['gap'] ?? 8 ) );
$rad  = max( 0, (int) ( $props['radius'] ?? 14 ) );
$dur  = max( 100, (int) ( $props['duration'] ?? 520 ) );
$openF = ! empty( $props['open_first'] );
$dim  = max( 0, min( 100, (int) ( $props['dim_others'] ?? 38 ) ) );

$lSize = max( 12, (int) ( $props['label_size'] ?? 18 ) );
$sSize = max( 10, (int) ( $props['sub_size'] ?? 13 ) );
$dSize = max( 11, (int) ( $props['desc_size'] ?? 14 ) );

$txt  = (string) ( $props['text_color'] ?? '#ffffff' );
$rowBg = (string) ( $props['row_bg'] ?? '#141416' );
$acc  = (string) ( $props['accent_color'] ?? '#EA5C1C' );
$ovl  = max( 0, min( 90, (int) ( $props['overlay'] ?? 55 ) ) );
$zoom = ! empty( $props['zoom'] );

$n   = count( $children );
$uid = wf_uid( 'wfhe_', $props, $n );

$rows = array();
foreach ( $children as $i => $child ) {
	$cp = (array) ( $child->props ?? array() );
	$label = trim( (string) ( $cp['label'] ?? '' ) );
	if ( '' === $label ) { $label = sprintf( __( 'Ligne %d', 'weframe' ), $i + 1 ); }

	$img = $cp['image'] ?? '';
	if ( is_array( $img ) ) { $img = $img['src'] ?? ( $img['url'] ?? '' ); }

	$link = $cp['link'] ?? '';
	if ( is_array( $link ) ) { $link = $link['url'] ?? ''; }

	$rows[] = array(
		'label'   => $label,
		'sub'     => trim( (string) ( $cp['sublabel'] ?? '' ) ),
		'desc'    => trim( (string) ( $cp['description'] ?? '' ) ),
		'img'     => trim( (string) $img ),
		'alt'     => trim( (string) ( $cp['image_alt'] ?? '' ) ),
		'link'    => trim( (string) $link ),
		'linkTxt' => trim( (string) ( $cp['link_text'] ?? '' ) ),
	);
}
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-he">
	<?php foreach ( $rows as $i => $r ) : ?>
	<div class="wf-he__row<?= ( $openF && 0 === $i ) ? ' is-open' : '' ?>">
		<button type="button" class="__hit" aria-expanded="<?= ( $openF && 0 === $i ) ? 'true' : 'false' ?>"
			aria-controls="<?= esc_attr( $uid ) ?>-p<?= (int) $i ?>">
			<?php if ( '' !== $r['img'] ) : ?>
			<span class="__bg" aria-hidden="true"><img src="<?= esc_url( $r['img'] ) ?>" alt="" loading="lazy" decoding="async"></span>
			<?php endif; ?>
			<span class="__head">
				<span class="__label"><?= esc_html( $r['label'] ) ?></span>
				<?php if ( '' !== $r['sub'] ) : ?><span class="__sub"><?= esc_html( $r['sub'] ) ?></span><?php endif; ?>
			</span>
		</button>
		<div class="__panel" id="<?= esc_attr( $uid ) ?>-p<?= (int) $i ?>">
			<?php if ( '' !== $r['desc'] ) : ?><p class="__desc"><?= nl2br( esc_html( $r['desc'] ) ) ?></p><?php endif; ?>
			<?php if ( '' !== $r['link'] ) : ?>
			<a class="__link" href="<?= esc_url( $r['link'] ) ?>"><?= esc_html( '' !== $r['linkTxt'] ? $r['linkTxt'] : __( 'En savoir plus', 'weframe' ) ) ?></a>
			<?php endif; ?>
		</div>
	</div>
	<?php endforeach; ?>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?>{display:flex;flex-direction:column;gap:<?= (int) $gap ?>px;container-type:inline-size;}
#<?= esc_attr( $uid ) ?> .wf-he__row{
	position:relative;overflow:hidden;border-radius:<?= (int) $rad ?>px;
	background:<?= esc_attr( $rowBg ) ?>;color:<?= esc_attr( $txt ) ?>;
	height:<?= (int) $hC ?>px;
	transition:height <?= (int) $dur ?>ms cubic-bezier(.2,.8,.2,1),opacity <?= (int) round( $dur * .6 ) ?>ms ease;
}
<?php if ( $dim > 0 ) : ?>
#<?= esc_attr( $uid ) ?>.has-open .wf-he__row{opacity:<?= esc_attr( round( 1 - $dim / 100, 2 ) ) ?>;}
#<?= esc_attr( $uid ) ?>.has-open .wf-he__row.is-open{opacity:1;}
<?php endif; ?>
#<?= esc_attr( $uid ) ?> .wf-he__row.is-open{height:<?= (int) $hE ?>px;}

#<?= esc_attr( $uid ) ?> .__hit{
	position:absolute;inset:0;width:100%;height:100%;z-index:1;
	display:flex;align-items:flex-end;text-align:left;
	background:none;border:0;padding:0;cursor:pointer;font-family:inherit;color:inherit;
}
#<?= esc_attr( $uid ) ?> .__hit:focus-visible{outline:2px solid <?= esc_attr( $acc ) ?>;outline-offset:-4px;border-radius:<?= (int) $rad ?>px;}
#<?= esc_attr( $uid ) ?> .__bg{position:absolute;inset:0;z-index:0;}
#<?= esc_attr( $uid ) ?> .__bg img{
	width:100%;height:100%;object-fit:cover;display:block;
	<?= $zoom ? 'transform:scale(1.06);transition:transform ' . (int) $dur . 'ms cubic-bezier(.2,.8,.2,1);' : '' ?>
}
<?php if ( $zoom ) : ?>
#<?= esc_attr( $uid ) ?> .wf-he__row.is-open .__bg img{transform:scale(1);}
<?php endif; ?>
<?php if ( $ovl > 0 ) : ?>
#<?= esc_attr( $uid ) ?> .__bg::after{
	content:"";position:absolute;inset:0;
	background:linear-gradient(180deg,rgba(0,0,0,<?= esc_attr( round( $ovl / 250, 2 ) ) ?>),rgba(0,0,0,<?= esc_attr( round( $ovl / 100, 2 ) ) ?>));
}
<?php endif; ?>
#<?= esc_attr( $uid ) ?> .__head{
	position:relative;z-index:1;display:flex;align-items:baseline;gap:.7em;flex-wrap:wrap;
	padding:0 <?= (int) max( 16, round( $hC * .28 ) ) ?>px <?= (int) max( 12, round( $hC * .24 ) ) ?>px;
}
#<?= esc_attr( $uid ) ?> .__label{font-size:<?= (int) $lSize ?>px;font-weight:700;line-height:1.2;}
#<?= esc_attr( $uid ) ?> .__sub{font-size:<?= (int) $sSize ?>px;opacity:.75;}
#<?= esc_attr( $uid ) ?> .__panel{
	position:absolute;left:0;right:0;bottom:0;z-index:2;pointer-events:none;
	padding:0 <?= (int) max( 16, round( $hC * .28 ) ) ?>px <?= (int) max( 12, round( $hC * .24 ) ) ?>px;
	transform:translateY(8px);opacity:0;
	transition:opacity <?= (int) round( $dur * .7 ) ?>ms ease <?= (int) round( $dur * .22 ) ?>ms,
		transform <?= (int) round( $dur * .7 ) ?>ms ease <?= (int) round( $dur * .22 ) ?>ms;
}
#<?= esc_attr( $uid ) ?> .wf-he__row.is-open .__panel{opacity:1;transform:none;pointer-events:auto;}
#<?= esc_attr( $uid ) ?> .__panel{padding-bottom:<?= (int) max( 34, round( $hC * .6 ) ) ?>px;}
#<?= esc_attr( $uid ) ?> .__desc{margin:0 0 .6em;font-size:<?= (int) $dSize ?>px;line-height:1.55;max-width:60ch;}
#<?= esc_attr( $uid ) ?> .__link{color:<?= esc_attr( $acc ) ?>;font-weight:700;text-decoration:none;}
#<?= esc_attr( $uid ) ?> .__link:hover{text-decoration:underline;}
@media (pointer:coarse){#<?= esc_attr( $uid ) ?> .wf-he__row{min-height:44px;}}
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?> .wf-he__row,#<?= esc_attr( $uid ) ?> .__panel,#<?= esc_attr( $uid ) ?> .__bg img{transition-duration:.001ms;}
}
</style>

<script>
(function(){
	var root = document.getElementById('<?= esc_js( $uid ) ?>');
	if (!root) { return; }
	var rows = [].slice.call(root.querySelectorAll('.wf-he__row'));
	if (!rows.length) { return; }

	var openIdx = <?= $openF ? '0' : '-1' ?>;
	// Le survol ne doit pas etre la seule facon d'ouvrir : le pointeur grossier
	// (tactile) passe par le clic, le clavier par le focus.
	var coarse = false;
	if (window.matchMedia) {
		if (window.matchMedia('(pointer: coarse)').matches) { coarse = true; }
	}

	function paint(i){
		openIdx = i;
		for (var k = 0; k < rows.length; k++) {
			var on = (k === i);
			rows[k].classList.toggle('is-open', on);
			var btn = rows[k].querySelector('.__hit');
			if (btn) { btn.setAttribute('aria-expanded', on ? 'true' : 'false'); }
		}
		root.classList.toggle('has-open', i > -1);
	}
	paint(openIdx);

	for (var i = 0; i < rows.length; i++) {
		(function(idx){
			var row = rows[idx];
			var btn = row.querySelector('.__hit');
			if (!coarse) {
				row.addEventListener('mouseenter', function(){ paint(idx); });
			}
			if (btn) {
				btn.addEventListener('focus', function(){ paint(idx); });
				btn.addEventListener('click', function(){
					if (openIdx === idx) { paint(-1); return; }
					paint(idx);
				});
			}
		})(i);
	}
})();
</script>
