<?php
/**
 * WeFrame – Counter Pro | template.php v2.2
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$cols     = max( 1, (int)( $props['columns']        ?? 4 ) );
$cols_m   = max( 1, (int)( $props['columns_mobile']  ?? 2 ) );
$gap      = max( 0, (int)( $props['gap']             ?? 32 ) );
$align    = $props['text_align'] ?? 'center';
$duration = max( 0, (int)( $props['duration']        ?? 2000 ) );
$sep      = ! empty( $props['separator'] );

$uid = wf_uid( 'wfc_', $props, count( $children ) );

$html = '';
foreach ( $children as $child ) {
    $html .= $builder->render( $child, [ 'element' => $props ] );
}
if ( ! trim( $html ) ) { return; }

?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-counter-grid" style="display:grid;grid-template-columns:repeat(<?= $cols ?>,1fr);gap:<?= $gap ?>px;text-align:<?= esc_attr( $align ) ?>;">
    <?= $html ?>
</div>
<style>
<?php if ( $sep ) : ?>
#<?= esc_attr( $uid ) ?> .wf-counter-cell+.wf-counter-cell{border-left:1px solid rgba(0,0,0,.1)}
<?php endif; ?>
@media(max-width:767px){
    #<?= esc_attr( $uid ) ?>{grid-template-columns:repeat(<?= $cols_m ?>,1fr) !important}
    <?php if ( $sep ) : ?>#<?= esc_attr( $uid ) ?> .wf-counter-cell+.wf-counter-cell{border-left:none}<?php endif; ?>
}
</style>
<?php if ( $duration > 0 ) : ?>
<script>
(function(){
    var el=document.getElementById('<?= esc_attr( $uid ) ?>');
    if(!el)return;
    WF.onVisible(el, function(){
        el.querySelectorAll('[data-wf-target]').forEach(function(s){
            var t=parseFloat(s.getAttribute('data-wf-target')),
                d=parseInt(s.getAttribute('data-wf-decimals')||'0',10),
                p=s.getAttribute('data-wf-prefix')||'',
                x=s.getAttribute('data-wf-suffix')||'',
                dur=<?= $duration ?>,st=null;
            function step(ts){
                if(!st)st=ts;var pr=Math.min((ts-st)/dur,1),
                e=1-Math.pow(1-pr,3),c=t*e;
                s.textContent=p+c.toFixed(d).replace(/\B(?=(\d{3})+(?!\d))/g,' ')+x;
                if(pr<1)requestAnimationFrame(step);
            }
            requestAnimationFrame(step);
        });
    }, 0.2);
})();
</script>
<?php endif; ?>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
