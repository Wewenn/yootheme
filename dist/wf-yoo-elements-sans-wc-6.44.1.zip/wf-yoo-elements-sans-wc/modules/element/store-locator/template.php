<?php
/**
 * WeFrame – Store Locator | template.php v1.0
 * Carte Leaflet (OpenStreetMap) avec marqueurs. Leaflet chargé depuis unpkg (CDN).
 */
defined( 'ABSPATH' ) || exit;
$list_bd   = $props['list_border']   ?? '#e5e5e5';
$marker_bd = $props['marker_border'] ?? '#ffffff';

$raw     = (string) ( $props['markers'] ?? '' );
$height  = max( 200, (int) ( $props['height'] ?? 420 ) );
$zoom    = max( 3, min( 18, (int) ( $props['zoom'] ?? 13 ) ) );
$mcolor  = $props['marker_color'] ?? '#e5484d';
$scroll  = ! empty( $props['scroll_zoom'] );
$radius  = (int) ( $props['radius'] ?? 16 );
$list    = ! empty( $props['show_list'] );

$markers = array();
foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $line ) {
    $line = trim( $line );
    if ( '' === $line ) { continue; }
    $p = array_map( 'trim', explode( '|', $line ) );
    $lat = isset( $p[1] ) ? (float) $p[1] : 0;
    $lng = isset( $p[2] ) ? (float) $p[2] : 0;
    if ( 0.0 === $lat && 0.0 === $lng ) { continue; }
    $markers[] = array(
        'name' => isset( $p[0] ) ? $p[0] : '',
        'lat'  => $lat,
        'lng'  => $lng,
        'addr' => isset( $p[3] ) ? $p[3] : '',
    );
}

if ( empty( $markers ) ) {
    if ( is_admin() ) { echo '<p style="padding:18px;background:#f6f7f9;border-radius:10px;color:#666;">Store Locator : ajoutez au moins un point (Nom | lat | lng | adresse).</p>'; }
    return;
}

wp_enqueue_style( 'leaflet', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css', array(), '1.9.4' );
wp_enqueue_script( 'leaflet', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js', array(), '1.9.4', true );

$uid = wf_uid( 'wfsl_', $props );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-sl">
    <div class="wf-sl-map" style="height:<?= $height ?>px;border-radius:<?= $radius ?>px;overflow:hidden;"></div>
    <?php if ( $list && count( $markers ) > 1 ) : ?>
    <ul class="wf-sl-list" style="list-style:none;margin:16px 0 0;padding:0;display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px;">
        <?php foreach ( $markers as $i => $m ) : ?>
        <li style="border:1px solid <?= esc_attr( $list_bd ) ?>;border-radius:10px;padding:12px 14px;">
            <strong><?= esc_html( $m['name'] ) ?></strong>
            <?php if ( $m['addr'] ) : ?><br><span style="opacity:.75;font-size:14px;"><?= esc_html( $m['addr'] ) ?></span><?php endif; ?>
        </li>
        <?php endforeach; ?>
    </ul>
    <?php endif; ?>
</div>

<script>
(function(){
    var id = <?= wp_json_encode( $uid ) ?>;
    var DATA = <?= wp_json_encode( $markers ) ?>;
    var ZOOM = <?= (int) $zoom ?>;
    var COLOR = <?= wp_json_encode( $mcolor ) ?>;
    var SCROLL = <?= $scroll ? 'true' : 'false' ?>;
    var tries = 0;
    function boot(){
        if (!window.L) { if (tries++ < 60) { setTimeout(boot, 100); } return; }
        var root = document.getElementById(id); if (!root) return;
        var el = root.querySelector('.wf-sl-map'); if (!el) return;
        var map = L.map(el, { scrollWheelZoom: SCROLL });
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19, attribution: '&copy; OpenStreetMap'
        }).addTo(map);

        var pin = L.divIcon({
            className: 'wf-sl-pin',
            html: '<span style="display:block;width:26px;height:26px;background:' + COLOR + ';border:3px solid ' + <?= wp_json_encode( $marker_bd ) ?> + ';border-radius:50% 50% 50% 0;transform:rotate(-45deg);box-shadow:0 2px 6px rgba(0,0,0,.3)"></span>',
            iconSize: [26, 26], iconAnchor: [13, 26], popupAnchor: [0, -24]
        });

        var pts = [];
        var k = 0;
        while (k < DATA.length) {
            var d = DATA[k];
            var mk = L.marker([d.lat, d.lng], { icon: pin }).addTo(map);
            var html = '<strong>' + (d.name || '') + '</strong>';
            if (d.addr) { html += '<br>' + d.addr; }
            mk.bindPopup(html);
            pts.push([d.lat, d.lng]);
            k++;
        }
        if (pts.length > 1) { map.fitBounds(pts, { padding: [40, 40] }); }
        else { map.setView(pts[0], ZOOM); }
        setTimeout(function(){ map.invalidateSize(); }, 200);
    }
    if (document.readyState !== 'loading') { boot(); } else { document.addEventListener('DOMContentLoaded', boot); }
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
