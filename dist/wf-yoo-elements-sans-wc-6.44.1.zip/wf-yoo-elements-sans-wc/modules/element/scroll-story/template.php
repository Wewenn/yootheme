<?php
/**
 * WeFrame – Scroll Story | template.php
 * Combines Scroll Reveal (word/char colour reveal) + Scroll Photos (side photos
 * flying in), both driven by one pinned-section scroll progress.
 * Config inlined (no <script type="application/json">), no "&&" in inline JS.
 */
defined( 'ABSPATH' ) || exit;

$props = is_array( $props ?? null ) ? $props : array();
if ( ! isset( $builder ) || ! is_object( $builder ) ) { return; }

$text = trim( (string) ( $props['text'] ?? '' ) );
if ( '' === $text ) { return; }

$mode    = (string) ( $props['reveal_mode'] ?? 'word' );
$cmode   = (string) ( $props['color_mode'] ?? 'solid' );
$c_off   = (string) ( $props['color_inactive'] ?? '#c8c8c8' );
$c_on    = (string) ( $props['color_active'] ?? '#111111' );
$c_on2   = (string) ( $props['color_active_2'] ?? '#EA5C1C' );
$hlbg    = (string) ( $props['highlight_bg'] ?? '#FFEB3B' );

$ts      = (int) ( $props['text_size']         ?? 52 );
$ts_t    = (int) ( $props['text_size_tablet']  ?? 40 );
$ts_m    = (int) ( $props['text_size_mobile']  ?? 28 );
$tw      = (string) ( $props['text_weight'] ?? '700' );
$tlh     = (int) ( $props['text_line_height'] ?? 120 );
$tls     = (float) ( $props['text_letter_spacing'] ?? -1 );
$tf      = trim( (string) ( $props['text_font'] ?? '' ) );
$ta      = (string) ( $props['text_align'] ?? 'center' );
$tmw     = (int) ( $props['text_max_width'] ?? 620 );
$bg      = trim( (string) ( $props['bg'] ?? '' ) );

$scroll_len = min( 600, max( 150, (int) ( $props['scroll_length'] ?? 340 ) ) );
$offset     = min( 200, max( 0, (int) ( $props['sticky_offset'] ?? 0 ) ) );
$tportion   = min( 100, max( 30, (int) ( $props['text_portion'] ?? 65 ) ) ) / 100;
$span       = min( 60, max( 10, (int) ( $props['reveal_span'] ?? 30 ) ) ) / 100;
$dist       = min( 300, max( 0, (int) ( $props['slide_distance'] ?? 110 ) ) );
$rise       = min( 200, max( 0, (int) ( $props['rise'] ?? 40 ) ) );
$pw         = min( 480, max( 120, (int) ( $props['photo_width'] ?? 280 ) ) );
$mobile_stack = ( ( $props['mobile_mode'] ?? 'stack' ) === 'stack' );

// ── Reveal tokens ──────────────────────────────────────
$words  = preg_split( '/\s+/u', $text );
$tokens = '';
if ( 'char' === $mode ) {
    foreach ( $words as $wi => $w ) {
        if ( $wi > 0 ) { $tokens .= '<span class="wf-ss-s"> </span>'; }
        $chars = function_exists( 'mb_str_split' ) ? mb_str_split( $w ) : str_split( $w );
        foreach ( $chars as $ch ) { $tokens .= '<span class="wf-ss-t">' . esc_html( $ch ) . '</span>'; }
    }
} else {
    foreach ( $words as $wi => $w ) {
        if ( $wi > 0 ) { $tokens .= '<span class="wf-ss-s"> </span>'; }
        $tokens .= '<span class="wf-ss-t">' . esc_html( $w ) . '</span>';
    }
}

// ── Photos (flyin, side alternating) ───────────────────
$photos   = '';
$k        = 0;
$left_ct  = 0;
$right_ct = 0;
if ( ! empty( $children ) && is_array( $children ) ) {
    foreach ( $children as $child ) {
        $inner = '';
        try { $inner = (string) $builder->render( $child, array( 'element' => $props ) ); }
        catch ( \Throwable $e ) { $inner = ''; }
        if ( ! trim( $inner ) ) { continue; }
        $cp   = ( is_array( $child ) && isset( $child['props'] ) && is_array( $child['props'] ) ) ? $child['props'] : array();
        $side = isset( $cp['side'] ) ? $cp['side'] : 'auto';
        if ( 'left' !== $side && 'right' !== $side ) { $side = ( $k % 2 === 0 ) ? 'left' : 'right'; }
        if ( 'left' === $side ) { $side_idx = $left_ct; $left_ct++; $dir = -1; $extra = 0; }
        else { $side_idx = $right_ct; $right_ct++; $dir = 1; $extra = 16; }
        $top_pct = 12 + ( $side_idx * 34 ) + $extra;
        if ( $top_pct > 82 ) { $top_pct = 82; }
        $inset = 3 + ( $side_idx * 2 );
        if ( $inset > 9 ) { $inset = 9; }
        $wov  = (int) ( isset( $cp['width_override'] ) ? $cp['width_override'] : 0 );
        $w    = $wov > 0 ? $wov : $pw;
        $edge = ( 'left' === $side ) ? 'left' : 'right';
        $photos .= '<div class="wf-ss-photo" data-dir="' . $dir . '" style="position:absolute;top:' . $top_pct . '%;' . $edge . ':' . $inset . '%;width:' . $w . 'px;max-width:42%;opacity:0;z-index:1;will-change:transform,opacity;">' . $inner . '</div>';
        $k++;
    }
}

$uid = 'wfss_' . substr( md5( $text . serialize( $props ) . $k ), 0, 8 );
$ff  = $tf ? 'font-family:' . $tf . ';' : '';
$mw  = ( $tmw > 0 ) ? 'max-width:' . $tmw . 'px;' . ( 'center' === $ta ? 'margin-left:auto;margin-right:auto;' : '' ) : '';
$bgc = $bg ? 'background:' . esc_attr( $bg ) . ';' : '';

$cfg = wp_json_encode( array(
    'uid'      => $uid,
    'cOff'     => $c_off,
    'cOn'      => $c_on,
    'cOn2'     => $c_on2,
    'hlBg'     => $hlbg,
    'cmode'    => $cmode,
    'tPortion' => $tportion,
    'span'     => $span,
    'nPhoto'   => $k,
    'dist'     => $dist,
    'rise'     => $rise,
    'mStack'   => $mobile_stack ? 1 : 0,
), JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-ss" style="position:relative;height:<?= $scroll_len ?>vh;<?= $bgc ?>">
    <div class="wf-ss-sticky" style="position:sticky;top:<?= $offset ?>px;height:calc(100vh - <?= $offset ?>px);overflow:hidden;">
        <div class="wf-ss-inner" style="position:relative;width:100%;height:100%;display:flex;align-items:center;justify-content:center;padding:0 5vw;box-sizing:border-box;">
            <div class="wf-ss-text" style="position:relative;z-index:2;<?= $mw ?>text-align:<?= esc_attr( $ta ) ?>;font-size:<?= $ts ?>px;font-weight:<?= esc_attr( $tw ) ?>;line-height:<?= $tlh ?>%;letter-spacing:<?= $tls ?>px;<?= $ff ?>" aria-label="<?= esc_attr( $text ) ?>"><?= $tokens ?></div>
            <?= $photos ?>
        </div>
    </div>
</div>

<style>
#<?= esc_attr( $uid ) ?> .wf-ss-t { color: <?= esc_attr( $c_off ) ?>; transition: color .15s ease, background .15s ease; display: inline; padding: 0 1px; border-radius: 3px; }
#<?= esc_attr( $uid ) ?> .wf-ss-s { display: inline; }
#<?= esc_attr( $uid ) ?> .wf-ss-photo { transition: opacity .05s linear; }
#<?= esc_attr( $uid ) ?> .wf-sp-fig img { pointer-events: none; }
@media (min-width:768px) and (max-width:1024px) { #<?= esc_attr( $uid ) ?> .wf-ss-text { font-size: <?= $ts_t ?>px !important; } }
@media (max-width:767px) {
    #<?= esc_attr( $uid ) ?> .wf-ss-text { font-size: <?= $ts_m ?>px !important; }
    <?php if ( $mobile_stack ) : ?>
    #<?= esc_attr( $uid ) ?> { height: auto !important; }
    #<?= esc_attr( $uid ) ?> .wf-ss-sticky { position: static !important; height: auto !important; overflow: visible !important; }
    #<?= esc_attr( $uid ) ?> .wf-ss-inner { display: block !important; padding: 0 20px !important; }
    #<?= esc_attr( $uid ) ?> .wf-ss-text { margin: 0 auto 32px !important; max-width: 100% !important; }
    #<?= esc_attr( $uid ) ?> .wf-ss-photo { position: static !important; width: 100% !important; max-width: 420px !important; margin: 0 auto 24px !important; opacity: 1 !important; transform: none !important; }
    <?php endif; ?>
}
@media (prefers-reduced-motion: reduce) {
    #<?= esc_attr( $uid ) ?> .wf-ss-t { color: <?= esc_attr( $c_on ) ?> !important; }
    #<?= esc_attr( $uid ) ?> .wf-ss-photo { opacity: 1 !important; transform: none !important; }
}
</style>

<script>
(function(){
    var C = <?= $cfg ?>;
    function boot(){
        var el = document.getElementById(C.uid); if (!el) return;
        var textEl = el.querySelector('.wf-ss-text');
        var tks = textEl ? textEl.querySelectorAll('.wf-ss-t') : [];
        var photos = el.querySelectorAll('.wf-ss-photo');
        var nT = tks.length;

        function allOn(){
            var i = 0; while (i < nT) { tks[i].style.color = C.cOn; if (C.cmode === 'highlight') { tks[i].style.background = C.hlBg; } i++; }
            var j = 0; while (j < photos.length) { photos[j].style.opacity = '1'; photos[j].style.transform = 'none'; j++; }
        }
        if (C.mStack) { if (window.innerWidth <= 767) { allOn(); return; } }

        var rgb1 = null, rgb2 = null;
        if (window.WF) { if (WF.hexToRgb) { rgb1 = WF.hexToRgb(C.cOn); rgb2 = WF.hexToRgb(C.cOn2); } }

        function clamp(v){ if (v < 0) return 0; if (v > 1) return 1; return v; }
        var ticking = false;

        function colorToken(i, on){
            if (!on) { tks[i].style.color = C.cOff; tks[i].style.background = 'transparent'; return; }
            if (C.cmode === 'gradient') {
                if (rgb1) {
                    var t = nT > 1 ? i / (nT - 1) : 0;
                    var rr = WF.lerpi(rgb1[0], rgb2[0], t);
                    var gg = WF.lerpi(rgb1[1], rgb2[1], t);
                    var bb = WF.lerpi(rgb1[2], rgb2[2], t);
                    tks[i].style.color = 'rgb(' + rr + ',' + gg + ',' + bb + ')';
                    tks[i].style.background = 'transparent';
                    return;
                }
                tks[i].style.color = C.cOn; tks[i].style.background = 'transparent'; return;
            }
            if (C.cmode === 'highlight') { tks[i].style.color = C.cOn; tks[i].style.background = C.hlBg; return; }
            tks[i].style.color = C.cOn; tks[i].style.background = 'transparent';
        }

        function update(){
            ticking = false;
            var range = el.offsetHeight - window.innerHeight;
            if (range <= 0) { allOn(); return; }
            var p = clamp((window.pageYOffset - el.offsetTop) / range);

            // Text reveal over the first tPortion of the scroll
            var pText = clamp(p / C.tPortion);
            var active = Math.round(pText * nT);
            var i = 0;
            while (i < nT) { colorToken(i, i < active); i++; }

            // Photos spread across the whole scroll
            var j = 0;
            while (j < photos.length) {
                var start = (j / C.nPhoto) * (1 - C.span);
                var rev = clamp((p - start) / C.span);
                var dir = parseFloat(photos[j].getAttribute('data-dir')) || 1;
                var x = dir * C.dist * (1 - rev);
                var y = C.rise * (1 - rev);
                var s = 0.92 + 0.08 * rev;
                photos[j].style.opacity = '' + rev;
                photos[j].style.transform = 'translate(' + x.toFixed(1) + 'px,' + y.toFixed(1) + 'px) scale(' + s.toFixed(3) + ')';
                j++;
            }
        }
        function onScroll(){ if (!ticking) { ticking = true; requestAnimationFrame(update); } }
        window.addEventListener('scroll', onScroll, { passive: true });
        window.addEventListener('resize', function(){
            if (C.mStack) { if (window.innerWidth <= 767) { allOn(); return; } }
            update();
        }, { passive: true });
        update();
    }
    if (window.WF) { if (WF.ready) { WF.ready(boot); return; } }
    if (document.readyState !== 'loading') { boot(); } else { document.addEventListener('DOMContentLoaded', boot); }
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
