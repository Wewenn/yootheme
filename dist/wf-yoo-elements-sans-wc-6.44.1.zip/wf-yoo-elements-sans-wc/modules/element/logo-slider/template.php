<?php
/**
 * WeFrame – Logo Slider | template.php
 * v1.4.0
 *
 * Fixes:
 * - animation moved to <style> so hover pause actually works (inline style
 *   specificity was overriding animation-play-state: paused)
 * - double row now splits children into two distinct groups (odd / even)
 * - gap_mobile via CSS custom property + media query
 * - prefers-reduced-motion support
 */
defined( 'ABSPATH' ) || exit;

if ( empty( $children ) ) { return; }

// ── Props ──────────────────────────────────────────────
$speed          = max( 1, (int) ( $props['speed']            ?? 16 ) );
$speed_mobile   = max( 0, (int) ( $props['speed_mobile']     ?? 0  ) );
$reverse        = ! empty( $props['reverse'] );
$hover          = ! empty( $props['pause_on_hover'] );
$double_row     = ! empty( $props['double_row'] );
$row_gap        = min( 80, max( 0, (int) ( $props['row_gap'] ?? 24 ) ) );
$fade           = ! empty( $props['fade_edges'] );
$fade_color     = $props['fade_color'] ?? '#ffffff';
$gap            = min( 200, max( 0, (int) ( $props['gap']      ?? 48 ) ) );
$gap_mobile     = max( 0, (int) ( $props['gap_mobile'] ?? 0 ) );
$gray           = ! empty( $props['grayscale'] );
$color_on_hover = ! empty( $props['color_on_hover'] ) && $gray;
$scale_hover    = ! empty( $props['scale_on_hover'] );
$scale_val      = min( 130, max( 100, (int) ( $props['scale_value'] ?? 110 ) ) );
$show_tooltip   = ! empty( $props['show_tooltip'] );

if ( ! preg_match( '/^#([0-9a-fA-F]{3}){1,2}$/', $fade_color ) ) {
    $fade_color = '#ffffff';
}

// ── UID ────────────────────────────────────────────────
$uid = wf_uid( 'wfls_', $props, count( $children ) );

// ── Render children ────────────────────────────────────
// For double row we split into two distinct groups (odd/even index).
// Minimum 2 items per group to loop properly; if not enough we fall back
// to single row behaviour.
if ( $double_row && count( $children ) >= 4 ) {
    $group_a = [];
    $group_b = [];
    foreach ( $children as $i => $child ) {
        if ( $i % 2 === 0 ) {
            $group_a[] = $child;
        } else {
            $group_b[] = $child;
        }
    }

    $html_a = '';
    foreach ( $group_a as $child ) {
        $html_a .= $builder->render( $child, [ 'element' => $props ] );
    }
    $html_b = '';
    foreach ( $group_b as $child ) {
        $html_b .= $builder->render( $child, [ 'element' => $props ] );
    }

    $has_double = trim( $html_a ) && trim( $html_b );
} else {
    $double_row = false;
    $has_double = false;
}

if ( ! $has_double ) {
    // Single row — render everything together
    $html_a = '';
    foreach ( $children as $child ) {
        $html_a .= $builder->render( $child, [ 'element' => $props ] );
    }
    if ( ! trim( $html_a ) ) { return; }
}

// ── Computed values ────────────────────────────────────
$fade_w      = (int) ( $gap * 2 );
$scale_css   = round( $scale_val / 100, 2 );
$has_mobile_speed = $speed_mobile > 0 && $speed_mobile !== $speed;
$has_mobile_gap   = $gap_mobile > 0 && $gap_mobile !== $gap;
$half_gap         = (int) round( $gap / 2 );
$half_gap_mobile  = $has_mobile_gap ? (int) round( $gap_mobile / 2 ) : $half_gap;

// Use shared keyframes from weframe-shared.css
$anim_r1 = $reverse ? 'wf-scroll-rev' : 'wf-scroll-fwd';
$anim_r2 = $reverse ? 'wf-scroll-fwd' : 'wf-scroll-rev';

?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-logo-slider"
     style="position:relative;overflow:hidden;<?= $has_double ? 'display:flex;flex-direction:column;gap:' . $row_gap . 'px;' : '' ?>">

    <?php if ( $fade ) : ?>
    <div aria-hidden="true" class="wf-ls-fade wf-ls-fade--l" style="position:absolute;top:0;left:0;bottom:0;width:<?= $fade_w ?>px;background:linear-gradient(90deg,<?= esc_attr( $fade_color ) ?>,transparent);z-index:2;pointer-events:none;"></div>
    <div aria-hidden="true" class="wf-ls-fade wf-ls-fade--r" style="position:absolute;top:0;right:0;bottom:0;width:<?= $fade_w ?>px;background:linear-gradient(270deg,<?= esc_attr( $fade_color ) ?>,transparent);z-index:2;pointer-events:none;"></div>
    <?php endif; ?>

    <?php /* ── Row 1 ── */ ?>
    <div class="wf-ls-track wf-ls-track--r1" style="display:flex;align-items:center;width:max-content;">
        <?= $html_a ?>
        <?= $html_a ?>
    </div>

    <?php if ( $has_double ) : ?>
    <?php /* ── Row 2 (different logos, opposite direction) ── */ ?>
    <div class="wf-ls-track wf-ls-track--r2" style="display:flex;align-items:center;width:max-content;">
        <?= $html_b ?>
        <?= $html_b ?>
    </div>
    <?php endif; ?>

</div>

<style>
/* ── Track animation (keyframes in weframe-shared.css) ── */
#<?= esc_attr( $uid ) ?> .wf-ls-track--r1 {
    animation: <?= $anim_r1 ?> <?= $speed ?>s linear infinite;
}
<?php if ( $has_double ) : ?>
#<?= esc_attr( $uid ) ?> .wf-ls-track--r2 {
    animation: <?= $anim_r2 ?> <?= $speed ?>s linear infinite;
}
<?php endif; ?>

/* ── Pause on hover ── */
<?php if ( $hover ) : ?>
#<?= esc_attr( $uid ) ?>:hover .wf-ls-track {
    animation-play-state: paused;
}
<?php endif; ?>

/* ── Item transitions ── */
#<?= esc_attr( $uid ) ?> .wf-ls-item img {
    transition: filter .3s ease<?= $scale_hover ? ', transform .3s ease' : '' ?>;
}

/* ── Color on hover ── */
<?php if ( $color_on_hover ) : ?>
#<?= esc_attr( $uid ) ?> .wf-ls-item:hover img {
    filter: grayscale(0) opacity(1) !important;
}
<?php endif; ?>

/* ── Scale on hover ── */
<?php if ( $scale_hover ) : ?>
#<?= esc_attr( $uid ) ?> .wf-ls-item:hover img {
    transform: scale(<?= $scale_css ?>);
}
<?php endif; ?>

/* ── Tooltip ── */
<?php if ( $show_tooltip ) : ?>
#<?= esc_attr( $uid ) ?> .wf-ls-item { position: relative; }
#<?= esc_attr( $uid ) ?> .wf-ls-item[data-tooltip]::after {
    content: attr(data-tooltip);
    position: absolute;
    bottom: calc(100% + 8px);
    left: 50%;
    transform: translateX(-50%) translateY(4px);
    background: rgba(0,0,0,.82);
    color: #fff;
    font-size: 12px;
    line-height: 1.3;
    padding: 5px 10px;
    border-radius: 6px;
    white-space: nowrap;
    pointer-events: none;
    opacity: 0;
    transition: opacity .2s ease, transform .2s ease;
    z-index: 10;
}
#<?= esc_attr( $uid ) ?> .wf-ls-item[data-tooltip]:hover::after {
    opacity: 1;
    transform: translateX(-50%) translateY(0);
}
<?php endif; ?>

/* ── Mobile overrides ── */
<?php if ( $has_mobile_speed || $has_mobile_gap ) : ?>
@media (max-width: 767px) {
    <?php if ( $has_mobile_speed ) : ?>
    #<?= esc_attr( $uid ) ?> .wf-ls-track {
        animation-duration: <?= (int) $speed_mobile ?>s !important;
    }
    <?php endif; ?>
    <?php if ( $has_mobile_gap ) : ?>
    #<?= esc_attr( $uid ) ?> .wf-ls-item {
        padding-left: <?= $half_gap_mobile ?>px !important;
        padding-right: <?= $half_gap_mobile ?>px !important;
    }
    <?php endif; ?>
}
<?php endif; ?>

/* ── Reduced motion ── */
@media (prefers-reduced-motion: reduce) {
    #<?= esc_attr( $uid ) ?> .wf-ls-track {
        animation-play-state: paused;
    }
}
</style>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
