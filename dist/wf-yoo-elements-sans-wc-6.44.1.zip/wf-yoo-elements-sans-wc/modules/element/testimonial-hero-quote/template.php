<?php
/**
 * WeFrame – Testimonial Hero Quote | template.php v2.0
 * Format par bloc (séparés par une ligne vide) :
 *   citation||auteur||rôle||avatar_url||note(0-5)
 * Les 3 dernières parties sont optionnelles.
 * Config inlined (no <script type="application/json">), no "&&" in inline JS.
 */
defined( 'ABSPATH' ) || exit;

$items_raw = $props['items'] ?? '';
if ( is_array( $items_raw ) ) { $items_raw = ''; }
$items_raw = (string) $items_raw;

$items = [];
foreach ( preg_split( "/\r?\n\r?\n/", trim( $items_raw ) ) as $block ) {
    $block = trim( $block );
    if ( '' === $block ) { continue; }
    $parts  = array_map( 'trim', explode( '||', $block ) );
    $quote  = $parts[0] ?? '';
    if ( '' === $quote ) { continue; } // skip malformed / empty blocks
    $avatar = $parts[3] ?? '';
    if ( $avatar && ! preg_match( '#^https?://#i', $avatar ) ) { $avatar = '/' . ltrim( $avatar, '/' ); }
    $rating = isset( $parts[4] ) ? max( 0, min( 5, (float) $parts[4] ) ) : 0;
    $items[] = [
        'quote'  => $quote,
        'author' => $parts[1] ?? '',
        'role'   => $parts[2] ?? '',
        'avatar' => $avatar,
        'rating' => $rating,
    ];
}
if ( empty( $items ) ) { return; }

$auto     = ! empty( $props['autoplay'] );
$auto_ms  = (int) ( $props['autoplay_ms'] ?? 6000 );
$arrows   = ! empty( $props['show_arrows'] );
$dots     = ! empty( $props['show_dots'] );
$qicon    = ! empty( $props['show_quote_icon'] );
$bg       = $props['bg'] ?? '#EEEAFE';
$acc      = $props['accent'] ?? '#5B58F0';
$tc       = $props['text_color'] ?? '#1A1A66';
$ac       = $props['attr_color'] ?? $acc;
$ff       = $props['font_family'] ?? "'Playfair Display', Georgia, serif";
$fs       = (int) ( $props['font_size'] ?? 26 );
$fs_m     = (int) ( $props['font_size_mobile'] ?? max( 18, (int) round( $fs * 0.72 ) ) );
$rad      = (int) ( $props['radius'] ?? 12 );
$pad      = (int) ( $props['padding'] ?? 72 );
$mw       = (int) ( $props['max_width'] ?? 900 );

$uid   = wf_uid( 'wfhq_', $props );
$multi = count( $items ) > 1;

if ( ! function_exists( 'wf_hq_star' ) ) {
    function wf_hq_star( $on, $acc ) {
        $c = $on ? esc_attr( $acc ) : '#d9dde3';
        return '<svg width="18" height="18" viewBox="0 0 24 24" fill="' . $c . '" style="display:inline-block;"><path d="M12 .587l3.668 7.431 8.2 1.192-5.934 5.784 1.401 8.169L12 18.897l-7.335 3.866 1.401-8.169L.132 9.21l8.2-1.192z"/></svg>';
    }
}

$cfg = wp_json_encode( array(
    'uid'  => $uid,
    'auto' => $auto ? 1 : 0,
    'step' => max( 2000, $auto_ms ),
), JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-hq-wrap" style="background:<?= esc_attr( $bg ) ?>;border-radius:<?= $rad ?>px;padding:<?= $pad ?>px;max-width:<?= $mw ?>px;margin:0 auto;text-align:center;position:relative;">
    <?php if ( $qicon ) : ?>
    <div style="display:flex;justify-content:center;margin-bottom:32px;">
        <svg width="84" height="66" viewBox="0 0 84 66" fill="none" stroke="<?= esc_attr( $acc ) ?>" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <path d="M18 8 C8 18, 6 30, 6 44 C6 56, 14 62, 22 62 C30 62, 36 56, 36 48 C36 40, 30 34, 22 34 C20 34, 18 34.5, 16 35.5 C16 24, 22 14, 32 10 Z"/>
            <path d="M66 8 C56 18, 54 30, 54 44 C54 56, 62 62, 70 62 C78 62, 84 56, 84 48 C84 40, 78 34, 70 34 C68 34, 66 34.5, 64 35.5 C64 24, 70 14, 80 10 Z"/>
        </svg>
    </div>
    <?php endif; ?>

    <div class="wf-hq-viewport" style="position:relative;">
    <?php foreach ( $items as $i => $it ) : ?>
        <div class="wf-hq-slide<?= 0 === $i ? ' is-active' : '' ?>" data-idx="<?= $i ?>">
            <?php if ( $it['rating'] > 0 ) : ?>
            <div style="display:flex;justify-content:center;gap:3px;margin-bottom:20px;">
                <?php for ( $s = 1; $s <= 5; $s++ ) { echo wf_hq_star( $it['rating'] >= $s - 0.25, $acc ); } ?>
            </div>
            <?php endif; ?>
            <p class="wf-hq-quote" style="margin:0 0 28px;font-family:<?= esc_attr( $ff ) ?>;font-size:<?= $fs ?>px;line-height:1.4;font-weight:600;color:<?= esc_attr( $tc ) ?>;"><?= esc_html( $it['quote'] ) ?></p>
            <?php if ( $it['avatar'] || $it['author'] || $it['role'] ) : ?>
            <div style="display:flex;align-items:center;justify-content:center;gap:12px;">
                <?php if ( $it['avatar'] ) : ?>
                <img src="<?= esc_url( $it['avatar'] ) ?>" alt="<?= esc_attr( $it['author'] ) ?>" loading="lazy" style="width:48px;height:48px;border-radius:50%;object-fit:cover;">
                <?php endif; ?>
                <?php if ( $it['author'] || $it['role'] ) : ?>
                <div style="text-align:<?= $it['avatar'] ? 'left' : 'center' ?>;font-size:12px;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;color:<?= esc_attr( $ac ) ?>;line-height:1.5;"><?= esc_html( trim( $it['author'] . ( $it['role'] ? ', ' . $it['role'] : '' ) ) ) ?></div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
    </div>

    <?php if ( $arrows && $multi ) : ?>
    <div style="display:flex;justify-content:center;gap:12px;margin-top:40px;">
        <button class="wf-hq-prev" aria-label="Précédent" style="width:44px;height:44px;background:<?= esc_attr( $acc ) ?>;color:#fff;border:0;border-radius:6px;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;transition:opacity .2s;"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg></button>
        <button class="wf-hq-next" aria-label="Suivant" style="width:44px;height:44px;background:<?= esc_attr( $acc ) ?>;color:#fff;border:0;border-radius:6px;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;transition:opacity .2s;"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></button>
    </div>
    <?php endif; ?>

    <?php if ( $dots && $multi ) : ?>
    <div class="wf-hq-dots" style="display:flex;justify-content:center;gap:8px;margin-top:24px;"></div>
    <?php endif; ?>
</div>

<style>
#<?= esc_attr( $uid ) ?> .wf-hq-slide { position:absolute;top:0;left:0;right:0;opacity:0;pointer-events:none;transition:opacity .5s ease; }
#<?= esc_attr( $uid ) ?> .wf-hq-slide.is-active { position:relative;opacity:1;pointer-events:auto; }
#<?= esc_attr( $uid ) ?> .wf-hq-prev:hover, #<?= esc_attr( $uid ) ?> .wf-hq-next:hover { opacity:0.85; }
#<?= esc_attr( $uid ) ?> .wf-hq-dot { width:8px;height:8px;border-radius:50%;border:0;padding:0;cursor:pointer;background:rgba(0,0,0,.18);transition:transform .2s,background .2s; }
#<?= esc_attr( $uid ) ?> .wf-hq-dot.is-on { background:<?= esc_attr( $acc ) ?>;transform:scale(1.4); }
@media(max-width:767px){ #<?= esc_attr( $uid ) ?> { padding:<?= max( 24, (int) round( $pad * 0.5 ) ) ?>px !important; } #<?= esc_attr( $uid ) ?> .wf-hq-quote { font-size:<?= $fs_m ?>px !important; } }
@media(prefers-reduced-motion:reduce){ #<?= esc_attr( $uid ) ?> .wf-hq-slide { transition:none !important; } }
</style>

<?php if ( $multi ) : ?>
<script>
(function(){
    var C = <?= $cfg ?>;
    function boot(){
        var root = document.getElementById(C.uid); if (!root) return;
        var slides = root.querySelectorAll('.wf-hq-slide');
        var total = slides.length; if (total < 2) return;
        var prev = root.querySelector('.wf-hq-prev');
        var next = root.querySelector('.wf-hq-next');
        var dotsWrap = root.querySelector('.wf-hq-dots');
        var idx = 0, timer = null, dots = [];

        function go(n){
            idx = (n + total) % total;
            var j = 0;
            while (j < total) { slides[j].classList.toggle('is-active', j === idx); j++; }
            var d = 0;
            while (d < dots.length) { dots[d].classList.toggle('is-on', d === idx); d++; }
        }
        function start(){ if (C.auto) { clearInterval(timer); timer = setInterval(function(){ go(idx + 1); }, C.step); } }

        if (dotsWrap) {
            var i = 0;
            while (i < total) {
                (function(k){
                    var b = document.createElement('button');
                    b.className = 'wf-hq-dot' + (k === 0 ? ' is-on' : '');
                    b.setAttribute('aria-label', 'Avis ' + (k + 1));
                    b.addEventListener('click', function(){ go(k); start(); });
                    dotsWrap.appendChild(b); dots.push(b);
                })(i);
                i++;
            }
        }
        if (prev) { prev.addEventListener('click', function(){ go(idx - 1); start(); }); }
        if (next) { next.addEventListener('click', function(){ go(idx + 1); start(); }); }
        root.addEventListener('mouseenter', function(){ clearInterval(timer); });
        root.addEventListener('mouseleave', start);
        root.setAttribute('tabindex', '0');
        root.addEventListener('keydown', function(e){
            if (e.key === 'ArrowLeft') { go(idx - 1); start(); }
            if (e.key === 'ArrowRight') { go(idx + 1); start(); }
        });
        start();
    }
    if (window.WF) { if (WF.ready) { WF.ready(boot); return; } }
    if (document.readyState !== 'loading') { boot(); } else { document.addEventListener('DOMContentLoaded', boot); }
})();
</script>
<?php endif; ?>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
