<?php
/**
 * WeFrame – Chips défilantes (parent) | rangées de pastilles en marquee alterné (style Granola).
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$rows    = min( 6, max( 1, (int) ( $props['rows'] ?? 3 ) ) );
$speed   = min( 120, max( 6, (int) ( $props['speed'] ?? 34 ) ) );
$gap     = max( 0, (int) ( $props['gap'] ?? 14 ) );
$rowGap  = max( 0, (int) ( $props['row_gap'] ?? 16 ) );
$pause   = ! empty( $props['pause_hover'] );

// Répartition round-robin des chips dans les rangées.
$chunks = array();
for ( $r = 0; $r < $rows; $r++ ) { $chunks[ $r ] = array(); }
$i = 0;
foreach ( $children as $child ) { $chunks[ $i % $rows ][] = $child; $i++; }

$uid = wf_uid( 'wfcm_', $props, count( $children ) );

// Rendu des rangées.
$rowsHtml = '';
foreach ( $chunks as $ri => $chunk ) {
    if ( empty( $chunk ) ) { continue; }
    $rowInner = '';
    foreach ( $chunk as $child ) { $rowInner .= $builder->render( $child, array( 'element' => $props ) ); }
    if ( ! trim( $rowInner ) ) { continue; }
    $rev = ( $ri % 2 === 1 ) ? ' wf-cm-rev' : '';
    // Piste dupliquée pour boucle sans couture.
    $rowsHtml .= '<div class="wf-cm-row' . $rev . '"><div class="wf-cm-track">'
        . $rowInner . '<span class="wf-cm-dup" aria-hidden="true">' . $rowInner . '</span>'
        . '</div></div>';
}
if ( ! trim( $rowsHtml ) ) { return; }
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-cm">
    <?= $rowsHtml ?>
</div>
<style>
#<?= esc_attr( $uid ) ?>.wf-cm{display:flex;flex-direction:column;gap:<?= $rowGap ?>px;overflow:hidden;width:100%;}
#<?= esc_attr( $uid ) ?> .wf-cm-row{overflow:hidden;width:100%;-webkit-mask-image:linear-gradient(90deg,transparent,#000 8%,#000 92%,transparent);mask-image:linear-gradient(90deg,transparent,#000 8%,#000 92%,transparent);}
#<?= esc_attr( $uid ) ?> .wf-cm-track{display:inline-flex;gap:<?= $gap ?>px;width:max-content;animation:wfcm-scroll <?= $speed ?>s linear infinite;will-change:transform;}
#<?= esc_attr( $uid ) ?> .wf-cm-dup{display:inline-flex;gap:<?= $gap ?>px;margin-left:<?= $gap ?>px;}
#<?= esc_attr( $uid ) ?> .wf-cm-rev .wf-cm-track{animation-direction:reverse;}
<?php if ( $pause ) : ?>#<?= esc_attr( $uid ) ?> .wf-cm-row:hover .wf-cm-track{animation-play-state:paused;}<?php endif; ?>
@keyframes wfcm-scroll{from{transform:translateX(0)}to{transform:translateX(-50%)}}
@media(max-width:640px){#<?= esc_attr( $uid ) ?> .wf-cm-chip{font-size:<?= max( 13, (int) round( ( (int) ( $props['font_size'] ?? 22 ) ) * 0.78 ) ) ?>px !important;}}
@media(prefers-reduced-motion:reduce){#<?= esc_attr( $uid ) ?> .wf-cm-track{animation:none !important;}#<?= esc_attr( $uid ) ?> .wf-cm-row{overflow-x:auto;}}
</style>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
