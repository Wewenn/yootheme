<?php
/**
 * WeFrame – Scroll Snap Panels | template.php
 * Self-contained vertical scroll container; each child becomes a full-height
 * snap panel. Optional side dots + scroll hint.
 * Config inlined (no <script type="application/json">), no "&&" in inline JS.
 */
defined( 'ABSPATH' ) || exit;

$props = is_array( $props ?? null ) ? $props : array();
if ( ! isset( $builder ) || ! is_object( $builder ) || empty( $children ) || ! is_array( $children ) ) { return; }

$ph        = min( 100, max( 60, (int) ( $props['panel_height'] ?? 100 ) ) );
$snap      = ( ( $props['snap_type'] ?? 'mandatory' ) === 'proximity' ) ? 'proximity' : 'mandatory';
$show_dots = ! empty( $props['show_dots'] );
$dot_col   = (string) ( $props['dot_color'] ?? 'rgba(0,0,0,0.25)' );
$dot_act   = (string) ( $props['dot_active'] ?? '#111111' );
$arrows    = ! empty( $props['show_arrows'] );

$panels = '';
$count  = 0;
foreach ( $children as $child ) {
    $inner = (string) $builder->render( $child, array( 'element' => $props ) );
    if ( ! trim( $inner ) ) { continue; }
    $panels .= '<section class="wf-snap-panel" data-i="' . $count . '" style="min-height:' . $ph . 'vh;scroll-snap-align:start;scroll-snap-stop:always;display:flex;align-items:center;justify-content:center;position:relative;">' . $inner . '</section>';
    $count++;
}
if ( 0 === $count ) { return; }

$uid = wf_uid( 'wfsnap_', $props, $count );

$cfg = wp_json_encode( array(
    'uid'  => $uid,
    'dots' => $show_dots ? 1 : 0,
), JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-snap" style="position:relative;height:<?= $ph ?>vh;overflow-y:scroll;overflow-x:hidden;scroll-snap-type:y <?= $snap ?>;scroll-behavior:smooth;-webkit-overflow-scrolling:touch;">
    <?= $panels ?>

    <?php if ( $arrows ) : ?>
    <div class="wf-snap-hint" aria-hidden="true" style="position:absolute;left:50%;bottom:24px;transform:translateX(-50%);z-index:5;opacity:.6;animation:wf-snap-bob 1.6s ease-in-out infinite;">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M19 12l-7 7-7-7"/></svg>
    </div>
    <?php endif; ?>

    <?php if ( $show_dots ) : ?>
    <nav class="wf-snap-dots" aria-label="Navigation" style="position:absolute;top:50%;right:18px;transform:translateY(-50%);z-index:6;display:flex;flex-direction:column;gap:12px;"></nav>
    <?php endif; ?>
</div>

<style>
#<?= esc_attr( $uid ) ?> { scrollbar-width: none; -ms-overflow-style: none; }
#<?= esc_attr( $uid ) ?>::-webkit-scrollbar { display: none; }
#<?= esc_attr( $uid ) ?> .wf-snap-dot { width: 10px; height: 10px; border-radius: 50%; border: 0; padding: 0; cursor: pointer; background: <?= esc_attr( $dot_col ) ?>; transition: transform .2s ease, background .2s ease; }
#<?= esc_attr( $uid ) ?> .wf-snap-dot.is-active { background: <?= esc_attr( $dot_act ) ?>; transform: scale(1.4); }
@keyframes wf-snap-bob { 0%,100% { transform: translateX(-50%) translateY(0); } 50% { transform: translateX(-50%) translateY(8px); } }
@media (max-width:767px) { #<?= esc_attr( $uid ) ?> .wf-snap-dots { right: 10px; } }
</style>

<script>
(function(){
    var C = <?= $cfg ?>;
    function boot(){
        var root = document.getElementById(C.uid); if (!root) return;
        var panels = root.querySelectorAll('.wf-snap-panel');
        if (panels.length < 1) return;

        var dots = [];
        if (C.dots) {
            var nav = root.querySelector('.wf-snap-dots');
            if (nav) {
                var i = 0;
                while (i < panels.length) {
                    (function(idx){
                        var b = document.createElement('button');
                        b.className = 'wf-snap-dot';
                        b.setAttribute('aria-label', 'Panneau ' + (idx + 1));
                        b.addEventListener('click', function(){
                            panels[idx].scrollIntoView({ behavior: 'smooth', block: 'start' });
                        });
                        nav.appendChild(b);
                        dots.push(b);
                    })(i);
                    i++;
                }
                if (dots.length > 0) { dots[0].classList.add('is-active'); }
            }
        }

        if ('IntersectionObserver' in window) {
            var obs = new IntersectionObserver(function(es){
                var k = 0;
                while (k < es.length) {
                    if (es[k].isIntersecting) {
                        var idx = parseInt(es[k].target.getAttribute('data-i'), 10) || 0;
                        var j = 0;
                        while (j < dots.length) {
                            if (j === idx) { dots[j].classList.add('is-active'); }
                            else { dots[j].classList.remove('is-active'); }
                            j++;
                        }
                    }
                    k++;
                }
            }, { root: root, threshold: 0.6 });
            var p = 0; while (p < panels.length) { obs.observe(panels[p]); p++; }
        }
    }
    if (window.WF) { if (WF.ready) { WF.ready(boot); return; } }
    if (document.readyState !== 'loading') { boot(); } else { document.addEventListener('DOMContentLoaded', boot); }
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
