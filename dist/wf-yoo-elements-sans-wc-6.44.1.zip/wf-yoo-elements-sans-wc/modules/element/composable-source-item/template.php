<?php defined( 'ABSPATH' ) || exit; // La variable est résolue par son parent.
