<?php
/**
 * WeFrame – Drag Pictures | template.php
 * Scattered draggable images with random rotation.
 * NO && in JS — WordPress safe.
 */
defined('ABSPATH') || exit;
if (empty($children)) return;

$sh = $props['section_height'] ?? '80vh';
$sbg = $props['section_bg'] ?? '#f5f5f5';
$ir = (int)($props['image_radius'] ?? 12);
$shadow = !empty($props['shadow']);
$escape  = ! empty( $props['escape'] );
$escZ    = max( 1, min( 999, (int) ( $props['escape_z'] ?? 30 ) ) );
$scatter = max(20, min(100, (int)($props['scatter_range'] ?? 80)));
$rotMax = max(0, min(30, (int)($props['rotation_range'] ?? 15)));
$title = $props['title'] ?? '';
$ts = (int)($props['title_size'] ?? 48);
$tsm = (int)($props['title_size_mobile'] ?? 28);
$tw = $props['title_weight'] ?? '700';
$tc = $props['title_color'] ?? '#000000';

$uid = 'wfdp_' . substr(md5(serialize($props) . count($children)), 0, 8);

// Collect images from children
$images = [];
foreach ($children as $child) {
    $cp = (array)($child->props ?? []);
    $src = $cp['image'] ?? '';
    if ($src) {
        if (!preg_match('#^https?://#i', $src)) $src = '/' . ltrim($src, '/');
        $images[] = [
            'src' => $src,
            'alt' => $cp['image_alt'] ?? '',
            'width' => (int)($cp['width'] ?? 250),
        ];
    }
}
if (empty($images)) return;

$shCSS = $shadow ? 'box-shadow:0 8px 30px rgba(0,0,0,.2);' : '';

$cfg = json_encode([
    'uid' => $uid,
    'images' => $images,
    'scatter' => $scatter,
    'rotMax' => $rotMax,
    'radius' => $ir,
    'shadow' => $shadow,
], JSON_HEX_AMP | JSON_HEX_APOS);
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr($uid) ?>" class="wf-drag-pics"
     style="position:relative;height:<?= esc_attr($sh) ?>;background:<?= esc_attr($sbg) ?>;<?php if ( $escape ) : ?>overflow:visible;z-index:<?= (int) $escZ ?>;<?php else : ?>overflow:hidden;<?php endif; ?>">

    <div class="wf-dp-canvas" style="position:absolute;top:0;left:0;width:100%;height:100%;z-index:1;<?php if ( $escape ) : ?>overflow:visible;<?php endif; ?>"></div>

    <?php if ($title) : ?>
    <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);z-index:0;text-align:center;pointer-events:none;padding:0 24px;">
        <div class="wf-dp-title" style="font-size:<?= $ts ?>px;font-weight:<?= esc_attr($tw) ?>;color:<?= esc_attr($tc) ?>;line-height:1.1;"><?= esc_html($title) ?></div>
    </div>
    <?php endif; ?>
</div>

<style>
#<?= esc_attr($uid) ?> .wf-dp-img {
    position: absolute;
    border-radius: <?= $ir ?>px;
    <?= $shCSS ?>
    cursor: grab;
    user-select: none;
    -webkit-user-select: none;
    transition: box-shadow .2s, transform .1s;
    object-fit: cover;
}
#<?= esc_attr($uid) ?> .wf-dp-img:hover {
    box-shadow: 0 12px 40px rgba(0,0,0,.3);
}
#<?= esc_attr($uid) ?> .wf-dp-img.wf-dp--dragging {
    cursor: grabbing;
    box-shadow: 0 20px 60px rgba(0,0,0,.35);
    z-index: 9999 !important;
    transition: box-shadow .2s;
}
@media(max-width:767px) {
    #<?= esc_attr($uid) ?> .wf-dp-title { font-size: <?= $tsm ?>px !important; }
}
</style>

<script>
(function(){
    function boot(){
        
        var c = <?= $cfg ?>;
        var el = document.getElementById(c.uid);
        if (!el) return;
        var canvas = el.querySelector('.wf-dp-canvas');
        if (!canvas) return;

        var zTop = 10;
        var imgs = c.images;
        var rect = el.getBoundingClientRect();
        var W = rect.width;
        var H = rect.height;

        /* Scatter images */
        var i = 0;
        while (i < imgs.length) {
            var img = document.createElement('img');
            img.className = 'wf-dp-img';
            img.src = imgs[i].src;
            img.alt = imgs[i].alt;
            img.draggable = false;
            img.style.width = imgs[i].width + 'px';
            img.style.height = 'auto';

            /* Random position within scatter range */
            var margin = (100 - c.scatter) / 2;
            var xPct = margin + Math.random() * c.scatter;
            var yPct = margin + Math.random() * c.scatter;
            var x = (xPct / 100) * W - imgs[i].width / 2;
            var y = (yPct / 100) * H - imgs[i].width * 0.35;
            img.style.left = x + 'px';
            img.style.top = y + 'px';

            /* Random rotation */
            var rot = (Math.random() - 0.5) * 2 * c.rotMax;
            img.style.transform = 'rotate(' + rot + 'deg)';
            img.style.zIndex = String(i + 1);

            canvas.appendChild(img);
            i++;
        }

        /* Drag logic */
        var dragEl = null;
        var dragOX = 0;
        var dragOY = 0;
        var dragRot = '';

        function startDrag(e, target) {
            dragEl = target;
            dragEl.classList.add('wf-dp--dragging');
            zTop++;
            dragEl.style.zIndex = String(zTop);

            var r2 = el.getBoundingClientRect();
            var px = e.clientX; var py = e.clientY;
            if (e.touches) { px = e.touches[0].clientX; py = e.touches[0].clientY; }
            dragOX = px - dragEl.getBoundingClientRect().left;
            dragOY = py - dragEl.getBoundingClientRect().top;

            /* Keep current rotation */
            var st = dragEl.style.transform;
            dragRot = st;
        }

        function moveDrag(e) {
            if (!dragEl) return;
            var r2 = el.getBoundingClientRect();
            var px = e.clientX; var py = e.clientY;
            if (e.touches) { px = e.touches[0].clientX; py = e.touches[0].clientY; }
            var nx = px - r2.left - dragOX;
            var ny = py - r2.top - dragOY;
            dragEl.style.left = nx + 'px';
            dragEl.style.top = ny + 'px';
        }

        function endDrag() {
            if (dragEl) {
                dragEl.classList.remove('wf-dp--dragging');
                dragEl = null;
            }
        }

        canvas.addEventListener('pointerdown', function(e) {
            if (e.target.classList.contains('wf-dp-img')) {
                e.preventDefault();
                canvas.setPointerCapture(e.pointerId);
                startDrag(e, e.target);
            }
        });
        canvas.addEventListener('pointermove', function(e) {
            if (dragEl) moveDrag(e);
        });
        canvas.addEventListener('pointerup', endDrag);
        canvas.addEventListener('pointercancel', endDrag);
    }

    WF.ready(boot);
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
