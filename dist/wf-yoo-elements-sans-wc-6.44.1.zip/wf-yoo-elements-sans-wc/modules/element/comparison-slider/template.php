<?php
/**
 * WeFrame – Comparison Slider | template.php v6.0
 * Deux panneaux côte à côte (avant/après, sans nous/avec nous…).
 * Sur mobile : empilés verticalement.
 */
defined( 'ABSPATH' ) || exit;

// ── Panneau gauche ───────────────────────────────────────────────
$l_badge  = $props['left_badge']       ?? 'Sans nous';
$l_bb     = $props['left_badge_bg']    ?? '#e5e5e5';
$l_bc     = $props['left_badge_color'] ?? '#666666';
$l_img    = $props['left_image']       ?? '';
$l_title  = $props['left_title']       ?? '';
$l_text   = $props['left_text']        ?? '';
$l_items  = $props['left_items']       ?? '';
$l_icon   = $props['left_item_icon']   ?? '✗';
$l_icol   = $props['left_item_icon_color'] ?? '#e74c3c';
$l_bg     = $props['left_bg']          ?? '#ffffff';
$l_color  = $props['left_color']       ?? '#333333';

// ── Panneau droit ────────────────────────────────────────────────
$r_badge  = $props['right_badge']       ?? 'Avec nous';
$r_bb     = $props['right_badge_bg']    ?? '#EA5C1C';
$r_bc     = $props['right_badge_color'] ?? '#ffffff';
$r_img    = $props['right_image']       ?? '';
$r_title  = $props['right_title']       ?? '';
$r_text   = $props['right_text']        ?? '';
$r_items  = $props['right_items']       ?? '';
$r_icon   = $props['right_item_icon']   ?? '✓';
$r_icol   = $props['right_item_icon_color'] ?? '#27ae60';
$r_bg     = $props['right_bg']          ?? '#fff8f5';
$r_color  = $props['right_color']       ?? '#111111';

// ── Global ───────────────────────────────────────────────────────
$show_div = ! empty( $props['divider'] );
$div_c    = $props['divider_color']   ?? '#e5e5e5';
$rad      = (int) ( $props['radius']  ?? 16 );
$shadow   = ! empty( $props['shadow'] );
$hl_right = ! empty( $props['highlight_right'] );
$gap      = (int) ( $props['gap']     ?? 0 );
$pad      = (int) ( $props['padding'] ?? 32 );
$ih       = (int) ( $props['image_height'] ?? 200 );
$tsz      = (int) ( $props['title_size']   ?? 20 );
$tw       = $props['title_weight']    ?? '700';
$xsz      = (int) ( $props['text_size']    ?? 14 );
$isz      = (int) ( $props['item_size']    ?? 14 );

$uid = wf_uid( 'wfcs_', $props );

// ── Helper: render items list ────────────────────────────────────
function wf_cs_items( $raw, $icon, $icon_color, $size ) {
    $lines = array_values( array_filter( array_map( 'trim', explode( "\n", $raw ) ) ) );
    if ( empty( $lines ) ) return '';
    $out = '<ul style="list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:8px;">';
    foreach ( $lines as $line ) {
        $out .= '<li style="display:flex;align-items:flex-start;gap:10px;font-size:' . (int)$size . 'px;line-height:1.5;">'
            . '<span style="color:' . esc_attr( $icon_color ) . ';font-weight:700;flex-shrink:0;margin-top:1px;">' . esc_html( $icon ) . '</span>'
            . '<span>' . esc_html( $line ) . '</span>'
            . '</li>';
    }
    $out .= '</ul>';
    return $out;
}

// ── Image helper ─────────────────────────────────────────────────
function wf_cs_img( $src, $height ) {
    if ( ! $src ) return '';
    if ( ! preg_match( '#^https?://#i', $src ) ) $src = '/' . ltrim( $src, '/' );
    return '<div style="width:100%;height:' . (int)$height . 'px;overflow:hidden;margin-bottom:20px;border-radius:8px;">'
        . '<img src="' . esc_url( $src ) . '" loading="lazy" style="width:100%;height:100%;object-fit:cover;display:block;">'
        . '</div>';
}

$sh_css = $shadow ? 'box-shadow:0 8px 40px rgba(0,0,0,.10);' : '';

// Right highlight = subtle ring + scale-up
$r_ring = $hl_right ? 'outline:2px solid ' . esc_attr( $r_bb ) . ';outline-offset:-1px;' : '';

// Wrapper layout: inline-flex so panels are side-by-side
$wrapper_style = "display:flex;align-items:stretch;border-radius:{$rad}px;{$sh_css}overflow:hidden;gap:{$gap}px;";
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-comparison-slider" style="<?= $wrapper_style ?>">

    <!-- Panneau GAUCHE -->
    <div class="wf-cs-panel wf-cs-left" style="flex:1;min-width:0;background:<?= esc_attr( $l_bg ) ?>;color:<?= esc_attr( $l_color ) ?>;padding:<?= $pad ?>px;box-sizing:border-box;<?= $show_div && ! $gap ? 'border-right:1px solid ' . esc_attr( $div_c ) . ';' : '' ?>display:flex;flex-direction:column;gap:16px;">

        <?php if ( $l_badge ) : ?>
        <div style="display:inline-block;background:<?= esc_attr( $l_bb ) ?>;color:<?= esc_attr( $l_bc ) ?>;padding:4px 12px;border-radius:100px;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;align-self:flex-start;"><?= esc_html( $l_badge ) ?></div>
        <?php endif; ?>

        <?= wf_cs_img( $l_img, $ih ) ?>

        <?php if ( $l_title ) : ?>
        <div style="font-size:<?= $tsz ?>px;font-weight:<?= esc_attr( $tw ) ?>;line-height:1.3;"><?= esc_html( $l_title ) ?></div>
        <?php endif; ?>

        <?php if ( $l_text ) : ?>
        <div style="font-size:<?= $xsz ?>px;line-height:1.6;opacity:.75;"><?= nl2br( esc_html( $l_text ) ) ?></div>
        <?php endif; ?>

        <?php echo wf_cs_items( $l_items, $l_icon, $l_icol, $isz ); ?>
    </div>

    <!-- Panneau DROIT -->
    <div class="wf-cs-panel wf-cs-right" style="flex:1;min-width:0;background:<?= esc_attr( $r_bg ) ?>;color:<?= esc_attr( $r_color ) ?>;padding:<?= $pad ?>px;box-sizing:border-box;<?= $r_ring ?>display:flex;flex-direction:column;gap:16px;position:relative;">

        <?php if ( $hl_right ) : ?>
        <div style="position:absolute;top:0;left:0;right:0;height:4px;background:<?= esc_attr( $r_bb ) ?>;border-radius:0 <?= $rad ?>px 0 0;"></div>
        <?php endif; ?>

        <?php if ( $r_badge ) : ?>
        <div style="display:inline-block;background:<?= esc_attr( $r_bb ) ?>;color:<?= esc_attr( $r_bc ) ?>;padding:4px 12px;border-radius:100px;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;align-self:flex-start;<?= $hl_right ? 'margin-top:8px;' : '' ?>"><?= esc_html( $r_badge ) ?></div>
        <?php endif; ?>

        <?= wf_cs_img( $r_img, $ih ) ?>

        <?php if ( $r_title ) : ?>
        <div style="font-size:<?= $tsz ?>px;font-weight:<?= esc_attr( $tw ) ?>;line-height:1.3;"><?= esc_html( $r_title ) ?></div>
        <?php endif; ?>

        <?php if ( $r_text ) : ?>
        <div style="font-size:<?= $xsz ?>px;line-height:1.6;opacity:.8;"><?= nl2br( esc_html( $r_text ) ) ?></div>
        <?php endif; ?>

        <?php echo wf_cs_items( $r_items, $r_icon, $r_icol, $isz ); ?>
    </div>

</div>

<style>
@media(max-width:767px){
    #<?= esc_attr( $uid ) ?>{
        flex-direction: column !important;
    }
    #<?= esc_attr( $uid ) ?> .wf-cs-left{
        border-right: none !important;
        border-bottom: 1px solid <?= esc_attr( $show_div ? $div_c : 'transparent' ) ?>;
    }
    #<?= esc_attr( $uid ) ?> .wf-cs-right{
        outline: none !important;
    }
}
</style>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
