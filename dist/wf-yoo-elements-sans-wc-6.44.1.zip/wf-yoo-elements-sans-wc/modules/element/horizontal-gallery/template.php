<?php
/**
 * WeFrame – Galerie horizontale (parent) | scroll vertical -> défilement horizontal des images (items), section épinglée.
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }
$iw  = max( 160, (int) ( $props['img_width'] ?? 440 ) );
$ih  = max( 160, (int) ( $props['img_height'] ?? 480 ) );
$gap = max( 0, (int) ( $props['gap'] ?? 20 ) );
$r   = max( 0, (int) ( $props['radius'] ?? 16 ) );
$bg  = trim( (string) ( $props['bg'] ?? '' ) );

$html = '';
foreach ( $children as $child ) { $html .= $builder->render( $child, array( 'element' => $props ) ); }
if ( ! trim( $html ) ) { return; }
$uid = wf_uid( 'wfhg_', $props, count( $children ) );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-hg" style="position:relative;<?= $bg ? 'background:' . esc_attr( $bg ) . ';' : '' ?>">
    <div class="wf-hg-sticky" style="position:sticky;top:0;height:100vh;display:flex;align-items:center;overflow:hidden;">
        <div class="wf-hg-track" style="display:flex;gap:<?= $gap ?>px;padding:0 24px;will-change:transform;"><?= $html ?></div>
    </div>
</div>
<style>
#<?= esc_attr( $uid ) ?> .wf-hg-i{flex:0 0 auto;width:<?= $iw ?>px;height:<?= $ih ?>px;border-radius:<?= $r ?>px;overflow:hidden;position:relative;}
#<?= esc_attr( $uid ) ?> .wf-hg-i img{width:100%;height:100%;object-fit:cover;display:block;}
@media(max-width:782px){
    #<?= esc_attr( $uid ) ?>{height:auto !important;}
    #<?= esc_attr( $uid ) ?> .wf-hg-sticky{position:relative !important;height:auto !important;overflow-x:auto !important;-webkit-overflow-scrolling:touch;}
    #<?= esc_attr( $uid ) ?> .wf-hg-track{transform:none !important;}
    #<?= esc_attr( $uid ) ?> .wf-hg-i{width:78vw !important;height:<?= (int) ( $ih * 0.8 ) ?>px !important;}
}
</style>
<script>
(function(){
    var outer = document.getElementById('<?= esc_js( $uid ) ?>'); if (!outer) return;
    var sticky = outer.querySelector('.wf-hg-sticky'), track = outer.querySelector('.wf-hg-track');
    if (!track) return;
    var maxX = 0, ticking = false, active = true;
    function isDesktop(){ return window.innerWidth > 782; }
    function measure(){
        if (!isDesktop()) { active = false; outer.style.height = ''; track.style.transform = ''; return; }
        active = true;
        var vw = sticky.clientWidth;
        maxX = track.scrollWidth - vw; if (maxX < 0) maxX = 0;
        outer.style.height = (window.innerHeight + maxX) + 'px';
    }
    function upd(){
        ticking = false;
        if (!active) return;
        var r = outer.getBoundingClientRect();
        var total = outer.offsetHeight - window.innerHeight;
        var p = total > 0 ? (-r.top) / total : 0;
        if (p < 0) p = 0; if (p > 1) p = 1;
        track.style.transform = 'translateX(' + (-p * maxX) + 'px)';
    }
    function onS(){ if (!ticking) { ticking = true; requestAnimationFrame(upd); } }
    window.addEventListener('scroll', onS, { passive: true });
    window.addEventListener('resize', function(){ measure(); upd(); }, { passive: true });
    window.addEventListener('load', function(){ measure(); upd(); });
    measure(); upd();
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
