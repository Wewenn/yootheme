<?php
/**
 * WeFrame – Texte à volets (split-flap) | template.php v1.0
 *
 * L'afficheur mécanique des gares : chaque caractère est un volet qui bat
 * jusqu'à tomber sur la bonne lettre.
 *
 * Un volet = quatre moitiés superposées. Deux fixes (haut et bas), deux qui
 * pivotent. Chaque moitié contient le caractère en pleine hauteur et n'en
 * laisse voir que sa part : c'est ce qui donne la coupure au milieu, sans
 * découper la police.
 *
 * Le texte est écrit une fois pour de vrai, hors écran, et les volets sont
 * marqués aria-hidden : un lecteur d'écran lit le message, pas 14 lettres
 * isolées qui changent toutes les secondes.
 *
 * Pas de "&&" ni de "||" dans le JS inline (règle interne du plugin).
 */

defined( 'ABSPATH' ) || exit;

$mode = (string) ( $props['mode'] ?? 'message' );
if ( ! in_array( $mode, array( 'message', 'rotate', 'number' ), true ) ) { $mode = 'message'; }

$text = (string) ( $props['text'] ?? '' );

$lines = array();
foreach ( preg_split( '/\r\n|\r|\n/', (string) ( $props['lines'] ?? '' ) ) as $l ) {
	$l = trim( wp_strip_all_tags( $l ) );
	if ( '' !== $l ) { $lines[] = $l; }
}
if ( 'rotate' === $mode && empty( $lines ) ) { $mode = 'message'; }
if ( 'rotate' !== $mode ) { $lines = array( trim( wp_strip_all_tags( $text ) ) ); }

$rotateDelay = max( 2, min( 30, (int) ( $props['rotate_delay'] ?? 5 ) ) );

$charset = (string) ( $props['charset'] ?? 'alnum' );
if ( ! in_array( $charset, array( 'alnum', 'digits', 'full' ), true ) ) { $charset = 'alnum'; }
if ( 'number' === $mode ) { $charset = 'digits'; }

$sets = array(
	'digits' => ' 0123456789',
	'alnum'  => ' ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
	'full'   => ' ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,:-/!?€%+\'',
);
$alphabet = $sets[ $charset ];

// Les volets ne connaissent que leur alphabet : tout est mis en capitales et
// les accents sont ramenés à leur lettre de base.
$normalize = function ( $s ) use ( $alphabet ) {
	$s = remove_accents( $s );
	$s = strtoupper( $s );
	$out = '';
	$len = mb_strlen( $s, 'UTF-8' );
	for ( $i = 0; $i < $len; $i++ ) {
		$ch = mb_substr( $s, $i, 1, 'UTF-8' );
		$out .= ( false !== mb_strpos( $alphabet, $ch, 0, 'UTF-8' ) ) ? $ch : ' ';
	}
	return $out;
};

$clean = array();
foreach ( $lines as $l ) { $clean[] = $normalize( $l ); }
if ( empty( $clean ) ) { $clean = array( '' ); }

$cells = max( 0, min( 40, (int) ( $props['cells'] ?? 0 ) ) );
if ( 0 === $cells ) {
	foreach ( $clean as $l ) { $cells = max( $cells, mb_strlen( $l, 'UTF-8' ) ); }
}
$cells = max( 1, min( 40, $cells ) );

// Un nombre se lit calé à droite ; un message, calé à gauche.
$padded = array();
foreach ( $clean as $l ) {
	$l = mb_substr( $l, 0, $cells, 'UTF-8' );
	$missing = $cells - mb_strlen( $l, 'UTF-8' );
	if ( $missing > 0 ) {
		$pad = str_repeat( ' ', $missing );
		$l = ( 'number' === $mode ) ? $pad . $l : $l . $pad;
	}
	$padded[] = $l;
}

$steps   = max( 1, min( 24, (int) ( $props['steps'] ?? 8 ) ) );
$flipMs  = max( 40, min( 400, (int) ( $props['flip_ms'] ?? 110 ) ) );
$stagger = max( 0, min( 300, (int) ( $props['stagger_ms'] ?? 60 ) ) );
$onView  = ! empty( $props['start_on_view'] );

$size   = max( 24, min( 200, (int) ( $props['size'] ?? 64 ) ) );
$gap    = max( 0, min( 24, (int) ( $props['gap'] ?? 4 ) ) );
$radius = max( 0, min( 20, (int) ( $props['radius'] ?? 6 ) ) );
$cellBg = (string) ( $props['cell_bg'] ?? '#15181d' );
$cellCol = (string) ( $props['cell_color'] ?? '#f5f5f4' );
$lineCol = (string) ( $props['line_color'] ?? '#000000' );

$font = ( 'inherit' === ( $props['font'] ?? 'mono' ) ) ? 'inherit' : 'ui-monospace,SFMono-Regular,Menlo,Consolas,monospace';

$align = (string) ( $props['align'] ?? 'center' );
$just  = 'center';
if ( 'left' === $align ) { $just = 'flex-start'; }
if ( 'right' === $align ) { $just = 'flex-end'; }

$width = (int) round( $size * 0.68 );
$fsz   = (int) round( $size * 0.62 );

$uid = wf_uid( 'wfsf_', $props );

$cellList = array();
$first = $padded[0];
for ( $i = 0; $i < $cells; $i++ ) {
	$ch = mb_substr( $first, $i, 1, 'UTF-8' );
	if ( '' === $ch ) { $ch = ' '; }
	$cellList[] = array( 'i' => $i, 'ch' => $ch );
}

$srText = trim( implode( ' — ', $clean ) );

$cfg = wp_json_encode(
	array(
		'uid'      => $uid,
		'lines'    => $padded,
		'alphabet' => $alphabet,
		'steps'    => $steps,
		'flip'     => $flipMs,
		'stagger'  => $stagger,
		'delay'    => $rotateDelay * 1000,
		'rotate'   => ( 'rotate' === $mode ),
		'onView'   => $onView,
	),
	JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE
);
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-sf">
	<p class="wf-sf__sr"<?php if ( 'rotate' === $mode ) : ?> aria-live="polite"<?php endif; ?>><?= esc_html( $srText ) ?></p>
	<div class="wf-sf__board" aria-hidden="true">
	<?php foreach ( $cellList as $c ) : ?>
		<span class="wf-sf__cell" data-i="<?= (int) $c['i'] ?>">
			<span class="wf-sf__half wf-sf__half--top"><i><?= esc_html( $c['ch'] ) ?></i></span>
			<span class="wf-sf__half wf-sf__half--bot"><i><?= esc_html( $c['ch'] ) ?></i></span>
			<span class="wf-sf__half wf-sf__half--ft"><i><?= esc_html( $c['ch'] ) ?></i></span>
			<span class="wf-sf__half wf-sf__half--fb"><i><?= esc_html( $c['ch'] ) ?></i></span>
		</span>
	<?php endforeach; ?>
	</div>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?> .wf-sf__sr{
	position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;
	clip-path:inset(50%);white-space:nowrap;border:0;
}
#<?= esc_attr( $uid ) ?> .wf-sf__board{
	display:flex;flex-wrap:wrap;justify-content:<?= esc_attr( $just ) ?>;
	gap:<?= (int) $gap ?>px;
}
#<?= esc_attr( $uid ) ?> .wf-sf__cell{
	position:relative;display:block;flex:0 0 auto;
	width:<?= (int) $width ?>px;height:<?= (int) $size ?>px;
	border-radius:<?= (int) $radius ?>px;background:<?= esc_attr( $cellBg ) ?>;
	perspective:<?= (int) ( $size * 4 ) ?>px;overflow:hidden;
	font-family:<?= $font ?>;font-size:<?= (int) $fsz ?>px;font-weight:700;
	color:<?= esc_attr( $cellCol ) ?>;line-height:1;
}
#<?= esc_attr( $uid ) ?> .wf-sf__half{
	position:absolute;left:0;right:0;height:50%;overflow:hidden;
	background:<?= esc_attr( $cellBg ) ?>;backface-visibility:hidden;
}
#<?= esc_attr( $uid ) ?> .wf-sf__half i{
	position:absolute;left:0;right:0;height:<?= (int) $size ?>px;
	display:flex;align-items:center;justify-content:center;font-style:normal;
}
/* Moitié haute : le caractère est collé en haut du bloc double hauteur. */
#<?= esc_attr( $uid ) ?> .wf-sf__half--top,#<?= esc_attr( $uid ) ?> .wf-sf__half--ft{
	top:0;border-radius:<?= (int) $radius ?>px <?= (int) $radius ?>px 0 0;
	border-bottom:1px solid <?= esc_attr( $lineCol ) ?>;
}
#<?= esc_attr( $uid ) ?> .wf-sf__half--top i,#<?= esc_attr( $uid ) ?> .wf-sf__half--ft i{top:0;}
#<?= esc_attr( $uid ) ?> .wf-sf__half--bot,#<?= esc_attr( $uid ) ?> .wf-sf__half--fb{
	bottom:0;border-radius:0 0 <?= (int) $radius ?>px <?= (int) $radius ?>px;
}
#<?= esc_attr( $uid ) ?> .wf-sf__half--bot i,#<?= esc_attr( $uid ) ?> .wf-sf__half--fb i{bottom:0;}
/* Les deux moitiés mobiles sont au repos hors du champ. */
#<?= esc_attr( $uid ) ?> .wf-sf__half--ft{transform-origin:center bottom;z-index:3;transform:rotateX(0deg);}
#<?= esc_attr( $uid ) ?> .wf-sf__half--fb{transform-origin:center top;z-index:3;transform:rotateX(90deg);}
#<?= esc_attr( $uid ) ?> .wf-sf__cell.is-flip .wf-sf__half--ft{
	transform:rotateX(-90deg);transition:transform <?= (int) round( $flipMs / 2 ) ?>ms ease-in;
}
#<?= esc_attr( $uid ) ?> .wf-sf__cell.is-flip2 .wf-sf__half--fb{
	transform:rotateX(0deg);transition:transform <?= (int) round( $flipMs / 2 ) ?>ms ease-out;
}
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?> .wf-sf__half--ft,#<?= esc_attr( $uid ) ?> .wf-sf__half--fb{transition:none;}
}
</style>
<script>
(function(){
	function boot(){
		var c = <?= $cfg ?>;
		var root = document.getElementById(c.uid);
		if(!root){return;}
		if(root.getAttribute('data-wf-ready')){return;}
		root.setAttribute('data-wf-ready','1');

		var cells = Array.prototype.slice.call(root.querySelectorAll('.wf-sf__cell'));
		if(!cells.length){return;}
		var half = Math.round(c.flip / 2);
		var line = 0;
		var busy = false;

		function parts(cell){
			return {
				top: cell.querySelector('.wf-sf__half--top i'),
				bot: cell.querySelector('.wf-sf__half--bot i'),
				ft:  cell.querySelector('.wf-sf__half--ft i'),
				fb:  cell.querySelector('.wf-sf__half--fb i')
			};
		}

		function current(cell){ return parts(cell).top.textContent; }

		// Un battement : la moitié haute tombe sur l'ancien caractère,
		// la moitié basse se relève sur le nouveau.
		function flip(cell, next, done){
			var p = parts(cell);
			var old = p.top.textContent;
			p.ft.textContent = old;
			p.fb.textContent = next;
			p.top.textContent = next;
			cell.classList.remove('is-flip2');
			void cell.offsetWidth;
			cell.classList.add('is-flip');
			window.setTimeout(function(){
				cell.classList.remove('is-flip');
				cell.classList.add('is-flip2');
				window.setTimeout(function(){
					p.bot.textContent = next;
					cell.classList.remove('is-flip2');
					if(done){done();}
				}, half);
			}, half);
		}

		function setNow(cell, ch){
			var p = parts(cell);
			p.top.textContent = ch;
			p.bot.textContent = ch;
			p.ft.textContent = ch;
			p.fb.textContent = ch;
		}

		function runCell(cell, target, steps, done){
			var n = 0;
			function step(){
				if(n >= steps){
					if(current(cell) === target){ if(done){done();} return; }
					flip(cell, target, done);
					return;
				}
				n++;
				var r = c.alphabet.charAt(Math.floor(Math.random() * c.alphabet.length));
				flip(cell, r, step);
			}
			step();
		}

		function show(text, instant){
			if(busy){return;}
			busy = true;
			var pending = cells.length;
			var i = 0;
			while(i < cells.length){
				(function(cell, idx){
					var target = text.charAt(idx);
					if(target === ''){ target = ' '; }
					if(instant){
						setNow(cell, target);
						pending--;
						if(pending === 0){ busy = false; }
						return;
					}
					window.setTimeout(function(){
						runCell(cell, target, c.steps, function(){
							pending--;
							if(pending === 0){ busy = false; }
						});
					}, idx * c.stagger);
				}(cells[i], i));
				i++;
			}
		}

		var reduce = false;
		if(WF.reducedMotion){ reduce = WF.reducedMotion(); }

		function start(){
			show(c.lines[0], reduce);
			if(!c.rotate){return;}
			window.setInterval(function(){
				line = (line + 1) % c.lines.length;
				show(c.lines[line], reduce);
			}, c.delay);
		}

		// Volets vides au départ : sinon le texte final est déjà lisible et
		// l'effet ne se voit pas.
		if(!reduce){
			var k = 0;
			while(k < cells.length){ setNow(cells[k], ' '); k++; }
		}

		var started = false;
		function go(){
			if(started){return;}
			started = true;
			start();
		}

		if(c.onView){
			if(WF.onVisible){ WF.onVisible(root, go, 0.2); }
			else { go(); }
			// Filet : si l'observateur ne se declenche jamais (onglet en arriere-plan
			// au chargement, navigateur exotique), le message doit quand meme
			// s'afficher. Des volets vides valent moins que pas d'animation.
			window.setTimeout(go, 2500);
			return;
		}
		go();
	}
	WF.ready(boot);
}());
</script>
