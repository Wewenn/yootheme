<?php
/**
 * WeFrame – Palette de commandes (⌘K) | template.php v1.0
 *
 * Une fenêtre de recherche au clavier : Ctrl/⌘ + K, on tape, on descend aux
 * flèches, Entrée ouvre. Les entrées sont saisies dans le panneau, donc rien
 * n'est deviné et rien n'appelle le serveur ; l'option « recherche du site »
 * renvoie simplement vers la recherche WordPress.
 *
 * La liste est écrite côté serveur : sans JavaScript, ce sont des liens
 * ordinaires dans une fenêtre qui ne s'ouvre pas — rien n'est perdu pour le
 * référencement. Le filtrage se fait ensuite dans le navigateur.
 *
 * La fenêtre est déplacée dans <body> au démarrage : une section animée
 * (transform) casserait son position:fixed.
 *
 * Pas de "&&" ni de "||" dans le JS inline (règle interne du plugin).
 */

defined( 'ABSPATH' ) || exit;

$rawEntries = (string) ( $props['entries'] ?? '' );
$entries = array();
foreach ( preg_split( '/\r\n|\r|\n/', $rawEntries ) as $line ) {
	$line = trim( wp_strip_all_tags( $line ) );
	if ( '' === $line ) { continue; }
	$parts = array_map( 'trim', explode( '|', $line ) );
	$label = isset( $parts[0] ) ? $parts[0] : '';
	$url   = isset( $parts[1] ) ? $parts[1] : '';
	if ( '' === $label ) { continue; }
	if ( '' === $url ) { $url = '#'; }
	$entries[] = array(
		'label' => $label,
		'url'   => $url,
		'group' => isset( $parts[2] ) ? $parts[2] : '',
		'keys'  => isset( $parts[3] ) ? $parts[3] : '',
	);
}
if ( empty( $entries ) ) { return; }

$placeholder = trim( (string) ( $props['placeholder'] ?? '' ) );
if ( '' === $placeholder ) { $placeholder = 'Rechercher…'; }
$emptyText = trim( (string) ( $props['empty_text'] ?? '' ) );
if ( '' === $emptyText ) { $emptyText = 'Aucun résultat.'; }

$siteSearch = ! empty( $props['site_search'] );
$siteLabel  = trim( (string) ( $props['site_search_label'] ?? '' ) );
if ( '' === $siteLabel ) { $siteLabel = 'Chercher « %s » sur tout le site'; }
$searchBase = esc_url( home_url( '/' ) );

$recents = max( 0, min( 8, (int) ( $props['recents'] ?? 3 ) ) );

$trigger = (string) ( $props['trigger_type'] ?? 'button' );
if ( ! in_array( $trigger, array( 'button', 'icon', 'selector', 'none' ), true ) ) { $trigger = 'button'; }
$btnText  = trim( (string) ( $props['btn_text'] ?? '' ) );
if ( '' === $btnText ) { $btnText = 'Rechercher'; }
$selector = trim( (string) ( $props['trigger_selector'] ?? '' ) );

$shortcut = ! empty( $props['shortcut'] );
$key = strtolower( trim( (string) ( $props['shortcut_key'] ?? 'k' ) ) );
$key = preg_replace( '/[^a-z0-9]/', '', $key );
if ( '' === $key ) { $key = 'k'; }
$key = substr( $key, 0, 1 );
$showHint = ! empty( $props['show_hint'] ) && $shortcut && ( 'button' === $trigger );

$width  = max( 320, min( 900, (int) ( $props['width'] ?? 620 ) ) );
$maxH   = max( 160, min( 640, (int) ( $props['max_height'] ?? 360 ) ) );
$top    = max( 0, min( 260, (int) ( $props['top'] ?? 90 ) ) );
$radius = max( 0, min( 28, (int) ( $props['radius'] ?? 14 ) ) );
$bg     = (string) ( $props['panel_bg'] ?? '#ffffff' );
$fg     = (string) ( $props['panel_color'] ?? '#111111' );
$accent = (string) ( $props['accent'] ?? '#EA5C1C' );
$bdOp   = max( 0, min( 100, (int) ( $props['backdrop_opacity'] ?? 45 ) ) );
$bdBlur = max( 0, min( 20, (int) ( $props['backdrop_blur'] ?? 4 ) ) );

$align = (string) ( $props['align'] ?? 'left' );
$just  = 'flex-start';
if ( 'center' === $align ) { $just = 'center'; }
if ( 'right' === $align ) { $just = 'flex-end'; }

$uid  = wf_uid( 'wfcp_', $props );
$host = $uid . '_host';

// Les groupes servent d'intertitres : on garde l'ordre de saisie.
$rows = array();
$lastGroup = null;
foreach ( $entries as $i => $e ) {
	$g = $e['group'];
	$rows[] = array(
		'i'        => $i,
		'label'    => $e['label'],
		'url'      => $e['url'],
		'group'    => $g,
		'keys'     => $e['keys'],
		'newGroup' => ( '' !== $g ) && ( $g !== $lastGroup ),
		'id'       => $uid . '-o' . $i,
		'keysAttr' => strtolower( $e['label'] . ' ' . $g . ' ' . $e['keys'] ),
	);
	if ( '' !== $g ) { $lastGroup = $g; }
}

$hintKey = strtoupper( $key );

$cfg = wp_json_encode(
	array(
		'uid'      => $uid,
		'host'     => $host,
		'sel'      => $selector,
		'shortcut' => $shortcut,
		'key'      => $key,
		'search'   => $siteSearch,
		'searchLb' => $siteLabel,
		'base'     => $searchBase,
		'recents'  => $recents,
		'store'    => 'wfcp_' . substr( md5( $rawEntries ), 0, 6 ),
	),
	JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE
);
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $host ) ?>" class="wf-cp-host">
<?php if ( 'button' === $trigger || 'icon' === $trigger ) : ?>
	<div class="wf-cp__triggerwrap">
		<button type="button" class="wf-cp__trigger" data-wf-cp-open="<?= esc_attr( $uid ) ?>" aria-haspopup="dialog"<?php if ( 'icon' === $trigger ) : ?> aria-label="<?= esc_attr( $btnText ) ?>"<?php endif; ?>>
			<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/></svg>
			<?php if ( 'button' === $trigger ) : ?><span><?= esc_html( $btnText ) ?></span><?php endif; ?>
			<?php if ( $showHint ) : ?><kbd class="wf-cp__kbd"><span class="wf-cp__mod">Ctrl</span><?= esc_html( $hintKey ) ?></kbd><?php endif; ?>
		</button>
	</div>
<?php endif; ?>

	<div id="<?= esc_attr( $uid ) ?>" class="wf-cp" hidden>
		<div class="wf-cp__backdrop"></div>
		<div class="wf-cp__panel" role="dialog" aria-modal="true" aria-label="<?= esc_attr( $placeholder ) ?>">
			<div class="wf-cp__field">
				<svg class="wf-cp__ico" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/></svg>
				<input type="text" class="wf-cp__input" role="combobox" aria-expanded="true" aria-controls="<?= esc_attr( $uid ) ?>-list" aria-autocomplete="list" autocomplete="off" placeholder="<?= esc_attr( $placeholder ) ?>" aria-label="<?= esc_attr( $placeholder ) ?>">
				<button type="button" class="wf-cp__esc" aria-label="Fermer">Échap</button>
			</div>
			<ul id="<?= esc_attr( $uid ) ?>-list" class="wf-cp__list" role="listbox" aria-label="<?= esc_attr( $placeholder ) ?>">
			<?php foreach ( $rows as $r ) : ?>
				<?php if ( $r['newGroup'] ) : ?>
				<li class="wf-cp__group" role="presentation"><?= esc_html( $r['group'] ) ?></li>
				<?php endif; ?>
				<li class="wf-cp__opt" role="option" id="<?= esc_attr( $r['id'] ) ?>" aria-selected="false" data-keys="<?= esc_attr( $r['keysAttr'] ) ?>" data-group="<?= esc_attr( $r['group'] ) ?>">
					<a class="wf-cp__link" href="<?= esc_url( $r['url'] ) ?>" tabindex="-1">
						<span class="wf-cp__label"><?= esc_html( $r['label'] ) ?></span>
						<?php if ( '' !== $r['group'] ) : ?><span class="wf-cp__tag"><?= esc_html( $r['group'] ) ?></span><?php endif; ?>
					</a>
				</li>
			<?php endforeach; ?>
			<?php if ( $siteSearch ) : ?>
				<li class="wf-cp__opt wf-cp__opt--search" role="option" id="<?= esc_attr( $uid ) ?>-search" aria-selected="false" hidden>
					<a class="wf-cp__link" href="<?= esc_url( $searchBase ) ?>" tabindex="-1">
						<span class="wf-cp__label"></span>
					</a>
				</li>
			<?php endif; ?>
			</ul>
			<p class="wf-cp__empty" hidden><?= esc_html( $emptyText ) ?></p>
			<div class="wf-cp__foot">
				<span><kbd>↑</kbd><kbd>↓</kbd> naviguer</span>
				<span><kbd>Entrée</kbd> ouvrir</span>
				<span><kbd>Échap</kbd> fermer</span>
			</div>
		</div>
	</div>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $host ) ?> .wf-cp__triggerwrap{display:flex;justify-content:<?= esc_attr( $just ) ?>;}
#<?= esc_attr( $host ) ?> .wf-cp__trigger{
	display:inline-flex;align-items:center;gap:.6em;min-height:44px;padding:.55em 1em;
	cursor:pointer;font:inherit;color:inherit;background:transparent;
	border:1px solid rgba(127,127,127,.45);border-radius:10px;
}
#<?= esc_attr( $host ) ?> .wf-cp__trigger:hover{border-color:<?= esc_attr( $accent ) ?>;}
#<?= esc_attr( $host ) ?> .wf-cp__kbd{
	display:inline-flex;align-items:center;gap:.25em;padding:.15em .45em;
	font:inherit;font-size:.78em;opacity:.65;
	border:1px solid rgba(127,127,127,.45);border-radius:5px;
}
#<?= esc_attr( $uid ) ?>{position:fixed;inset:0;z-index:1020;}
#<?= esc_attr( $uid ) ?> .wf-cp__backdrop{
	position:absolute;inset:0;background:rgba(0,0,0,<?= esc_attr( round( $bdOp / 100, 2 ) ) ?>);
	<?php if ( $bdBlur > 0 ) : ?>backdrop-filter:blur(<?= (int) $bdBlur ?>px);-webkit-backdrop-filter:blur(<?= (int) $bdBlur ?>px);<?php endif; ?>
}
#<?= esc_attr( $uid ) ?> .wf-cp__panel{
	position:absolute;top:<?= (int) $top ?>px;left:50%;transform:translateX(-50%);
	width:<?= (int) $width ?>px;max-width:calc(100vw - 24px);max-height:calc(100vh - <?= (int) $top ?>px - 24px);
	display:flex;flex-direction:column;overflow:hidden;
	background:<?= esc_attr( $bg ) ?>;color:<?= esc_attr( $fg ) ?>;
	border-radius:<?= (int) $radius ?>px;box-shadow:0 24px 70px rgba(0,0,0,.32);
}
#<?= esc_attr( $uid ) ?> .wf-cp__field{
	display:flex;align-items:center;gap:.7em;padding:14px 16px;
	border-bottom:1px solid rgba(127,127,127,.22);
}
#<?= esc_attr( $uid ) ?> .wf-cp__ico{flex:0 0 auto;opacity:.5;}
#<?= esc_attr( $uid ) ?> .wf-cp__input{
	flex:1 1 auto;min-width:0;min-height:32px;padding:0;font:inherit;font-size:1.05em;
	color:inherit;background:transparent;border:0;outline:none;
}
#<?= esc_attr( $uid ) ?> .wf-cp__esc{
	flex:0 0 auto;padding:.25em .6em;cursor:pointer;font:inherit;font-size:.75em;
	color:inherit;opacity:.6;background:transparent;
	border:1px solid rgba(127,127,127,.45);border-radius:6px;
}
#<?= esc_attr( $uid ) ?> .wf-cp__list{
	flex:1 1 auto;margin:0;padding:8px;list-style:none;overflow-y:auto;
	max-height:<?= (int) $maxH ?>px;
}
#<?= esc_attr( $uid ) ?> .wf-cp__group{
	padding:10px 10px 4px;font-size:.72em;font-weight:700;letter-spacing:.09em;
	text-transform:uppercase;opacity:.5;
}
#<?= esc_attr( $uid ) ?> .wf-cp__link{
	display:flex;align-items:center;justify-content:space-between;gap:1em;
	padding:10px 12px;min-height:44px;border-radius:8px;
	color:inherit;text-decoration:none;
}
#<?= esc_attr( $uid ) ?> .wf-cp__opt[aria-selected="true"] .wf-cp__link{background:<?= esc_attr( $accent ) ?>;color:#fff;}
#<?= esc_attr( $uid ) ?> .wf-cp__tag{font-size:.75em;opacity:.55;white-space:nowrap;}
#<?= esc_attr( $uid ) ?> .wf-cp__opt[aria-selected="true"] .wf-cp__tag{opacity:.85;}
#<?= esc_attr( $uid ) ?> .wf-cp__empty{margin:0;padding:24px 18px;text-align:center;opacity:.6;}
#<?= esc_attr( $uid ) ?> .wf-cp__foot{
	display:flex;flex-wrap:wrap;gap:1.2em;padding:10px 16px;font-size:.75em;opacity:.6;
	border-top:1px solid rgba(127,127,127,.22);
}
#<?= esc_attr( $uid ) ?> .wf-cp__foot kbd{
	display:inline-block;margin-right:.3em;padding:.1em .4em;font:inherit;font-size:.95em;
	border:1px solid rgba(127,127,127,.45);border-radius:4px;
}
@media (max-width:520px){
	#<?= esc_attr( $uid ) ?> .wf-cp__foot{display:none;}
	#<?= esc_attr( $host ) ?> .wf-cp__kbd{display:none;}
}
</style>
<script>
(function(){
	function boot(){
		var c = <?= $cfg ?>;
		var root = document.getElementById(c.uid);
		if(!root){return;}
		if(root.getAttribute('data-wf-ready')){return;}
		root.setAttribute('data-wf-ready','1');

		if(root.parentNode !== document.body){document.body.appendChild(root);}

		var panel = root.querySelector('.wf-cp__panel');
		var input = root.querySelector('.wf-cp__input');
		var list  = root.querySelector('.wf-cp__list');
		var empty = root.querySelector('.wf-cp__empty');
		var back  = root.querySelector('.wf-cp__backdrop');
		var srch  = root.querySelector('.wf-cp__opt--search');
		var opts  = Array.prototype.slice.call(root.querySelectorAll('.wf-cp__opt'));
		var groups = Array.prototype.slice.call(root.querySelectorAll('.wf-cp__group'));
		var release = null;
		var cur = -1;

		function flat(s){
			return String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
		}

		function readRecents(){
			if(c.recents < 1){return [];}
			try{
				var v = window.localStorage.getItem(c.store);
				if(!v){return [];}
				return JSON.parse(v);
			}catch(e){return [];}
		}

		function pushRecent(id){
			if(c.recents < 1){return;}
			try{
				var r = readRecents().filter(function(x){ return x !== id; });
				r.unshift(id);
				window.localStorage.setItem(c.store, JSON.stringify(r.slice(0, c.recents)));
			}catch(e){}
		}

		function visible(){
			return opts.filter(function(o){ return !o.hidden; });
		}

		function select(n){
			var v = visible();
			if(!v.length){ cur = -1; input.removeAttribute('aria-activedescendant'); return; }
			if(n < 0){ n = v.length - 1; }
			if(n >= v.length){ n = 0; }
			cur = n;
			var i = 0;
			while(i < opts.length){ opts[i].setAttribute('aria-selected','false'); i++; }
			v[n].setAttribute('aria-selected','true');
			input.setAttribute('aria-activedescendant', v[n].id);
			v[n].scrollIntoView({block:'nearest'});
		}

		function filter(){
			var q = flat(input.value.trim());
			var shown = 0;
			var rec = q === '' ? readRecents() : [];
			var i = 0;
			while(i < opts.length){
				var o = opts[i];
				if(o === srch){ i++; continue; }
				var hit = true;
				if(q !== ''){ hit = flat(o.getAttribute('data-keys')).indexOf(q) !== -1; }
				if(q === ''){
					if(rec.length > 0){ hit = rec.indexOf(o.id) !== -1; }
				}
				o.hidden = !hit;
				if(hit){ shown++; }
				i++;
			}
			// Les intertitres n'ont de sens que si leur groupe a survécu au filtre.
			var g = 0;
			while(g < groups.length){
				var name = groups[g].textContent.trim();
				var alive = opts.some(function(o){
					if(o.hidden){return false;}
					return o.getAttribute('data-group') === name;
				});
				groups[g].hidden = !alive;
				g++;
			}
			if(srch){
				if(q === ''){ srch.hidden = true; }
				else {
					srch.hidden = false;
					var lbl = c.searchLb.replace('%s', input.value.trim());
					srch.querySelector('.wf-cp__label').textContent = lbl;
					srch.querySelector('.wf-cp__link').setAttribute(
						'href', c.base + '?s=' + encodeURIComponent(input.value.trim())
					);
					shown++;
				}
			}
			if(empty){ empty.hidden = shown !== 0; }
			select(0);
		}

		function open(){
			if(!root.hidden){return;}
			root.hidden = false;
			input.value = '';
			filter();
			if(WF.lockScroll){WF.lockScroll();}
			if(WF.trapFocus){release = WF.trapFocus(panel);}
			input.focus();
		}

		function close(){
			if(root.hidden){return;}
			root.hidden = true;
			if(WF.unlockScroll){WF.unlockScroll();}
			if(release){release();release = null;}
		}

		function triggers(){
			var out = [];
			function push(l){var i=0;while(i<l.length){out.push(l[i]);i++;}}
			push(document.querySelectorAll('[data-wf-cp-open="' + c.uid + '"]'));
			if(c.sel){try{push(document.querySelectorAll(c.sel));}catch(e){}}
			return out;
		}
		var t = triggers();
		var ti = 0;
		while(ti < t.length){
			t[ti].addEventListener('click', function(e){ e.preventDefault(); open(); });
			ti++;
		}

		var esc = root.querySelector('.wf-cp__esc');
		if(esc){esc.addEventListener('click', close);}
		if(back){back.addEventListener('click', close);}

		input.addEventListener('input', filter);

		root.addEventListener('keydown', function(e){
			if(e.key === 'Escape'){ e.preventDefault(); close(); return; }
			if(e.key === 'ArrowDown'){ e.preventDefault(); select(cur + 1); return; }
			if(e.key === 'ArrowUp'){ e.preventDefault(); select(cur - 1); return; }
			if(e.key === 'Home'){ e.preventDefault(); select(0); return; }
			if(e.key === 'End'){ e.preventDefault(); select(visible().length - 1); return; }
			if(e.key === 'Enter'){
				var v = visible();
				if(cur < 0){return;}
				if(cur >= v.length){return;}
				e.preventDefault();
				var a = v[cur].querySelector('.wf-cp__link');
				if(!a){return;}
				pushRecent(v[cur].id);
				a.click();
			}
		});

		var li = 0;
		while(li < opts.length){
			(function(o){
				o.addEventListener('click', function(){ pushRecent(o.id); });
				o.addEventListener('mousemove', function(){
					var v = visible();
					var n = v.indexOf(o);
					if(n === -1){return;}
					if(n === cur){return;}
					select(n);
				});
			}(opts[li]));
			li++;
		}

		if(c.shortcut){
			document.addEventListener('keydown', function(e){
				if(!e.key){return;}
				if(e.key.toLowerCase() !== c.key){return;}
				var mod = e.metaKey;
				if(!mod){ mod = e.ctrlKey; }
				if(!mod){return;}
				e.preventDefault();
				if(root.hidden){ open(); return; }
				close();
			});
		}
	}
	WF.ready(boot);
}());
</script>
