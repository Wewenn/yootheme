<?php
defined( 'ABSPATH' ) || exit; // Data-only, rendered by parent
