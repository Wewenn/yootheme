<?php
/**
 * WeFrame – Bouton de partage | template.php v1.0
 *
 * Un bouton qui se déploie en icônes de réseaux. Les liens sont écrits côté
 * serveur : ce sont de vrais liens, ils fonctionnent sans JavaScript et sans
 * appeler le moindre script tiers — donc aucun traceur ajouté à la page.
 *
 * « Copier le lien » est la seule entrée qui a besoin de JavaScript ; elle n'est
 * affichée que si le navigateur sait le faire.
 *
 * Pas de "&&" ni de "||" dans le JS inline (règle interne du plugin).
 */

defined( 'ABSPATH' ) || exit;

$label = trim( (string) ( $props['label'] ?? '' ) );
if ( '' === $label ) { $label = 'Partager'; }

$url = trim( (string) ( $props['share_url'] ?? '' ) );
if ( '' === $url ) {
	$url = is_singular() ? get_permalink() : home_url( add_query_arg( array(), $GLOBALS['wp']->request ?? '' ) );
}
$url = (string) $url;

$title = trim( (string) ( $props['share_title'] ?? '' ) );
if ( '' === $title ) { $title = wp_get_document_title(); }

$eUrl   = rawurlencode( $url );
$eTitle = rawurlencode( $title );

$brand = ! empty( $props['brand_colors'] );

// Chaque réseau : son icône, sa couleur de marque, et l'adresse de partage.
$catalog = array(
	'facebook' => array(
		'name'  => 'Facebook',
		'color' => '#1877F2',
		'href'  => 'https://www.facebook.com/sharer/sharer.php?u=' . $eUrl,
		'path'  => '<path d="M14 9h2.4V6.2h-2.6c-2.4 0-3.8 1.4-3.8 3.9V12H8v2.9h2v7.1h3v-7.1h2.3l.4-2.9H13v-1.7c0-.9.3-1.3 1-1.3Z"/>',
	),
	'x' => array(
		'name'  => 'X',
		'color' => '#000000',
		'href'  => 'https://twitter.com/intent/tweet?url=' . $eUrl . '&text=' . $eTitle,
		'path'  => '<path d="M17.5 3h3.1l-6.8 7.7 8 10.3h-6.3l-4.9-6.4-5.6 6.4H1.9l7.3-8.3L1.5 3h6.4l4.4 5.9L17.5 3Zm-1.1 16.1h1.7L7.7 4.8H5.9l10.5 14.3Z"/>',
	),
	'linkedin' => array(
		'name'  => 'LinkedIn',
		'color' => '#0A66C2',
		'href'  => 'https://www.linkedin.com/sharing/share-offsite/?url=' . $eUrl,
		'path'  => '<path d="M6.9 8.5H4V20h2.9V8.5Zm.2-3.1a1.7 1.7 0 1 0-3.4 0 1.7 1.7 0 0 0 3.4 0ZM20 13.6c0-3-1.6-4.4-3.7-4.4-1.7 0-2.5.9-2.9 1.6V8.5h-2.9V20h2.9v-6.3c0-1.3.6-2.1 1.7-2.1s1.6.8 1.6 2.1V20H20v-6.4Z"/>',
	),
	'whatsapp' => array(
		'name'  => 'WhatsApp',
		'color' => '#25D366',
		'href'  => 'https://api.whatsapp.com/send?text=' . $eTitle . '%20' . $eUrl,
		'path'  => '<path d="M12 3a9 9 0 0 0-7.7 13.6L3 21l4.6-1.2A9 9 0 1 0 12 3Zm0 16.4a7.4 7.4 0 0 1-3.8-1l-.3-.2-2.7.7.7-2.7-.2-.3A7.4 7.4 0 1 1 12 19.4Zm4.1-5.4c-.2-.1-1.3-.7-1.5-.8s-.4-.1-.5.1-.6.8-.7.9-.3.2-.5 0a6 6 0 0 1-1.8-1.1 6.7 6.7 0 0 1-1.2-1.6c-.1-.2 0-.3.1-.4l.4-.4.2-.4v-.4l-.7-1.7c-.2-.4-.4-.4-.5-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.7 11.8 11.8 0 0 0 4.5 4 5.3 5.3 0 0 0 2.4.5 2.7 2.7 0 0 0 1.8-1.2 2.2 2.2 0 0 0 .2-1.2c-.1-.1-.3-.2-.5-.3Z"/>',
	),
	'telegram' => array(
		'name'  => 'Telegram',
		'color' => '#26A5E4',
		'href'  => 'https://t.me/share/url?url=' . $eUrl . '&text=' . $eTitle,
		'path'  => '<path d="M21.2 4.3 2.9 11.4c-.9.4-.9 1 0 1.2l4.6 1.4 1.8 5.4c.2.6.4.6.9.2l2.5-2.1 4.7 3.5c.9.5 1.4.2 1.6-.8l2.9-13.6c.2-1-.4-1.5-1.7-.9ZM9.6 14.2l8.4-5.3c.4-.2.8-.1.5.2l-7.2 6.5-.3 3-1.4-4.4Z"/>',
	),
	'email' => array(
		'name'  => 'E-mail',
		'color' => '#6b7280',
		'href'  => 'mailto:?subject=' . $eTitle . '&body=' . $eUrl,
		'path'  => '<path d="M4 5h16a1.5 1.5 0 0 1 1.5 1.5v11A1.5 1.5 0 0 1 20 19H4a1.5 1.5 0 0 1-1.5-1.5v-11A1.5 1.5 0 0 1 4 5Zm.9 2 7.1 5 7.1-5H4.9ZM20 17V8.6l-7.5 5.3a1 1 0 0 1-1 0L4 8.6V17h16Z"/>',
	),
);

$nets = array();
foreach ( $catalog as $key => $def ) {
	if ( empty( $props[ 'net_' . $key ] ) ) { continue; }
	$nets[] = array(
		'key'   => $key,
		'name'  => $def['name'],
		'href'  => $def['href'],
		'path'  => $def['path'],
		'color' => $def['color'],
	);
}

$copy = ! empty( $props['net_copy'] );
$copiedText = trim( (string) ( $props['copied_text'] ?? '' ) );
if ( '' === $copiedText ) { $copiedText = 'Lien copié'; }

if ( empty( $nets ) && ! $copy ) { return; }

$openOn = (string) ( $props['open_on'] ?? 'hover' );
if ( ! in_array( $openOn, array( 'hover', 'click' ), true ) ) { $openOn = 'hover'; }

$dir = (string) ( $props['direction'] ?? 'right' );
if ( ! in_array( $dir, array( 'right', 'left', 'up', 'down' ), true ) ) { $dir = 'right'; }

$btnBg  = (string) ( $props['btn_bg'] ?? '#111111' );
$btnCol = (string) ( $props['btn_color'] ?? '#ffffff' );
$icoBg  = (string) ( $props['icon_bg'] ?? '#f1f1f1' );
$icoCol = (string) ( $props['icon_color'] ?? '#111111' );

$size    = max( 32, min( 72, (int) ( $props['size'] ?? 42 ) ) );
$gap     = max( 0, min( 24, (int) ( $props['gap'] ?? 8 ) ) );
$radius  = max( 0, min( 40, (int) ( $props['radius'] ?? 100 ) ) );
$stagger = max( 0, min( 160, (int) ( $props['stagger'] ?? 45 ) ) );

$align = (string) ( $props['align'] ?? 'left' );
$just  = 'flex-start';
if ( 'center' === $align ) { $just = 'center'; }
if ( 'right' === $align ) { $just = 'flex-end'; }

$vertical = in_array( $dir, array( 'up', 'down' ), true );
$flexDir  = 'row';
if ( 'left' === $dir ) { $flexDir = 'row-reverse'; }
if ( 'up' === $dir ) { $flexDir = 'column-reverse'; }
if ( 'down' === $dir ) { $flexDir = 'column'; }

// Sens du glissement à l'ouverture : les icônes viennent de sous le bouton.
$hiddenT = 'translateX(-14px)';
if ( 'left' === $dir ) { $hiddenT = 'translateX(14px)'; }
if ( 'up' === $dir ) { $hiddenT = 'translateY(14px)'; }
if ( 'down' === $dir ) { $hiddenT = 'translateY(-14px)'; }

$copyDelay = count( $nets ) * $stagger;
$icoBgCss  = $brand ? 'var(--b,' . $icoBg . ')' : $icoBg;
$icoColCss = $brand ? '#fff' : $icoCol;

$uid = wf_uid( 'wfsh_', $props, $url );

$cfg = wp_json_encode(
	array(
		'uid'    => $uid,
		'click'  => ( 'click' === $openOn ),
		'copy'   => $copy,
		'url'    => $url,
		'copied' => $copiedText,
	),
	JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE
);
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div class="wf-sh-wrap" style="display:flex;justify-content:<?= esc_attr( $just ) ?>;">
	<div id="<?= esc_attr( $uid ) ?>" class="wf-sh wf-sh--<?= esc_attr( $dir ) ?>">
		<button type="button" class="wf-sh__btn" aria-expanded="false" aria-controls="<?= esc_attr( $uid ) ?>-list">
			<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="18" cy="5" r="2.6"/><circle cx="6" cy="12" r="2.6"/><circle cx="18" cy="19" r="2.6"/><path d="M8.3 10.8 15.7 6.4M8.3 13.2l7.4 4.4"/></svg>
			<span><?= esc_html( $label ) ?></span>
		</button>
		<ul id="<?= esc_attr( $uid ) ?>-list" class="wf-sh__list">
		<?php foreach ( $nets as $n => $net ) : ?>
			<li class="wf-sh__i" style="--d:<?= (int) ( $n * $stagger ) ?>ms;<?php if ( $brand ) : ?>--b:<?= esc_attr( $net['color'] ) ?>;<?php endif; ?>">
				<a class="wf-sh__lnk" href="<?= esc_url( $net['href'] ) ?>" target="_blank" rel="noopener noreferrer" title="<?= esc_attr( $net['name'] ) ?>">
					<span class="wf-sh__sr">Partager sur <?= esc_html( $net['name'] ) ?></span>
					<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><?= $net['path'] ?></svg>
				</a>
			</li>
		<?php endforeach; ?>
		<?php if ( $copy ) : ?>
			<li class="wf-sh__i wf-sh__i--copy" style="--d:<?= (int) $copyDelay ?>ms;" hidden>
				<button type="button" class="wf-sh__lnk wf-sh__copy" title="Copier le lien">
					<span class="wf-sh__sr">Copier le lien</span>
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a1 1 0 0 1 1-1h9"/></svg>
				</button>
			</li>
		<?php endif; ?>
		</ul>
		<p class="wf-sh__flash" role="status" aria-live="polite"></p>
	</div>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?>{
	display:inline-flex;align-items:center;gap:<?= (int) $gap ?>px;
	flex-direction:<?= esc_attr( $flexDir ) ?>;position:relative;
}
#<?= esc_attr( $uid ) ?> .wf-sh__btn{
	display:inline-flex;align-items:center;gap:.55em;flex:0 0 auto;
	min-height:44px;padding:0 1.1em;cursor:pointer;font:inherit;font-weight:600;
	color:<?= esc_attr( $btnCol ) ?>;background:<?= esc_attr( $btnBg ) ?>;
	border:0;border-radius:<?= (int) $radius ?>px;
}
#<?= esc_attr( $uid ) ?> .wf-sh__list{
	display:flex;align-items:center;gap:<?= (int) $gap ?>px;
	flex-direction:<?= esc_attr( $flexDir ) ?>;
	margin:0;padding:0;list-style:none;
}
#<?= esc_attr( $uid ) ?> .wf-sh__i{
	opacity:0;transform:<?= esc_attr( $hiddenT ) ?> scale(.8);
	transition:opacity .26s ease,transform .26s cubic-bezier(.2,.8,.2,1);
	transition-delay:0ms;
	<?php if ( $vertical ) : ?>height:0;<?php else : ?>width:0;<?php endif; ?>
	pointer-events:none;
}
#<?= esc_attr( $uid ) ?>.is-open .wf-sh__i{
	opacity:1;transform:none;pointer-events:auto;transition-delay:var(--d,0ms);
	<?php if ( $vertical ) : ?>height:<?= (int) $size ?>px;<?php else : ?>width:<?= (int) $size ?>px;<?php endif; ?>
}
#<?= esc_attr( $uid ) ?> .wf-sh__lnk{
	display:flex;align-items:center;justify-content:center;
	width:<?= (int) $size ?>px;height:<?= (int) $size ?>px;
	border:0;border-radius:<?= (int) $radius ?>px;cursor:pointer;
	background:<?= esc_attr( $icoBgCss ) ?>;
	color:<?= esc_attr( $icoColCss ) ?>;
	text-decoration:none;transition:transform .18s ease;
}
#<?= esc_attr( $uid ) ?> .wf-sh__i--copy .wf-sh__lnk{background:<?= esc_attr( $icoBg ) ?>;color:<?= esc_attr( $icoCol ) ?>;}
#<?= esc_attr( $uid ) ?> .wf-sh__lnk:hover{transform:scale(1.1);}
#<?= esc_attr( $uid ) ?> .wf-sh__lnk svg{width:<?= (int) round( $size * 0.48 ) ?>px;height:<?= (int) round( $size * 0.48 ) ?>px;}
#<?= esc_attr( $uid ) ?> .wf-sh__sr{
	position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;
	clip-path:inset(50%);white-space:nowrap;border:0;
}
#<?= esc_attr( $uid ) ?> .wf-sh__flash{
	position:absolute;left:50%;bottom:calc(100% + 8px);transform:translateX(-50%);
	margin:0;padding:.3em .7em;white-space:nowrap;font-size:.8em;
	color:#fff;background:#111;border-radius:6px;opacity:0;pointer-events:none;
	transition:opacity .2s ease;
}
#<?= esc_attr( $uid ) ?> .wf-sh__flash.is-on{opacity:1;}
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?> .wf-sh__i{transition:none;}
}
</style>
<script>
(function(){
	function boot(){
		var c = <?= $cfg ?>;
		var root = document.getElementById(c.uid);
		if(!root){return;}
		if(root.getAttribute('data-wf-ready')){return;}
		root.setAttribute('data-wf-ready','1');

		var btn = root.querySelector('.wf-sh__btn');
		var flash = root.querySelector('.wf-sh__flash');

		function open(){
			root.classList.add('is-open');
			btn.setAttribute('aria-expanded','true');
		}
		function close(){
			root.classList.remove('is-open');
			btn.setAttribute('aria-expanded','false');
		}
		function toggle(){
			if(root.classList.contains('is-open')){close();return;}
			open();
		}

		btn.addEventListener('click', toggle);

		if(!c.click){
			root.addEventListener('mouseenter', open);
			root.addEventListener('mouseleave', close);
			// Le clavier doit voir la même chose que la souris.
			root.addEventListener('focusin', open);
			root.addEventListener('focusout', function(e){
				if(root.contains(e.relatedTarget)){return;}
				close();
			});
		}

		document.addEventListener('click', function(e){
			if(root.contains(e.target)){return;}
			close();
		});

		if(!c.copy){return;}
		var li = root.querySelector('.wf-sh__i--copy');
		if(!li){return;}
		// Affiché seulement si le navigateur sait copier : sinon le bouton
		// serait là sans rien faire.
		if(!navigator.clipboard){return;}
		li.hidden = false;
		li.querySelector('.wf-sh__copy').addEventListener('click', function(){
			navigator.clipboard.writeText(c.url).then(function(){
				flash.textContent = c.copied;
				flash.classList.add('is-on');
				window.setTimeout(function(){
					flash.classList.remove('is-on');
					flash.textContent = '';
				}, 1800);
			});
		});
	}
	WF.ready(boot);
}());
</script>
