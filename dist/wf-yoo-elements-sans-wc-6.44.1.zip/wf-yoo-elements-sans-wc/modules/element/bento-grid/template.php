<?php
defined('ABSPATH') || exit;
if (empty($children)) return;
$cols = (int)($props['columns']??4); $gap = (int)($props['gap']??16); $gm = (int)($props['gap_mobile']??12);
$mrh = (int)($props['min_row_height']??200);
$anim = !empty($props['animate']); $lift = !empty($props['hover_lift']);
$bgimg = $props['bg_image']??'';
if ($bgimg) { if (!preg_match('#^https?://#i',$bgimg)) $bgimg='/'.ltrim($bgimg,'/'); }
$uid = 'wfbn_'.substr(md5(serialize($props).count($children)),0,8);
$html = '';
foreach ($children as $i => $child) { $html .= $builder->render($child, ['element'=>$props, 'index'=>$i]); }
if (!trim($html)) return;
$bgcss = $bgimg ? "background:url('".esc_url($bgimg)."') center/cover no-repeat;" : '';
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr($uid) ?>" style="<?= $bgcss ?>display:grid;grid-template-columns:repeat(<?= $cols ?>,1fr);gap:<?= $gap ?>px;grid-auto-rows:minmax(<?= $mrh ?>px,auto);">
<?= $html ?>
</div>
<style>
@media(max-width:767px){#<?= esc_attr($uid) ?>{grid-template-columns:1fr !important;gap:<?= $gm ?>px !important}}
<?php if ($anim) : ?>
#<?= esc_attr($uid) ?> > div{opacity:0;transform:translateY(24px);transition:opacity .5s ease,transform .5s ease}
#<?= esc_attr($uid) ?> > div.wf-bn--vis{opacity:1;transform:translateY(0)}
<?php endif; ?>
<?php if ($lift) : ?>
#<?= esc_attr($uid) ?> > div{transition:transform .3s ease,box-shadow .3s ease,opacity .5s ease}
#<?= esc_attr($uid) ?> > div:hover{transform:translateY(-4px);box-shadow:0 12px 32px rgba(0,0,0,.12)}
<?php endif; ?>
</style>
<?php if ($anim) : ?>
<script>
(function(){
    function boot(){
        var el=document.getElementById('<?= esc_attr($uid) ?>');if(!el)return;
        var cells=el.children;
        if('IntersectionObserver' in window){
            var obs=new IntersectionObserver(function(es){var i=0;while(i<es.length){if(es[i].isIntersecting){es[i].target.classList.add('wf-bn--vis');obs.unobserve(es[i].target)}i++}},{threshold:0.1});
            var j=0;while(j<cells.length){
                cells[j].style.transitionDelay=(j*80)+'ms';
                obs.observe(cells[j]);j++}
        }else{var k=0;while(k<cells.length){cells[k].classList.add('wf-bn--vis');k++}}
    }
    WF.ready(boot)
})();
</script>
<?php endif; ?>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
