<?php
/**
 * WeFrame – Avis Google (Places API) | note globale + derniers avis.
 * Utilise le fetcher partagé wf_google_reviews_fetch() (cache transient + filtre).
 * Clé API : champ, ou constante WF_GOOGLE_PLACES_KEY (recommandé) dans wp-config.php.
 */
defined( 'ABSPATH' ) || exit;
$on_accent = $props['on_accent'] ?? '#ffffff';

if ( ! function_exists( 'wf_gr_stars' ) ) {
    function wf_gr_stars( $rating, $color, $size = 16 ) {
        $rating = (float) $rating;
        $out = '<span class="wf-gr-stars" aria-label="' . esc_attr( round( $rating, 1 ) ) . ' / 5">';
        for ( $i = 1; $i <= 5; $i++ ) {
            $fill = ( $rating >= $i - 0.25 ) ? $color : 'rgba(0,0,0,.14)';
            $out .= '<svg width="' . (int) $size . '" height="' . (int) $size . '" viewBox="0 0 24 24" fill="' . esc_attr( $fill ) . '" style="flex:0 0 auto;"><path d="M12 2l2.9 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l7.1-1.01L12 2z"/></svg>';
        }
        return $out . '</span>';
    }
}

$key     = defined( 'WF_GOOGLE_PLACES_KEY' ) ? WF_GOOGLE_PLACES_KEY : trim( (string) ( $props['api_key'] ?? '' ) );
$place   = trim( (string) ( $props['place_id'] ?? '' ) );
$canEdit = function_exists( 'current_user_can' ) && current_user_can( 'edit_posts' );

if ( '' === $place || '' === $key ) {
    if ( $canEdit ) { echo '<div style="padding:14px 16px;border:1px dashed #bbb;border-radius:10px;color:#666;font-size:14px;">Avis Google : renseignez le <b>Place ID</b> et la <b>clé API</b> (ou la constante WF_GOOGLE_PLACES_KEY).</div>'; }
    return;
}

$max       = min( 5, max( 1, (int) ( $props['max_reviews'] ?? 5 ) ) );
$minRating = min( 5, max( 1, (int) ( $props['min_rating'] ?? 4 ) ) );
$cols      = min( 4, max( 1, (int) ( $props['columns'] ?? 3 ) ) );
$photos    = ! empty( $props['show_photos'] );
$header    = ! empty( $props['show_header'] );
$cacheH    = min( 168, max( 1, (int) ( $props['cache_hours'] ?? 12 ) ) );
$title     = trim( (string) ( $props['title'] ?? '' ) );
$revUrl    = trim( (string) ( $props['review_url'] ?? '' ) );

$cardBg = $props['card_bg']     ?? '#ffffff';
$txt    = $props['text_color']  ?? '#1a1a1a';
$muted  = $props['muted_color'] ?? '#6b7280';
$star   = $props['star_color']  ?? '#fbbc04';
$accent = $props['accent']      ?? '#1a73e8';

$data = function_exists( 'wf_google_reviews_fetch' )
    ? wf_google_reviews_fetch( $key, $place, array( 'lang' => 'fr', 'min_rating' => $minRating, 'max' => $max, 'cache_hours' => $cacheH ) )
    : null;

if ( ! is_array( $data ) ) {
    if ( $canEdit ) { echo '<div style="padding:14px 16px;border:1px dashed #d33;border-radius:10px;color:#a00;font-size:14px;">Avis Google : réponse API vide ou en erreur (vérifiez le Place ID, la clé et l\'activation de « Places API »).</div>'; }
    return;
}

$avg     = (float) ( $data['rating'] ?? 0 );
$total   = (int) ( $data['total'] ?? 0 );
$reviews = isset( $data['reviews'] ) && is_array( $data['reviews'] ) ? $data['reviews'] : array();
if ( empty( $reviews ) && ! $header ) { return; }

$uid = 'wfgr_' . substr( md5( serialize( array( $place, $props ) ) ), 0, 8 );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-gr">
    <?php if ( $header ) : ?>
    <div class="wf-gr-head">
        <span class="wf-gr-g" aria-hidden="true">
            <svg width="26" height="26" viewBox="0 0 48 48"><path fill="#4285F4" d="M45.12 24.5c0-1.56-.14-3.06-.4-4.5H24v8.51h11.84c-.51 2.75-2.06 5.08-4.39 6.64v5.52h7.11c4.16-3.83 6.56-9.47 6.56-16.17z"/><path fill="#34A853" d="M24 46c5.94 0 10.92-1.97 14.56-5.33l-7.11-5.52c-1.97 1.32-4.49 2.1-7.45 2.1-5.73 0-10.58-3.87-12.31-9.07H4.34v5.7C7.96 41.07 15.4 46 24 46z"/><path fill="#FBBC05" d="M11.69 28.18C11.25 26.86 11 25.45 11 24s.25-2.86.69-4.18v-5.7H4.34C2.85 17.09 2 20.45 2 24s.85 6.91 2.34 9.88l7.35-5.7z"/><path fill="#EA4335" d="M24 10.75c3.23 0 6.13 1.11 8.41 3.29l6.31-6.31C34.91 4.18 29.93 2 24 2 15.4 2 7.96 6.93 4.34 14.12l7.35 5.7c1.73-5.2 6.58-9.07 12.31-9.07z"/></svg>
        </span>
        <div class="wf-gr-head-txt">
            <?php if ( '' !== $title ) : ?><div class="wf-gr-title"><?= esc_html( $title ) ?></div><?php endif; ?>
            <div class="wf-gr-rate">
                <b class="wf-gr-avg"><?= esc_html( number_format_i18n( $avg, 1 ) ) ?></b>
                <?= wf_gr_stars( $avg, $star, 18 ) ?>
                <span class="wf-gr-count"><?= esc_html( $total ) ?> avis Google</span>
            </div>
        </div>
        <?php if ( '' !== $revUrl ) : ?>
        <a class="wf-gr-btn" href="<?= esc_url( $revUrl ) ?>" target="_blank" rel="noopener nofollow">Laisser un avis</a>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php if ( ! empty( $reviews ) ) : ?>
    <div class="wf-gr-grid">
        <?php foreach ( $reviews as $r ) :
            $an   = esc_html( '' !== trim( (string) ( $r['name'] ?? '' ) ) ? $r['name'] : 'Client' );
            $rt   = (float) ( $r['rating'] ?? 5 );
            $when = esc_html( $r['relative'] ?? '' );
            $text = trim( (string) ( $r['content'] ?? '' ) );
            if ( function_exists( 'mb_strlen' ) && mb_strlen( $text ) > 260 ) { $text = mb_substr( $text, 0, 258 ) . '…'; }
            $photo = $photos ? trim( (string) ( $r['avatar'] ?? '' ) ) : '';
            $aurl  = trim( (string) ( $r['review_url'] ?? '' ) );
            ?>
        <div class="wf-gr-card">
            <div class="wf-gr-card-top">
                <?php if ( '' !== $photo ) : ?><img class="wf-gr-photo" src="<?= esc_url( $photo ) ?>" alt="" loading="lazy" referrerpolicy="no-referrer"><?php else : ?><span class="wf-gr-photo wf-gr-photo-ph"><?= esc_html( function_exists( 'mb_substr' ) ? mb_substr( wp_strip_all_tags( $an ), 0, 1 ) : substr( $an, 0, 1 ) ) ?></span><?php endif; ?>
                <div>
                    <div class="wf-gr-author"><?php if ( '' !== $aurl ) : ?><a href="<?= esc_url( $aurl ) ?>" target="_blank" rel="noopener nofollow"><?= $an ?></a><?php else : ?><?= $an ?><?php endif; ?></div>
                    <div class="wf-gr-when"><?= $when ?></div>
                </div>
            </div>
            <?= wf_gr_stars( $rt, $star, 15 ) ?>
            <?php if ( '' !== $text ) : ?><p class="wf-gr-text"><?= nl2br( esc_html( $text ) ) ?></p><?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>
<style>
#<?= esc_attr( $uid ) ?>{--gr-card:<?= esc_attr( $cardBg ) ?>;--gr-txt:<?= esc_attr( $txt ) ?>;--gr-muted:<?= esc_attr( $muted ) ?>;--gr-accent:<?= esc_attr( $accent ) ?>;color:var(--gr-txt);}
#<?= esc_attr( $uid ) ?> .wf-gr-head{display:flex;align-items:center;gap:16px;flex-wrap:wrap;margin-bottom:22px;}
#<?= esc_attr( $uid ) ?> .wf-gr-g{flex:0 0 auto;}
#<?= esc_attr( $uid ) ?> .wf-gr-head-txt{flex:1;min-width:180px;}
#<?= esc_attr( $uid ) ?> .wf-gr-title{font-size:20px;font-weight:700;margin-bottom:4px;}
#<?= esc_attr( $uid ) ?> .wf-gr-rate{display:flex;align-items:center;gap:8px;flex-wrap:wrap;}
#<?= esc_attr( $uid ) ?> .wf-gr-avg{font-size:20px;}
#<?= esc_attr( $uid ) ?> .wf-gr-stars{display:inline-flex;gap:1px;}
#<?= esc_attr( $uid ) ?> .wf-gr-count{color:var(--gr-muted);font-size:14px;}
#<?= esc_attr( $uid ) ?> .wf-gr-btn{margin-left:auto;padding:10px 18px;background:var(--gr-accent);color:<?= esc_attr( $on_accent ) ?>;border-radius:8px;text-decoration:none;font-weight:600;font-size:14px;}
#<?= esc_attr( $uid ) ?> .wf-gr-btn:hover{opacity:.9;}
#<?= esc_attr( $uid ) ?> .wf-gr-grid{display:grid;grid-template-columns:repeat(<?= $cols ?>,1fr);gap:16px;}
#<?= esc_attr( $uid ) ?> .wf-gr-card{background:var(--gr-card);border:1px solid rgba(0,0,0,.08);border-radius:14px;padding:18px;box-shadow:0 4px 14px rgba(0,0,0,.05);display:flex;flex-direction:column;gap:10px;}
#<?= esc_attr( $uid ) ?> .wf-gr-card-top{display:flex;align-items:center;gap:12px;}
#<?= esc_attr( $uid ) ?> .wf-gr-photo{width:44px;height:44px;border-radius:50%;object-fit:cover;flex:0 0 auto;}
#<?= esc_attr( $uid ) ?> .wf-gr-photo-ph{display:flex;align-items:center;justify-content:center;background:var(--gr-accent);color:<?= esc_attr( $on_accent ) ?>;font-weight:700;font-size:18px;}
#<?= esc_attr( $uid ) ?> .wf-gr-author{font-weight:600;font-size:15px;}
#<?= esc_attr( $uid ) ?> .wf-gr-author a{color:inherit;text-decoration:none;}
#<?= esc_attr( $uid ) ?> .wf-gr-when{color:var(--gr-muted);font-size:13px;}
#<?= esc_attr( $uid ) ?> .wf-gr-text{margin:0;font-size:14px;line-height:1.55;color:var(--gr-txt);}
@media(max-width:900px){#<?= esc_attr( $uid ) ?> .wf-gr-grid{grid-template-columns:repeat(<?= min( 2, $cols ) ?>,1fr);}}
@media(max-width:560px){#<?= esc_attr( $uid ) ?> .wf-gr-grid{grid-template-columns:1fr;}#<?= esc_attr( $uid ) ?> .wf-gr-btn{margin-left:0;}}
</style>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
