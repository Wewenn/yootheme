<?php
/**
 * WeFrame – Texte qui s'assemble | template.php v1.0
 * Les mots partent dispersés puis se rangent : soit progressivement au defilement
 * (section epinglee facultative), soit d'un trait quand la section apparait.
 *
 * La dispersion est tiree cote serveur a partir d'une graine : le rendu est
 * identique a chaque chargement et entre le cache et la page. Le texte est dans
 * le DOM en clair, a sa place finale : lisible sans JS et indexable.
 * Pas de "&&" ni de "||" dans le JS inline (regle interne du plugin).
 */
defined( 'ABSPATH' ) || exit;

$text = trim( (string) ( $props['text'] ?? '' ) );
if ( '' === $text ) { return; }

$tag = (string) ( $props['tag'] ?? 'h2' );
if ( ! in_array( $tag, array( 'p', 'h2', 'h3', 'div' ), true ) ) { $tag = 'h2'; }

$trigger = ( 'view' === ( $props['trigger'] ?? 'scroll' ) ) ? 'view' : 'scroll';
$pin     = ( 'scroll' === $trigger ) && ! empty( $props['pin'] );
$pinTop  = max( 0, (int) ( $props['pin_offset'] ?? 100 ) );
$dwell   = max( 60, min( 400, (int) ( $props['dwell'] ?? 160 ) ) );

$spreadX = max( 0, (int) ( $props['spread'] ?? 220 ) );
$spreadY = max( 0, (int) ( $props['spread_y'] ?? 120 ) );
$rotMax  = max( 0, min( 90, (int) ( $props['rotate_max'] ?? 14 ) ) );
$scaleF  = max( 0.2, min( 3, (float) ( $props['scale_from'] ?? 1.4 ) ) );
$blurF   = max( 0, (int) ( $props['blur_from'] ?? 3 ) );
$opF     = max( 0, min( 1, (float) ( $props['opacity_from'] ?? 0 ) ) );

$order = (string) ( $props['order'] ?? 'random' );
if ( ! in_array( $order, array( 'random', 'ltr', 'center', 'none' ), true ) ) { $order = 'random'; }
$stag  = max( 0, (int) ( $props['stagger'] ?? 45 ) );
$dur   = max( 100, (int) ( $props['duration'] ?? 900 ) );

$fs    = max( 12, (int) ( $props['font_size'] ?? 46 ) );
$fsMin = max( 10, (int) ( $props['font_size_min'] ?? 24 ) );
if ( $fsMin > $fs ) { $fsMin = $fs; }
$fw    = (string) ( $props['weight'] ?? '500' );
$lh    = max( 0.9, min( 2.4, (float) ( $props['line_height'] ?? 1.25 ) ) );
$align = (string) ( $props['align'] ?? 'center' );
if ( ! in_array( $align, array( 'left', 'center', 'right' ), true ) ) { $align = 'center'; }
$color = (string) ( $props['color'] ?? '#111111' );
$acc   = (string) ( $props['accent_color'] ?? '#EA5C1C' );
$maxW  = max( 200, (int) ( $props['max_width'] ?? 900 ) );
$vary  = ! empty( $props['vary_style'] );
$seed  = max( 1, (int) ( $props['seed'] ?? 7 ) );

$accentList = array();
foreach ( explode( ',', (string) ( $props['accent_words'] ?? '' ) ) as $w ) {
	$w = mb_strtolower( trim( $w ) );
	if ( '' !== $w ) { $accentList[] = $w; }
}

$words = preg_split( '/\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY );
if ( ! $words ) { return; }
$n = count( $words );

// Tirage reproductible : meme graine, meme dispersion. On n'utilise pas rand()
// pour ne pas perturber la sequence globale de PHP.
$rngState = ( $seed * 2654435761 ) % 4294967296;
$rng = function () use ( &$rngState ) {
	$rngState = ( $rngState * 1103515245 + 12345 ) % 2147483648;
	return $rngState / 2147483648;
};

$items = array();
for ( $i = 0; $i < $n; $i++ ) {
	$dx = (int) round( ( $rng() * 2 - 1 ) * $spreadX );
	$dy = (int) round( ( $rng() * 2 - 1 ) * $spreadY );
	$rt = round( ( $rng() * 2 - 1 ) * $rotMax, 1 );
	$sc = round( 1 + ( $scaleF - 1 ) * ( 0.6 + 0.4 * $rng() ), 3 );
	$rd = $rng();

	if ( 'ltr' === $order )         { $d = $n > 1 ? $i / ( $n - 1 ) : 0; }
	elseif ( 'center' === $order )  { $d = $n > 1 ? abs( $i - ( $n - 1 ) / 2 ) / ( ( $n - 1 ) / 2 ) : 0; }
	elseif ( 'none' === $order )    { $d = 0; }
	else                            { $d = $rd; }

	$style = '--dx:' . $dx . 'px;--dy:' . $dy . 'px;--r:' . $rt . 'deg;--sc:' . $sc . ';--d:' . round( $d, 3 ) . ';';

	$w    = $words[ $i ];
	$bare = mb_strtolower( preg_replace( '/[^\p{L}\p{N}\'-]+/u', '', $w ) );
	$cls  = '__w';
	if ( in_array( $bare, $accentList, true ) ) { $cls .= ' is-accent'; }
	if ( $vary ) {
		if ( $rd > 0.82 )      { $cls .= ' is-em'; }
		elseif ( $rd < 0.18 )  { $cls .= ' is-strong'; }
	}

	$items[] = array( 'w' => $w, 'cls' => $cls, 'style' => $style, 'i' => $i );
}

$uid = wf_uid( 'wfta_', $props, $n );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<?php if ( $pin ) : ?>
<div class="wf-ta-track" id="<?= esc_attr( $uid ) ?>-track">
<div class="wf-ta-pin">
<?php endif; ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-ta wf-ta--<?= esc_attr( $trigger ) ?>" style="--p:1">
	<<?= $tag ?> class="wf-ta__text">
		<?php foreach ( $items as $it ) : ?><span class="<?= esc_attr( $it['cls'] ) ?>" style="<?= esc_attr( $it['style'] ) ?>"><?= esc_html( $it['w'] ) ?></span><?php if ( $it['i'] < $n - 1 ) : ?> <?php endif; ?><?php endforeach; ?>
	</<?= $tag ?>>
</div>

<?php if ( $pin ) : ?>
</div>
</div>
<?php endif; ?>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?>{container-type:inline-size;}
#<?= esc_attr( $uid ) ?> .wf-ta__text{
	margin:0;max-width:<?= (int) $maxW ?>px;
	<?= 'center' === $align ? 'margin-inline:auto;' : ( 'right' === $align ? 'margin-left:auto;' : '' ) ?>
	text-align:<?= esc_attr( $align ) ?>;
	font-size:clamp(<?= (int) $fsMin ?>px, 5cqw, <?= (int) $fs ?>px);
	font-weight:<?= esc_attr( $fw ) ?>;line-height:<?= esc_attr( $lh ) ?>;
	color:<?= esc_attr( $color ) ?>;
	text-wrap:balance;
}
#<?= esc_attr( $uid ) ?> .__w{
	display:inline-block;white-space:pre;will-change:transform,opacity,filter;
	/* --wp : 0 = en place, 1 = disperse. Ecrit par le script. */
	--wp:0;
	transform:
		translate(calc(var(--dx) * var(--wp)), calc(var(--dy) * var(--wp)))
		rotate(calc(var(--r) * var(--wp)))
		scale(calc(1 + (var(--sc) - 1) * var(--wp)));
	opacity:calc(1 - (1 - <?= esc_attr( $opF ) ?>) * var(--wp));
	<?= $blurF > 0 ? 'filter:blur(calc(' . (int) $blurF . 'px * var(--wp)));' : '' ?>
}
#<?= esc_attr( $uid ) ?> .__w.is-accent{color:<?= esc_attr( $acc ) ?>;}
#<?= esc_attr( $uid ) ?> .__w.is-em{font-style:italic;}
#<?= esc_attr( $uid ) ?> .__w.is-strong{font-weight:700;}
<?php if ( 'view' === $trigger ) : ?>
#<?= esc_attr( $uid ) ?>.wf-ta--view .__w{
	--wp:1;
	transition:transform <?= (int) $dur ?>ms cubic-bezier(.2,.8,.2,1),
		opacity <?= (int) round( $dur * 0.7 ) ?>ms ease,
		filter <?= (int) round( $dur * 0.7 ) ?>ms ease;
	transition-delay:calc(var(--d) * <?= (int) $stag ?>ms * <?= (int) $n ?>);
}
#<?= esc_attr( $uid ) ?>.wf-ta--view.is-in .__w{--wp:0;}
<?php endif; ?>
<?php if ( $pin ) : ?>
#<?= esc_attr( $uid ) ?>-track{min-height:calc(<?= (int) $dwell ?>vh + 100vh);}
#<?= esc_attr( $uid ) ?>-track .wf-ta-pin{
	position:sticky;top:<?= (int) $pinTop ?>px;
	min-height:calc(100vh - <?= (int) $pinTop ?>px);
	display:flex;align-items:center;
}
#<?= esc_attr( $uid ) ?>-track .wf-ta-pin > .wf-ta{width:100%;}
<?php endif; ?>
/* Moins d'animations : le texte est simplement en place. */
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?> .__w{--wp:0 !important;transform:none;filter:none;opacity:1;transition:none;}
<?php if ( $pin ) : ?>
	#<?= esc_attr( $uid ) ?>-track{min-height:0;}
	#<?= esc_attr( $uid ) ?>-track .wf-ta-pin{position:static;min-height:0;}
<?php endif; ?>
}
</style>

<script>
(function(){
	var root = document.getElementById('<?= esc_js( $uid ) ?>');
	if (!root) { return; }
	var words = [].slice.call(root.querySelectorAll('.__w'));
	if (!words.length) { return; }

	var reduced = false;
	if (window.matchMedia) {
		if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { reduced = true; }
	}
	if (reduced) { return; }

<?php if ( 'view' === $trigger ) : ?>
	// Etat disperse pose par le CSS ; on retire la classe pour laisser filer la transition.
	function play(){ root.classList.add('is-in'); }
	if (typeof WF !== 'undefined') {
		if (WF.onVisible) { WF.onVisible(root, play, 0.25); return; }
	}
	play();
<?php else : ?>
	var n = words.length;
	var stagger = <?= (int) $stag ?> / 1000;      // en fraction de la course
	var span = 1 - stagger * (n - 1);
	if (span < 0.15) { span = 0.15; stagger = n > 1 ? (1 - span) / (n - 1) : 0; }

	var track = document.getElementById('<?= esc_js( $uid ) ?>-track');
	var scope = track ? track : root;
	var ticking = false;

	function paint(){
		ticking = false;
		var r = scope.getBoundingClientRect();
		var vh = window.innerHeight;
		var p;
		if (track) {
			var run = r.height - vh;
			p = run > 0 ? (-r.top) / run : 0;
		} else {
			var total = r.height + vh;
			p = total > 0 ? (vh - r.top) / total : 0;
		}
		if (p < 0) { p = 0; }
		if (p > 1) { p = 1; }

		for (var i = 0; i < n; i++) {
			var d = parseFloat(words[i].style.getPropertyValue('--d'));
			if (isNaN(d)) { d = 0; }
			var start = d * stagger * (n - 1) / (n > 1 ? 1 : 1);
			var local = (p - start) / span;
			if (local < 0) { local = 0; }
			if (local > 1) { local = 1; }
			// douceur en sortie : le mot ralentit en arrivant a sa place
			var e = 1 - Math.pow(1 - local, 3);
			words[i].style.setProperty('--wp', String(1 - e));
		}
	}

	function onScroll(){
		if (ticking) { return; }
		ticking = true;
		// Un onglet en arriere-plan ne declenche aucun requestAnimationFrame :
		// on peint alors directement, sinon l'element resterait fige.
		if (document.hidden) { paint(); }
		else { requestAnimationFrame(paint); }
	}
	window.addEventListener('scroll', onScroll, { passive: true });
	window.addEventListener('resize', onScroll);
	paint();
<?php endif; ?>
})();
</script>
