<?php
/**
 * WeFrame – Chips défilantes : une pastille (item).
 * Lit ses couleurs/tailles depuis le parent via $props['element'].
 */
defined( 'ABSPATH' ) || exit;

$label = trim( (string) ( $props['label'] ?? '' ) );
if ( '' === $label ) { return; }

$url = trim( (string) ( $props['url'] ?? '' ) );
$p   = isset( $props['element'] ) && is_array( $props['element'] ) ? $props['element'] : array();

$chip_bg   = $p['chip_bg']   ?? '#ffffff';
$chip_col  = $p['chip_color'] ?? '#1a1a1a';
$icon_bg   = $p['icon_bg']   ?? '#cdd9a3';
$icon_col  = $p['icon_color'] ?? '#1a1a1a';
$fs        = max( 12, (int) ( $p['font_size'] ?? 22 ) );
$isz       = max( 20, (int) round( $fs * 1.5 ) );

$tag = ( '' !== $url ) ? 'a' : 'span';
$hrefAttr = ( '' !== $url ) ? ' href="' . esc_url( $url ) . '"' : '';

$chipStyle = 'flex:0 0 auto;display:inline-flex;align-items:center;gap:' . max( 8, (int) round( $fs * 0.55 ) ) . 'px;'
    . 'background:' . esc_attr( $chip_bg ) . ';color:' . esc_attr( $chip_col ) . ';'
    . 'padding:' . max( 8, (int) round( $fs * 0.5 ) ) . 'px ' . max( 8, (int) round( $fs * 0.5 ) ) . 'px ' . max( 8, (int) round( $fs * 0.5 ) ) . 'px ' . max( 12, (int) round( $fs * 1.15 ) ) . 'px;'
    . 'border-radius:999px;box-shadow:0 6px 18px rgba(0,0,0,.07);text-decoration:none;font-weight:600;'
    . 'white-space:nowrap;font-size:' . $fs . 'px;line-height:1;';

$iconStyle = 'display:inline-flex;align-items:center;justify-content:center;flex:0 0 auto;'
    . 'width:' . $isz . 'px;height:' . $isz . 'px;border-radius:50%;'
    . 'background:' . esc_attr( $icon_bg ) . ';color:' . esc_attr( $icon_col ) . ';';
?>
<<?= $tag ?> class="wf-cm-chip"<?= $hrefAttr ?> style="<?= esc_attr( $chipStyle ) ?>">
    <span class="wf-cm-lbl"><?= esc_html( $label ) ?></span>
    <span class="wf-cm-arrow" aria-hidden="true" style="<?= esc_attr( $iconStyle ) ?>">
        <svg width="<?= (int) round( $isz * 0.55 ) ?>" height="<?= (int) round( $isz * 0.55 ) ?>" viewBox="0 0 256 256" fill="currentColor"><path d="M200,64V168a8,8,0,0,1-16,0V83.31L69.66,197.66a8,8,0,0,1-11.32-11.32L172.69,72H88a8,8,0,0,1,0-16H192A8,8,0,0,1,200,64Z"/></svg>
    </span>
</<?= $tag ?>>
