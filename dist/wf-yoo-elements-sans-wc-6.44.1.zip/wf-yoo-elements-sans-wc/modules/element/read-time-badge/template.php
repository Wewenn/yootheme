<?php
/**
 * WeFrame – Read Time Badge | template.php v6.0
 * Calcule et affiche le temps de lecture estimé.
 * Source : post WordPress, sélecteur CSS, ou texte personnalisé.
 */
defined( 'ABSPATH' ) || exit;

$source   = $props['source']          ?? 'post';
$custom   = $props['custom_text']     ?? '';
$selector = $props['selector']        ?? '.entry-content';
$wpm      = max( 50, (int) ( $props['wpm'] ?? 200 ) );
$label    = $props['label']           ?? 'min de lecture';
$label_s  = $props['label_singular']  ?? 'min de lecture';
$show_ico = ! empty( $props['show_icon'] );
$icon     = $props['icon_char']       ?? '📖';
$style    = $props['style']           ?? 'badge';
$bg       = $props['bg']              ?? '#f0f0f0';
$color    = $props['color']           ?? '#333333';
$rad      = (int) ( $props['border_radius'] ?? 100 );
$fs       = (int) ( $props['font_size']  ?? 13 );
$fw       = $props['font_weight']     ?? '600';
$ph       = (int) ( $props['padding_h'] ?? 14 );
$pv       = (int) ( $props['padding_v'] ?? 6 );
$align    = $props['align']           ?? 'left';

$uid = wf_uid( 'wfrtb_', $props );

// ── Calculate reading time server-side when possible ────────────
$minutes  = null;
$js_needed = false;

if ( $source === 'post' ) {
    $post = get_post();
    if ( $post ) {
        $text     = wp_strip_all_tags( $post->post_content );
        $words    = str_word_count( $text );
        $minutes  = max( 1, (int) ceil( $words / $wpm ) );
    }
} elseif ( $source === 'custom' && $custom ) {
    $words   = str_word_count( wp_strip_all_tags( $custom ) );
    $minutes = max( 1, (int) ceil( $words / $wpm ) );
} else {
    // selector = needs JS
    $js_needed = true;
}

// ── Build style string ───────────────────────────────────────────
$base_style = "font-size:{$fs}px;font-weight:{$fw};color:" . esc_attr( $color ) . ";line-height:1.4;white-space:nowrap;";

if ( $style === 'badge' ) {
    $base_style .= "background:" . esc_attr( $bg ) . ";border-radius:{$rad}px;padding:{$pv}px {$ph}px;";
} elseif ( $style === 'chip' ) {
    $base_style .= "background:transparent;border:1.5px solid " . esc_attr( $color ) . ";border-radius:{$rad}px;padding:{$pv}px {$ph}px;";
} else {
    // inline
    $base_style .= "background:transparent;padding:0;";
}

$icon_html = $show_ico ? '<span style="margin-right:6px;font-style:normal;">' . esc_html( $icon ) . '</span>' : '';
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div style="text-align:<?= esc_attr( $align ) ?>;">
    <span id="<?= esc_attr( $uid ) ?>" class="wf-rtb" style="display:inline-flex;align-items:center;<?= $base_style ?>">
        <?= $icon_html ?>
        <span class="wf-rtb-num">
            <?php if ( $minutes !== null ) : ?>
                <?= esc_html( $minutes ) ?> <?= esc_html( $minutes <= 1 ? $label_s : $label ) ?>
            <?php else : ?>
                &hellip;
            <?php endif; ?>
        </span>
    </span>
</div>

<?php if ( $js_needed ) :
    $cfg = json_encode( [
        'uid'      => $uid,
        'selector' => $selector,
        'wpm'      => $wpm,
        'label'    => $label,
        'labelS'   => $label_s,
    ], JSON_HEX_AMP | JSON_HEX_APOS );
?>
<script>
(function(){
    WF.ready(function(){
        
        var c = <?= $cfg ?>;
        var badge = document.getElementById(c.uid);
        if (!badge) return;
        var num = badge.querySelector('.wf-rtb-num');
        if (!num) return;
        // Wait for DOM to be fully painted
        setTimeout(function(){
            var target = document.querySelector(c.selector);
            if (!target) { num.textContent = '1 ' + c.labelS; return; }
            var text = target.innerText || target.textContent || '';
            var words = text.trim().split(/\s+/).filter(function(w){ return w.length > 0; }).length;
            var mins = Math.max(1, Math.ceil(words / c.wpm));
            num.textContent = mins + ' ' + (mins <= 1 ? c.labelS : c.label);
        }, 300);
    });
})();
</script>
<?php endif; ?>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
