<?php
/**
 * WeFrame – Équipe (membre) | template.php v1.0
 */
defined( 'ABSPATH' ) || exit;

$name = (string) ( $props['name'] ?? '' );
$role = (string) ( $props['role'] ?? '' );
$bio  = (string) ( $props['bio'] ?? '' );
$img  = trim( (string) ( $props['photo'] ?? '' ) );
if ( '' === $name && '' === $img ) { return; }
if ( $img && ! preg_match( '#^https?://#i', $img ) ) { $img = '/' . ltrim( $img, '/' ); }

$link = $props['link'] ?? '';
if ( is_array( $link ) ) { $link = $link['url'] ?? ''; }
$link = (string) $link;

$shape   = $props['element']['shape'] ?? 'circle';
$radius  = ( 'circle' === $shape ) ? '50%' : ( ( 'rounded' === $shape ) ? '16px' : '0' );
$n_col   = $props['element']['name_color'] ?? '#111111';
$r_col   = $props['element']['role_color'] ?? '#c0272d';
$card    = ! empty( $props['element']['card'] );
$card_css = $card ? 'background:#fff;border:1px solid #ececec;border-radius:16px;padding:22px 18px;' : '';

$inner  = '';
if ( $img ) {
    $inner .= '<div class="wf-team-photo" style="width:120px;height:120px;margin:0 auto 14px;border-radius:' . $radius . ';overflow:hidden;background:#f0f0f0;">'
        . '<img src="' . esc_url( $img ) . '" alt="' . esc_attr( $name ) . '" loading="lazy" style="width:100%;height:100%;object-fit:cover;display:block;"></div>';
}
$inner .= '<div class="wf-team-name" style="font-weight:700;font-size:17px;color:' . esc_attr( $n_col ) . ';">' . esc_html( $name ) . '</div>';
if ( '' !== $role ) { $inner .= '<div class="wf-team-role" style="font-size:14px;font-weight:600;color:' . esc_attr( $r_col ) . ';margin-top:2px;">' . esc_html( $role ) . '</div>'; }
if ( '' !== $bio )  { $inner .= '<p class="wf-team-bio" style="font-size:13.5px;line-height:1.5;color:#6b7280;margin:8px 0 0;">' . esc_html( $bio ) . '</p>'; }

// Contenu libre depose dans la carte (sublayout).
$wfInner = '';
if ( ! empty( $children ) ) {
	foreach ( $children as $wfI => $wfChild ) {
		$wfInner .= $builder->render( $wfChild, array( 'element' => $props, 'index' => $wfI ) );
	}
}
if ( '' !== trim( $wfInner ) ) { $inner .= '<div class="wf-free">' . $wfInner . '</div>'; }
?>
<div class="wf-team-item" style="<?= $card_css ?>">
    <?php if ( '' !== $link ) : ?>
        <a href="<?= esc_url( $link ) ?>" style="text-decoration:none;display:block;color:inherit;"><?= $inner ?></a>
    <?php else : ?>
        <?= $inner ?>
    <?php endif; ?>
</div>
