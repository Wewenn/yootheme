<?php
/**
 * WeFrame – Galerie parallaxe (image) | template.php v1.0
 * L'enfant ne rend rien : c'est le parent qui compose les colonnes et place
 * chaque image dans la sienne.
 */
defined( 'ABSPATH' ) || exit;
