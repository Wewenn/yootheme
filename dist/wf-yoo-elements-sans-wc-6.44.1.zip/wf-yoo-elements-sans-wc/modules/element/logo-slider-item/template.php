<?php
/**
 * WeFrame – Logo Slider Item | template.php
 * v1.4.0
 *
 * $props   = this item's props (image, image_alt, link, …)
 * $element = parent Logo Slider's props (logo_max_height, gap, …)
 */
defined( 'ABSPATH' ) || exit;

$src  = $props['image']           ?? '';
$alt  = $props['image_alt']       ?? '';
$href = $props['link']            ?? '';
$aria = $props['link_aria_label'] ?? '';

if ( ! $src ) { return; }

// ── Path resolution ──
if ( ! preg_match( '#^https?://#i', $src ) ) {
    $src = '/' . ltrim( $src, '/' );
}

// ── Parent props ──
$logo_h      = min( 200, max( 16, (int) ( $element['logo_max_height']  ?? 48 ) ) );
$gap         = min( 200, max(  0, (int) ( $element['gap']              ?? 48 ) ) );
$gray        = ! empty( $element['grayscale'] );
$opacity     = min( 100, max(  0, (int) ( $element['opacity']          ?? 55 ) ) );
$new_window  = ! empty( $element['link_target_blank'] );
$tooltip     = ! empty( $element['show_tooltip'] ) && $alt;

$filter = $gray
    ? sprintf( 'grayscale(1) opacity(%s)', round( $opacity / 100, 2 ) )
    : 'none';

$half_gap     = (int) round( $gap / 2 );
$target_attr  = $new_window ? 'target="_blank" rel="noopener noreferrer"' : '';
$tooltip_attr = $tooltip ? 'data-tooltip="' . esc_attr( $alt ) . '"' : '';

?>
<div class="wf-ls-item" <?= $tooltip_attr ?> style="padding:0 <?= $half_gap ?>px;flex-shrink:0;display:flex;align-items:center;">
    <?php if ( $href ) : ?>
        <a href="<?= esc_url( $href ) ?>"
            <?= $aria ? 'aria-label="' . esc_attr( $aria ) . '"' : '' ?>
            style="display:block;text-decoration:none;"
            <?= $target_attr ?>
        ><img src="<?= esc_url( $src ) ?>" alt="<?= esc_attr( $alt ) ?>" loading="lazy"
              style="display:block;max-height:<?= $logo_h ?>px;width:auto;filter:<?= esc_attr( $filter ) ?>;"></a>
    <?php else : ?>
        <img src="<?= esc_url( $src ) ?>" alt="<?= esc_attr( $alt ) ?>" loading="lazy"
             style="display:block;max-height:<?= $logo_h ?>px;width:auto;filter:<?= esc_attr( $filter ) ?>;">
    <?php endif; ?>
</div>
