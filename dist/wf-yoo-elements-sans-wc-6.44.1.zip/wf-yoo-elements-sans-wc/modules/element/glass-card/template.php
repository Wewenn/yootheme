<?php
/**
 * WeFrame – Glass Card (Glassmorphism) | template.php v6.0
 * Pure CSS glassmorphism — zero JS.
 */
defined( 'ABSPATH' ) || exit;

$content = $props['content'] ?? '';
$blur    = (int) ( $props['blur'] ?? 16 );
$bg      = $props['bg_color'] ?? 'rgba(255,255,255,0.15)';
$bc      = $props['border_color'] ?? 'rgba(255,255,255,0.25)';
$bw      = (int) ( $props['border_width'] ?? 1 );
$rad     = (int) ( $props['radius'] ?? 20 );
$pad     = (int) ( $props['padding'] ?? 32 );
$shadow  = ! empty( $props['shadow'] );
$mw      = (int) ( $props['max_width'] ?? 0 );

$inner = '';
if ( ! empty( $children ) ) {
    foreach ( $children as $child ) {
        $inner .= $builder->render( $child, [ 'element' => $props ] );
    }
}
if ( ! trim( $inner ) ) { $inner = wp_kses_post( $content ); }

$mw_css    = $mw > 0 ? "max-width:{$mw}px;" : '';
$sh_css    = $shadow ? 'box-shadow:0 8px 32px rgba(0,0,0,.12);' : '';
$border    = $bw > 0 ? "border:{$bw}px solid {$bc};" : '';
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div class="wf-glass-card" style="<?= $mw_css ?>background:<?= esc_attr( $bg ) ?>;backdrop-filter:blur(<?= $blur ?>px);-webkit-backdrop-filter:blur(<?= $blur ?>px);<?= $border ?>border-radius:<?= $rad ?>px;padding:<?= $pad ?>px;<?= $sh_css ?>">
    <?= $inner ?>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
