<?php
/**
 * WeFrame – Switcher Pro (volet enfant) | template.php v1.0
 * L'enfant ne rend que son contenu : c'est le parent qui construit la navigation
 * (a partir de label / sublabel / badge / image) et l'enveloppe du volet.
 */
defined( 'ABSPATH' ) || exit;

$inner = '';
if ( ! empty( $children ) ) {
	foreach ( $children as $ci => $child ) {
		$inner .= $builder->render( $child, array( 'element' => $props, 'index' => $ci ) );
	}
}
echo $inner;
