<?php
defined('ABSPATH') || exit;
if (empty($children)) return;
$mode = $props['display_mode']??'button'; $pkh = max(0,(int)($props['peek_height']??120));
$pkc = $props['peek_gradient_color']??'#ffffff';
$txo = $props['btn_text_open']??'En savoir plus'; $txc = $props['btn_text_close']??'Réduire';
$sty = $props['btn_style']??'outline'; $clr = $props['btn_color']??'#333';
$bgc = $props['btn_bg']??''; $bdr = $props['btn_border_color']??'#333';
$rad = (int)($props['btn_radius']??100); $sz = $props['btn_size']??'medium';
$aln = $props['btn_align']??'center'; $ico = !empty($props['btn_icon']);
$dur = max(0,(int)($props['duration']??400)); $grp = trim($props['group_id']??'');
$uid = 'wftg_'.substr(md5(serialize($props).count($children)),0,8);
if (!preg_match('/^#([0-9a-fA-F]{3}){1,2}$/',$pkc)) $pkc='#ffffff';
$inner = '';
foreach ($children as $child) { $inner .= $builder->render($child); }
if (!trim($inner)) return;
$pad = match($sz){'small'=>'6px 16px','large'=>'14px 32px',default=>'10px 24px'};
$fs = match($sz){'small'=>'13px','large'=>'16px',default=>'14px'};
$bc = match($sty){'filled'=>"background:".esc_attr($bgc?:$clr).";color:#fff;border:none;",'text'=>"background:transparent;color:".esc_attr($clr).";border:none;",default=>"background:transparent;color:".esc_attr($clr).";border:2px solid ".esc_attr($bdr).";"};
$ac = match($aln){'center'=>'justify-content:center;','right'=>'justify-content:flex-end;',default=>''};
$chev = $ico ? '<svg class="wf-tg-chev" width="16" height="16" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 8 10 12 14 8"/></svg>' : '';
$ga = $grp ? ' data-wf-group="'.esc_attr($grp).'"' : '';
$peek = ($mode === 'peek');
$cfg = json_encode(['uid'=>$uid,'txo'=>$txo,'txc'=>$txc,'dur'=>$dur,'grp'=>$grp,'peek'=>$peek,'pkh'=>$pkh], JSON_HEX_AMP|JSON_HEX_APOS);
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr($uid) ?>" class="wf-toggle-reveal"<?= $ga ?>>
<?php if ($peek) : ?>
    <div class="wf-tg-panel" style="position:relative;max-height:<?= $pkh ?>px;overflow:hidden;transition:max-height <?= $dur ?>ms ease;">
        <div class="wf-tg-inner"><?= $inner ?></div>
        <div class="wf-tg-grad" style="position:absolute;bottom:0;left:0;right:0;height:<?= max(40,(int)($pkh*0.5)) ?>px;background:linear-gradient(transparent,<?= esc_attr($pkc) ?>);pointer-events:none;transition:opacity <?= $dur ?>ms;"></div>
    </div>
<?php else : ?>
    <div class="wf-tg-panel" style="overflow:hidden;max-height:0;opacity:0;transition:max-height <?= $dur ?>ms ease,opacity <?= $dur ?>ms ease;">
        <div class="wf-tg-inner" style="padding-top:16px;"><?= $inner ?></div>
    </div>
<?php endif; ?>
    <div style="display:flex;<?= $ac ?>margin-top:12px;">
        <button type="button" class="wf-tg-btn" aria-expanded="false" style="cursor:pointer;display:inline-flex;align-items:center;gap:8px;padding:<?= $pad ?>;font-size:<?= $fs ?>;font-weight:600;line-height:1.4;border-radius:<?= $rad ?>px;<?= $bc ?>transition:all .2s;font-family:inherit;">
            <span class="wf-tg-label"><?= esc_html($txo) ?></span><?= $chev ?>
        </button>
    </div>
</div>
<style>#<?= esc_attr($uid) ?> .wf-tg-btn:hover{opacity:.8}#<?= esc_attr($uid) ?> .wf-tg-chev{transition:transform <?= $dur ?>ms}#<?= esc_attr($uid) ?>.wf-toggle--open .wf-tg-chev{transform:rotate(180deg)}#<?= esc_attr($uid) ?>.wf-toggle--open .wf-tg-grad{opacity:0}</style>
<script>
(function(){
    function boot(){
        
        var c = <?= $cfg ?>;
        var el=document.getElementById(c.uid);if(!el)return;
        var btn=el.querySelector('.wf-tg-btn');if(!btn)return;
        var lbl=el.querySelector('.wf-tg-label');var panel=el.querySelector('.wf-tg-panel');if(!panel)return;
        var isOpen=false;
        function doClose(){isOpen=false;el.classList.remove('wf-toggle--open');btn.setAttribute('aria-expanded','false');lbl.textContent=c.txo;if(c.peek){panel.style.maxHeight=c.pkh+'px'}else{panel.style.maxHeight=panel.scrollHeight+'px';requestAnimationFrame(function(){panel.style.maxHeight='0';panel.style.opacity='0'})}}
        function doOpen(){if(c.grp){var others=document.querySelectorAll('[data-wf-group="'+c.grp+'"].wf-toggle--open');var oi=0;while(oi<others.length){if(others[oi]!==el){if(others[oi]._wfClose)others[oi]._wfClose()}oi++}}isOpen=true;el.classList.add('wf-toggle--open');btn.setAttribute('aria-expanded','true');lbl.textContent=c.txc;panel.style.maxHeight=panel.scrollHeight+'px';panel.style.opacity='1';setTimeout(function(){panel.style.maxHeight='none'},c.dur)}
        el._wfClose=doClose;btn.addEventListener('click',function(){if(isOpen){doClose()}else{doOpen()}});
    }
    WF.ready(boot)
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
