<?php
defined( 'ABSPATH' ) || exit;
if ( ! function_exists( 'wf_data_csv' ) ) {
function wf_data_csv( $url, $minutes = 30 ) {
	$url = esc_url_raw( (string) $url ); if ( ! $url ) { return new WP_Error( 'wf_data_url', 'URL invalide.' ); }
	$key = 'wf_csv_' . md5( $url ); $cached = get_transient( $key ); if ( false !== $cached ) { return $cached; }
	$res = wp_safe_remote_get( $url, array( 'timeout' => 12, 'redirection' => 3 ) );
	if ( is_wp_error( $res ) ) { return $res; }
	if ( (int) wp_remote_retrieve_response_code( $res ) < 200 || (int) wp_remote_retrieve_response_code( $res ) >= 300 ) { return new WP_Error( 'wf_data_http', 'La source ne répond pas correctement.' ); }
	$body = wp_remote_retrieve_body( $res ); if ( '' === trim( $body ) ) { return new WP_Error( 'wf_data_empty', 'Source vide.' ); }
	$body = preg_replace( '/^\xEF\xBB\xBF/', '', $body );
	$lines = preg_split( '/\R/', trim( $body ) ); $first = (string) array_shift( $lines );
	$delimiter = ','; foreach ( array( ';', "\t", '|' ) as $candidate ) { if ( substr_count( $first, $candidate ) > substr_count( $first, $delimiter ) ) { $delimiter = $candidate; } }
	$head = array_map( 'trim', str_getcsv( $first, $delimiter ) ); if ( ! array_filter( $head, 'strlen' ) ) { return new WP_Error( 'wf_data_header', 'En-tête CSV invalide.' ); }
	$rows = array(); foreach ( array_slice( $lines, 0, 500 ) as $line ) { $cells = str_getcsv( $line, $delimiter ); if ( count( $cells ) === count( $head ) ) { $rows[] = array_combine( $head, $cells ); } }
	$data = array( 'head' => $head, 'rows' => $rows ); set_transient( $key, $data, max( 1, min( 1440, (int) $minutes ) ) * MINUTE_IN_SECONDS ); return $data;
}}
if ( ! function_exists( 'wf_data_ical' ) ) {
function wf_data_ical( $url, $minutes = 30 ) {
	$url=esc_url_raw((string)$url);if(!$url)return new WP_Error('wf_ical_url','URL invalide.');$key='wf_ical_'.md5($url);$cached=get_transient($key);if(false!==$cached)return $cached;$r=wp_safe_remote_get($url,array('timeout'=>12,'redirection'=>3));if(is_wp_error($r))return $r;$raw=wp_remote_retrieve_body($r);$raw=preg_replace('/\R[ \t]/','',$raw);preg_match_all('/BEGIN:VEVENT(.*?)END:VEVENT/s',$raw,$matches);$events=array();foreach($matches[1] as $block){$field=array();foreach(preg_split('/\R/',$block) as $line){if(preg_match('/^([A-Z]+)(?:;[^:]*)?:(.*)$/',$line,$m))$field[$m[1]]=$m[2];}$start=$field['DTSTART']??'';$stamp=preg_match('/^(\d{8})/',$start,$m)?strtotime($m[1]):false;if(!$stamp)continue;$events[]=array('title'=>wp_strip_all_tags($field['SUMMARY']??'Événement'),'date'=>$stamp,'end'=>$field['DTEND']??'','location'=>wp_strip_all_tags($field['LOCATION']??''),'url'=>esc_url_raw($field['URL']??''));}usort($events,static fn($a,$b)=>$a['date']<=>$b['date']);set_transient($key,$events,max(1,min(1440,(int)$minutes))*MINUTE_IN_SECONDS);return $events;
}}
