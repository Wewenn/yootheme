<?php
defined( 'ABSPATH' ) || exit;

/** Lien d’évitement global : il cible <main>, puis #main, sans modifier le thème. */
add_action( 'wp_body_open', static function () {
	if ( is_admin() ) { return; }
	echo '<a class="wf-skip-link" href="#main">Aller directement au contenu</a>';
} );
add_action( 'wp_head', static function () {
	if ( is_admin() ) { return; }
	echo '<style>.wf-skip-link{position:fixed;left:12px;top:12px;z-index:2147483647;transform:translateY(-180%);padding:12px 16px;border-radius:8px;background:#111;color:#fff;font:600 14px/1 sans-serif;text-decoration:none;transition:transform .16s}.wf-skip-link:focus{transform:none;outline:3px solid #fff;outline-offset:2px}</style>';
} );
add_action( 'wp_footer', static function () {
	if ( is_admin() ) { return; }
	echo '<script>document.addEventListener("click",function(e){var a=e.target.closest(".wf-skip-link");if(!a)return;var m=document.querySelector("main")||document.getElementById("main");if(!m)return;e.preventDefault();if(!m.id)m.id="main";m.tabIndex=-1;m.focus({preventScroll:true});m.scrollIntoView({behavior:"smooth",block:"start"});});</script>';
}, 99 );
