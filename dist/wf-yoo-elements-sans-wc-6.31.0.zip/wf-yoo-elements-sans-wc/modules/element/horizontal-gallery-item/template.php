<?php
/**
 * WeFrame – Galerie horizontale : image (item).
 */
defined( 'ABSPATH' ) || exit;
$img = trim( (string) ( $props['image'] ?? '' ) );
if ( '' === $img ) { return; }
if ( ! preg_match( '#^https?://#i', $img ) ) { $img = '/' . ltrim( $img, '/' ); }
$cap = (string) ( $props['caption'] ?? '' );
?>
<div class="wf-hg-i">
    <img src="<?= esc_url( $img ) ?>" alt="<?= esc_attr( $cap ) ?>" loading="lazy">
    <?php if ( '' !== $cap ) : ?><span style="position:absolute;left:0;right:0;bottom:0;padding:16px 18px;color:#fff;font-size:15px;font-weight:600;background:linear-gradient(transparent,rgba(0,0,0,.6));"><?= esc_html( $cap ) ?></span><?php endif; ?>
</div>
