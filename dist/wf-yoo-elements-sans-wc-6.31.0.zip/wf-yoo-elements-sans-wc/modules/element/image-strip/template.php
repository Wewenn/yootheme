<?php
/**
 * WeFrame – Bande d'images (parent) | 2-3 images (items) qui apparaissent en cascade au scroll.
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }
$layout = ( 'stagger' === ( $props['layout'] ?? 'row' ) ) ? 'stagger' : 'row';
$eff    = $props['effect'] ?? 'up';
if ( ! in_array( $eff, array( 'up', 'zoom', 'sides' ), true ) ) { $eff = 'up'; }
$gap    = max( 0, (int) ( $props['gap'] ?? 16 ) );
$rad    = max( 0, (int) ( $props['radius'] ?? 14 ) );
$h      = max( 120, (int) ( $props['height'] ?? 320 ) );

$html = '';
foreach ( $children as $child ) { $html .= $builder->render( $child, array( 'element' => $props ) ); }
if ( ! trim( $html ) ) { return; }
$uid = wf_uid( 'wfstr_', $props, count( $children ) );

$init = 'up' === $eff ? 'opacity:0;transform:translateY(32px);' : ( 'zoom' === $eff ? 'opacity:0;transform:scale(.9);' : 'opacity:0;' );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-str" style="display:flex;gap:<?= $gap ?>px;align-items:stretch;"><?= $html ?></div>
<style>
#<?= esc_attr( $uid ) ?> .wf-str-i{flex:1;min-width:0;height:<?= $h ?>px;border-radius:<?= $rad ?>px;overflow:hidden;<?= $init ?>transition:opacity .7s cubic-bezier(.16,1,.3,1),transform .7s cubic-bezier(.16,1,.3,1);will-change:opacity,transform;}
<?php if ( 'sides' === $eff ) : ?>
#<?= esc_attr( $uid ) ?> .wf-str-i:nth-child(odd){transform:translateX(-42px);}
#<?= esc_attr( $uid ) ?> .wf-str-i:nth-child(even){transform:translateX(42px);}
<?php endif; ?>
<?php if ( 'stagger' === $layout ) : ?>
#<?= esc_attr( $uid ) ?> .wf-str-i:nth-child(even){margin-top:<?= (int) ( $h * 0.14 ) ?>px;}
<?php endif; ?>
#<?= esc_attr( $uid ) ?> .wf-str-i.on{opacity:1 !important;transform:none !important;}
@media(max-width:640px){ #<?= esc_attr( $uid ) ?>{flex-direction:column;} #<?= esc_attr( $uid ) ?> .wf-str-i{margin-top:0 !important;} }
</style>
<script>
(function(){
    var el = document.getElementById('<?= esc_js( $uid ) ?>'); if (!el) return;
    var items = el.querySelectorAll('.wf-str-i');
    function show(){ for (var i = 0; i < items.length; i++){ (function(x,d){ setTimeout(function(){ x.classList.add('on'); }, d); })(items[i], i * 120); } }
    if (window.matchMedia) if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { for (var k = 0; k < items.length; k++) items[k].classList.add('on'); return; }
    if (!window.IntersectionObserver) { show(); return; }
    var io = new IntersectionObserver(function(ents){ for (var i = 0; i < ents.length; i++){ if (ents[i].isIntersecting) { show(); io.disconnect(); } } }, { threshold: 0.25 });
    io.observe(el);
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
