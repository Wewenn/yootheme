<?php
/**
 * WeFrame – Faisceaux animés | template.php v1.0
 * Des etapes reliees par des traits que parcourt une lumiere. Deux dispositions :
 * en etoile (deux colonnes vers un centre) ou en chaine.
 *
 * Les traits sont traces par le script, a partir des positions reelles des
 * boites : c'est la seule facon de rester juste quand la largeur change ou que
 * les libelles passent sur deux lignes. Sans JS, on voit les etapes, sans les
 * traits — l'information reste la.
 * Pas de "&&" ni de "||" dans le JS inline (regle interne du plugin).
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$layout = ( 'chain' === ( $props['layout'] ?? 'hub' ) ) ? 'chain' : 'hub';
$cLabel = trim( (string) ( $props['center_label'] ?? '' ) );
$cImg   = $props['center_image'] ?? '';
if ( is_array( $cImg ) ) { $cImg = $cImg['src'] ?? ( $cImg['url'] ?? '' ); }
$cImg   = trim( (string) $cImg );

$gap    = max( 8, (int) ( $props['gap'] ?? 28 ) );
$nSize  = max( 40, (int) ( $props['node_size'] ?? 72 ) );
$cSize  = max( 50, (int) ( $props['center_size'] ?? 110 ) );
$curve  = max( 0, min( 100, (int) ( $props['curvature'] ?? 60 ) ) );
$speed  = max( 1, (float) ( $props['speed'] ?? 3 ) );
$bw     = max( 1, min( 8, (int) ( $props['beam_width'] ?? 2 ) ) );

$lCol   = (string) ( $props['line_color'] ?? '#e3e3ea' );
$b1     = (string) ( $props['beam_1'] ?? '#EA5C1C' );
$b2     = (string) ( $props['beam_2'] ?? '#7C3AED' );
$nBg    = (string) ( $props['node_bg'] ?? '#ffffff' );
$nBd    = (string) ( $props['node_border'] ?? '#e8e8ec' );
$nCol   = (string) ( $props['node_color'] ?? '#111111' );
$cBg    = (string) ( $props['center_bg'] ?? '#111111' );
$cCol   = (string) ( $props['center_color'] ?? '#ffffff' );

$showL  = ! empty( $props['show_labels'] );
$lSize  = max( 10, (int) ( $props['label_size'] ?? 13 ) );
$labCol = (string) ( $props['label_color'] ?? '#6b7280' );

$icons = array(
	'bolt'   => '<path d="M213.85,125.46l-112,120a8,8,0,0,1-13.69-7l14.66-73.29L45.19,143.49a8,8,0,0,1-3-13l112-120a8,8,0,0,1,13.69,7L153.18,90.9l57.63,21.61a8,8,0,0,1,3,12.95Z"/>',
	'cart'   => '<path d="M96,216a16,16,0,1,1-16-16A16,16,0,0,1,96,216Zm88-16a16,16,0,1,0,16,16A16,16,0,0,0,184,200ZM220.83,63.7,197.5,146.42A16,16,0,0,1,182.1,158H83.11a16,16,0,0,1-15.4-11.58L34.4,32H16a8,8,0,0,1,0-16H34.4a16,16,0,0,1,15.4,11.58L54.72,48H213.13a8,8,0,0,1,7.7,15.7Z"/>',
	'mail'   => '<path d="M224,48H32a8,8,0,0,0-8,8V192a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A8,8,0,0,0,224,48Zm-96,85.15L52.57,64H203.43ZM40,72.19l53.24,48.79L40,175.66Zm12.57,119.81,52.51-52.51L128,160.15l22.92-20.66L203.43,192Zm163.43-16.34-53.24-54.68L216,72.19Z"/>',
	'chart'  => '<path d="M224,200h-8V40a8,8,0,0,0-8-8H152a8,8,0,0,0-8,8V80H96a8,8,0,0,0-8,8v40H48a8,8,0,0,0-8,8v64H32a8,8,0,0,0,0,16H224a8,8,0,0,0,0-16Z"/>',
	'user'   => '<path d="M230.92,212c-15.23-26.33-38.7-45.21-66.09-54.16a72,72,0,1,0-73.66,0C63.78,166.78,40.31,185.66,25.08,212a8,8,0,1,0,13.85,8c18.84-32.56,52.14-52,89.07-52s70.23,19.44,89.07,52a8,8,0,1,0,13.85-8Z"/>',
	'gear'   => '<path d="M128,80a48,48,0,1,0,48,48A48.05,48.05,0,0,0,128,80Zm0,80a32,32,0,1,1,32-32A32,32,0,0,1,128,160Z"/>',
	'cloud'  => '<path d="M160,40A88.09,88.09,0,0,0,81.29,88.67,64,64,0,1,0,72,216h88a88,88,0,0,0,0-176Zm0,160H72a48,48,0,0,1,0-96c1.1,0,2.2,0,3.29.11A88,88,0,0,0,72,128a8,8,0,0,0,16,0,72,72,0,1,1,72,72Z"/>',
	'phone'  => '<path d="M176,16H80A24,24,0,0,0,56,40V216a24,24,0,0,0,24,24h96a24,24,0,0,0,24-24V40A24,24,0,0,0,176,16Zm8,200a8,8,0,0,1-8,8H80a8,8,0,0,1-8-8V40a8,8,0,0,1,8-8h96a8,8,0,0,1,8,8Z"/>',
);

$left = array(); $right = array(); $chain = array();
foreach ( $children as $i => $child ) {
	$cp    = (array) ( $child->props ?? array() );
	$label = trim( (string) ( $cp['label'] ?? '' ) );
	if ( '' === $label ) { $label = sprintf( __( 'Étape %d', 'weframe' ), $i + 1 ); }

	$img = $cp['image'] ?? '';
	if ( is_array( $img ) ) { $img = $img['src'] ?? ( $img['url'] ?? '' ); }

	$node = array(
		'label' => $label,
		'img'   => trim( (string) $img ),
		'icon'  => (string) ( $cp['icon'] ?? 'bolt' ),
		'side'  => ( 'right' === ( $cp['side'] ?? 'left' ) ) ? 'right' : 'left',
		'id'    => 'n' . $i,
	);
	$chain[] = $node;
	if ( 'right' === $node['side'] ) { $right[] = $node; } else { $left[] = $node; }
}

$uid = wf_uid( 'wfbf_', $props, count( $chain ) );

// Le balisage d'une etape est le meme partout : on le prepare une fois.
$nodeHtml = function ( $node ) use ( $icons, $showL, $uid ) {
	$svg = isset( $icons[ $node['icon'] ] ) ? $icons[ $node['icon'] ] : $icons['bolt'];
	ob_start();
	?>
	<div class="wf-bf__node" data-node="<?= esc_attr( $node['id'] ) ?>">
		<span class="__box">
			<?php if ( '' !== $node['img'] ) : ?>
			<img src="<?= esc_url( $node['img'] ) ?>" alt="<?= esc_attr( $node['label'] ) ?>" loading="lazy" decoding="async">
			<?php else : ?>
			<svg viewBox="0 0 256 256" width="26" height="26" fill="currentColor" aria-hidden="true" focusable="false"><?= $svg ?></svg>
			<?php endif; ?>
		</span>
		<span class="__label<?= $showL ? '' : ' wf-sr' ?>"><?= esc_html( $node['label'] ) ?></span>
	</div>
	<?php
	return ob_get_clean();
};
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-bf wf-bf--<?= esc_attr( $layout ) ?>">
	<svg class="__wires" aria-hidden="true" focusable="false"></svg>

	<?php if ( 'hub' === $layout ) : ?>
	<div class="__col __col-left">
		<?php foreach ( $left as $node ) { echo $nodeHtml( $node ); } ?>
	</div>
	<div class="__col __col-center">
		<div class="wf-bf__node wf-bf__node--center" data-node="center">
			<span class="__box">
				<?php if ( '' !== $cImg ) : ?>
				<img src="<?= esc_url( $cImg ) ?>" alt="<?= esc_attr( $cLabel ) ?>" loading="lazy" decoding="async">
				<?php elseif ( '' !== $cLabel ) : ?>
				<span class="__ctext"><?= esc_html( $cLabel ) ?></span>
				<?php endif; ?>
			</span>
		</div>
	</div>
	<div class="__col __col-right">
		<?php foreach ( $right as $node ) { echo $nodeHtml( $node ); } ?>
	</div>
	<?php else : ?>
	<div class="__chain">
		<?php foreach ( $chain as $node ) { echo $nodeHtml( $node ); } ?>
	</div>
	<?php endif; ?>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?>{position:relative;container-type:inline-size;}
#<?= esc_attr( $uid ) ?> .__wires{
	position:absolute;inset:0;width:100%;height:100%;z-index:0;pointer-events:none;overflow:visible;
}
#<?= esc_attr( $uid ) ?>.wf-bf--hub{
	display:grid;grid-template-columns:1fr auto 1fr;align-items:center;
	gap:<?= (int) max( 24, $gap * 2 ) ?>px;
}
#<?= esc_attr( $uid ) ?> .__col{display:flex;flex-direction:column;gap:<?= (int) $gap ?>px;position:relative;z-index:1;}
#<?= esc_attr( $uid ) ?> .__col-left{align-items:flex-start;}
#<?= esc_attr( $uid ) ?> .__col-right{align-items:flex-end;}
#<?= esc_attr( $uid ) ?> .__col-center{align-items:center;}
#<?= esc_attr( $uid ) ?> .__chain{
	display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;
	gap:<?= (int) $gap ?>px;position:relative;z-index:1;
}

#<?= esc_attr( $uid ) ?> .wf-bf__node{display:flex;align-items:center;gap:10px;}
#<?= esc_attr( $uid ) ?> .__col-right .wf-bf__node{flex-direction:row-reverse;}
#<?= esc_attr( $uid ) ?> .__chain .wf-bf__node{flex-direction:column;text-align:center;gap:8px;}
#<?= esc_attr( $uid ) ?> .__box{
	display:flex;align-items:center;justify-content:center;flex:0 0 auto;
	width:<?= (int) $nSize ?>px;height:<?= (int) $nSize ?>px;border-radius:18px;
	background:<?= esc_attr( $nBg ) ?>;border:1px solid <?= esc_attr( $nBd ) ?>;
	color:<?= esc_attr( $nCol ) ?>;box-shadow:0 8px 22px rgba(0,0,0,.07);
}
#<?= esc_attr( $uid ) ?> .__box img{width:56%;height:56%;object-fit:contain;}
#<?= esc_attr( $uid ) ?> .wf-bf__node--center .__box{
	width:<?= (int) $cSize ?>px;height:<?= (int) $cSize ?>px;border-radius:50%;
	background:<?= esc_attr( $cBg ) ?>;color:<?= esc_attr( $cCol ) ?>;border-color:transparent;
	box-shadow:0 14px 40px rgba(0,0,0,.18);
}
#<?= esc_attr( $uid ) ?> .__ctext{font-weight:700;font-size:<?= (int) max( 12, round( $cSize / 8 ) ) ?>px;text-align:center;padding:6px;}
#<?= esc_attr( $uid ) ?> .__label{font-size:<?= (int) $lSize ?>px;font-weight:600;color:<?= esc_attr( $labCol ) ?>;}
#<?= esc_attr( $uid ) ?> .wf-sr{
	position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;
	clip:rect(0,0,0,0);white-space:nowrap;border:0;
}
#<?= esc_attr( $uid ) ?> .__wire{fill:none;stroke:<?= esc_attr( $lCol ) ?>;stroke-width:<?= (int) $bw ?>;}
#<?= esc_attr( $uid ) ?> .__beam{
	fill:none;stroke-width:<?= (int) $bw ?>;stroke-linecap:round;
	stroke-dasharray:var(--len);
	animation:<?= esc_attr( $uid ) ?>-run <?= esc_attr( $speed ) ?>s linear infinite;
	animation-delay:var(--dl,0s);
}
@keyframes <?= esc_attr( $uid ) ?>-run{
	from{stroke-dashoffset:var(--len)}
	to{stroke-dashoffset:0}
}
@container (max-width: 620px){
	#<?= esc_attr( $uid ) ?>.wf-bf--hub{grid-template-columns:1fr;justify-items:center;}
	#<?= esc_attr( $uid ) ?> .__col-left,#<?= esc_attr( $uid ) ?> .__col-right{align-items:center;}
	#<?= esc_attr( $uid ) ?> .__col-right .wf-bf__node{flex-direction:row;}
}
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?> .__beam{animation:none;stroke-dasharray:none;opacity:.6;}
}
</style>

<script>
(function(){
	var root = document.getElementById('<?= esc_js( $uid ) ?>');
	if (!root) { return; }
	var svg = root.querySelector('.__wires');
	if (!svg) { return; }
	var NS = 'http://www.w3.org/2000/svg';
	var curve = <?= (int) $curve ?> / 100;
	var beams = ['<?= esc_js( $b1 ) ?>', '<?= esc_js( $b2 ) ?>'];
	var speed = <?= esc_js( (string) $speed ) ?>;
	var layout = '<?= esc_js( $layout ) ?>';

	function centerOf(node, box){
		var b = node.querySelector('.__box').getBoundingClientRect();
		return { x: b.left + b.width / 2 - box.left, y: b.top + b.height / 2 - box.top,
			w: b.width, h: b.height };
	}

	function pathBetween(a, b, horizontal){
		var d;
		if (curve <= 0) {
			d = 'M' + a.x + ' ' + a.y + ' L' + b.x + ' ' + b.y;
		} else if (horizontal) {
			var off = (b.x - a.x) * curve;
			d = 'M' + a.x + ' ' + a.y + ' C' + (a.x + off) + ' ' + a.y +
				' ' + (b.x - off) + ' ' + b.y + ' ' + b.x + ' ' + b.y;
		} else {
			var offy = (b.y - a.y) * curve;
			d = 'M' + a.x + ' ' + a.y + ' C' + a.x + ' ' + (a.y + offy) +
				' ' + b.x + ' ' + (b.y - offy) + ' ' + b.x + ' ' + b.y;
		}
		return d;
	}

	function draw(){
		var box = root.getBoundingClientRect();
		while (svg.firstChild) { svg.removeChild(svg.firstChild); }
		svg.setAttribute('viewBox', '0 0 ' + box.width + ' ' + box.height);
		svg.setAttribute('width', box.width);
		svg.setAttribute('height', box.height);

		var pairs = [];
		if (layout === 'hub') {
			var c = root.querySelector('[data-node="center"]');
			if (!c) { return; }
			var cc = centerOf(c, box);
			var lefts = [].slice.call(root.querySelectorAll('.__col-left .wf-bf__node'));
			var rights = [].slice.call(root.querySelectorAll('.__col-right .wf-bf__node'));
			lefts.forEach(function(n){ pairs.push([centerOf(n, box), cc]); });
			rights.forEach(function(n){ pairs.push([cc, centerOf(n, box)]); });
		} else {
			var all = [].slice.call(root.querySelectorAll('.__chain .wf-bf__node'));
			for (var i = 0; i < all.length - 1; i++) {
				pairs.push([centerOf(all[i], box), centerOf(all[i + 1], box)]);
			}
		}

		for (var k = 0; k < pairs.length; k++) {
			var a = pairs[k][0];
			var b = pairs[k][1];
			// on part du bord de la boite, pas de son centre
			var horizontal = Math.abs(b.x - a.x) > Math.abs(b.y - a.y);
			var A = { x: a.x, y: a.y }, B = { x: b.x, y: b.y };
			if (horizontal) {
				var s = b.x > a.x ? 1 : -1;
				A.x = a.x + s * a.w / 2;
				B.x = b.x - s * b.w / 2;
			} else {
				var sv = b.y > a.y ? 1 : -1;
				A.y = a.y + sv * a.h / 2;
				B.y = b.y - sv * b.h / 2;
			}
			var d = pathBetween(A, B, horizontal);

			var wire = document.createElementNS(NS, 'path');
			wire.setAttribute('class', '__wire');
			wire.setAttribute('d', d);
			svg.appendChild(wire);

			var beam = document.createElementNS(NS, 'path');
			beam.setAttribute('class', '__beam');
			beam.setAttribute('d', d);
			beam.setAttribute('stroke', beams[k % beams.length]);
			svg.appendChild(beam);
			var len = 0;
			if (beam.getTotalLength) { len = beam.getTotalLength(); }
			// le trait lumineux fait un cinquieme du fil : on le voit passer
			var dash = Math.max(20, len / 5);
			beam.style.strokeDasharray = dash + ' ' + Math.max(1, len - dash);
			beam.style.setProperty('--len', String(Math.ceil(len)));
			beam.style.setProperty('--dl', (-(k * speed / Math.max(1, pairs.length))).toFixed(2) + 's');
		}
	}

	draw();
	window.addEventListener('resize', draw);
	if (window.ResizeObserver) { new ResizeObserver(draw).observe(root); }
	if (document.fonts) {
		if (document.fonts.ready) { document.fonts.ready.then(draw); }
	}
})();
</script>
