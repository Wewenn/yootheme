<?php
/**
 * WeFrame – Marquee Gallery | template.php
 * Infinite horizontal image band. Pure CSS (children duplicated for a
 * seamless loop). No inline JS, no config block.
 */
defined( 'ABSPATH' ) || exit;

$props = is_array( $props ?? null ) ? $props : array();
if ( ! isset( $builder ) || ! is_object( $builder ) || empty( $children ) || ! is_array( $children ) ) { return; }

$speed    = min( 120, max( 10, (int) ( $props['speed'] ?? 40 ) ) );
$speed_m  = max( 0, (int) ( $props['speed_mobile'] ?? 0 ) );
$reverse  = ! empty( $props['reverse'] );
$hover    = ! empty( $props['pause_on_hover'] );
$gap      = min( 80, max( 0, (int) ( $props['gap'] ?? 24 ) ) );
$img_h    = min( 500, max( 100, (int) ( $props['img_height'] ?? 260 ) ) );
$img_h_m  = min( 400, max( 80, (int) ( $props['img_height_mobile'] ?? 170 ) ) );
$radius   = min( 40, max( 0, (int) ( $props['radius'] ?? 14 ) ) );
$gray     = ! empty( $props['grayscale'] );
$col_hov  = ! empty( $props['color_on_hover'] ) && $gray;
$fade     = ! empty( $props['fade_edges'] );
$fade_col = (string) ( $props['fade_color'] ?? '#ffffff' );
if ( ! preg_match( '/^#([0-9a-fA-F]{3}){1,2}$/', $fade_col ) ) { $fade_col = '#ffffff'; }

$html = '';
foreach ( $children as $child ) {
    $html .= (string) $builder->render( $child, array( 'element' => $props ) );
}
if ( ! trim( $html ) ) { return; }

$uid = wf_uid( 'wfmq_', $props, count( $children ) );
$fade_w = (int) ( $gap * 3 );
$half_gap = (int) round( $gap / 2 );
$has_mob_speed = $speed_m > 0 && $speed_m !== $speed;
$filter = $gray ? 'grayscale(1)' : 'none';
$dir = $reverse ? 'reverse' : 'normal';
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-mq" style="position:relative;overflow:hidden;">
    <?php if ( $fade ) : ?>
    <div aria-hidden="true" style="position:absolute;top:0;left:0;bottom:0;width:<?= $fade_w ?>px;z-index:2;pointer-events:none;background:linear-gradient(90deg,<?= esc_attr( $fade_col ) ?>,transparent);"></div>
    <div aria-hidden="true" style="position:absolute;top:0;right:0;bottom:0;width:<?= $fade_w ?>px;z-index:2;pointer-events:none;background:linear-gradient(270deg,<?= esc_attr( $fade_col ) ?>,transparent);"></div>
    <?php endif; ?>
    <div class="wf-mq-track" style="display:flex;width:max-content;align-items:center;animation:wf-mq-scroll <?= $speed ?>s linear infinite;animation-direction:<?= $dir ?>;">
        <?= $html ?>
        <?= $html ?>
    </div>
</div>

<style>
@keyframes wf-mq-scroll { from { transform: translateX(0); } to { transform: translateX(-50%); } }
#<?= esc_attr( $uid ) ?> .wf-sp-fig { margin: 0 <?= $half_gap ?>px; flex-shrink: 0; }
#<?= esc_attr( $uid ) ?> .wf-sp-fig img { height: <?= $img_h ?>px; width: auto; max-width: none; border-radius: <?= $radius ?>px !important; filter: <?= $filter ?>; transition: filter .3s ease; }
<?php if ( $col_hov ) : ?>
#<?= esc_attr( $uid ) ?> .wf-sp-fig:hover img { filter: grayscale(0); }
<?php endif; ?>
<?php if ( $hover ) : ?>
#<?= esc_attr( $uid ) ?>:hover .wf-mq-track { animation-play-state: paused; }
<?php endif; ?>
<?php if ( $has_mob_speed ) : ?>
@media (max-width:767px) { #<?= esc_attr( $uid ) ?> .wf-mq-track { animation-duration: <?= $speed_m ?>s !important; } }
<?php endif; ?>
@media (max-width:767px) { #<?= esc_attr( $uid ) ?> .wf-sp-fig img { height: <?= $img_h_m ?>px; } }
@media (prefers-reduced-motion: reduce) { #<?= esc_attr( $uid ) ?> .wf-mq-track { animation: none !important; } }
</style>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
