<?php
defined('ABSPATH') || exit;
$title = $props['title']??''; $content = $props['content']??''; $rich = $props['html_content']??'';
$img = $props['image']??''; $ialt = $props['image_alt']??'';
$bg = $props['bg_color']??'#f5f5f5'; $tc = $props['text_color']??'#000';
$cs = (int)($props['col_span']??1); $rs = (int)($props['row_span']??1);
$ta = $props['text_align']??'left'; $va = $props['vertical_align']??'end';
if ($img) { if (!preg_match('#^https?://#i',$img)) $img='/'.ltrim($img,'/'); }
$r = (int)($element['card_radius']??16); $p = (int)($element['card_padding']??32);
$pm = (int)($element['card_padding_mobile']??20);

// Contenu libre depose dans la carte (sublayout).
$wfInner = '';
if ( ! empty( $children ) ) {
	foreach ( $children as $wfI => $wfChild ) {
		$wfInner .= $builder->render( $wfChild, array( 'element' => $props, 'index' => $wfI ) );
	}
}
$uid = 'wfbi_'.substr(md5($title.$bg.$cs.$rs),0,6);
?>
<div id="<?= esc_attr($uid) ?>" style="grid-column:span <?= $cs ?>;grid-row:span <?= $rs ?>;background:<?= esc_attr($bg) ?>;color:<?= esc_attr($tc) ?>;border-radius:<?= $r ?>px;padding:<?= $p ?>px;display:flex;flex-direction:column;justify-content:<?= esc_attr($va) ?>;text-align:<?= esc_attr($ta) ?>;overflow:hidden;position:relative;">
    <?php if ($img) : ?>
    <img src="<?= esc_url($img) ?>" alt="<?= esc_attr($ialt) ?>" loading="lazy" style="position:absolute;top:0;left:0;width:100%;height:100%;object-fit:cover;z-index:0;">
    <div style="position:relative;z-index:1;">
    <?php endif; ?>
    <?php if ($title) : ?><div style="font-size:clamp(18px,2vw,28px);font-weight:700;line-height:1.2;margin-bottom:8px;"><?= esc_html($title) ?></div><?php endif; ?>
    <?php if ($content) : ?><p style="margin:0;font-size:15px;line-height:1.6;opacity:.8;"><?= esc_html($content) ?></p><?php endif; ?>
    <?php if ($rich) : ?><div style="margin-top:8px;"><?= $rich ?></div><?php endif; ?>
    <?php if ( '' !== trim( $wfInner ) ) : ?><div class="wf-free"><?= $wfInner ?></div><?php endif; ?>
    <?php if ($img) : ?></div><?php endif; ?>
</div>
<style>@media(max-width:767px){#<?= esc_attr($uid) ?>{grid-column:span 1 !important;grid-row:span 1 !important;padding:<?= $pm ?>px !important}}</style>
