<?php
/**
 * WeFrame - Trainee d'images (image enfant) | template.php v1.0
 * Le parent lit les proprietes de l'enfant ; l'enfant n'affiche rien seul.
 */
defined( 'ABSPATH' ) || exit;
echo '';
