<?php
/**
 * WeFrame – Floating Contact | template.php v1.0
 * Bouton flottant type "speed-dial" : WhatsApp, téléphone, email, itinéraire, retour haut.
 */
defined( 'ABSPATH' ) || exit;

$pos    = ( ( $props['position'] ?? 'br' ) === 'bl' ) ? 'bl' : 'br';
$offset = max( 8, (int) ( $props['offset'] ?? 24 ) );
$size   = max( 44, (int) ( $props['size'] ?? 58 ) );
$mcol   = $props['main_color'] ?? '#111111';
$open   = ( ( $props['open_on'] ?? 'click' ) === 'hover' ) ? 'hover' : 'click';
$labels = ! empty( $props['show_labels'] );

$items = array();

if ( ! empty( $props['wa_enable'] ) ) {
    $num = preg_replace( '/\D/', '', (string) ( $props['wa_number'] ?? '' ) );
    if ( $num ) {
        $href = 'https://wa.me/' . $num;
        $txt  = trim( (string) ( $props['wa_text'] ?? '' ) );
        if ( '' !== $txt ) { $href .= '?text=' . rawurlencode( $txt ); }
        $items[] = array( 'href' => $href, 'color' => '#25D366', 'label' => 'WhatsApp', 'target' => 1,
            'icon' => '<path d="M20.5 3.5A11 11 0 0 0 3.2 17L2 22l5.2-1.2A11 11 0 1 0 20.5 3.5zM12 20a8 8 0 0 1-4.1-1.1l-.3-.2-3 .7.7-2.9-.2-.3A8 8 0 1 1 12 20zm4.4-5.9c-.24-.12-1.43-.7-1.65-.78-.22-.08-.38-.12-.54.12-.16.24-.62.78-.76.94-.14.16-.28.18-.52.06a6.6 6.6 0 0 1-3.24-2.83c-.24-.42.24-.39.69-1.29.08-.16.04-.3-.02-.42-.06-.12-.54-1.3-.74-1.78-.2-.47-.4-.4-.54-.41h-.46c-.16 0-.42.06-.64.3-.22.24-.84.82-.84 2 0 1.18.86 2.32.98 2.48.12.16 1.7 2.6 4.12 3.64 1.53.66 2.13.72 2.9.6.47-.07 1.43-.58 1.63-1.15.2-.56.2-1.04.14-1.15-.06-.1-.22-.16-.46-.28z" fill="currentColor" stroke="none"/>' );
    }
}
if ( ! empty( $props['tel_enable'] ) ) {
    $tel = trim( (string) ( $props['tel_number'] ?? '' ) );
    if ( $tel ) {
        $items[] = array( 'href' => 'tel:' . preg_replace( '/[^0-9+]/', '', $tel ), 'color' => '#2563eb', 'label' => 'Appeler', 'target' => 0,
            'icon' => '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2 4.2 2 2 0 0 1 4 2h3a2 2 0 0 1 2 1.7c.1.9.3 1.8.6 2.6a2 2 0 0 1-.5 2.1L8 9.6a16 16 0 0 0 6 6l1.2-1.1a2 2 0 0 1 2.1-.5c.8.3 1.7.5 2.6.6a2 2 0 0 1 1.7 2z"/>' );
    }
}
if ( ! empty( $props['mail_enable'] ) ) {
    $mail = sanitize_email( (string) ( $props['mail_address'] ?? '' ) );
    if ( $mail ) {
        $items[] = array( 'href' => 'mailto:' . $mail, 'color' => '#6b7280', 'label' => 'Email', 'target' => 0,
            'icon' => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>' );
    }
}
if ( ! empty( $props['map_enable'] ) ) {
    $map = trim( (string) ( $props['map_url'] ?? '' ) );
    if ( $map ) {
        $items[] = array( 'href' => esc_url( $map ), 'color' => '#ea4335', 'label' => 'Itinéraire', 'target' => 1,
            'icon' => '<path d="M21 10c0 7-9 12-9 12s-9-5-9-12a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>' );
    }
}
if ( ! empty( $props['scrolltop_enable'] ) ) {
    $items[] = array( 'href' => '#', 'color' => $mcol, 'label' => 'Haut de page', 'target' => 0, 'top' => 1,
        'icon' => '<path d="M12 19V5M5 12l7-7 7 7"/>' );
}

if ( empty( $items ) ) { return; }

$uid  = wf_uid( 'wffc_', $props );
$side = ( 'bl' === $pos ) ? 'left:' . $offset . 'px;' : 'right:' . $offset . 'px;';
$isz  = (int) round( $size * 0.82 );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-fc wf-fc--<?= $pos ?>" data-open="<?= esc_attr( $open ) ?>" style="position:fixed;bottom:<?= $offset ?>px;<?= $side ?>z-index:99990;">
    <div class="wf-fc-items">
        <?php foreach ( $items as $it ) : ?>
        <a class="wf-fc-item" href="<?= esc_url( $it['href'] ) ?>"<?= ! empty( $it['target'] ) ? ' target="_blank" rel="noopener"' : '' ?><?= ! empty( $it['top'] ) ? ' data-top="1"' : '' ?>
           style="width:<?= $isz ?>px;height:<?= $isz ?>px;background:<?= esc_attr( $it['color'] ) ?>;" aria-label="<?= esc_attr( $it['label'] ) ?>">
            <?php if ( $labels ) : ?><span class="wf-fc-lbl"><?= esc_html( $it['label'] ) ?></span><?php endif; ?>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><?= $it['icon'] ?></svg>
        </a>
        <?php endforeach; ?>
    </div>
    <button type="button" class="wf-fc-main" aria-label="Contact" aria-expanded="false" style="width:<?= $size ?>px;height:<?= $size ?>px;background:<?= esc_attr( $mcol ) ?>;">
        <svg class="wf-fc-ic-open" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
        <svg class="wf-fc-ic-close" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
    </button>
</div>

<style>
#<?= esc_attr( $uid ) ?> .wf-fc-main{border:none;border-radius:50%;cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:0 6px 20px rgba(0,0,0,.28);transition:transform .2s;position:relative;z-index:2}
#<?= esc_attr( $uid ) ?> .wf-fc-main:hover{transform:scale(1.06)}
#<?= esc_attr( $uid ) ?> .wf-fc-ic-close{display:none}
#<?= esc_attr( $uid ) ?>.is-open .wf-fc-ic-open{display:none}
#<?= esc_attr( $uid ) ?>.is-open .wf-fc-ic-close{display:block}
#<?= esc_attr( $uid ) ?> .wf-fc-items{position:absolute;bottom:100%;<?= 'bl' === $pos ? 'left:0;' : 'right:0;' ?>display:flex;flex-direction:column;align-items:center;gap:12px;padding-bottom:14px}
#<?= esc_attr( $uid ) ?> .wf-fc-item{display:flex;align-items:center;justify-content:center;border-radius:50%;text-decoration:none;box-shadow:0 4px 14px rgba(0,0,0,.25);opacity:0;transform:translateY(14px) scale(.6);pointer-events:none;transition:opacity .25s,transform .25s;position:relative}
#<?= esc_attr( $uid ) ?>.is-open .wf-fc-item{opacity:1;transform:none;pointer-events:auto}
#<?= esc_attr( $uid ) ?> .wf-fc-item:nth-child(1){transition-delay:.02s}
#<?= esc_attr( $uid ) ?> .wf-fc-item:nth-child(2){transition-delay:.05s}
#<?= esc_attr( $uid ) ?> .wf-fc-item:nth-child(3){transition-delay:.08s}
#<?= esc_attr( $uid ) ?> .wf-fc-item:nth-child(4){transition-delay:.11s}
#<?= esc_attr( $uid ) ?> .wf-fc-item:nth-child(5){transition-delay:.14s}
#<?= esc_attr( $uid ) ?> .wf-fc-lbl{position:absolute;<?= 'bl' === $pos ? 'left:calc(100% + 10px);' : 'right:calc(100% + 10px);' ?>white-space:nowrap;background:rgba(17,17,17,.9);color:#fff;font-size:13px;font-weight:600;padding:5px 10px;border-radius:8px;opacity:0;transition:opacity .2s;pointer-events:none}
#<?= esc_attr( $uid ) ?> .wf-fc-item:hover .wf-fc-lbl{opacity:1}
@media (prefers-reduced-motion: reduce){#<?= esc_attr( $uid ) ?> .wf-fc-item{transition:opacity .2s}}
</style>

<script>
(function(){
    var id = <?= wp_json_encode( $uid ) ?>;
    function boot(){
        var el = document.getElementById(id); if (!el) return;
        var main = el.querySelector('.wf-fc-main');
        var mode = el.getAttribute('data-open');
        function open(){ el.classList.add('is-open'); main.setAttribute('aria-expanded','true'); }
        function close(){ el.classList.remove('is-open'); main.setAttribute('aria-expanded','false'); }
        function toggle(){ if (el.classList.contains('is-open')) { close(); } else { open(); } }

        main.addEventListener('click', toggle);
        if (mode === 'hover') {
            el.addEventListener('mouseenter', open);
            el.addEventListener('mouseleave', close);
        }
        document.addEventListener('click', function(e){ if (!el.contains(e.target)) { close(); } });

        var top = el.querySelector('.wf-fc-item[data-top="1"]');
        if (top) {
            top.addEventListener('click', function(e){ e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' }); close(); });
        }
    }
    if (window.WF) { if (WF.ready) { WF.ready(boot); return; } }
    if (document.readyState !== 'loading') { boot(); } else { document.addEventListener('DOMContentLoaded', boot); }
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
