<?php
/**
 * WeFrame – Switcher Pro | template.php v1.0
 * Onglets / pilules / liste / vignettes + bascule automatique en accordeon quand
 * l'element est trop etroit (mesure sur l'element, pas sur la fenetre).
 * Sans JS, tous les volets restent visibles : rien n'est perdu pour le referencement
 * ni pour un visiteur dont le script ne se charge pas.
 * Pas de "&&" ni de "||" dans le JS inline (regle interne du plugin).
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$navStyle = (string) ( $props['nav_style'] ?? 'tabs' );
if ( ! in_array( $navStyle, array( 'tabs', 'pills', 'list', 'numbers', 'dots', 'thumbs' ), true ) ) { $navStyle = 'tabs'; }
$navPos   = (string) ( $props['nav_position'] ?? 'top' );
if ( ! in_array( $navPos, array( 'top', 'bottom', 'left', 'right' ), true ) ) { $navPos = 'top'; }
$navAlign = (string) ( $props['nav_align'] ?? 'left' );
if ( ! in_array( $navAlign, array( 'left', 'center', 'right', 'stretch' ), true ) ) { $navAlign = 'left'; }

$navW     = max( 15, min( 60, (int) ( $props['nav_width'] ?? 32 ) ) );
$navGap   = max( 0, (int) ( $props['nav_gap'] ?? 6 ) );
$navRad   = max( 0, (int) ( $props['nav_radius'] ?? 10 ) );
$navPad   = max( 0, (int) ( $props['nav_padding'] ?? 12 ) );
$navSize  = max( 11, (int) ( $props['nav_size'] ?? 15 ) );
$navWeight = (string) ( $props['nav_weight'] ?? '600' );

$cIn      = (string) ( $props['nav_color'] ?? '#6b7280' );
$cAct     = (string) ( $props['nav_active_color'] ?? '#111111' );
$bgIn     = trim( (string) ( $props['nav_bg'] ?? '' ) );
$bgAct    = trim( (string) ( $props['nav_active_bg'] ?? '' ) );
$accent   = (string) ( $props['accent_color'] ?? '#EA5C1C' );
$showSub  = ! empty( $props['show_sublabel'] );
$thumbSz  = max( 32, (int) ( $props['thumb_size'] ?? 56 ) );

$pBg      = trim( (string) ( $props['panel_bg'] ?? '' ) );
$pCol     = trim( (string) ( $props['panel_color'] ?? '' ) );
$pPad     = max( 0, (int) ( $props['panel_padding'] ?? 24 ) );
$pRad     = max( 0, (int) ( $props['panel_radius'] ?? 12 ) );
$pBd      = trim( (string) ( $props['panel_border'] ?? '' ) );

$anim     = (string) ( $props['anim'] ?? 'fade' );
if ( ! in_array( $anim, array( 'fade', 'slide-h', 'slide-v', 'scale', 'none' ), true ) ) { $anim = 'fade'; }
$animMs   = max( 0, (int) ( $props['anim_duration'] ?? 380 ) );

$count    = count( $children );
$start    = max( 1, min( $count, (int) ( $props['start_index'] ?? 1 ) ) ) - 1;

$accOn    = ! empty( $props['accordion_mobile'] );
$accBp    = max( 320, (int) ( $props['accordion_bp'] ?? 640 ) );
$autoplay = ! empty( $props['autoplay'] );
$autoDel  = max( 2, (int) ( $props['autoplay_delay'] ?? 6 ) );
$pauseHov = ! empty( $props['pause_hover'] );
$swipe    = ! empty( $props['swipe'] );
$deeplink = ! empty( $props['deeplink'] );

$fromT    = array( 'fade' => '', 'slide-h' => 'transform:translateX(24px);', 'slide-v' => 'transform:translateY(18px);', 'scale' => 'transform:scale(.97);' );
$animFrom = isset( $fromT[ $anim ] ) ? $fromT[ $anim ] : '';

$uid = wf_uid( 'wfsw_', $props, $count );

// Rendu des volets + collecte des entrees de navigation, en une passe.
$panels = array();
$navs   = array();
foreach ( $children as $i => $child ) {
	$cp    = (array) ( $child->props ?? array() );
	$label = trim( (string) ( $cp['label'] ?? '' ) );
	if ( '' === $label ) { $label = sprintf( __( 'Volet %d', 'weframe' ), $i + 1 ); }
	$sub   = trim( (string) ( $cp['sublabel'] ?? '' ) );
	$badge = trim( (string) ( $cp['badge'] ?? '' ) );
	$alt   = trim( (string) ( $cp['image_alt'] ?? '' ) );

	$img = $cp['image'] ?? '';
	if ( is_array( $img ) ) { $img = $img['src'] ?? ( $img['url'] ?? '' ); }
	$img = trim( (string) $img );

	$slugSrc = trim( (string) ( $cp['anchor'] ?? '' ) );
	if ( '' === $slugSrc ) { $slugSrc = $label; }
	$slug = sanitize_title( $slugSrc );
	if ( '' === $slug ) { $slug = 'v' . ( $i + 1 ); }

	$navs[]   = array( 'label' => $label, 'sub' => $sub, 'badge' => $badge, 'img' => $img, 'alt' => $alt, 'slug' => $slug );
	$panels[] = $builder->render( $child, array( 'element' => $props, 'index' => $i ) );
}

$vertical = in_array( $navPos, array( 'left', 'right' ), true );
$rootCls  = 'wf-switcher wf-switcher--' . $navStyle . ' wf-switcher--' . $navPos;
if ( $accOn ) { $rootCls .= ' wf-switcher--foldable'; }

$justMap = array( 'left' => 'flex-start', 'center' => 'center', 'right' => 'flex-end', 'stretch' => 'stretch' );
$navJust = $justMap[ $navAlign ] ?? 'flex-start';
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="<?= esc_attr( $rootCls ) ?>" data-start="<?= (int) $start ?>">
	<div class="__nav" role="tablist"<?= $vertical ? ' aria-orientation="vertical"' : '' ?>>
		<?php foreach ( $navs as $i => $n ) : ?>
		<button type="button" class="__tab<?= $i === $start ? ' is-active' : '' ?>" role="tab"
			id="<?= esc_attr( $uid ) ?>-t<?= (int) $i ?>"
			aria-controls="<?= esc_attr( $uid ) ?>-p<?= (int) $i ?>"
			aria-selected="<?= $i === $start ? 'true' : 'false' ?>"
			tabindex="<?= $i === $start ? '0' : '-1' ?>"
			data-slug="<?= esc_attr( $n['slug'] ) ?>"
			<?= 'dots' === $navStyle ? ' aria-label="' . esc_attr( $n['label'] ) . '"' : '' ?>>
			<?php if ( 'thumbs' === $navStyle && '' !== $n['img'] ) : ?>
			<span class="__thumb"><img src="<?= esc_url( $n['img'] ) ?>" alt="<?= esc_attr( $n['alt'] ) ?>" loading="lazy" decoding="async"<?= '' === $n['alt'] ? ' aria-hidden="true"' : '' ?>></span>
			<?php endif; ?>
			<?php if ( 'dots' !== $navStyle ) : ?>
			<span class="__txt">
				<span class="__label"><?= esc_html( $n['label'] ) ?></span>
				<?php if ( $showSub && '' !== $n['sub'] ) : ?><span class="__sub"><?= esc_html( $n['sub'] ) ?></span><?php endif; ?>
			</span>
			<?php if ( '' !== $n['badge'] ) : ?><span class="__badge"><?= esc_html( $n['badge'] ) ?></span><?php endif; ?>
			<?php endif; ?>
		</button>
		<?php endforeach; ?>
	</div>

	<div class="__panels">
		<?php foreach ( $panels as $i => $html ) : ?>
		<section class="__pwrap<?= $i === $start ? ' is-active' : '' ?>">
			<?php if ( $accOn ) : ?>
			<button type="button" class="__fold" aria-expanded="<?= $i === $start ? 'true' : 'false' ?>" aria-controls="<?= esc_attr( $uid ) ?>-p<?= (int) $i ?>">
				<span class="__label"><?= esc_html( $navs[ $i ]['label'] ) ?></span>
				<?php if ( $showSub && '' !== $navs[ $i ]['sub'] ) : ?><span class="__sub"><?= esc_html( $navs[ $i ]['sub'] ) ?></span><?php endif; ?>
				<svg class="__chev" viewBox="0 0 256 256" width="18" height="18" fill="currentColor" aria-hidden="true" focusable="false"><path d="M213.66,101.66l-80,80a8,8,0,0,1-11.32,0l-80-80A8,8,0,0,1,53.66,90.34L128,164.69l74.34-74.35a8,8,0,0,1,11.32,11.32Z"/></svg>
			</button>
			<?php endif; ?>
			<div class="__panel" id="<?= esc_attr( $uid ) ?>-p<?= (int) $i ?>" role="tabpanel"
				aria-labelledby="<?= esc_attr( $uid ) ?>-t<?= (int) $i ?>" tabindex="0"><?= $html ?></div>
		</section>
		<?php endforeach; ?>
	</div>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?>{container-type:inline-size;display:block;}
#<?= esc_attr( $uid ) ?> .__nav{display:flex;gap:<?= (int) $navGap ?>px;<?= $vertical ? 'flex-direction:column;align-items:stretch;' : 'flex-wrap:wrap;justify-content:' . esc_attr( $navJust ) . ';' ?>}
<?php if ( ! $vertical && 'stretch' === $navAlign ) : ?>
#<?= esc_attr( $uid ) ?> .__nav .__tab{flex:1 1 0;}
<?php endif; ?>
#<?= esc_attr( $uid ) ?> .__tab{
	display:flex;align-items:center;gap:.6em;background:<?= '' !== $bgIn ? esc_attr( $bgIn ) : 'transparent' ?>;
	color:<?= esc_attr( $cIn ) ?>;border:0;cursor:pointer;font-family:inherit;
	font-size:<?= (int) $navSize ?>px;font-weight:<?= esc_attr( $navWeight ) ?>;line-height:1.25;
	padding:<?= (int) $navPad ?>px <?= (int) round( $navPad * 1.3 ) ?>px;border-radius:<?= (int) $navRad ?>px;
	transition:color .2s ease,background-color .2s ease,border-color .2s ease,opacity .2s ease;
	text-align:<?= $vertical ? 'left' : 'center' ?>;
	<?= $vertical ? 'justify-content:flex-start;' : 'justify-content:center;' ?>
}
#<?= esc_attr( $uid ) ?> .__tab .__txt{display:flex;flex-direction:column;gap:2px;min-width:0;}
#<?= esc_attr( $uid ) ?> .__sub{font-size:<?= max( 10, (int) round( $navSize * .78 ) ) ?>px;font-weight:400;opacity:.75;}
#<?= esc_attr( $uid ) ?> .__badge{
	margin-left:auto;font-size:<?= max( 9, (int) round( $navSize * .68 ) ) ?>px;font-weight:700;line-height:1;
	padding:.35em .6em;border-radius:100px;background:<?= esc_attr( $accent ) ?>;color:#fff;white-space:nowrap;
}
#<?= esc_attr( $uid ) ?> .__tab:hover{color:<?= esc_attr( $cAct ) ?>;}
#<?= esc_attr( $uid ) ?> .__tab:focus-visible{outline:2px solid <?= esc_attr( $accent ) ?>;outline-offset:2px;}
#<?= esc_attr( $uid ) ?> .__tab.is-active{color:<?= esc_attr( $cAct ) ?>;<?= '' !== $bgAct ? 'background:' . esc_attr( $bgAct ) . ';' : '' ?>}
@media (pointer:coarse){#<?= esc_attr( $uid ) ?> .__tab{min-height:44px;}}

<?php if ( 'tabs' === $navStyle ) : ?>
#<?= esc_attr( $uid ) ?> .__tab{border-radius:0;<?= $vertical ? 'border-left:2px solid transparent;' : 'border-bottom:2px solid transparent;' ?>}
#<?= esc_attr( $uid ) ?> .__tab.is-active{<?= $vertical ? 'border-left-color:' : 'border-bottom-color:' ?><?= esc_attr( $accent ) ?>;}
#<?= esc_attr( $uid ) ?> .__nav{gap:<?= (int) max( $navGap, 4 ) ?>px;<?= $vertical ? '' : 'border-bottom:1px solid rgba(127,127,127,.22);' ?>}
<?php elseif ( 'pills' === $navStyle ) : ?>
#<?= esc_attr( $uid ) ?> .__tab{background:<?= '' !== $bgIn ? esc_attr( $bgIn ) : 'rgba(127,127,127,.10)' ?>;}
#<?= esc_attr( $uid ) ?> .__tab.is-active{background:<?= '' !== $bgAct ? esc_attr( $bgAct ) : esc_attr( $accent ) ?>;color:<?= '' !== $bgAct ? esc_attr( $cAct ) : '#fff' ?>;}
<?php elseif ( 'list' === $navStyle ) : ?>
#<?= esc_attr( $uid ) ?> .__tab{width:100%;justify-content:flex-start;text-align:left;border-left:2px solid transparent;border-radius:0;}
#<?= esc_attr( $uid ) ?> .__tab.is-active{border-left-color:<?= esc_attr( $accent ) ?>;background:<?= '' !== $bgAct ? esc_attr( $bgAct ) : 'rgba(127,127,127,.08)' ?>;}
<?php elseif ( 'numbers' === $navStyle ) : ?>
#<?= esc_attr( $uid ) ?> .__nav{counter-reset:wfsw;}
#<?= esc_attr( $uid ) ?> .__tab{counter-increment:wfsw;}
#<?= esc_attr( $uid ) ?> .__tab::before{
	content:counter(wfsw,decimal-leading-zero);flex:0 0 auto;
	display:inline-flex;align-items:center;justify-content:center;
	width:2.1em;height:2.1em;border-radius:100px;border:1px solid currentColor;
	font-size:<?= max( 10, (int) round( $navSize * .78 ) ) ?>px;font-weight:700;opacity:.65;
}
#<?= esc_attr( $uid ) ?> .__tab.is-active::before{background:<?= esc_attr( $accent ) ?>;border-color:<?= esc_attr( $accent ) ?>;color:#fff;opacity:1;}
<?php elseif ( 'dots' === $navStyle ) : ?>
#<?= esc_attr( $uid ) ?> .__nav{justify-content:<?= $vertical ? 'flex-start' : esc_attr( $navJust ) ?>;align-items:center;}
#<?= esc_attr( $uid ) ?> .__tab{width:12px;height:12px;padding:0;border-radius:100px;background:rgba(127,127,127,.35);flex:0 0 auto;}
#<?= esc_attr( $uid ) ?> .__tab.is-active{background:<?= esc_attr( $accent ) ?>;transform:scale(1.25);}
@media (pointer:coarse){
	#<?= esc_attr( $uid ) ?> .__tab{min-height:0;position:relative;}
	#<?= esc_attr( $uid ) ?> .__tab::after{content:"";position:absolute;inset:-16px;}
}
<?php elseif ( 'thumbs' === $navStyle ) : ?>
#<?= esc_attr( $uid ) ?> .__tab{flex-direction:<?= $vertical ? 'row' : 'column' ?>;align-items:center;gap:.5em;padding:<?= (int) max( 6, round( $navPad * .6 ) ) ?>px;}
#<?= esc_attr( $uid ) ?> .__thumb{
	display:block;flex:0 0 auto;width:<?= (int) $thumbSz ?>px;height:<?= (int) $thumbSz ?>px;
	border-radius:<?= (int) min( $navRad, round( $thumbSz / 2 ) ) ?>px;overflow:hidden;
	box-shadow:0 0 0 2px transparent;transition:box-shadow .2s ease;
}
#<?= esc_attr( $uid ) ?> .__thumb img{width:100%;height:100%;object-fit:cover;display:block;}
#<?= esc_attr( $uid ) ?> .__tab.is-active .__thumb{box-shadow:0 0 0 2px <?= esc_attr( $accent ) ?>;}
#<?= esc_attr( $uid ) ?> .__tab .__txt{text-align:<?= $vertical ? 'left' : 'center' ?>;}
<?php endif; ?>

<?php if ( $vertical ) : ?>
#<?= esc_attr( $uid ) ?>{display:grid;gap:<?= (int) max( 16, $navGap * 3 ) ?>px;align-items:start;
	grid-template-columns:<?= 'left' === $navPos ? (int) $navW . '% 1fr' : '1fr ' . (int) $navW . '%' ?>;}
#<?= esc_attr( $uid ) ?> .__nav{<?= 'right' === $navPos ? 'order:2;' : 'order:1;' ?>}
#<?= esc_attr( $uid ) ?> .__panels{<?= 'right' === $navPos ? 'order:1;' : 'order:2;' ?>min-width:0;}
<?php else : ?>
#<?= esc_attr( $uid ) ?>{display:flex;flex-direction:column;gap:<?= (int) max( 12, $navGap * 2 ) ?>px;}
#<?= esc_attr( $uid ) ?> .__nav{<?= 'bottom' === $navPos ? 'order:2;' : 'order:1;' ?>}
#<?= esc_attr( $uid ) ?> .__panels{<?= 'bottom' === $navPos ? 'order:1;' : 'order:2;' ?>min-width:0;}
<?php endif; ?>

#<?= esc_attr( $uid ) ?> .__panel{
	<?= '' !== $pBg ? 'background:' . esc_attr( $pBg ) . ';' : '' ?>
	<?= '' !== $pCol ? 'color:' . esc_attr( $pCol ) . ';' : '' ?>
	<?= $pPad > 0 ? 'padding:' . (int) $pPad . 'px;' : '' ?>
	border-radius:<?= (int) $pRad ?>px;
	<?= '' !== $pBd ? 'border:1px solid ' . esc_attr( $pBd ) . ';' : '' ?>
}
#<?= esc_attr( $uid ) ?> .__panel:focus-visible{outline:2px solid <?= esc_attr( $accent ) ?>;outline-offset:2px;}
#<?= esc_attr( $uid ) ?> .__pwrap + .__pwrap{margin-top:<?= (int) max( 8, $navGap ) ?>px;}
#<?= esc_attr( $uid ) ?>.is-ready .__pwrap + .__pwrap{margin-top:0;}
#<?= esc_attr( $uid ) ?>.is-ready.is-fold .__pwrap + .__pwrap{margin-top:<?= (int) max( 8, $navGap ) ?>px;}

/* Sans JS : tout est visible. Le script ne masque qu'apres avoir pris la main. */
#<?= esc_attr( $uid ) ?> .__fold{display:none;}
#<?= esc_attr( $uid ) ?>.is-ready .__panel[hidden]{display:none;}
#<?= esc_attr( $uid ) ?>.is-ready.is-fold .__nav{display:none;}
#<?= esc_attr( $uid ) ?>.is-ready.is-fold .__fold{
	display:flex;align-items:center;gap:.6em;width:100%;text-align:left;cursor:pointer;
	background:<?= '' !== $bgIn ? esc_attr( $bgIn ) : 'transparent' ?>;color:<?= esc_attr( $cIn ) ?>;
	border:0;border-bottom:1px solid rgba(127,127,127,.22);font-family:inherit;
	font-size:<?= (int) $navSize ?>px;font-weight:<?= esc_attr( $navWeight ) ?>;
	padding:<?= (int) max( 12, $navPad ) ?>px 0;min-height:44px;
}
#<?= esc_attr( $uid ) ?>.is-ready.is-fold .__fold .__sub{margin-left:.6em;}
#<?= esc_attr( $uid ) ?>.is-ready.is-fold .__fold .__chev{margin-left:auto;transition:transform .25s ease;}
#<?= esc_attr( $uid ) ?>.is-ready.is-fold .__fold[aria-expanded="true"]{color:<?= esc_attr( $cAct ) ?>;}
#<?= esc_attr( $uid ) ?>.is-ready.is-fold .__fold[aria-expanded="true"] .__chev{transform:rotate(180deg);}
#<?= esc_attr( $uid ) ?>.is-ready.is-fold .__panel{padding-left:0;padding-right:0;border:0;background:none;}

<?php if ( 'none' !== $anim && $animMs > 0 ) : ?>
#<?= esc_attr( $uid ) ?>.is-ready .__panel.is-enter{animation:<?= esc_attr( $uid ) ?>-in <?= (int) $animMs ?>ms cubic-bezier(.2,.8,.2,1) both;}
@keyframes <?= esc_attr( $uid ) ?>-in{
	from{opacity:0;<?= $animFrom ?>}
	to{opacity:1;transform:none;}
}
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?>.is-ready .__panel.is-enter{animation-duration:.001ms;}
}
<?php endif; ?>

/* Pose par le script (ResizeObserver) : une container query ne s'applique pas
   au conteneur qui la declare. La mesure porte sur l'element, pas sur la fenetre. */
#<?= esc_attr( $uid ) ?>.is-narrow{display:flex;flex-direction:column;}
</style>

<script>
(function(){
	var root = document.getElementById('<?= esc_js( $uid ) ?>');
	if (!root) { return; }
	var tabs   = [].slice.call(root.querySelectorAll('.__tab'));
	var wraps  = [].slice.call(root.querySelectorAll('.__pwrap'));
	var folds  = [].slice.call(root.querySelectorAll('.__fold'));
	var panels = wraps.map(function(w){ return w.querySelector('.__panel'); });
	if (!tabs.length) { return; }

	var current = parseInt(root.getAttribute('data-start'), 10);
	if (isNaN(current)) { current = 0; }
	var foldMode = false;
	var animate  = <?= ( 'none' !== $anim && $animMs > 0 ) ? 'true' : 'false' ?>;

	function paint(i, focusPanel){
		current = i;
		for (var k = 0; k < tabs.length; k++) {
			var on = (k === i);
			tabs[k].classList.toggle('is-active', on);
			tabs[k].setAttribute('aria-selected', on ? 'true' : 'false');
			tabs[k].setAttribute('tabindex', on ? '0' : '-1');
			wraps[k].classList.toggle('is-active', on);
			if (folds[k]) { folds[k].setAttribute('aria-expanded', on ? 'true' : 'false'); }
			if (!panels[k]) { continue; }
			panels[k].hidden = !on;
			panels[k].classList.remove('is-enter');
			if (on) {
				if (animate) {
					// reflow force le redemarrage de l'animation
					void panels[k].offsetWidth;
					panels[k].classList.add('is-enter');
				}
			}
		}
		if (focusPanel) {
			if (panels[i]) { panels[i].focus({ preventScroll: true }); }
		}
<?php if ( $deeplink ) : ?>
		var slug = tabs[i].getAttribute('data-slug');
		if (slug) {
			try { history.replaceState(null, '', '#' + slug); } catch (err) {}
		}
<?php endif; ?>
	}

	function go(i, focusPanel){
		if (i < 0) { i = tabs.length - 1; }
		if (i >= tabs.length) { i = 0; }
		paint(i, focusPanel);
	}

	for (var t = 0; t < tabs.length; t++) {
		(function(idx){
			tabs[idx].addEventListener('click', function(){ stop(); go(idx, false); });
			tabs[idx].addEventListener('keydown', function(e){
				var k = e.key;
				var next = null;
				var horiz = <?= $vertical ? 'false' : 'true' ?>;
				if (k === 'ArrowRight') { if (horiz) { next = idx + 1; } }
				if (k === 'ArrowLeft')  { if (horiz) { next = idx - 1; } }
				if (k === 'ArrowDown')  { if (!horiz) { next = idx + 1; } }
				if (k === 'ArrowUp')    { if (!horiz) { next = idx - 1; } }
				if (k === 'Home') { next = 0; }
				if (k === 'End')  { next = tabs.length - 1; }
				if (next === null) { return; }
				e.preventDefault();
				stop();
				if (next < 0) { next = tabs.length - 1; }
				if (next >= tabs.length) { next = 0; }
				go(next, false);
				tabs[next].focus();
			});
		})(t);
	}

	for (var f = 0; f < folds.length; f++) {
		(function(idx){
			folds[idx].addEventListener('click', function(){
				stop();
				if (current === idx) {
					// en accordeon, refermer le volet ouvert est attendu
					var p = panels[idx];
					var open = folds[idx].getAttribute('aria-expanded') === 'true';
					folds[idx].setAttribute('aria-expanded', open ? 'false' : 'true');
					if (p) { p.hidden = open; }
					return;
				}
				go(idx, false);
			});
		})(f);
	}

	function measure(){
		var wide = root.clientWidth > <?= (int) $accBp ?>;
		var want = !wide;
		root.classList.toggle('is-narrow', want);
		if (want === foldMode) { return; }
		foldMode = <?= $accOn ? 'want' : 'false' ?>;
		root.classList.toggle('is-fold', foldMode);
		if (!<?= $accOn ? 'true' : 'false' ?>) { return; }
		// Les roles ARIA d'onglets n'ont plus de sens sans liste d'onglets visible.
		for (var k = 0; k < panels.length; k++) {
			if (!panels[k]) { continue; }
			if (foldMode) {
				panels[k].removeAttribute('role');
				panels[k].removeAttribute('aria-labelledby');
				panels[k].removeAttribute('tabindex');
			} else {
				panels[k].setAttribute('role', 'tabpanel');
				panels[k].setAttribute('aria-labelledby', tabs[k].id);
				panels[k].setAttribute('tabindex', '0');
			}
		}
	}
	if (window.ResizeObserver) {
		new ResizeObserver(measure).observe(root);
	} else {
		window.addEventListener('resize', measure);
	}
	measure();

<?php if ( $swipe ) : ?>
	var sx = 0, sy = 0, tracking = false;
	root.addEventListener('touchstart', function(e){
		if (foldMode) { return; }
		if (e.touches.length !== 1) { return; }
		sx = e.touches[0].clientX; sy = e.touches[0].clientY; tracking = true;
	}, { passive: true });
	root.addEventListener('touchend', function(e){
		if (!tracking) { return; }
		tracking = false;
		var dx = e.changedTouches[0].clientX - sx;
		var dy = e.changedTouches[0].clientY - sy;
		if (Math.abs(dx) < 50) { return; }
		if (Math.abs(dx) < Math.abs(dy) * 1.5) { return; }
		stop();
		go(dx < 0 ? current + 1 : current - 1, false);
	}, { passive: true });
<?php endif; ?>

	var timer = null;
	function stop(){
		if (!timer) { return; }
		clearInterval(timer);
		timer = null;
	}
<?php if ( $autoplay ) : ?>
	function play(){
		var reduced = false;
		if (window.matchMedia) {
			if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { reduced = true; }
		}
		if (reduced) { return; }
		stop();
		timer = setInterval(function(){ go(current + 1, false); }, <?= (int) $autoDel ?> * 1000);
	}
<?php if ( $pauseHov ) : ?>
	root.addEventListener('mouseenter', function(){ if (timer) { clearInterval(timer); timer = null; } });
	root.addEventListener('mouseleave', play);
	root.addEventListener('focusin', function(){ if (timer) { clearInterval(timer); timer = null; } });
<?php endif; ?>
	play();
<?php endif; ?>

<?php if ( $deeplink ) : ?>
	(function(){
		var h = location.hash ? location.hash.replace('#', '') : '';
		if (!h) { return; }
		for (var k = 0; k < tabs.length; k++) {
			if (tabs[k].getAttribute('data-slug') === h) { current = k; return; }
		}
	})();
<?php endif; ?>

	root.classList.add('is-ready');
	paint(current, false);
})();
</script>
