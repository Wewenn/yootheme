<?php
/**
 * WeFrame – Aperçus au survol | template.php
 *
 * Un paragraphe dont certains mots, écrits entre crochets, ouvrent une petite
 * carte au survol : image, titre, description. Les cartes sont des items, le
 * texte reste un texte — les moteurs de recherche lisent la phrase entière.
 */
defined( 'ABSPATH' ) || exit;

$props = is_array( $props ?? null ) ? $props : array();

$text = (string) ( $props['text'] ?? '' );
if ( '' === trim( $text ) ) { return; }

// Les mots des items servent à relier « [Midjourney] » à sa carte.
$mots  = array();
$cards = '';
if ( ! empty( $children ) ) {
	if ( is_array( $children ) ) {
		foreach ( $children as $child ) {
			$cp = isset( $child['props'] ) ? (array) $child['props'] : array();
			$un = (string) $builder->render( $child, array( 'element' => $props ) );
			if ( '' === trim( $un ) ) { continue; }
			$mots[] = mb_strtolower( trim( (string) ( $cp['word'] ?? '' ) ), 'UTF-8' );
			$cards .= $un;
		}
	}
}

$tag = (string) ( $props['tag'] ?? 'p' );
if ( ! in_array( $tag, array( 'p', 'div', 'h2', 'h3' ), true ) ) { $tag = 'p'; }

$size   = max( 10, min( 90, (int) ( $props['size'] ?? 26 ) ) );
$sizem  = max( 10, min( 60, (int) ( $props['size_mobile'] ?? 19 ) ) );
$lh     = max( 100, min( 250, (int) ( $props['line_height'] ?? 160 ) ) ) / 100;
$col    = (string) ( $props['color'] ?? '#9ca3af' );
$wcol   = (string) ( $props['word_color'] ?? '#111827' );
$align  = 'center' === ( $props['align'] ?? 'left' ) ? 'center' : 'left';
$under  = ! empty( $props['underline'] );

$cpos   = 'below' === ( $props['card_pos'] ?? 'above' ) ? 'below' : 'above';
$cw     = max( 140, min( 520, (int) ( $props['card_w'] ?? 260 ) ) );
$cih    = max( 0, min( 400, (int) ( $props['card_image_h'] ?? 130 ) ) );
$cbg    = (string) ( $props['card_bg'] ?? '#16181d' );
$crad   = max( 0, min( 40, (int) ( $props['card_radius'] ?? 14 ) ) );
$ctcol  = (string) ( $props['card_title_color'] ?? '#ffffff' );
$cdcol  = (string) ( $props['card_text_color'] ?? '#9ca3af' );

$uid = wf_uid( 'wfhp_', $props, $cards );

/**
 * Remplace « [mot] » par une accroche numérotée. Un mot sans carte reste
 * simplement mis en avant : on ne fabrique jamais un survol qui n'ouvre rien.
 */
$rendu = static function ( $ligne ) use ( $mots ) {
	return preg_replace_callback(
		'/\[([^\]\[]{1,80})\]/u',
		static function ( $m ) use ( $mots ) {
			$brut = trim( $m[1] );
			$cle  = mb_strtolower( $brut, 'UTF-8' );
			$i    = array_search( $cle, $mots, true );
			if ( false === $i ) {
				return '<span class="wf-hp-w is-plain">' . esc_html( $brut ) . '</span>';
			}
			return '<span class="wf-hp-w" data-i="' . (int) $i . '" tabindex="0" role="button" aria-expanded="false">'
				. esc_html( $brut ) . '</span>';
		},
		$ligne
	);
};

$paras = preg_split( '/\R\s*\R/u', trim( $text ) );
$corps = '';
foreach ( $paras as $p ) {
	$p = trim( $p );
	if ( '' === $p ) { continue; }
	$corps .= '<' . $tag . ' class="wf-hp-p">' . $rendu( nl2br( esc_html( $p ) ) ) . '</' . $tag . '>';
}
if ( '' === $corps ) { return; }

$cfg = wp_json_encode( array(
	'uid' => $uid,
	'pos' => $cpos,
), JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-hp">
	<div class="wf-hp-txt"><?= $corps ?></div>
	<?php if ( '' !== $cards ) : ?><div class="wf-hp-cards"><?= $cards ?></div><?php endif; ?>
</div>

<style>
#<?= esc_attr( $uid ) ?>{position:relative;}
#<?= esc_attr( $uid ) ?> .wf-hp-p{margin:0 0 1em;font-size:<?= $size ?>px;line-height:<?= $lh ?>;color:<?= esc_attr( $col ) ?>;text-align:<?= $align ?>;}
#<?= esc_attr( $uid ) ?> .wf-hp-p:last-child{margin-bottom:0;}
#<?= esc_attr( $uid ) ?> .wf-hp-w{color:<?= esc_attr( $wcol ) ?>;font-weight:700;cursor:pointer;<?= $under ? 'text-decoration:underline;text-underline-offset:3px;text-decoration-thickness:2px;' : '' ?>border-radius:4px;transition:opacity .2s ease;}
#<?= esc_attr( $uid ) ?> .wf-hp-w.is-plain{cursor:inherit;}
#<?= esc_attr( $uid ) ?> .wf-hp-w:focus-visible{outline:2px solid <?= esc_attr( $wcol ) ?>;outline-offset:2px;}
#<?= esc_attr( $uid ) ?> .wf-hp-cards{position:absolute;inset:0;pointer-events:none;z-index:5;}
#<?= esc_attr( $uid ) ?> .wf-hp-card{position:absolute;left:0;top:0;width:<?= $cw ?>px;padding:10px;border-radius:<?= $crad ?>px;background:<?= esc_attr( $cbg ) ?>;box-shadow:0 24px 50px rgba(0,0,0,.35);opacity:0;visibility:hidden;transform:translateY(<?= 'above' === $cpos ? '8px' : '-8px' ?>) scale(.97);transition:opacity .22s ease,transform .22s cubic-bezier(.16,1,.3,1),visibility .22s;text-decoration:none;display:block;}
#<?= esc_attr( $uid ) ?> .wf-hp-card.is-on{opacity:1;visibility:visible;transform:none;pointer-events:auto;}
<?php if ( $cih > 0 ) : ?>
#<?= esc_attr( $uid ) ?> .wf-hp-img{display:block;width:100%;height:<?= $cih ?>px;border-radius:<?= max( 0, $crad - 5 ) ?>px;overflow:hidden;background:#23262d;}
#<?= esc_attr( $uid ) ?> .wf-hp-img img{width:100%;height:100%;object-fit:cover;display:block;}
<?php endif; ?>
#<?= esc_attr( $uid ) ?> .wf-hp-ct{display:block;margin-top:10px;font-size:15px;font-weight:600;line-height:1.3;color:<?= esc_attr( $ctcol ) ?>;}
#<?= esc_attr( $uid ) ?> .wf-hp-cd{display:block;margin-top:4px;font-size:13px;line-height:1.45;color:<?= esc_attr( $cdcol ) ?>;}
@media(max-width:640px){#<?= esc_attr( $uid ) ?> .wf-hp-p{font-size:<?= $sizem ?>px;}}
</style>

<script>
(function(){
	var C = <?= $cfg ?>;
	function boot(){
		var el = document.getElementById(C.uid); if (!el) { return; }
		var words = el.querySelectorAll('.wf-hp-w[data-i]');
		var cards = el.querySelectorAll('.wf-hp-card');
		if (!words.length) { return; }
		if (!cards.length) { return; }

		var open = null, tmo = 0;

		function hide(){
			if (tmo) { clearTimeout(tmo); tmo = 0; }
			for (var i = 0; i < cards.length; i++) { cards[i].classList.remove('is-on'); }
			for (var j = 0; j < words.length; j++) { words[j].setAttribute('aria-expanded', 'false'); }
			open = null;
		}

		function show(w){
			var i = parseInt(w.getAttribute('data-i'), 10);
			var card = cards[i];
			if (!card) { return; }
			if (open === card) { return; }
			hide();
			open = card;
			var box = el.getBoundingClientRect();
			var r = w.getBoundingClientRect();
			card.classList.add('is-on');
			var cw = card.offsetWidth;
			var ch = card.offsetHeight;
			var x = (r.left - box.left) + r.width / 2 - cw / 2;
			var maxX = box.width - cw;
			if (x < 0) { x = 0; }
			if (maxX < 0) { maxX = 0; }
			if (x > maxX) { x = maxX; }
			var y;
			if (C.pos === 'below') { y = (r.bottom - box.top) + 12; }
			else { y = (r.top - box.top) - ch - 12; }
			card.style.left = Math.round(x) + 'px';
			card.style.top  = Math.round(y) + 'px';
			w.setAttribute('aria-expanded', 'true');
		}

		for (var k = 0; k < words.length; k++) {
			(function(w){
				w.addEventListener('pointerenter', function(){ show(w); });
				w.addEventListener('focus', function(){ show(w); });
				w.addEventListener('pointerleave', function(){
					tmo = setTimeout(hide, 120);
				});
				w.addEventListener('blur', hide);
				w.addEventListener('click', function(e){
					if (open) { e.preventDefault(); }
					show(w);
				});
				w.addEventListener('keydown', function(e){
					if (e.key === 'Escape') { hide(); }
				});
			})(words[k]);
		}

		for (var m = 0; m < cards.length; m++) {
			(function(c){
				c.addEventListener('pointerenter', function(){ if (tmo) { clearTimeout(tmo); tmo = 0; } });
				c.addEventListener('pointerleave', hide);
			})(cards[m]);
		}

		document.addEventListener('click', function(e){
			if (el.contains(e.target)) { return; }
			hide();
		});
		window.addEventListener('resize', hide);
	}
	if (window.WF) { if (WF.ready) { WF.ready(boot); return; } }
	if (document.readyState !== 'loading') { boot(); } else { document.addEventListener('DOMContentLoaded', boot); }
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
