<?php
/**
 * WeFrame – Trame de points | template.php
 *
 * Fond de section : une grille de points dont le diamètre grandit vers un
 * halo (centre du bloc, haut du bloc, ou la souris). Un clic envoie une onde
 * qui fait gonfler les points sur son passage. Le contenu déposé dans
 * l'élément se pose par-dessus.
 */
defined( 'ABSPATH' ) || exit;

$props = is_array( $props ?? null ) ? $props : array();

$inner = '';
if ( isset( $builder ) && is_object( $builder ) ) {
	if ( ! empty( $children ) ) {
		if ( is_array( $children ) ) {
			foreach ( $children as $child ) {
				$inner .= (string) $builder->render( $child, array( 'element' => $props ) );
			}
		}
	}
}

$bg      = (string) ( $props['bg'] ?? '#ffffff' );
$dotCol  = (string) ( $props['dot_color'] ?? '#111827' );
$gap     = max( 6, min( 90, (int) ( $props['gap'] ?? 26 ) ) );
$dmin    = max( 0, min( 20, (float) ( $props['dot_min'] ?? 1 ) ) );
$dmax    = max( 0.5, min( 24, (float) ( $props['dot_max'] ?? 4 ) ) );
if ( $dmax < $dmin ) { $dmax = $dmin; }
$op      = max( 5, min( 100, (int) ( $props['opacity'] ?? 55 ) ) ) / 100;
$focus   = (string) ( $props['focus'] ?? 'center' );
if ( ! in_array( $focus, array( 'center', 'top', 'mouse', 'none' ), true ) ) { $focus = 'center'; }
$halo    = max( 10, min( 150, (int) ( $props['halo'] ?? 55 ) ) ) / 100;
$ripple  = ! empty( $props['ripple'] );
$ripCol  = trim( (string) ( $props['ripple_color'] ?? '' ) );
if ( '' === $ripCol ) { $ripCol = $dotCol; }
$minH    = max( 0, min( 1600, (int) ( $props['min_height'] ?? 520 ) ) );
$pad     = max( 0, min( 160, (int) ( $props['padding'] ?? 48 ) ) );
$align   = 'left' === ( $props['content_align'] ?? 'center' ) ? 'left' : 'center';
$cw      = max( 200, min( 1600, (int) ( $props['content_width'] ?? 640 ) ) );

$uid = wf_uid( 'wfdm_', $props, $inner );

$cfg = wp_json_encode( array(
	'uid'    => $uid,
	'gap'    => $gap,
	'min'    => $dmin,
	'max'    => $dmax,
	'op'     => $op,
	'color'  => $dotCol,
	'focus'  => $focus,
	'halo'   => $halo,
	'ripple' => $ripple ? 1 : 0,
	'rcolor' => $ripCol,
), JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-dm">
	<canvas class="wf-dm-cv" aria-hidden="true"></canvas>
	<div class="wf-dm-in"><?= $inner ?></div>
</div>

<style>
#<?= esc_attr( $uid ) ?>{position:relative;isolation:isolate;background:<?= esc_attr( $bg ) ?>;<?= $minH > 0 ? 'min-height:' . $minH . 'px;' : '' ?>padding:<?= $pad ?>px;display:flex;align-items:center;justify-content:<?= 'left' === $align ? 'flex-start' : 'center' ?>;overflow:hidden;}
#<?= esc_attr( $uid ) ?> .wf-dm-cv{position:absolute;inset:0;width:100%;height:100%;display:block;z-index:0;pointer-events:none;}
#<?= esc_attr( $uid ) ?> .wf-dm-in{position:relative;z-index:1;width:100%;max-width:<?= $cw ?>px;text-align:<?= $align ?>;}
@media(max-width:640px){#<?= esc_attr( $uid ) ?>{padding:<?= max( 16, (int) round( $pad * 0.6 ) ) ?>px;}}
</style>

<script>
(function(){
	var C = <?= $cfg ?>;
	function boot(){
		var el = document.getElementById(C.uid); if (!el) { return; }
		var cv = el.querySelector('.wf-dm-cv'); if (!cv) { return; }
		var ctx = cv.getContext ? cv.getContext('2d') : null; if (!ctx) { return; }

		var calm = false;
		if (window.matchMedia) { if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { calm = true; } }

		var w = 0, h = 0, dpr = 1;
		var fx = 0, fy = 0;          // centre du halo
		var rip = null;              // onde en cours
		var raf = 0, pending = 0;

		function focusPoint(){
			if (C.focus === 'top')  { fx = w / 2; fy = h * 0.18; return; }
			if (C.focus === 'mouse'){ return; }
			fx = w / 2; fy = h / 2;
		}

		function size(){
			var r = el.getBoundingClientRect();
			w = Math.max(1, Math.round(r.width));
			h = Math.max(1, Math.round(r.height));
			dpr = Math.min(2, window.devicePixelRatio ? window.devicePixelRatio : 1);
			cv.width  = Math.round(w * dpr);
			cv.height = Math.round(h * dpr);
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
			focusPoint();
		}

		function paint(){
			ctx.clearRect(0, 0, w, h);
			var span = Math.max(w, h);
			var R = C.halo * span;
			var mid = (C.min + C.max) / 2;
			var band = 90;
			var ringR = 0, fade = 0;
			if (rip) { ringR = rip.r; fade = rip.fade; }

			ctx.globalAlpha = C.op;
			ctx.fillStyle = C.color;
			var half = C.gap / 2;
			for (var y = half; y < h; y += C.gap) {
				for (var x = half; x < w; x += C.gap) {
					var rad;
					if (C.focus === 'none') {
						rad = mid;
					} else {
						var ddx = x - fx, ddy = y - fy;
						var d = Math.sqrt(ddx * ddx + ddy * ddy);
						var t = 1 - d / R;
						if (t < 0) { t = 0; }
						if (t > 1) { t = 1; }
						rad = C.min + (C.max - C.min) * t * t;
					}
					if (rip) {
						var rx = x - rip.x, ry = y - rip.y;
						var rd = Math.abs(Math.sqrt(rx * rx + ry * ry) - ringR);
						if (rd < band) { rad += (C.max - C.min + 1.5) * (1 - rd / band) * fade; }
					}
					if (rad < 0.2) { continue; }
					ctx.beginPath();
					ctx.arc(x, y, rad, 0, 6.2832);
					ctx.fill();
				}
			}
			ctx.globalAlpha = 1;
		}

		function ask(){
			if (pending) { return; }
			pending = 1;
			requestAnimationFrame(function(){ pending = 0; paint(); });
		}

		function wave(t){
			if (!rip) { raf = 0; return; }
			var age = t - rip.t0;
			var life = 1100;
			if (age > life) { rip = null; paint(); raf = 0; return; }
			rip.r = (age / life) * Math.max(w, h) * 1.15;
			rip.fade = 1 - age / life;
			paint();
			raf = requestAnimationFrame(wave);
		}

		if (C.focus === 'mouse') {
			fx = -9999; fy = -9999;
			if (!calm) {
				el.addEventListener('pointermove', function(e){
					var r = el.getBoundingClientRect();
					fx = e.clientX - r.left; fy = e.clientY - r.top;
					ask();
				});
				el.addEventListener('pointerleave', function(){ fx = w / 2; fy = h / 2; ask(); });
			}
		}

		if (C.ripple) {
			if (!calm) {
				el.addEventListener('pointerdown', function(e){
					if (e.target.closest) { if (e.target.closest('a,button,input,select,textarea')) { return; } }
					var r = el.getBoundingClientRect();
					rip = { x: e.clientX - r.left, y: e.clientY - r.top, r: 0, fade: 1, t0: performance.now() };
					if (!raf) { raf = requestAnimationFrame(wave); }
				});
			}
		}

		var tmo = 0;
		function relayout(){ size(); paint(); }
		window.addEventListener('resize', function(){
			clearTimeout(tmo);
			tmo = setTimeout(relayout, 150);
		});
		if (window.ResizeObserver) {
			var ro = new ResizeObserver(function(){
				clearTimeout(tmo);
				tmo = setTimeout(relayout, 150);
			});
			ro.observe(el);
		}
		relayout();
	}
	if (window.WF) { if (WF.ready) { WF.ready(boot); return; } }
	if (document.readyState !== 'loading') { boot(); } else { document.addEventListener('DOMContentLoaded', boot); }
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
