<?php
/**
 * WeFrame – Aperçus au survol : carte (item).
 */
defined( 'ABSPATH' ) || exit;

$props = is_array( $props ?? null ) ? $props : array();

$word  = trim( (string) ( $props['word'] ?? '' ) );
$title = trim( (string) ( $props['title'] ?? '' ) );
$desc  = trim( (string) ( $props['description'] ?? '' ) );

$img = trim( (string) ( $props['image'] ?? '' ) );
if ( '' !== $img ) {
	if ( ! preg_match( '#^https?://#i', $img ) ) { $img = '/' . ltrim( $img, '/' ); }
}

if ( '' === $title ) { if ( '' === $desc ) { if ( '' === $img ) { return; } } }

$link = $props['link'] ?? '';
if ( is_array( $link ) ) { $link = $link['url'] ?? ''; }
$link = (string) $link;

$tag  = '' !== $link ? 'a' : 'div';
$href = '' !== $link ? ' href="' . esc_url( $link ) . '"' : '';
?>
<<?= $tag ?> class="wf-hp-card"<?= $href ?> data-word="<?= esc_attr( mb_strtolower( $word, 'UTF-8' ) ) ?>" aria-hidden="true">
	<?php if ( '' !== $img ) : ?><span class="wf-hp-img"><img src="<?= esc_url( $img ) ?>" alt="" loading="lazy"></span><?php endif; ?>
	<?php if ( '' !== $title ) : ?><span class="wf-hp-ct"><?= esc_html( $title ) ?></span><?php endif; ?>
	<?php if ( '' !== $desc ) : ?><span class="wf-hp-cd"><?= esc_html( $desc ) ?></span><?php endif; ?>
</<?= $tag ?>>
