<?php
/**
 * WeFrame – Couloir d'images | template.php
 *
 * Deux murs d'images qui filent vers un point de fuite au centre. La
 * perspective fait tout le travail : chaque image est posée à gauche ou à
 * droite, puis reculée d'un cran ; plus elle est loin, plus elle est petite et
 * proche du centre. La souris fait pivoter le couloir, le défilement y fait
 * avancer.
 */
defined( 'ABSPATH' ) || exit;

$props = is_array( $props ?? null ) ? $props : array();

if ( empty( $children ) ) { return; }

$parts = array();
foreach ( $children as $child ) {
	$one = (string) $builder->render( $child, array( 'element' => $props ) );
	if ( '' !== trim( $one ) ) { $parts[] = $one; }
}
if ( ! $parts ) { return; }
$n = count( $parts );

$iw    = max( 40, min( 600, (int) ( $props['img_w'] ?? 190 ) ) );
$ih    = max( 40, min( 800, (int) ( $props['img_h'] ?? 250 ) ) );
$rad   = max( 0, min( 60, (int) ( $props['radius'] ?? 4 ) ) );
$spr   = max( 60, min( 1400, (int) ( $props['spread'] ?? 420 ) ) );
$step  = max( 40, min( 900, (int) ( $props['step'] ?? 230 ) ) );
$persp = max( 300, min( 4000, (int) ( $props['perspective'] ?? 1100 ) ) );
$h     = max( 240, min( 1400, (int) ( $props['height'] ?? 660 ) ) );
$hm    = max( 200, min( 1400, (int) ( $props['height_mobile'] ?? 460 ) ) );
$bg    = (string) ( $props['bg'] ?? '#ffffff' );
$shad  = ! empty( $props['shadow'] );
$para  = ! empty( $props['parallax'] );
$zoom  = ! empty( $props['scroll_zoom'] );

$title  = trim( (string) ( $props['title'] ?? '' ) );
$tsize  = max( 14, min( 140, (int) ( $props['title_size'] ?? 56 ) ) );
$tsizem = max( 14, min( 90, (int) ( $props['title_size_mobile'] ?? 30 ) ) );
$tcol   = (string) ( $props['title_color'] ?? '#111827' );
$text   = trim( (string) ( $props['text'] ?? '' ) );
$xcol   = (string) ( $props['text_color'] ?? '#6b7280' );
$tpos   = 'top' === ( $props['text_pos'] ?? 'bottom' ) ? 'top' : 'bottom';

$uid = wf_uid( 'wfic_', $props, $n );

// Chaque image est placée par une règle nth-child : le gabarit d'item ne
// connaît pas son rang, c'est le parent qui distribue gauche / droite.
$rules = '';
for ( $i = 0; $i < $n; $i++ ) {
	$side  = ( 0 === $i % 2 ) ? -1 : 1;
	$depth = (int) floor( $i / 2 );
	$off   = (int) round( sin( $i * 1.7 ) * ( $ih * 0.09 ) );
	$rules .= '#' . $uid . ' .wf-ic-i:nth-child(' . ( $i + 1 ) . '){transform:translate(-50%,-50%) translate3d('
		. ( $side * $spr ) . 'px,' . $off . 'px,' . ( -1 * $depth * $step ) . 'px);z-index:' . ( 100 - $depth ) . ';}' . "\n";
}

$cfg = wp_json_encode( array(
	'uid'   => $uid,
	'para'  => $para ? 1 : 0,
	'zoom'  => $zoom ? 1 : 0,
	'range' => (int) round( $step * 1.4 ),
), JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-ic">
	<div class="wf-ic-stage">
		<div class="wf-ic-world"><?= implode( '', $parts ) ?></div>
	</div>
	<?php if ( '' !== $title ) : ?>
	<div class="wf-ic-title"><?= nl2br( esc_html( $title ) ) ?></div>
	<?php endif; ?>
	<?php if ( '' !== $text ) : ?>
	<div class="wf-ic-text"><?= nl2br( esc_html( $text ) ) ?></div>
	<?php endif; ?>
</div>

<style>
#<?= esc_attr( $uid ) ?>{position:relative;height:<?= $h ?>px;background:<?= esc_attr( $bg ) ?>;overflow:hidden;}
#<?= esc_attr( $uid ) ?> .wf-ic-stage{position:absolute;inset:0;perspective:<?= $persp ?>px;perspective-origin:50% 50%;}
#<?= esc_attr( $uid ) ?> .wf-ic-world{position:absolute;inset:0;transform-style:preserve-3d;will-change:transform;transition:transform .25s cubic-bezier(.16,1,.3,1);}
#<?= esc_attr( $uid ) ?> .wf-ic-i{position:absolute;left:50%;top:50%;width:<?= $iw ?>px;height:<?= $ih ?>px;border-radius:<?= $rad ?>px;overflow:hidden;background:#e5e7eb;text-decoration:none;<?= $shad ? 'box-shadow:0 24px 60px rgba(0,0,0,.18);' : '' ?>}
#<?= esc_attr( $uid ) ?> .wf-ic-i img{width:100%;height:100%;object-fit:cover;display:block;}
<?= $rules ?>
<?php if ( '' !== $title ) : ?>
#<?= esc_attr( $uid ) ?> .wf-ic-title{position:absolute;left:0;right:0;top:clamp(24px,6%,72px);z-index:200;text-align:center;padding:0 20px;font-size:<?= $tsize ?>px;line-height:1.08;font-weight:700;letter-spacing:-.02em;color:<?= esc_attr( $tcol ) ?>;pointer-events:none;}
<?php endif; ?>
<?php if ( '' !== $text ) : ?>
#<?= esc_attr( $uid ) ?> .wf-ic-text{position:absolute;left:0;right:0;<?= 'top' === $tpos ? 'top:calc(clamp(24px,6%,72px) + ' . (int) round( $tsize * 1.25 ) . 'px)' : 'bottom:clamp(20px,7%,64px)' ?>;z-index:200;text-align:center;padding:0 20px;font-size:15px;line-height:1.65;color:<?= esc_attr( $xcol ) ?>;pointer-events:none;}
<?php endif; ?>
@media(max-width:900px){#<?= esc_attr( $uid ) ?> .wf-ic-world{transform:scale(.62);}}
@media(max-width:640px){
	#<?= esc_attr( $uid ) ?>{height:<?= $hm ?>px;}
	#<?= esc_attr( $uid ) ?> .wf-ic-world{transform:scale(.44);}
	<?php if ( '' !== $title ) : ?>#<?= esc_attr( $uid ) ?> .wf-ic-title{font-size:<?= $tsizem ?>px;}<?php endif; ?>
}
</style>

<script>
(function(){
	var C = <?= $cfg ?>;
	function boot(){
		var el = document.getElementById(C.uid); if (!el) { return; }
		var world = el.querySelector('.wf-ic-world'); if (!world) { return; }

		if (window.matchMedia) { if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { return; } }

		// Sous 900px la mise à l'échelle est faite en CSS : un transform posé en
		// ligne la masquerait après un simple redimensionnement de la fenêtre.
		function narrow(){
			if (!window.matchMedia) { return false; }
			return window.matchMedia('(max-width: 900px)').matches;
		}
		window.addEventListener('resize', function(){
			if (narrow()) { world.style.transform = ''; }
		});
		if (narrow()) { return; }

		var rx = 0, ry = 0, tz = 0, pending = 0;

		function apply(){
			world.style.transform = 'translateZ(' + tz.toFixed(1) + 'px) rotateX(' + rx.toFixed(2) + 'deg) rotateY(' + ry.toFixed(2) + 'deg)';
		}
		function ask(){
			if (pending) { return; }
			pending = 1;
			requestAnimationFrame(function(){ pending = 0; apply(); });
		}

		if (C.para) {
			el.addEventListener('pointermove', function(e){
				var r = el.getBoundingClientRect();
				var nx = (e.clientX - r.left) / r.width - 0.5;
				var ny = (e.clientY - r.top) / r.height - 0.5;
				ry = nx * 7;
				rx = -ny * 5;
				ask();
			});
			el.addEventListener('pointerleave', function(){ rx = 0; ry = 0; ask(); });
		}

		if (C.zoom) {
			var onScroll = function(){
				var r = el.getBoundingClientRect();
				var vh = window.innerHeight ? window.innerHeight : 800;
				if (r.bottom < 0) { return; }
				if (r.top > vh) { return; }
				var p = (vh - r.top) / (vh + r.height);
				if (p < 0) { p = 0; }
				if (p > 1) { p = 1; }
				tz = (p - 0.5) * C.range;
				ask();
			};
			window.addEventListener('scroll', onScroll, { passive: true });
			onScroll();
		}
	}
	if (window.WF) { if (WF.ready) { WF.ready(boot); return; } }
	if (document.readyState !== 'loading') { boot(); } else { document.addEventListener('DOMContentLoaded', boot); }
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
