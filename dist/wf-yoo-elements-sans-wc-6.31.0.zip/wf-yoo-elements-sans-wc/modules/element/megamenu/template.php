<?php
/**
 * WeFrame – Mégamenu | template.php v1.0
 *
 * Barre d'entrées + panneaux à contenu libre (chaque entrée est un conteneur
 * du builder). Trois largeurs de panneau : pleine largeur d'écran, largeur du
 * mégamenu, ou largeur fixe posée sous l'entrée.
 *
 * Le panneau vit dans son <li>. Selon le mode, le <li> est position:static ou
 * position:relative — c'est ce qui décide si le panneau se cale sur l'entrée ou
 * sur toute la barre, sans dupliquer le balisage.
 *
 * Sous le seuil mobile, tout redevient un accordéon dans le flux : aucun
 * panneau flottant sur un petit écran.
 *
 * Pas de "&&" ni de "||" dans le JS inline (règle interne du plugin).
 */

defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$barAlign = (string) ( $props['bar_align'] ?? 'left' );
if ( ! in_array( $barAlign, array( 'left', 'center', 'right', 'stretch' ), true ) ) { $barAlign = 'left'; }

$showArrow = ! empty( $props['show_arrow'] );

$openOn = (string) ( $props['open_on'] ?? 'hover' );
if ( ! in_array( $openOn, array( 'hover', 'click' ), true ) ) { $openOn = 'hover'; }
$closeDelay = max( 0, min( 1200, (int) ( $props['close_delay'] ?? 220 ) ) );

$anim = (string) ( $props['anim'] ?? 'fade' );
if ( ! in_array( $anim, array( 'fade', 'slide', 'none' ), true ) ) { $anim = 'fade'; }
$animMs = max( 0, min( 900, (int) ( $props['anim_ms'] ?? 200 ) ) );
if ( 'none' === $anim ) { $animMs = 0; }

$barGap    = max( 0, min( 60, (int) ( $props['bar_gap'] ?? 6 ) ) );
$barPad    = max( 0, min( 40, (int) ( $props['bar_padding'] ?? 14 ) ) );
$barRad    = max( 0, min( 40, (int) ( $props['bar_radius'] ?? 8 ) ) );
$barBg     = trim( (string) ( $props['bar_bg'] ?? '' ) );
$barCol    = (string) ( $props['bar_color'] ?? '#111111' );
$barActCol = (string) ( $props['bar_active_color'] ?? '#111111' );
$barActBg  = trim( (string) ( $props['bar_active_bg'] ?? '' ) );
$barSize   = max( 11, min( 24, (int) ( $props['bar_size'] ?? 15 ) ) );
$barWeight = (string) ( $props['bar_weight'] ?? '600' );
$indicator = (string) ( $props['bar_indicator'] ?? 'underline' );
if ( ! in_array( $indicator, array( 'none', 'underline', 'pill' ), true ) ) { $indicator = 'underline'; }
$accent = (string) ( $props['accent'] ?? '#EA5C1C' );

$pWidth = (string) ( $props['panel_width'] ?? 'container' );
if ( ! in_array( $pWidth, array( 'full', 'container', 'fixed' ), true ) ) { $pWidth = 'container'; }
$pMax    = max( 200, min( 1400, (int) ( $props['panel_max'] ?? 720 ) ) );
$pAlign  = (string) ( $props['panel_align'] ?? 'start' );
if ( ! in_array( $pAlign, array( 'start', 'center', 'end' ), true ) ) { $pAlign = 'start'; }
$pOffset = max( 0, min( 60, (int) ( $props['panel_offset'] ?? 8 ) ) );
$pBg     = (string) ( $props['panel_bg'] ?? '#ffffff' );
$pCol    = (string) ( $props['panel_color'] ?? '#111111' );
$pPad    = max( 0, min( 80, (int) ( $props['panel_pad'] ?? 28 ) ) );
$pRad    = max( 0, min( 40, (int) ( $props['panel_radius'] ?? 14 ) ) );
$pBorder = trim( (string) ( $props['panel_border'] ?? '' ) );
$pShadow = (string) ( $props['panel_shadow'] ?? 'strong' );

$mobileBp = (int) ( $props['mobile_bp'] ?? 960 );
if ( ! in_array( $mobileBp, array( 640, 768, 960, 1200 ), true ) ) { $mobileBp = 960; }

$uid = wf_uid( 'wfmm_', $props, count( $children ) );

// Chaque entrée est préparée ici : le corps du gabarit n'a plus qu'à écrire.
$entries = array();
foreach ( $children as $i => $child ) {
	$cp    = (array) ( $child->props ?? array() );
	$mode  = (string) ( $cp['mode'] ?? 'panel' );
	if ( ! in_array( $mode, array( 'panel', 'link' ), true ) ) { $mode = 'panel'; }
	$label = trim( (string) ( $cp['label'] ?? '' ) );
	if ( '' === $label ) { $label = 'Entrée'; }
	$link  = trim( (string) ( $cp['link'] ?? '' ) );

	$html = $builder->render( $child, array( 'element' => $props, 'index' => $i ) );
	if ( 'panel' === $mode && '' === trim( (string) $html ) ) { $mode = 'link'; }

	$entries[] = array(
		'mode'     => $mode,
		'label'    => $label,
		'sublabel' => trim( (string) ( $cp['sublabel'] ?? '' ) ),
		'badge'    => trim( (string) ( $cp['badge'] ?? '' ) ),
		'link'     => $link,
		'hasLink'  => '' !== $link,
		'target'   => ! empty( $cp['link_target'] ) ? ' target="_blank" rel="noopener"' : '',
		'pid'      => $uid . '-p' . $i,
		'toggleLabel' => sprintf( 'Ouvrir le sous-menu %s', $label ),
		'html'     => $html,
		// Une entrée à panneau qui porte aussi un lien : le libellé mène quelque
		// part, un bouton séparé ouvre le panneau. C'est le motif accessible.
		'split'    => ( 'panel' === $mode ) && ( '' !== $link ),
	);
}

$justify = 'flex-start';
if ( 'center' === $barAlign ) { $justify = 'center'; }
if ( 'right' === $barAlign ) { $justify = 'flex-end'; }
if ( 'stretch' === $barAlign ) { $justify = 'space-between'; }

$shadowCss = 'none';
if ( 'soft' === $pShadow ) { $shadowCss = '0 6px 24px rgba(0,0,0,.10)'; }
if ( 'strong' === $pShadow ) { $shadowCss = '0 18px 50px rgba(0,0,0,.18)'; }

// Placement horizontal du panneau, selon la largeur choisie.
$panelPos = 'left:0;right:0;';
if ( 'full' === $pWidth ) {
	// --wf-vw : largeur de page sans la barre de defilement (voir WF.viewportVar).
	$panelPos = 'left:50%;width:var(--wf-vw,100vw);margin-left:calc(var(--wf-vw,100vw) / -2);';
} elseif ( 'fixed' === $pWidth ) {
	$panelPos = 'left:0;width:' . $pMax . 'px;max-width:calc(100vw - 32px);';
	if ( 'center' === $pAlign ) {
		// margin négatif plutôt que translateX : l'animation se sert déjà du transform.
		$panelPos = 'left:50%;margin-left:-' . (int) round( $pMax / 2 ) . 'px;width:' . $pMax . 'px;max-width:calc(100vw - 32px);';
	} elseif ( 'end' === $pAlign ) {
		$panelPos = 'right:0;width:' . $pMax . 'px;max-width:calc(100vw - 32px);';
	}
}

$closedTransform = 'none';
if ( 'slide' === $anim ) { $closedTransform = 'translateY(-8px)'; }

$rootClass = 'wf-mm wf-mm--' . $pWidth;

$chev = '<svg class="wf-mm__chev" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>';

$cfg = wp_json_encode(
	array(
		'uid'    => $uid,
		'openOn' => $openOn,
		'delay'  => $closeDelay,
		'bp'     => $mobileBp,
	),
	JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE
);
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<nav id="<?= esc_attr( $uid ) ?>" class="<?= esc_attr( $rootClass ) ?>" aria-label="<?= esc_attr__( 'Menu', 'weframe' ) ?>">
	<ul class="wf-mm__list">
	<?php foreach ( $entries as $i => $e ) : ?>
		<li class="wf-mm__item" data-i="<?= (int) $i ?>">
		<?php if ( 'link' === $e['mode'] ) : ?>
			<a class="wf-mm__trigger" href="<?= esc_url( $e['link'] ) ?>"<?= $e['target'] ?>>
				<span class="wf-mm__label"><?= esc_html( $e['label'] ) ?><?php if ( '' !== $e['badge'] ) : ?><span class="wf-mm__badge"><?= esc_html( $e['badge'] ) ?></span><?php endif; ?></span>
				<?php if ( '' !== $e['sublabel'] ) : ?><span class="wf-mm__sub"><?= esc_html( $e['sublabel'] ) ?></span><?php endif; ?>
			</a>
		<?php elseif ( $e['split'] ) : ?>
			<a class="wf-mm__trigger" href="<?= esc_url( $e['link'] ) ?>"<?= $e['target'] ?>>
				<span class="wf-mm__label"><?= esc_html( $e['label'] ) ?><?php if ( '' !== $e['badge'] ) : ?><span class="wf-mm__badge"><?= esc_html( $e['badge'] ) ?></span><?php endif; ?></span>
				<?php if ( '' !== $e['sublabel'] ) : ?><span class="wf-mm__sub"><?= esc_html( $e['sublabel'] ) ?></span><?php endif; ?>
			</a>
			<button type="button" class="wf-mm__toggle" aria-expanded="false" aria-controls="<?= esc_attr( $e['pid'] ) ?>" aria-label="<?= esc_attr( $e['toggleLabel'] ) ?>"><?= $chev ?></button>
		<?php else : ?>
			<button type="button" class="wf-mm__trigger wf-mm__trigger--btn" aria-expanded="false" aria-controls="<?= esc_attr( $e['pid'] ) ?>">
				<span class="wf-mm__label"><?= esc_html( $e['label'] ) ?><?php if ( '' !== $e['badge'] ) : ?><span class="wf-mm__badge"><?= esc_html( $e['badge'] ) ?></span><?php endif; ?></span>
				<?php if ( '' !== $e['sublabel'] ) : ?><span class="wf-mm__sub"><?= esc_html( $e['sublabel'] ) ?></span><?php endif; ?>
				<?php if ( $showArrow ) : ?><?= $chev ?><?php endif; ?>
			</button>
		<?php endif; ?>
		<?php if ( 'panel' === $e['mode'] ) : ?>
			<div class="wf-mm__panel" id="<?= esc_attr( $e['pid'] ) ?>" hidden><div class="wf-mm__panelin"><?= $e['html'] ?></div></div>
		<?php endif; ?>
		</li>
	<?php endforeach; ?>
	</ul>
</nav>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?>{position:relative;}
#<?= esc_attr( $uid ) ?> .wf-mm__list{
	display:flex;flex-wrap:wrap;align-items:stretch;gap:<?= (int) $barGap ?>px;
	justify-content:<?= esc_attr( $justify ) ?>;margin:0;padding:0;list-style:none;
	<?php if ( '' !== $barBg ) : ?>background:<?= esc_attr( $barBg ) ?>;border-radius:<?= (int) $barRad ?>px;padding:4px;<?php endif; ?>
}
#<?= esc_attr( $uid ) ?> .wf-mm__item{position:static;display:flex;align-items:stretch;}
#<?= esc_attr( $uid ) ?>.wf-mm--fixed .wf-mm__item{position:relative;}
#<?= esc_attr( $uid ) ?> .wf-mm__trigger{
	display:flex;flex-direction:column;justify-content:center;gap:1px;
	min-height:44px;padding:.4em <?= (int) $barPad ?>px;cursor:pointer;
	font:inherit;font-size:<?= (int) $barSize ?>px;font-weight:<?= esc_attr( $barWeight ) ?>;line-height:1.25;
	color:<?= esc_attr( $barCol ) ?>;background:transparent;border:0;border-radius:<?= (int) $barRad ?>px;
	text-decoration:none;position:relative;transition:color .18s ease,background-color .18s ease;
}
#<?= esc_attr( $uid ) ?> .wf-mm__label{display:inline-flex;align-items:center;gap:.45em;}
#<?= esc_attr( $uid ) ?> .wf-mm__trigger--btn .wf-mm__label{gap:.45em;}
#<?= esc_attr( $uid ) ?> .wf-mm__sub{font-size:.78em;font-weight:400;opacity:.62;}
#<?= esc_attr( $uid ) ?> .wf-mm__badge{
	display:inline-flex;align-items:center;justify-content:center;min-width:1.5em;height:1.5em;padding:0 .45em;
	border-radius:100px;background:<?= esc_attr( $accent ) ?>;color:#fff;font-size:.68em;font-weight:700;line-height:1;
}
#<?= esc_attr( $uid ) ?> .wf-mm__toggle{
	display:inline-flex;align-items:center;justify-content:center;width:36px;min-height:44px;
	cursor:pointer;color:<?= esc_attr( $barCol ) ?>;background:transparent;border:0;border-radius:<?= (int) $barRad ?>px;
}
#<?= esc_attr( $uid ) ?> .wf-mm__chev{transition:transform .2s ease;flex:0 0 auto;}
#<?= esc_attr( $uid ) ?> .wf-mm__item.is-open .wf-mm__chev{transform:rotate(180deg);}
#<?= esc_attr( $uid ) ?> .wf-mm__item.is-open .wf-mm__trigger{color:<?= esc_attr( $barActCol ) ?>;<?php if ( '' !== $barActBg ) : ?>background:<?= esc_attr( $barActBg ) ?>;<?php endif; ?>}
<?php if ( 'underline' === $indicator ) : ?>
#<?= esc_attr( $uid ) ?> .wf-mm__trigger::after{
	content:"";position:absolute;left:<?= (int) $barPad ?>px;right:<?= (int) $barPad ?>px;bottom:2px;height:2px;
	background:<?= esc_attr( $accent ) ?>;transform:scaleX(0);transform-origin:left center;transition:transform .2s ease;
}
#<?= esc_attr( $uid ) ?> .wf-mm__item.is-open .wf-mm__trigger::after,#<?= esc_attr( $uid ) ?> .wf-mm__trigger:hover::after{transform:scaleX(1);}
<?php elseif ( 'pill' === $indicator ) : ?>
#<?= esc_attr( $uid ) ?> .wf-mm__item.is-open .wf-mm__trigger{background:<?= esc_attr( $accent ) ?>;color:#fff;}
#<?= esc_attr( $uid ) ?> .wf-mm__item.is-open .wf-mm__toggle{color:#fff;}
<?php endif; ?>
#<?= esc_attr( $uid ) ?> .wf-mm__panel{
	position:absolute;top:100%;z-index:60;<?= $panelPos ?>
	margin-top:<?= (int) $pOffset ?>px;
	background:<?= esc_attr( $pBg ) ?>;color:<?= esc_attr( $pCol ) ?>;
	border-radius:<?= (int) $pRad ?>px;box-shadow:<?= esc_attr( $shadowCss ) ?>;
	<?php if ( '' !== $pBorder ) : ?>border:1px solid <?= esc_attr( $pBorder ) ?>;<?php endif; ?>
	opacity:0;transform:<?= esc_attr( $closedTransform ) ?>;pointer-events:none;
	transition:opacity <?= (int) $animMs ?>ms ease,transform <?= (int) $animMs ?>ms ease;
}
#<?= esc_attr( $uid ) ?> .wf-mm__panelin{padding:<?= (int) $pPad ?>px;}
#<?= esc_attr( $uid ) ?> .wf-mm__item.is-open .wf-mm__panel{opacity:1;transform:none;pointer-events:auto;}
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?> .wf-mm__panel{transition:none;}
}
/* Sous le seuil : plus rien ne flotte, tout rentre dans le flux. */
@media (max-width:<?= (int) ( $mobileBp - 1 ) ?>px){
	#<?= esc_attr( $uid ) ?> .wf-mm__list{flex-direction:column;gap:0;padding:0;background:none;}
	#<?= esc_attr( $uid ) ?> .wf-mm__item{display:block;border-bottom:1px solid rgba(127,127,127,.2);}
	#<?= esc_attr( $uid ) ?> .wf-mm__trigger{width:100%;flex-direction:row;align-items:center;justify-content:space-between;gap:.6em;}
	#<?= esc_attr( $uid ) ?> .wf-mm__trigger::after{display:none;}
	#<?= esc_attr( $uid ) ?> .wf-mm__toggle{position:absolute;top:0;right:0;width:48px;height:100%;}
	#<?= esc_attr( $uid ) ?> .wf-mm__item{position:relative;}
	#<?= esc_attr( $uid ) ?> .wf-mm__panel{
		position:static;width:auto;max-width:none;margin:0 0 12px;
		box-shadow:none;border:0;border-radius:0;background:none;color:inherit;
		opacity:1;transform:none;pointer-events:auto;transition:none;
	}
	#<?= esc_attr( $uid ) ?> .wf-mm__panelin{padding:0 0 4px;}
}
</style>
<script>
(function(){
	function boot(){
		var c = <?= $cfg ?>;
		var root = document.getElementById(c.uid);
		if(!root){return;}
		if(root.getAttribute('data-wf-ready')){return;}
		root.setAttribute('data-wf-ready','1');

		if(WF.viewportVar){WF.viewportVar();}

		var items = Array.prototype.slice.call(root.querySelectorAll('.wf-mm__item'));
		var timer = null;
		var mq = window.matchMedia('(max-width:' + (c.bp - 1) + 'px)');

		function ctl(li){
			var b = li.querySelector('.wf-mm__toggle');
			if(b){return b;}
			return li.querySelector('.wf-mm__trigger--btn');
		}

		function panel(li){ return li.querySelector('.wf-mm__panel'); }

		function shut(li){
			if(!li.classList.contains('is-open')){return;}
			li.classList.remove('is-open');
			var b = ctl(li);
			if(b){b.setAttribute('aria-expanded','false');}
			var p = panel(li);
			if(!p){return;}
			// En mode replié, le panneau reste dans le flux : on le masque vraiment.
			window.setTimeout(function(){
				if(li.classList.contains('is-open')){return;}
				p.hidden = true;
			}, mq.matches ? 0 : 260);
		}

		function shutAll(except){
			var i = 0;
			while(i < items.length){
				if(items[i] !== except){shut(items[i]);}
				i++;
			}
		}

		function show(li){
			var p = panel(li);
			if(!p){return;}
			shutAll(li);
			p.hidden = false;
			// Un reflow avant la classe, sinon la transition part d'un élément
			// qui vient d'apparaître et ne joue pas.
			void p.offsetWidth;
			li.classList.add('is-open');
			var b = ctl(li);
			if(b){b.setAttribute('aria-expanded','true');}
		}

		function toggle(li){
			if(li.classList.contains('is-open')){shut(li);return;}
			show(li);
		}

		var i = 0;
		while(i < items.length){
			(function(li){
				var b = ctl(li);
				if(b){
					b.addEventListener('click', function(e){
						e.preventDefault();
						toggle(li);
					});
				}
				if(c.openOn === 'hover'){
					li.addEventListener('mouseenter', function(){
						if(mq.matches){return;}
						window.clearTimeout(timer);
						show(li);
					});
					li.addEventListener('mouseleave', function(){
						if(mq.matches){return;}
						window.clearTimeout(timer);
						timer = window.setTimeout(function(){ shut(li); }, c.delay);
					});
					// Le survol seul laisserait le clavier dehors.
					li.addEventListener('focusin', function(){
						if(mq.matches){return;}
						show(li);
					});
				}
			}(items[i]));
			i++;
		}

		root.addEventListener('keydown', function(e){
			var li = e.target.closest ? e.target.closest('.wf-mm__item') : null;
			if(e.key === 'Escape'){
				if(!li){return;}
				shut(li);
				var t = li.querySelector('.wf-mm__trigger');
				if(t){t.focus();}
				return;
			}
			if(e.key === 'ArrowRight'){
				if(!li){return;}
				var n = li.nextElementSibling;
				if(!n){return;}
				e.preventDefault();
				n.querySelector('.wf-mm__trigger').focus();
				return;
			}
			if(e.key === 'ArrowLeft'){
				if(!li){return;}
				var pv = li.previousElementSibling;
				if(!pv){return;}
				e.preventDefault();
				pv.querySelector('.wf-mm__trigger').focus();
			}
		});

		document.addEventListener('click', function(e){
			if(root.contains(e.target)){return;}
			shutAll(null);
		});

		// Passage d'un côté à l'autre du seuil : on repart d'un état propre.
		function sync(){ shutAll(null); }
		if(mq.addEventListener){mq.addEventListener('change', sync);}
		else if(mq.addListener){mq.addListener(sync);}
	}
	WF.ready(boot);
}());
</script>
