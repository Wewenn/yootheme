<?php
/**
 * WeFrame – Navbar sidebar : un lien (item). Titre de section optionnel (à mettre sur le 1er lien du groupe).
 */
defined( 'ABSPATH' ) || exit;

$label = trim( (string) ( $props['label'] ?? '' ) );
if ( '' === $label ) { return; }
$url     = trim( (string) ( $props['url'] ?? '' ) );
$section = trim( (string) ( $props['section'] ?? '' ) );
$info    = trim( (string) ( $props['info'] ?? '' ) );
$href    = ( '' !== $url ) ? $url : '#';
?>
<?php if ( '' !== $section ) : ?><div class="wf-ns-section"><?= esc_html( $section ) ?></div><?php endif; ?>
<a class="wf-ns-link" href="<?= esc_url( $href ) ?>">
    <span class="wf-ns-link-txt"><?= esc_html( $label ) ?></span>
    <?php if ( '' !== $info ) : ?><span class="wf-ns-link-info"><?= esc_html( $info ) ?></span><?php endif; ?>
</a>
