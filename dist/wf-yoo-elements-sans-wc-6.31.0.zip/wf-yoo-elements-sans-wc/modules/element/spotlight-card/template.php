<?php
/**
 * WeFrame – Spotlight Card | template.php
 * Container card with a radial glow that follows the cursor (+ optional border glow).
 * Config inlined (no <script type="application/json">), no "&&" in inline JS.
 */
defined( 'ABSPATH' ) || exit;

$props = is_array( $props ?? null ) ? $props : array();

$bg      = (string) ( $props['bg_color'] ?? '#111318' );
$bcol    = (string) ( $props['border_color'] ?? 'rgba(255,255,255,0.10)' );
$bw      = min( 6, max( 0, (int) ( $props['border_width'] ?? 1 ) ) );
$radius  = min( 40, max( 0, (int) ( $props['radius'] ?? 18 ) ) );
$pad     = min( 80, max( 0, (int) ( $props['padding'] ?? 32 ) ) );
$minh    = max( 0, (int) ( $props['min_height'] ?? 0 ) );
$glow    = (string) ( $props['glow_color'] ?? 'rgba(120,150,255,0.35)' );
$gsize   = min( 700, max( 100, (int) ( $props['glow_size'] ?? 350 ) ) );
$gop     = min( 100, max( 10, (int) ( $props['glow_opacity'] ?? 100 ) ) ) / 100;
$bglow   = ! empty( $props['border_glow'] );
$lift    = ! empty( $props['hover_lift'] );

// Children (container) with textarea fallback
$inner = '';
if ( isset( $builder ) && is_object( $builder ) && ! empty( $children ) && is_array( $children ) ) {
    foreach ( $children as $child ) {
        $inner .= (string) $builder->render( $child, array( 'element' => $props ) );
    }
}
if ( '' === trim( $inner ) ) {
    $content = (string) ( $props['content'] ?? '' );
    $inner   = wp_kses_post( wpautop( $content ) );
}

$uid = wf_uid( 'wfspot_', $props, $inner );

$cfg = wp_json_encode( array(
    'uid'   => $uid,
    'bglow' => $bglow ? 1 : 0,
), JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE );

$mh = $minh > 0 ? 'min-height:' . $minh . 'px;' : '';
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-spot" style="position:relative;border-radius:<?= $radius ?>px;background:<?= esc_attr( $bg ) ?>;border:<?= $bw ?>px solid <?= esc_attr( $bcol ) ?>;padding:<?= $pad ?>px;<?= $mh ?>overflow:hidden;isolation:isolate;transition:transform .3s ease;">
    <div class="wf-spot-glow" aria-hidden="true" style="position:absolute;inset:0;z-index:0;opacity:0;transition:opacity .35s ease;pointer-events:none;background:radial-gradient(<?= $gsize ?>px circle at var(--mx,50%) var(--my,50%),<?= esc_attr( $glow ) ?>,transparent 70%);"></div>
    <?php if ( $bglow ) : ?>
    <div class="wf-spot-border" aria-hidden="true" style="position:absolute;inset:0;z-index:0;border-radius:<?= $radius ?>px;opacity:0;transition:opacity .35s ease;pointer-events:none;padding:<?= $bw ?>px;background:radial-gradient(<?= (int) ( $gsize * 0.7 ) ?>px circle at var(--mx,50%) var(--my,50%),<?= esc_attr( $glow ) ?>,transparent 60%);-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);mask-composite:exclude;"></div>
    <?php endif; ?>
    <div class="wf-spot-inner" style="position:relative;z-index:1;"><?= $inner ?></div>
</div>

<style>
#<?= esc_attr( $uid ) ?>:hover .wf-spot-glow { opacity: <?= $gop ?>; }
<?php if ( $bglow ) : ?>#<?= esc_attr( $uid ) ?>:hover .wf-spot-border { opacity: 1; }<?php endif; ?>
<?php if ( $lift ) : ?>#<?= esc_attr( $uid ) ?>:hover { transform: translateY(-6px); }<?php endif; ?>
@media (hover: none) {
    #<?= esc_attr( $uid ) ?> .wf-spot-glow { opacity: <?= $gop * 0.5 ?>; }
}
</style>

<script>
(function(){
    var C = <?= $cfg ?>;
    function boot(){
        var el = document.getElementById(C.uid); if (!el) return;
        var glow = el.querySelector('.wf-spot-glow');
        var bd = el.querySelector('.wf-spot-border');
        function move(e){
            var r = el.getBoundingClientRect();
            var x = ((e.clientX - r.left) / r.width) * 100;
            var y = ((e.clientY - r.top) / r.height) * 100;
            el.style.setProperty('--mx', x.toFixed(2) + '%');
            el.style.setProperty('--my', y.toFixed(2) + '%');
        }
        el.addEventListener('mousemove', move);
    }
    if (window.WF) { if (WF.ready) { WF.ready(boot); return; } }
    if (document.readyState !== 'loading') { boot(); } else { document.addEventListener('DOMContentLoaded', boot); }
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
