<?php
/**
 * WeFrame – Navbar plein écran (parent) | barre + panneau overlay (menu + CTA), style agence.
 */
defined( 'ABSPATH' ) || exit;

$brand   = trim( (string) ( $props['brand_text'] ?? '' ) );
$logo    = trim( (string) ( $props['logo'] ?? '' ) );
if ( '' !== $logo && ! preg_match( '#^https?://#i', $logo ) ) { $logo = '/' . ltrim( $logo, '/' ); }
$sticky  = ! empty( $props['sticky'] );
$mode    = ( ( $props['panel_mode'] ?? 'card' ) === 'full' ) ? 'full' : 'card';

$pitchT  = trim( (string) ( $props['pitch_text'] ?? '' ) );
$pitchU  = trim( (string) ( $props['pitch_url'] ?? '' ) );
$c1t     = trim( (string) ( $props['cta1_text'] ?? '' ) );
$c1u     = trim( (string) ( $props['cta1_url'] ?? '' ) );
$c2t     = trim( (string) ( $props['cta2_text'] ?? '' ) );
$c2u     = trim( (string) ( $props['cta2_url'] ?? '' ) );

$barBg   = $props['bar_bg']     ?? 'rgba(20,16,12,0)';
$panelBg = $props['panel_bg']   ?? '#161210';
$txt     = $props['text_color'] ?? '#f4efe9';
$muted   = $props['muted_color'] ?? '#a89f95';
$accent  = $props['accent']     ?? '#f4efe9';
$ctaBg   = $props['cta_bg']     ?? '#f4efe9';
$ctaCol  = $props['cta_color']  ?? '#161210';

$links = '';
if ( ! empty( $children ) ) {
    foreach ( $children as $child ) { $links .= $builder->render( $child, array( 'element' => $props ) ); }
}

$uid = wf_uid( 'wfnf_', $props, count( (array) $children ) );
$pid = $uid . '_p';

$brandHtml = '';
if ( '' !== $logo ) { $brandHtml .= '<img class="wf-nf-logoimg" src="' . esc_url( $logo ) . '" alt="' . esc_attr( $brand ) . '">'; }
if ( '' !== $brand ) { $brandHtml .= '<span class="wf-nf-brand">' . esc_html( $brand ) . '</span>'; }
if ( '' === $brandHtml ) { $brandHtml = '<span class="wf-nf-brand">Menu</span>'; }
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-nf wf-nf-<?= esc_attr( $mode ) ?>">
    <div class="wf-nf-bar">
        <div class="wf-nf-bar-brand"><?= $brandHtml ?></div>
        <button type="button" class="wf-nf-toggle" aria-expanded="false" aria-controls="<?= esc_attr( $pid ) ?>" aria-label="Ouvrir le menu">
            <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="3" y1="8" x2="21" y2="8"/><line x1="3" y1="16" x2="21" y2="16"/></svg>
        </button>
    </div>
    <div class="wf-nf-backdrop" hidden></div>
    <div id="<?= esc_attr( $pid ) ?>" class="wf-nf-panel" role="dialog" aria-modal="true" aria-label="<?= esc_attr__( 'Menu', 'weframe' ) ?>" hidden>
        <div class="wf-nf-panel-head">
            <div class="wf-nf-bar-brand"><?= $brandHtml ?></div>
            <button type="button" class="wf-nf-close" aria-label="Fermer le menu">
                <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="5" y1="12" x2="19" y2="12"/></svg>
            </button>
        </div>
        <nav class="wf-nf-links"><?= $links ?></nav>
        <?php if ( '' !== $pitchT || '' !== $c1t || '' !== $c2t ) : ?>
        <div class="wf-nf-actions">
            <?php if ( '' !== $pitchT ) : ?><a class="wf-nf-pitch" href="<?= esc_url( '' !== $pitchU ? $pitchU : '#' ) ?>"><?= esc_html( $pitchT ) ?></a><?php endif; ?>
            <?php if ( '' !== $c1t || '' !== $c2t ) : ?>
            <div class="wf-nf-ctas">
                <?php if ( '' !== $c1t ) : ?><a class="wf-nf-cta" href="<?= esc_url( '' !== $c1u ? $c1u : '#' ) ?>"><?= esc_html( $c1t ) ?></a><?php endif; ?>
                <?php if ( '' !== $c2t ) : ?><a class="wf-nf-cta" href="<?= esc_url( '' !== $c2u ? $c2u : '#' ) ?>"><?= esc_html( $c2t ) ?></a><?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</div>
<style>
#<?= esc_attr( $uid ) ?>{--nf-txt:<?= esc_attr( $txt ) ?>;--nf-muted:<?= esc_attr( $muted ) ?>;--nf-accent:<?= esc_attr( $accent ) ?>;--nf-panel:<?= esc_attr( $panelBg ) ?>;--nf-ctabg:<?= esc_attr( $ctaBg ) ?>;--nf-ctacol:<?= esc_attr( $ctaCol ) ?>;position:relative;font-family:inherit;}
#<?= esc_attr( $uid ) ?> .wf-nf-bar{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:14px 20px;background:<?= esc_attr( $barBg ) ?>;color:var(--nf-txt);<?= $sticky ? 'position:sticky;top:0;z-index:40;' : '' ?>}
#<?= esc_attr( $uid ) ?> .wf-nf-bar-brand{display:flex;align-items:center;gap:12px;color:var(--nf-txt);min-height:28px;}
#<?= esc_attr( $uid ) ?> .wf-nf-logoimg{height:26px;width:auto;display:block;}
#<?= esc_attr( $uid ) ?> .wf-nf-brand{font-size:13px;letter-spacing:.18em;text-transform:uppercase;font-weight:600;}
#<?= esc_attr( $uid ) ?> .wf-nf-toggle,#<?= esc_attr( $uid ) ?> .wf-nf-close{background:none;border:0;color:var(--nf-txt);cursor:pointer;padding:6px;line-height:0;border-radius:8px;}
#<?= esc_attr( $uid ) ?> .wf-nf-toggle:hover,#<?= esc_attr( $uid ) ?> .wf-nf-close:hover{opacity:.7;}
#<?= esc_attr( $uid ) ?> .wf-nf-backdrop{position:fixed;inset:0;z-index:44;background:rgba(0,0,0,.5);opacity:0;transition:opacity .3s ease;}
#<?= esc_attr( $uid ) ?> .wf-nf-panel{position:fixed;z-index:45;background:var(--nf-panel);color:var(--nf-txt);opacity:0;pointer-events:none;transition:opacity .3s ease,transform .35s cubic-bezier(.16,1,.3,1);box-shadow:0 30px 80px rgba(0,0,0,.4);}
#<?= esc_attr( $uid ) ?>.wf-nf-card .wf-nf-panel{top:12px;right:12px;width:min(560px,94vw);border-radius:16px;border:1px solid rgba(255,255,255,.08);transform:translateY(-14px);}
#<?= esc_attr( $uid ) ?>.wf-nf-full .wf-nf-panel{inset:0;width:100%;transform:translateY(-24px);display:flex;flex-direction:column;justify-content:center;}
#<?= esc_attr( $uid ) ?>.wf-nf-open .wf-nf-panel{opacity:1;pointer-events:auto;transform:translateY(0);}
#<?= esc_attr( $uid ) ?>.wf-nf-open .wf-nf-backdrop{opacity:1;}
#<?= esc_attr( $uid ) ?> .wf-nf-panel-head{display:flex;align-items:center;justify-content:space-between;padding:18px 22px;border-bottom:1px solid rgba(255,255,255,.09);}
#<?= esc_attr( $uid ) ?> .wf-nf-links{display:flex;flex-direction:column;}
#<?= esc_attr( $uid ) ?> .wf-nf-link{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:18px 22px;color:var(--nf-txt);text-decoration:none;font-size:26px;font-weight:500;border-bottom:1px solid rgba(255,255,255,.07);transition:background .2s ease,padding-left .2s ease;}
#<?= esc_attr( $uid ) ?> .wf-nf-link:hover{background:rgba(255,255,255,.05);padding-left:30px;}
#<?= esc_attr( $uid ) ?> .wf-nf-link-badge{font-size:12px;color:var(--nf-muted);letter-spacing:.1em;}
#<?= esc_attr( $uid ) ?> .wf-nf-actions{padding:18px 22px;display:flex;flex-direction:column;gap:12px;}
#<?= esc_attr( $uid ) ?> .wf-nf-pitch{display:flex;align-items:center;justify-content:center;padding:16px;border:1px solid var(--nf-accent);border-radius:12px;color:var(--nf-txt);text-decoration:none;font-size:13px;letter-spacing:.14em;text-transform:uppercase;}
#<?= esc_attr( $uid ) ?> .wf-nf-pitch:hover{background:rgba(255,255,255,.06);}
#<?= esc_attr( $uid ) ?> .wf-nf-ctas{display:flex;gap:12px;}
#<?= esc_attr( $uid ) ?> .wf-nf-cta{flex:1;display:flex;align-items:center;justify-content:center;padding:18px 14px;background:var(--nf-ctabg);color:var(--nf-ctacol);text-decoration:none;border-radius:12px;font-size:13px;letter-spacing:.12em;text-transform:uppercase;font-weight:600;}
#<?= esc_attr( $uid ) ?> .wf-nf-cta:hover{opacity:.9;}
@media(max-width:600px){#<?= esc_attr( $uid ) ?> .wf-nf-link{font-size:21px;}#<?= esc_attr( $uid ) ?> .wf-nf-ctas{flex-direction:column;}}
@media(prefers-reduced-motion:reduce){#<?= esc_attr( $uid ) ?> .wf-nf-panel,#<?= esc_attr( $uid ) ?> .wf-nf-backdrop{transition:none;}}
</style>
<script>
(function(){
    var root=document.getElementById('<?= esc_js( $uid ) ?>'); if(!root) return;
    var toggle=root.querySelector('.wf-nf-toggle');
    var panel=root.querySelector('.wf-nf-panel');
    var backdrop=root.querySelector('.wf-nf-backdrop');
    var closeBtn=root.querySelector('.wf-nf-close');
    if(!panel) return;
    var t;
var wfRelease=null;
    function open(){
        if(t){clearTimeout(t);}
        panel.hidden=false; if(backdrop){backdrop.hidden=false;}
        requestAnimationFrame(function(){ root.classList.add('wf-nf-open'); });
        if(toggle){toggle.setAttribute('aria-expanded','true');}
        document.body.style.overflow='hidden';
        if(window.WF&&WF.trapFocus){ wfRelease=WF.trapFocus(panel); }
    }
    function close(){
        if(wfRelease){ wfRelease(); wfRelease=null; }
        root.classList.remove('wf-nf-open');
        if(toggle){toggle.setAttribute('aria-expanded','false');}
        document.body.style.overflow='';
        t=setTimeout(function(){ panel.hidden=true; if(backdrop){backdrop.hidden=true;} },320);
    }
    if(toggle){toggle.addEventListener('click',open);}
    if(closeBtn){closeBtn.addEventListener('click',close);}
    if(backdrop){backdrop.addEventListener('click',close);}
    document.addEventListener('keydown',function(e){ if(e.key==='Escape'){ if(root.classList.contains('wf-nf-open')){ close(); } } });
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
