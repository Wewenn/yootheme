<?php
defined('ABSPATH') || exit;
if (empty($children)) return;
$cr=(int)($props['card_radius']??24);$cp=(int)($props['card_padding']??48);$cpm=(int)($props['card_padding_mobile']??28);
$min_h=(int)($props['card_min_height']??500);$gap=(int)($props['card_gap']??24);
$card_w=max(50,min(100,(int)($props['card_width']??90)));$card_max=(int)($props['card_max_width']??1200);$section_bg=trim($props['section_bg']??'');
$img_pos=$props['image_position']??'right';$img_r=(int)($props['image_radius']??16);$img_w=(int)($props['image_width']??45);
$t_size=(int)($props['title_size']??36);$t_size_m=(int)($props['title_size_mobile']??24);$t_weight=$props['title_weight']??'700';
$d_size=(int)($props['desc_size']??16);$d_size_m=(int)($props['desc_size_mobile']??14);
$shadow=!empty($props['shadow']);$offset=(int)($props['sticky_offset']??0);
$center=!empty($props['center_first']);
$pbar=!empty($props['progress_bar']);$pc=$props['progress_color']??'#EA5C1C';$ph=(int)($props['progress_height']??3);
$uid='wfhc_'.substr(md5(serialize($props).count($children)),0,8);$n=count($children);
$cards='';
foreach($children as $i=>$child){$cards.=$builder->render($child,['element'=>$props,'index'=>$i]);}
if(!trim($cards))return;
$shadow_css=$shadow?'box-shadow:0 8px 40px rgba(0,0,0,.15),0 0 0 1px rgba(0,0,0,.05);':'';
$is_side=in_array($img_pos,['left','right'],true);
if($img_pos==='both'){$grid_cols="{$img_w}% 1fr {$img_w}%";}
elseif($is_side){$grid_cols=$img_pos==='left'?"{$img_w}% 1fr":"1fr {$img_w}%";}
else{$grid_cols='1fr';}
$cfg=json_encode(['uid'=>$uid,'n'=>$n,'offset'=>$offset,'center'=>$center],JSON_HEX_AMP|JSON_HEX_APOS);
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr($uid) ?>" class="wf-hcards" style="position:relative;height:<?= $n*100 ?>vh;<?= $section_bg ? 'background:'.esc_attr($section_bg).';' : '' ?>">
    <div class="wf-hc-sticky" style="position:sticky;top:<?= $offset ?>px;height:calc(100vh - <?= $offset ?>px);overflow:hidden;display:flex;align-items:center;">
        <?php if ($pbar) : ?><div style="position:absolute;top:0;left:0;right:0;height:<?= $ph ?>px;z-index:10;background:rgba(0,0,0,.08);"><div class="wf-hc-pbar" style="height:100%;width:0;background:<?= esc_attr($pc) ?>;transition:width .05s linear;"></div></div><?php endif; ?>
        <div class="wf-hc-track" style="display:flex;gap:<?= $gap ?>px;will-change:transform;padding:<?= $gap ?>px;">
            <?= $cards ?>
        </div>
    </div>
</div>
<style>
#<?= esc_attr($uid) ?> .wf-hc-card{width:min(<?= $card_w ?>vw,<?= $card_max ?>px);flex-shrink:0;border-radius:<?= $cr ?>px;overflow:hidden;padding:<?= $cp ?>px;<?= $shadow_css ?><?= $min_h?"min-height:{$min_h}px;":'' ?>display:grid;grid-template-columns:<?= $grid_cols ?>;gap:<?= $cp ?>px;align-items:center}
#<?= esc_attr($uid) ?> .wf-hc-title{font-size:<?= $t_size ?>px;font-weight:<?= esc_attr($t_weight) ?>;line-height:1.15;letter-spacing:-0.02em;margin:0 0 12px}
#<?= esc_attr($uid) ?> .wf-hc-desc{font-size:<?= $d_size ?>px;line-height:1.65;opacity:.75;margin:0}
#<?= esc_attr($uid) ?> .wf-hc-media{border-radius:<?= $img_r ?>px;overflow:hidden;display:flex;align-items:center;justify-content:center;padding:<?= (int)($cp*0.5) ?>px;min-height:200px;<?= $img_pos==='left'?'order:-1;':'' ?><?= $img_pos==='top'?'order:-1;':'' ?>}
#<?= esc_attr($uid) ?> .wf-hc-media img{max-width:100%;max-height:100%;object-fit:contain}
@media(max-width:767px){
    #<?= esc_attr($uid) ?> .wf-hc-card{width:calc(100vw - <?= $gap*2 ?>px) !important;grid-template-columns:1fr !important;padding:<?= $cpm ?>px !important;min-height:auto !important;gap:<?= (int)($cpm*0.7) ?>px !important}
    #<?= esc_attr($uid) ?> .wf-hc-media{order:0 !important;min-height:160px;padding:<?= (int)($cpm*0.4) ?>px;margin:0 !important;border-radius:<?= $img_r ?>px !important;align-self:auto !important}
    #<?= esc_attr($uid) ?> .wf-hc-textcol{padding:0 !important}
    #<?= esc_attr($uid) ?> .wf-hc-title{font-size:<?= $t_size_m ?>px !important}
    #<?= esc_attr($uid) ?> .wf-hc-desc{font-size:<?= $d_size_m ?>px !important}
}
</style>
<script>
(function(){
    function boot(){
        
        var c = <?= $cfg ?>;
        var el=document.getElementById(c.uid);if(!el)return;
        var track=el.querySelector('.wf-hc-track');if(!track)return;
        var pbar=el.querySelector('.wf-hc-pbar');var ticking=false;
        /* Center first card: add initial padding */
        if(c.center){
            var firstCard=track.querySelector('.wf-hc-card');
            if(firstCard){
                var cardW=firstCard.offsetWidth;
                var viewW=window.innerWidth;
                var padLeft=Math.max(0,(viewW-cardW)/2);
                track.style.paddingLeft=padLeft+'px';
            }
        }
        function update(){
            var rect=el.getBoundingClientRect();
            var totalScroll=el.offsetHeight-window.innerHeight;
            if(totalScroll<=0){ticking=false;return}
            var scrolled=-rect.top;if(scrolled<0)scrolled=0;if(scrolled>totalScroll)scrolled=totalScroll;
            var progress=scrolled/totalScroll;
            var trackW=track.scrollWidth;var viewW=window.innerWidth;
            var maxMove=trackW-viewW;if(maxMove<0)maxMove=0;
            track.style.transform='translateX(-'+(progress*maxMove)+'px)';
            if(pbar){pbar.style.width=(progress*100)+'%'}
            ticking=false;
        }
        function onScroll(){if(!ticking){ticking=true;requestAnimationFrame(update)}}
        if('IntersectionObserver' in window){
            var bound=false;
            new IntersectionObserver(function(entries){var i=0;while(i<entries.length){if(entries[i].isIntersecting){if(!bound){bound=true;window.addEventListener('scroll',onScroll,{passive:true});update()}}else{if(bound){bound=false;window.removeEventListener('scroll',onScroll)}}i++}},{rootMargin:'200px'}).observe(el);
        }else{window.addEventListener('scroll',onScroll,{passive:true})}
        update();
    }
    WF.ready(boot)
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
