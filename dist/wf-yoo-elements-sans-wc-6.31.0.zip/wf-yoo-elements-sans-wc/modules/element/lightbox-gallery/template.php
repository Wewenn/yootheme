<?php
/**
 * WeFrame – Lightbox Gallery | template.php v6.0
 * Pure uk-lightbox + uk-grid — zero custom JS.
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$cols   = max( 1, (int) ( $props['columns'] ?? 3 ) );
$cols_m = max( 1, (int) ( $props['columns_mobile'] ?? 2 ) );
$gap    = (int) ( $props['gap'] ?? 16 );
$radius = (int) ( $props['radius'] ?? 8 );
$ratio  = $props['ratio'] ?? '1-1';
$anim   = $props['animation'] ?? 'fade';

$uid = wf_uid( 'wflg_', $props, count( $children ) );

$images = [];
foreach ( $children as $child ) {
    $cp  = (array) ( $child->props ?? [] );
    $src = $cp['image'] ?? '';
    if ( $src ) {
        if ( ! preg_match( '#^https?://#i', $src ) ) { $src = '/' . ltrim( $src, '/' ); }
        $images[] = [ 'src' => $src, 'caption' => $cp['caption'] ?? '' ];
    }
}
if ( empty( $images ) ) { return; }

$ratio_class = $ratio ? ' uk-cover-container' : '';
$ratio_attr  = $ratio ? " uk-img" : "";
?>
<?php $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( 'div' ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" uk-lightbox="animation: <?= esc_attr( $anim ) ?>">
    <div class="uk-grid uk-grid-<?= $gap <= 8 ? 'small' : ( $gap <= 16 ? 'medium' : 'match' ) ?> uk-child-width-1-<?= $cols_m ?>@s uk-child-width-1-<?= $cols ?>@m" uk-grid style="gap: <?= $gap ?>px;">
        <?php foreach ( $images as $img ) : ?>
        <div>
            <a class="uk-inline" href="<?= esc_url( $img['src'] ) ?>" data-caption="<?= esc_attr( $img['caption'] ) ?>">
                <?php if ( $ratio ) : ?>
                <div class="uk-cover-container" style="border-radius: <?= $radius ?>px; overflow: hidden;">
                    <canvas width="<?= $ratio === '16-9' ? 16 : ( $ratio === '4-3' ? 4 : ( $ratio === '3-2' ? 3 : 1 ) ) ?>" height="<?= $ratio === '16-9' ? 9 : ( $ratio === '4-3' ? 3 : ( $ratio === '3-2' ? 2 : 1 ) ) ?>"></canvas>
                    <img src="<?= esc_url( $img['src'] ) ?>" alt="<?= esc_attr( $img['caption'] ) ?>" loading="lazy" uk-cover>
                </div>
                <?php else : ?>
                <img src="<?= esc_url( $img['src'] ) ?>" alt="<?= esc_attr( $img['caption'] ) ?>" loading="lazy" style="border-radius: <?= $radius ?>px; width: 100%; display: block;">
                <?php endif; ?>
            </a>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
