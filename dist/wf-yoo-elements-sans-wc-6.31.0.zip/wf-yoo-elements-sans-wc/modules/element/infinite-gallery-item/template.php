<?php
/**
 * WeFrame – Galerie infinie : image (item).
 */
defined( 'ABSPATH' ) || exit;

$props = is_array( $props ?? null ) ? $props : array();

$img = trim( (string) ( $props['image'] ?? '' ) );
if ( '' === $img ) { return; }
if ( ! preg_match( '#^https?://#i', $img ) ) { $img = '/' . ltrim( $img, '/' ); }

$alt  = (string) ( $props['title'] ?? '' );
$link = $props['link'] ?? '';
if ( is_array( $link ) ) { $link = $link['url'] ?? ''; }
$link = (string) $link;

$tag  = '' !== $link ? 'a' : 'div';
$href = '' !== $link ? ' href="' . esc_url( $link ) . '"' : '';
?>
<<?= $tag ?> class="wf-ig-t"<?= $href ?> draggable="false">
	<img src="<?= esc_url( $img ) ?>" alt="<?= esc_attr( $alt ) ?>" loading="lazy" draggable="false">
</<?= $tag ?>>
