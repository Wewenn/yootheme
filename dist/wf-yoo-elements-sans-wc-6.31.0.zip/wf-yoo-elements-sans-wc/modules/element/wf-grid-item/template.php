<?php
/**
 * WeFrame – Grille WeFrame (carte enfant) | template.php v1.0
 * Modes : stat (chiffre animé), bar (barre), text, free (éléments déposés).
 * Le chiffre est rendu à sa valeur finale côté serveur : si le JS ne tourne pas,
 * le visiteur voit la vraie valeur (pas un 0).
 */
defined( 'ABSPATH' ) || exit;

$mode  = (string) ( $props['mode'] ?? 'stat' );
if ( ! in_array( $mode, array( 'stat', 'bar', 'text' ), true ) ) { $mode = 'stat'; }
$label = (string) ( $props['label'] ?? '' );
$title = (string) ( $props['title'] ?? '' );
$span  = max( 1, min( 3, (int) ( $props['span'] ?? 1 ) ) );

$bgOv  = trim( (string) ( $props['bg_override'] ?? '' ) );
$coOv  = trim( (string) ( $props['color_override'] ?? '' ) );

$link  = $props['link'] ?? '';
if ( is_array( $link ) ) { $link = $link['url'] ?? ''; }
$link  = (string) $link;

$style = '';
if ( $span > 1 )   { $style .= 'grid-column:span ' . $span . ';'; }
if ( '' !== $bgOv ) { $style .= 'background:' . esc_attr( $bgOv ) . ';'; }
if ( '' !== $coOv ) { $style .= 'color:' . esc_attr( $coOv ) . ';'; }

$tag   = ( '' !== $link ) ? 'a' : 'div';
$extra = ( '' !== $link ) ? ' href="' . esc_url( $link ) . '"' : '';

// Valeur finale formatée (secours sans JS + point de départ visuel identique).
$num      = (float) ( $props['number'] ?? 0 );
$decimals = max( 0, min( 3, (int) ( $props['decimals'] ?? 0 ) ) );
$prefix   = (string) ( $props['prefix'] ?? '' );
$suffix   = (string) ( $props['suffix'] ?? '' );
$numOut   = $prefix . number_format( $num, $decimals, ',', ' ' ) . $suffix;

// Contenu libre : tout element depose dans la carte est rendu ici.
$inner = '';
if ( ! empty( $children ) ) {
	if ( isset( $builder ) ) {
		foreach ( $children as $ci => $child ) {
			$inner .= $builder->render( $child, array( 'element' => $props, 'index' => $ci ) );
		}
	}
}
// Un <a> ne peut pas contenir d'autres liens : si la carte a du contenu depose,
// on retombe sur un <div> plutot que de produire des liens imbriques.
if ( '' !== $inner ) { $tag = 'div'; $extra = ''; }
?>
<<?= $tag ?> class="wf-grid-item<?= 'bar' === $mode ? ' wf-grid-item--bar' : '' ?>"<?= $extra ?><?= '' !== $style ? ' style="' . $style . '"' : '' ?>>
	<?php if ( 'bar' === $mode ) : ?>
		<?php
		$barMax = (float) ( $props['bar_max'] ?? 100 );
		$pct    = $barMax > 0 ? max( 0, min( 100, ( $num / $barMax ) * 100 ) ) : 0;
		?>
		<span class="wf-grid-num"
			data-target="<?= esc_attr( $num ) ?>"
			data-decimals="<?= esc_attr( $decimals ) ?>"
			data-prefix="<?= esc_attr( $prefix ) ?>"
			data-suffix="<?= esc_attr( $suffix ) ?>"><?= esc_html( $numOut ) ?></span>
		<?php if ( '' !== $label ) : ?><span class="wf-grid-label"><?= esc_html( $label ) ?></span><?php endif; ?>
		<div class="wf-grid-bar" role="progressbar"
			aria-valuenow="<?= esc_attr( round( $pct ) ) ?>" aria-valuemin="0" aria-valuemax="100"
			aria-label="<?= esc_attr( '' !== $label ? $label : $numOut ) ?>">
			<span class="wf-grid-bar-fill" data-pct="<?= esc_attr( round( $pct, 2 ) ) ?>" style="width:<?= esc_attr( round( $pct, 2 ) ) ?>%"></span>
		</div>
	<?php elseif ( 'stat' === $mode ) : ?>
		<span class="wf-grid-num"
			data-target="<?= esc_attr( $num ) ?>"
			data-decimals="<?= esc_attr( $decimals ) ?>"
			data-prefix="<?= esc_attr( $prefix ) ?>"
			data-suffix="<?= esc_attr( $suffix ) ?>"><?= esc_html( $numOut ) ?></span>
		<?php if ( '' !== $label ) : ?><span class="wf-grid-label"><?= esc_html( $label ) ?></span><?php endif; ?>
	<?php elseif ( 'text' === $mode ) : ?>
		<?php if ( '' !== $title ) : ?><span class="wf-grid-title"><?= esc_html( $title ) ?></span><?php endif; ?>
		<?php if ( '' !== $label ) : ?><span class="wf-grid-label"><?= esc_html( $label ) ?></span><?php endif; ?>
	<?php endif; ?>
	<?php if ( '' !== $inner ) : ?><div class="wf-grid-free"><?= $inner ?></div><?php endif; ?>
</<?= $tag ?>>
