<?php
/**
 * WeFrame – Grille qui s'assemble : image (item).
 */
defined( 'ABSPATH' ) || exit;
$img = trim( (string) ( $props['image'] ?? '' ) );
if ( '' === $img ) { return; }
if ( ! preg_match( '#^https?://#i', $img ) ) { $img = '/' . ltrim( $img, '/' ); }
$link = $props['link'] ?? '';
if ( is_array( $link ) ) { $link = $link['url'] ?? ''; }
$link = (string) $link;
$tag  = '' !== $link ? 'a' : 'div';
$href = '' !== $link ? ' href="' . esc_url( $link ) . '"' : '';
?>
<<?= $tag ?> class="wf-ag-i"<?= $href ?> style="display:block;">
    <img src="<?= esc_url( $img ) ?>" alt="" loading="lazy" style="width:100%;height:100%;object-fit:cover;display:block;">
</<?= $tag ?>>
