<?php
/**
 * WeFrame – Accordion FAQ | template.php v6.0
 * Uses uk-accordion (zero custom JS). Optional FAQ Schema JSON-LD for SEO.
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$multiple   = ! empty( $props['multiple'] );
$first_open = ! empty( $props['first_open'] );
$schema     = ! empty( $props['schema'] );
$icon_color = $props['icon_color'] ?? '#EA5C1C';
$border     = $props['border_color'] ?? '#e5e5e5';
$gap        = (int) ( $props['gap'] ?? 0 );

$uid = wf_uid( 'wfaq_', $props, count( $children ) );

// Collect Q&A for schema
$qa_items = [];
foreach ( $children as $child ) {
    $cp = (array) ( $child->props ?? [] );
    $q  = $cp['question'] ?? '';
    $a  = $cp['answer'] ?? '';
    if ( $q && $a ) {
        $qa_items[] = [ 'q' => $q, 'a' => $a ];
    }
}

$uk_opts = [];
if ( $multiple ) { $uk_opts[] = 'multiple: true'; }
if ( $first_open ) { $uk_opts[] = 'active: 0'; }
$uk_attr = implode( '; ', $uk_opts );
?>
<?php $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( 'div' ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>">
    <ul class="uk-accordion" uk-accordion="<?= esc_attr( $uk_attr ) ?>">
        <?php foreach ( $children as $i => $child ) :
            $cp = (array) ( $child->props ?? [] );
            $q  = $cp['question'] ?? 'Question';
            $a  = $cp['answer'] ?? '';
            $slug = sanitize_title( $q ) ?: ( 'q' . ( $i + 1 ) );
        ?>
        <li id="faq-<?= esc_attr( $slug ) ?>"<?= ( $first_open && $i === 0 ) ? ' class="uk-open"' : '' ?>>
            <a class="uk-accordion-title" href style="border-bottom: 1px solid <?= esc_attr( $border ) ?>; padding: 16px 0; font-weight: 600;">
                <?= esc_html( $q ) ?>
            </a>
            <div class="uk-accordion-content" style="padding: 16px 0;">
                <?= wp_kses_post( $a ) ?>
            </div>
        </li>
        <?php endforeach; ?>
    </ul>
</div>

<?php if ( $icon_color !== '#EA5C1C' || $gap > 0 ) : ?>
<style>
<?php if ( $icon_color !== '#EA5C1C' ) : ?>
#<?= esc_attr( $uid ) ?> .uk-accordion-title::before { color: <?= esc_attr( $icon_color ) ?>; }
<?php endif; ?>
<?php if ( $gap > 0 ) : ?>
#<?= esc_attr( $uid ) ?> .uk-accordion > :nth-child(n+2) { margin-top: <?= $gap ?>px; }
<?php endif; ?>
</style>
<?php endif; ?>

<script>
(function(){
    WF.ready(function(){
        var root = document.getElementById('<?= esc_attr( $uid ) ?>');
        if (!root || !window.UIkit) return;
        function openFromHash(){
            var h = (location.hash || '').replace('#','');
            if (!h) return;
            var target = root.querySelector('#' + CSS.escape(h));
            if (!target) return;
            var items = [].slice.call(root.querySelectorAll('.uk-accordion > li'));
            var idx = items.indexOf(target);
            if (idx < 0) return;
            try { UIkit.accordion(root.querySelector('.uk-accordion')).toggle(idx, false); } catch(e) {}
            setTimeout(function(){ target.scrollIntoView({ behavior:'smooth', block:'start' }); }, 120);
        }
        openFromHash();
        window.addEventListener('hashchange', openFromHash);
    });
})();
</script>

<?php if ( $schema && ! empty( $qa_items ) ) : ?>
<script type="application/ld+json">
<?= wp_json_encode( [
    '@context'   => 'https://schema.org',
    '@type'      => 'FAQPage',
    'mainEntity' => array_map( function ( $item ) {
        return [
            '@type'          => 'Question',
            'name'           => $item['q'],
            'acceptedAnswer' => [
                '@type' => 'Answer',
                'text'  => wp_strip_all_tags( $item['a'] ),
            ],
        ];
    }, $qa_items ),
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT ) ?>
</script>
<?php endif; ?>

<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
