<?php
defined('ABSPATH') || exit;
if (empty($children)) return;
$features = array_filter(array_map('trim', explode("\n", $props['features']??'')));
$hbg = $props['header_bg']??'#f8f8f8'; $hlbg = $props['highlight_bg']??'#EA5C1C';
$hlc = $props['highlight_color']??'#fff'; $r = (int)($props['radius']??16);
$ckc = $props['check_color']??'#16a34a'; $crc = $props['cross_color']??'#dc2626';
$uid = 'wfcmp_'.substr(md5(serialize($props).count($children)),0,8);
$plans = [];
foreach ($children as $child) {
    $cp = (array)($child->props ?? []);
    $plans[] = $cp;
}
$nPlans = count($plans);
$check = '<svg aria-hidden="true" focusable="false" width="18" height="18" viewBox="0 0 20 20" fill="none" stroke="'.esc_attr($ckc).'" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 10 8 14 16 6"/></svg>';
$cross = '<svg aria-hidden="true" focusable="false" width="18" height="18" viewBox="0 0 20 20" fill="none" stroke="'.esc_attr($crc).'" stroke-width="2" stroke-linecap="round"><line x1="6" y1="6" x2="14" y2="14"/><line x1="14" y1="6" x2="6" y2="14"/></svg>';
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr($uid) ?>" style="overflow-x:auto;">
<table style="width:100%;border-collapse:separate;border-spacing:0;font-size:14px;line-height:1.5;">
    <thead>
        <tr>
            <th style="padding:16px 20px;text-align:left;background:<?= esc_attr($hbg) ?>;border-radius:<?= $r ?>px 0 0 0;"></th>
            <?php foreach ($plans as $i => $p) :
                $hl = !empty($p['is_highlighted']);
                $bg = $hl ? $hlbg : $hbg; $c = $hl ? $hlc : 'inherit';
                $br = ($i === $nPlans-1) ? "border-radius:0 {$r}px 0 0;" : '';
            ?>
            <th style="padding:20px;text-align:center;background:<?= esc_attr($bg) ?>;color:<?= esc_attr($c) ?>;<?= $br ?>min-width:140px;">
                <div style="font-size:18px;font-weight:700;"><?= esc_html($p['title']??'') ?></div>
                <div style="font-size:28px;font-weight:800;margin:8px 0 4px;">
                    <?= esc_html($p['price']??'') ?>
                    <?php if (!empty($p['period'])) : ?><span style="font-size:14px;font-weight:400;opacity:.7;"><?= esc_html($p['period']) ?></span><?php endif; ?>
                </div>
            </th>
            <?php endforeach; ?>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($features as $fi => $feat) : ?>
        <tr style="<?= $fi%2===0?'background:rgba(0,0,0,.02);':'' ?>">
            <td style="padding:12px 20px;font-weight:500;"><?= esc_html($feat) ?></td>
            <?php foreach ($plans as $p) :
                $vals = array_map('trim', explode("\n", $p['values']??''));
                $v = $vals[$fi] ?? '';
                $hl = !empty($p['is_highlighted']);
                $bg = $hl ? 'rgba(234,92,28,.05)' : 'transparent';
            ?>
            <td style="padding:12px 20px;text-align:center;background:<?= $bg ?>;">
                <?php if ($v === '1') { echo $check; } elseif ($v === '0') { echo $cross; } else { echo esc_html($v); } ?>
            </td>
            <?php endforeach; ?>
        </tr>
        <?php endforeach; ?>
    </tbody>
    <tfoot>
        <tr>
            <td style="padding:20px;"></td>
            <?php foreach ($plans as $i => $p) :
                $hl = !empty($p['is_highlighted']); $ct = $p['cta_text']??''; $cl = $p['cta_link']??'';
                $bg2 = $hl ? $hlbg : 'transparent'; $c2 = $hl ? $hlc : 'inherit';
                $brl = ($i===0) ? "border-radius:0 0 0 {$r}px;" : (($i===$nPlans-1) ? "border-radius:0 0 {$r}px 0;" : '');
            ?>
            <td style="padding:20px;text-align:center;background:<?= esc_attr($hl?'rgba(234,92,28,.05)':'transparent') ?>;<?= $brl ?>">
                <?php if ($ct) : ?>
                <a href="<?= esc_url($cl) ?>" style="display:inline-block;padding:10px 24px;border-radius:100px;font-size:14px;font-weight:600;text-decoration:none;<?= $hl ? "background:".esc_attr($hlbg).";color:".esc_attr($hlc).";" : "border:2px solid #333;color:#333;" ?>"><?= esc_html($ct) ?></a>
                <?php endif; ?>
            </td>
            <?php endforeach; ?>
        </tr>
    </tfoot>
</table>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
