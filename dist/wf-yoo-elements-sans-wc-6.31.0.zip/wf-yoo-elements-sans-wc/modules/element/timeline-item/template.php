<?php
defined('ABSPATH') || exit;
$date = $props['date']??''; $title = $props['title']??''; $content = $props['content']??'';
$img = $props['image']??''; $ialt = $props['image_alt']??'';
if (!$title) return;
if ($img) { if (!preg_match('#^https?://#i',$img)) $img='/'.ltrim($img,'/'); }

// Contenu libre depose dans la carte (sublayout).
$wfInner = '';
if ( ! empty( $children ) ) {
	foreach ( $children as $wfI => $wfChild ) {
		$wfInner .= $builder->render( $wfChild, array( 'element' => $props, 'index' => $wfI ) );
	}
}
$dc = $element['date_color']??'#888'; $ts = (int)($element['title_size']??20); $tw = $element['title_weight']??'700';
?>
<div class="wf-tl-item">
    <div class="wf-tl-dot"></div>
    <?php if ($date) : ?><div style="font-size:12px;font-weight:700;color:<?= esc_attr($dc) ?>;text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px;"><?= esc_html($date) ?></div><?php endif; ?>
    <div style="font-size:<?= $ts ?>px;font-weight:<?= esc_attr($tw) ?>;line-height:1.3;margin-bottom:6px;"><?= esc_html($title) ?></div>
    <?php if ($content) : ?><p style="margin:0;font-size:14px;line-height:1.6;color:#555;"><?= esc_html($content) ?></p><?php endif; ?>
    <?php if ($img) : ?><img src="<?= esc_url($img) ?>" alt="<?= esc_attr($ialt) ?>" loading="lazy" style="margin-top:10px;border-radius:8px;max-width:100%;height:auto;"><?php endif; ?>
<?php if ( '' !== trim( $wfInner ) ) : ?><div class="wf-free"><?= $wfInner ?></div><?php endif; ?>
</div>
