<?php
/**
 * WeFrame – Pile qui se déploie : vignette (item).
 */
defined( 'ABSPATH' ) || exit;

$props = is_array( $props ?? null ) ? $props : array();

$img = trim( (string) ( $props['image'] ?? '' ) );
if ( '' === $img ) { return; }
if ( ! preg_match( '#^https?://#i', $img ) ) { $img = '/' . ltrim( $img, '/' ); }

$alt = (string) ( $props['title'] ?? '' );
?>
<span class="wf-if-i"><img src="<?= esc_url( $img ) ?>" alt="<?= esc_attr( $alt ) ?>" loading="lazy" draggable="false"></span>
