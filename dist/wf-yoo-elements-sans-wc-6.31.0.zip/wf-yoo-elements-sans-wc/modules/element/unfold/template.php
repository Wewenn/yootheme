<?php
/**
 * WeFrame – Unfold (grille depliante) | template.php v1.0
 * Une grille de tuiles ; au clic, le volet correspondant se deplie sur toute la
 * largeur, juste sous la ligne de la tuile. Le volet est deplace dans le DOM
 * apres la derniere tuile de sa ligne : le rang est recalcule a chaque
 * redimensionnement, donc le repere reste juste quel que soit le nombre de colonnes.
 * Sans JS, tuiles et volets restent lisibles (rien n'est masque au chargement).
 * Pas de "&&" ni de "||" dans le JS inline (regle interne du plugin).
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$cols   = max( 1, min( 6, (int) ( $props['columns'] ?? 3 ) ) );
$colsT  = max( 1, min( 4, (int) ( $props['columns_tablet'] ?? 2 ) ) );
$colsM  = max( 1, min( 2, (int) ( $props['columns_mobile'] ?? 1 ) ) );
$gap    = max( 0, (int) ( $props['gap'] ?? 16 ) );

$tLayout = (string) ( $props['tile_layout'] ?? 'text' );
if ( ! in_array( $tLayout, array( 'text', 'image-top', 'image-bg', 'icon' ), true ) ) { $tLayout = 'text'; }
$tH     = max( 0, (int) ( $props['tile_height'] ?? 0 ) );
$tBg    = (string) ( $props['tile_bg'] ?? '#f4f4f5' );
$tCol   = (string) ( $props['tile_color'] ?? '#111111' );
$tMut   = (string) ( $props['tile_muted'] ?? '#6b7280' );
$tBd    = trim( (string) ( $props['tile_border'] ?? '' ) );
$tActBg = trim( (string) ( $props['tile_active_bg'] ?? '' ) );
$tRad   = max( 0, (int) ( $props['tile_radius'] ?? 14 ) );
$tPad   = max( 0, (int) ( $props['tile_padding'] ?? 22 ) );
$tSize  = max( 12, (int) ( $props['title_size'] ?? 18 ) );
$acc    = (string) ( $props['accent_color'] ?? '#EA5C1C' );
$hover  = (string) ( $props['hover'] ?? 'lift' );
$marker = ! empty( $props['marker'] );

$pBg    = trim( (string) ( $props['panel_bg'] ?? '#ffffff' ) );
$pCol   = trim( (string) ( $props['panel_color'] ?? '' ) );
$pPad   = max( 0, (int) ( $props['panel_padding'] ?? 28 ) );
$pRad   = max( 0, (int) ( $props['panel_radius'] ?? 14 ) );
$pBd    = trim( (string) ( $props['panel_border'] ?? '' ) );

$animMs = max( 0, (int) ( $props['anim_duration'] ?? 360 ) );
$openF  = ! empty( $props['open_first'] );
$single = ! empty( $props['single'] );
$scroll = ! empty( $props['scroll_into_view'] );
$deep   = ! empty( $props['deeplink'] );

$icons = array(
	'star'   => '<path d="M239.2,97.29a16,16,0,0,0-13.81-11L166,81.17,142.72,25.81h0a15.95,15.95,0,0,0-29.44,0L90.07,81.17,30.61,86.32a16,16,0,0,0-9.11,28.06L66.61,153.8,53.09,212.34a16,16,0,0,0,23.84,17.34l51-31,51.11,31a16,16,0,0,0,23.84-17.34l-13.51-58.6,45.1-39.36A16,16,0,0,0,239.2,97.29Z"/>',
	'bolt'   => '<path d="M215.79,118.17a8,8,0,0,0-5-5.66L153.18,90.9l14.66-73.33a8,8,0,0,0-13.69-7L39,153.06A8,8,0,0,0,45,166l57.63,21.61L88,260.93a8,8,0,0,0,13.69,7L217,102.94A8,8,0,0,0,215.79,118.17Z" transform="translate(0 -18)"/>',
	'target' => '<path d="M221.87,83.16A104.1,104.1,0,1,1,195.67,49l22.67-22.68a8,8,0,0,1,11.32,11.32l-96,96a8,8,0,0,1-11.32-11.32l27.72-27.72A40,40,0,1,0,168,128a8,8,0,0,1,16,0,56,56,0,1,1-21.31-44l17.34-17.34A79.79,79.79,0,0,0,128,48a80,80,0,1,0,80,80,78.72,78.72,0,0,0-2.32-19.17,8,8,0,0,1,15.51-3.87Z"/>',
	'shield' => '<path d="M208,40H48A16,16,0,0,0,32,56v58.78c0,89.61,75.82,119.34,91,124.39a15.53,15.53,0,0,0,10,0c15.2-5.05,91-34.78,91-124.39V56A16,16,0,0,0,208,40Zm0,74.79c0,78.42-66.35,104.62-80,109.18-13.53-4.51-80-30.69-80-109.18V56H208ZM82.34,141.66a8,8,0,0,1,11.32-11.32L112,148.68l50.34-50.34a8,8,0,0,1,11.32,11.32l-56,56a8,8,0,0,1-11.32,0Z"/>',
	'bulb'   => '<path d="M176,232a8,8,0,0,1-8,8H88a8,8,0,0,1,0-16h80A8,8,0,0,1,176,232Zm40-128a87.55,87.55,0,0,1-33.64,69.21A16.24,16.24,0,0,0,176,186v6a16,16,0,0,1-16,16H96a16,16,0,0,1-16-16v-6a16,16,0,0,0-6.23-12.66A87.59,87.59,0,0,1,40,104.49C39.74,56.83,78.26,17.14,125.88,16A88,88,0,0,1,216,104Zm-16,0a72,72,0,0,0-73.74-72c-39,.92-70.47,33.39-70.26,72.4a71.65,71.65,0,0,0,27.64,56.3A32,32,0,0,1,96,186v6h64v-6a32.12,32.12,0,0,1,12.47-25.35A71.65,71.65,0,0,0,200,104Z"/>',
	'chart'  => '<path d="M224,200h-8V40a8,8,0,0,0-8-8H152a8,8,0,0,0-8,8V80H96a8,8,0,0,0-8,8v40H48a8,8,0,0,0-8,8v64H32a8,8,0,0,0,0,16H224a8,8,0,0,0,0-16ZM160,48h40V200H160ZM104,96h40V200H104ZM56,144H88v56H56Z"/>',
);

$uid = wf_uid( 'wfuf_', $props, count( $children ) );

$tiles = array();
foreach ( $children as $i => $child ) {
	$cp    = (array) ( $child->props ?? array() );
	$title = trim( (string) ( $cp['title'] ?? '' ) );
	if ( '' === $title ) { $title = sprintf( __( 'Tuile %d', 'weframe' ), $i + 1 ); }

	$img = $cp['image'] ?? '';
	if ( is_array( $img ) ) { $img = $img['src'] ?? ( $img['url'] ?? '' ); }

	$slugSrc = trim( (string) ( $cp['anchor'] ?? '' ) );
	if ( '' === $slugSrc ) { $slugSrc = $title; }
	$slug = sanitize_title( $slugSrc );
	if ( '' === $slug ) { $slug = 't' . ( $i + 1 ); }

	$tiles[] = array(
		'title' => $title,
		'sub'   => trim( (string) ( $cp['subtitle'] ?? '' ) ),
		'badge' => trim( (string) ( $cp['badge'] ?? '' ) ),
		'icon'  => (string) ( $cp['icon'] ?? 'none' ),
		'img'   => trim( (string) $img ),
		'alt'   => trim( (string) ( $cp['image_alt'] ?? '' ) ),
		'span'  => max( 1, min( 3, (int) ( $cp['span'] ?? 1 ) ) ),
		'slug'  => $slug,
		'bg'    => trim( (string) ( $cp['bg_override'] ?? '' ) ),
		'col'   => trim( (string) ( $cp['color_override'] ?? '' ) ),
		'html'  => $builder->render( $child, array( 'element' => $props, 'index' => $i ) ),
	);

	$last = count( $tiles ) - 1;
	$st   = '';
	if ( $tiles[ $last ]['span'] > 1 ) { $st .= 'grid-column:span ' . (int) $tiles[ $last ]['span'] . ';'; }
	if ( '' !== $tiles[ $last ]['bg'] ) { $st .= 'background:' . esc_attr( $tiles[ $last ]['bg'] ) . ';'; }
	if ( '' !== $tiles[ $last ]['col'] ) { $st .= 'color:' . esc_attr( $tiles[ $last ]['col'] ) . ';'; }
	$tiles[ $last ]['style'] = $st;
}
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-unfold wf-unfold--<?= esc_attr( $tLayout ) ?> wf-unfold--hover-<?= esc_attr( $hover ) ?><?= $marker ? ' wf-unfold--marker' : '' ?>">
<div class="wf-unfold__grid">
	<?php foreach ( $tiles as $i => $t ) : ?>
	<button type="button" class="wf-unfold__tile" id="<?= esc_attr( $uid ) ?>-t<?= (int) $i ?>"
		aria-expanded="false" aria-controls="<?= esc_attr( $uid ) ?>-p<?= (int) $i ?>"
		data-slug="<?= esc_attr( $t['slug'] ) ?>"
		<?= '' !== $t['style'] ? ' style="' . $t['style'] . '"' : '' ?>>
		<?php if ( 'image-bg' === $tLayout && '' !== $t['img'] ) : ?>
		<span class="__bg" aria-hidden="true"><img src="<?= esc_url( $t['img'] ) ?>" alt="" loading="lazy" decoding="async"></span>
		<?php elseif ( 'image-top' === $tLayout && '' !== $t['img'] ) : ?>
		<span class="__media"><img src="<?= esc_url( $t['img'] ) ?>" alt="<?= esc_attr( $t['alt'] ) ?>" loading="lazy" decoding="async"<?= '' === $t['alt'] ? ' aria-hidden="true"' : '' ?>></span>
		<?php elseif ( 'icon' === $tLayout && isset( $icons[ $t['icon'] ] ) ) : ?>
		<span class="__icon" aria-hidden="true"><svg viewBox="0 0 256 256" width="26" height="26" fill="currentColor"><?= $icons[ $t['icon'] ] ?></svg></span>
		<?php endif; ?>
		<span class="__txt">
			<?php if ( '' !== $t['badge'] ) : ?><span class="__badge"><?= esc_html( $t['badge'] ) ?></span><?php endif; ?>
			<span class="__title"><?= esc_html( $t['title'] ) ?></span>
			<?php if ( '' !== $t['sub'] ) : ?><span class="__sub"><?= esc_html( $t['sub'] ) ?></span><?php endif; ?>
		</span>
		<?php if ( $marker ) : ?>
		<svg class="__chev" viewBox="0 0 256 256" width="18" height="18" fill="currentColor" aria-hidden="true" focusable="false"><path d="M213.66,101.66l-80,80a8,8,0,0,1-11.32,0l-80-80A8,8,0,0,1,53.66,90.34L128,164.69l74.34-74.35a8,8,0,0,1,11.32,11.32Z"/></svg>
		<?php endif; ?>
	</button>
	<?php endforeach; ?>

	<?php foreach ( $tiles as $i => $t ) : ?>
	<div class="wf-unfold__panel" id="<?= esc_attr( $uid ) ?>-p<?= (int) $i ?>" role="region"
		aria-labelledby="<?= esc_attr( $uid ) ?>-t<?= (int) $i ?>">
		<div class="__inner"><div class="__pad"><?= $t['html'] ?></div></div>
	</div>
	<?php endforeach; ?>
</div>
</div>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
/* container-type sur l'enveloppe, grille sur l'enfant : une container query
   ne s'applique jamais au conteneur qui la declare, seulement a ses descendants. */
#<?= esc_attr( $uid ) ?>{container-type:inline-size;display:block;}
#<?= esc_attr( $uid ) ?> .wf-unfold__grid{
	display:grid;gap:<?= (int) $gap ?>px;
	grid-template-columns:repeat(<?= (int) $cols ?>,minmax(0,1fr));
	align-items:start;
}
@container (max-width: 900px){
	#<?= esc_attr( $uid ) ?> .wf-unfold__grid{grid-template-columns:repeat(<?= (int) $colsT ?>,minmax(0,1fr));}
	#<?= esc_attr( $uid ) ?> .wf-unfold__tile{grid-column:span 1;}
}
@container (max-width: 560px){
	#<?= esc_attr( $uid ) ?> .wf-unfold__grid{grid-template-columns:repeat(<?= (int) $colsM ?>,minmax(0,1fr));}
}
#<?= esc_attr( $uid ) ?> .wf-unfold__tile{
	position:relative;display:flex;flex-direction:column;align-items:flex-start;gap:.6em;
	width:100%;text-align:left;cursor:pointer;font-family:inherit;overflow:hidden;
	background:<?= esc_attr( $tBg ) ?>;color:<?= esc_attr( $tCol ) ?>;
	<?= '' !== $tBd ? 'border:1px solid ' . esc_attr( $tBd ) . ';' : 'border:1px solid transparent;' ?>
	border-radius:<?= (int) $tRad ?>px;padding:<?= (int) $tPad ?>px;
	<?= $tH > 0 ? 'min-height:' . (int) $tH . 'px;' : '' ?>
	transition:transform .25s ease,box-shadow .25s ease,background-color .25s ease,border-color .25s ease;
}
@media (pointer:coarse){#<?= esc_attr( $uid ) ?> .wf-unfold__tile{min-height:<?= (int) max( 56, $tH ) ?>px;}}
#<?= esc_attr( $uid ) ?> .wf-unfold__tile:focus-visible{outline:2px solid <?= esc_attr( $acc ) ?>;outline-offset:3px;}
#<?= esc_attr( $uid ) ?> .__txt{display:flex;flex-direction:column;gap:.3em;min-width:0;width:100%;}
#<?= esc_attr( $uid ) ?> .__title{font-size:<?= (int) $tSize ?>px;font-weight:700;line-height:1.25;}
#<?= esc_attr( $uid ) ?> .__sub{font-size:<?= max( 11, (int) round( $tSize * .78 ) ) ?>px;font-weight:400;color:<?= esc_attr( $tMut ) ?>;line-height:1.45;}
#<?= esc_attr( $uid ) ?> .__badge{
	align-self:flex-start;font-size:10px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;
	padding:.35em .7em;border-radius:100px;background:<?= esc_attr( $acc ) ?>;color:#fff;
}
#<?= esc_attr( $uid ) ?> .__icon{
	display:inline-flex;align-items:center;justify-content:center;width:2.4em;height:2.4em;
	border-radius:12px;background:<?= esc_attr( $acc ) ?>;color:#fff;flex:0 0 auto;
}
#<?= esc_attr( $uid ) ?> .__media{display:block;width:100%;aspect-ratio:16 / 9;overflow:hidden;border-radius:<?= (int) max( 0, $tRad - 4 ) ?>px;}
#<?= esc_attr( $uid ) ?> .__media img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .4s ease;}
#<?= esc_attr( $uid ) ?> .__bg{position:absolute;inset:0;z-index:0;}
#<?= esc_attr( $uid ) ?> .__bg img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .4s ease;}
#<?= esc_attr( $uid ) ?> .__bg::after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,.15),rgba(0,0,0,.72));}
#<?= esc_attr( $uid ) ?>.wf-unfold--image-bg .__txt,#<?= esc_attr( $uid ) ?>.wf-unfold--image-bg .__chev{position:relative;z-index:1;color:#fff;}
#<?= esc_attr( $uid ) ?>.wf-unfold--image-bg .__sub{color:rgba(255,255,255,.82);}
#<?= esc_attr( $uid ) ?> .__chev{margin-top:auto;align-self:flex-end;transition:transform .25s ease;opacity:.6;}
#<?= esc_attr( $uid ) ?> .wf-unfold__tile[aria-expanded="true"] .__chev{transform:rotate(180deg);opacity:1;color:<?= esc_attr( $acc ) ?>;}
<?php if ( 'lift' === $hover ) : ?>
#<?= esc_attr( $uid ) ?> .wf-unfold__tile:hover{transform:translateY(-3px);box-shadow:0 12px 28px rgba(0,0,0,.12);}
<?php elseif ( 'zoom' === $hover ) : ?>
#<?= esc_attr( $uid ) ?> .wf-unfold__tile:hover .__media img,#<?= esc_attr( $uid ) ?> .wf-unfold__tile:hover .__bg img{transform:scale(1.06);}
<?php endif; ?>
#<?= esc_attr( $uid ) ?> .wf-unfold__tile[aria-expanded="true"]{
	border-color:<?= esc_attr( $acc ) ?>;
	<?= '' !== $tActBg ? 'background:' . esc_attr( $tActBg ) . ';' : '' ?>
}

#<?= esc_attr( $uid ) ?> .wf-unfold__panel{
	grid-column:1 / -1;
	<?= '' !== $pBg ? 'background:' . esc_attr( $pBg ) . ';' : '' ?>
	<?= '' !== $pCol ? 'color:' . esc_attr( $pCol ) . ';' : '' ?>
	<?= '' !== $pBd ? 'border:1px solid ' . esc_attr( $pBd ) . ';' : '' ?>
	border-radius:<?= (int) $pRad ?>px;
}
#<?= esc_attr( $uid ) ?> .wf-unfold__panel .__pad{padding:<?= (int) $pPad ?>px;}
<?php if ( $marker ) : ?>
#<?= esc_attr( $uid ) ?>.is-ready .wf-unfold__panel.is-open{position:relative;box-shadow:inset 0 3px 0 <?= esc_attr( $acc ) ?>;}
<?php endif; ?>

/* Sans JS : tuiles et volets sont tous lisibles. Le script prend la main ensuite. */
#<?= esc_attr( $uid ) ?>.is-ready .wf-unfold__panel{
	display:grid;grid-template-rows:0fr;
	transition:grid-template-rows <?= (int) $animMs ?>ms cubic-bezier(.2,.8,.2,1);
	border-width:0;
}
#<?= esc_attr( $uid ) ?>.is-ready .wf-unfold__panel > .__inner{overflow:hidden;min-height:0;}
#<?= esc_attr( $uid ) ?>.is-ready .wf-unfold__panel.is-open{
	grid-template-rows:1fr;
	<?= '' !== $pBd ? 'border-width:1px;' : '' ?>
}
#<?= esc_attr( $uid ) ?>.is-ready .wf-unfold__panel[hidden]{display:none;}
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?>.is-ready .wf-unfold__panel{transition-duration:.001ms;}
	#<?= esc_attr( $uid ) ?> .wf-unfold__tile{transition-duration:.001ms;}
}
</style>

<script>
(function(){
	var root = document.getElementById('<?= esc_js( $uid ) ?>');
	if (!root) { return; }
	var tiles  = [].slice.call(root.querySelectorAll('.wf-unfold__tile'));
	var panels = [].slice.call(root.querySelectorAll('.wf-unfold__panel'));
	if (!tiles.length) { return; }
	var single = <?= $single ? 'true' : 'false' ?>;
	var open   = [];

	root.classList.add('is-ready');
	for (var k = 0; k < panels.length; k++) { panels[k].hidden = true; }

	// Derniere tuile de la ligne de `i` : on compare les positions verticales,
	// ce qui reste juste avec des tuiles sur 2 ou 3 colonnes.
	function rowEnd(i){
		var top = tiles[i].offsetTop;
		var last = tiles[i];
		for (var k = i + 1; k < tiles.length; k++) {
			if (Math.abs(tiles[k].offsetTop - top) > 4) { break; }
			last = tiles[k];
		}
		return last;
	}

	function place(i){
		var anchor = rowEnd(i);
		var p = panels[i];
		if (anchor.nextElementSibling === p) { return; }
		anchor.parentNode.insertBefore(p, anchor.nextElementSibling);
	}

	function close(i){
		var idx = open.indexOf(i);
		if (idx > -1) { open.splice(idx, 1); }
		tiles[i].setAttribute('aria-expanded', 'false');
		panels[i].classList.remove('is-open');
		var p = panels[i];
		window.setTimeout(function(){
			if (p.classList.contains('is-open')) { return; }
			p.hidden = true;
		}, <?= (int) $animMs ?>);
	}

	function show(i, focusIt){
		if (single) {
			for (var k = open.length - 1; k >= 0; k--) {
				if (open[k] !== i) { close(open[k]); }
			}
		}
		place(i);
		var p = panels[i];
		p.hidden = false;
		tiles[i].setAttribute('aria-expanded', 'true');
		if (open.indexOf(i) === -1) { open.push(i); }
		// Reflow synchrone : la transition part bien de 0fr. On n'utilise pas
		// requestAnimationFrame, qui ne se declenche jamais dans un onglet en
		// arriere-plan (le volet resterait alors ferme).
		void p.offsetHeight;
		p.classList.add('is-open');
<?php if ( $deep ) : ?>
		var slug = tiles[i].getAttribute('data-slug');
		if (slug) {
			try { history.replaceState(null, '', '#' + slug); } catch (err) {}
		}
<?php endif; ?>
<?php if ( $scroll ) : ?>
		if (focusIt) {
			window.setTimeout(function(){
				var r = tiles[i].getBoundingClientRect();
				if (r.top >= 0) {
					if (r.top < window.innerHeight * 0.5) { return; }
				}
				tiles[i].scrollIntoView({ behavior: 'smooth', block: 'center' });
			}, <?= (int) min( 400, $animMs ) ?>);
		}
<?php endif; ?>
	}

	function toggle(i){
		if (open.indexOf(i) > -1) { close(i); return; }
		show(i, true);
	}

	for (var t = 0; t < tiles.length; t++) {
		(function(idx){
			tiles[idx].addEventListener('click', function(){ toggle(idx); });
		})(t);
	}

	// Le nombre de colonnes change : le volet ouvert doit suivre sa ligne.
	function reflow(){
		for (var k = 0; k < open.length; k++) { place(open[k]); }
	}
	if (window.ResizeObserver) {
		new ResizeObserver(reflow).observe(root);
	} else {
		window.addEventListener('resize', reflow);
	}

	var startIdx = -1;
<?php if ( $deep ) : ?>
	(function(){
		var h = location.hash ? location.hash.replace('#', '') : '';
		if (!h) { return; }
		for (var k = 0; k < tiles.length; k++) {
			if (tiles[k].getAttribute('data-slug') === h) { startIdx = k; return; }
		}
	})();
<?php endif; ?>
<?php if ( $openF ) : ?>
	if (startIdx === -1) { startIdx = 0; }
<?php endif; ?>
	if (startIdx > -1) { show(startIdx, false); }
})();
</script>
