<?php
/**
 * WeFrame – Entrée | template.php v1.0
 * L'enfant ne rend rien : le parent lit ses proprietes et compose tout.
 */
defined( 'ABSPATH' ) || exit;
