<?php
/**
 * WeFrame – Theme Toggle | template.php v1.0
 * Bascule clair/sombre avec révélation animée : circular | swipe | fade
 * Applique data-theme sur <html> (+ mode filtre auto optionnel). Persiste en localStorage.
 */
defined( 'ABSPATH' ) || exit;

$mode      = $props['reveal_mode']   ?? 'circular';
$def       = $props['default_theme'] ?? 'auto';
$apply     = $props['apply_mode']    ?? 'attribute';
$rev_dark  = $props['reveal_dark']   ?? '#0f1117';
$rev_light = $props['reveal_light']  ?? '#ffffff';
$dur_ms    = max( 200, (int) ( $props['anim_duration'] ?? 650 ) );
$bstyle    = $props['btn_style']     ?? 'icon';
$lab_l     = $props['label_light']   ?? 'Clair';
$lab_d     = $props['label_dark']    ?? 'Sombre';
$shape     = $props['btn_shape']     ?? 'circle';
$size      = max( 28, (int) ( $props['btn_size'] ?? 44 ) );
$icol      = $props['icon_color']    ?? '#111111';
$bbg       = $props['btn_bg']        ?? 'rgba(0,0,0,0.05)';
$bbord     = $props['btn_border']    ?? 'rgba(0,0,0,0.10)';
$align     = $props['align']         ?? 'left';

$uid    = wf_uid( 'wftt_', $props );
$dur_s  = round( $dur_ms / 1000, 3 );
$radius = ( 'circle' === $shape ) ? '50%' : ( 'pill' === $shape ? '100px' : '12px' );
$pill_pad = ( 'pill' === $shape || 'icon-label' === $bstyle ) ? true : false;
$justify  = ( 'center' === $align ) ? 'center' : ( 'right' === $align ? 'flex-end' : 'flex-start' );
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<script>
/* Init thème avant le paint (idempotent pour plusieurs toggles) */
(function(){
    if (window.__wfThemeInit) return; window.__wfThemeInit = true;
    var DEF = <?= wp_json_encode( $def ) ?>;
    var t = null;
    try { t = localStorage.getItem('wf_theme'); } catch (e) {}
    if (t !== 'dark') { if (t !== 'light') {
        if (DEF === 'auto') {
            var m = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
            t = 'light';
            if (m) { if (m.matches) { t = 'dark'; } }
        } else { t = DEF; }
    }}
    document.documentElement.setAttribute('data-theme', t);
})();
</script>

<div id="<?= esc_attr( $uid ) ?>" class="wf-tt" style="display:flex;justify-content:<?= $justify ?>;">
    <button type="button" class="wf-tt-btn" aria-label="Changer de thème" aria-pressed="false"
        style="color:<?= esc_attr( $icol ) ?>;background:<?= esc_attr( $bbg ) ?>;border:1px solid <?= esc_attr( $bbord ) ?>;<?= $pill_pad ? 'padding:0 16px;height:' . $size . 'px;min-width:' . $size . 'px;' : 'width:' . $size . 'px;height:' . $size . 'px;' ?>border-radius:<?= $radius ?>;">
        <span class="wf-tt-ico wf-tt-moon" aria-hidden="true"><svg width="<?= (int) ( $size * 0.5 ) ?>" height="<?= (int) ( $size * 0.5 ) ?>" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.5A8.5 8.5 0 1 1 11.5 3a6.5 6.5 0 0 0 9.5 9.5z"/></svg></span>
        <span class="wf-tt-ico wf-tt-sun" aria-hidden="true"><svg width="<?= (int) ( $size * 0.5 ) ?>" height="<?= (int) ( $size * 0.5 ) ?>" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg></span>
        <?php if ( 'icon-label' === $bstyle ) : ?>
        <span class="wf-tt-label wf-tt-label--light"><?= esc_html( $lab_l ) ?></span>
        <span class="wf-tt-label wf-tt-label--dark"><?= esc_html( $lab_d ) ?></span>
        <?php endif; ?>
    </button>
</div>

<style>
#<?= esc_attr( $uid ) ?> .wf-tt-btn { display:inline-flex; align-items:center; gap:8px; cursor:pointer; line-height:1; font-size:14px; font-weight:600; transition:background .2s, transform .15s; -webkit-tap-highlight-color:transparent; }
#<?= esc_attr( $uid ) ?> .wf-tt-btn:hover { transform:translateY(-1px); }
#<?= esc_attr( $uid ) ?> .wf-tt-btn:active { transform:scale(.94); }
#<?= esc_attr( $uid ) ?> .wf-tt-ico { display:inline-flex; }
#<?= esc_attr( $uid ) ?> .wf-tt-sun { display:none; }
#<?= esc_attr( $uid ) ?> .wf-tt-label--dark { display:none; }
html[data-theme="dark"] #<?= esc_attr( $uid ) ?> .wf-tt-sun { display:inline-flex; }
html[data-theme="dark"] #<?= esc_attr( $uid ) ?> .wf-tt-moon { display:none; }
html[data-theme="dark"] #<?= esc_attr( $uid ) ?> .wf-tt-label--dark { display:inline; }
html[data-theme="dark"] #<?= esc_attr( $uid ) ?> .wf-tt-label--light { display:none; }
<?php if ( 'filter' === $apply ) : ?>
/* Mode sombre auto par filtre (démo sans CSS dédié) */
html[data-theme="dark"] { filter:invert(1) hue-rotate(180deg); background:#fff; }
html[data-theme="dark"] img, html[data-theme="dark"] video, html[data-theme="dark"] picture, html[data-theme="dark"] iframe, html[data-theme="dark"] svg image, html[data-theme="dark"] [style*="background-image"] { filter:invert(1) hue-rotate(180deg); }
<?php endif; ?>
.wf-tt-reveal { position:fixed; inset:0; z-index:2147482000; pointer-events:none; will-change:clip-path,transform,opacity; }
@media (prefers-reduced-motion: reduce) { .wf-tt-reveal { display:none !important; } }
</style>

<script>
(function(){
    var id = <?= wp_json_encode( $uid ) ?>;
    var MODE = <?= wp_json_encode( $mode ) ?>;
    var DUR = <?= (int) $dur_ms ?>;
    var RD = <?= wp_json_encode( $rev_dark ) ?>;
    var RL = <?= wp_json_encode( $rev_light ) ?>;

    function boot(){
        var root = document.getElementById(id);
        if (!root) return;
        var btn = root.querySelector('.wf-tt-btn');
        if (!btn) return;

        function current(){ return document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light'; }
        function setPressed(){ btn.setAttribute('aria-pressed', current() === 'dark' ? 'true' : 'false'); }
        setPressed();

        function apply(next){
            document.documentElement.setAttribute('data-theme', next);
            try { localStorage.setItem('wf_theme', next); } catch (e) {}
            setPressed();
        }

        var busy = false;
        var reduce = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)').matches : false;

        btn.addEventListener('click', function(ev){
            if (busy) return;
            var cur = current();
            var next = cur === 'dark' ? 'light' : 'dark';
            var color = next === 'dark' ? RD : RL;

            if (reduce) { apply(next); return; }
            busy = true;

            var r = btn.getBoundingClientRect();
            var x = r.left + r.width / 2;
            var y = r.top + r.height / 2;
            if (ev) { if (ev.clientX) { x = ev.clientX; y = ev.clientY; } }

            var ov = document.createElement('div');
            ov.className = 'wf-tt-reveal';
            ov.style.background = color;
            document.body.appendChild(ov);

            function cleanup(){ if (ov) { if (ov.parentNode) { ov.parentNode.removeChild(ov); } } busy = false; }

            if (MODE === 'circular') {
                var w = window.innerWidth, h = window.innerHeight;
                var maxR = Math.max(
                    Math.sqrt(x * x + y * y),
                    Math.sqrt((w - x) * (w - x) + y * y),
                    Math.sqrt(x * x + (h - y) * (h - y)),
                    Math.sqrt((w - x) * (w - x) + (h - y) * (h - y))
                ) + 4;
                ov.style.clipPath = 'circle(0px at ' + x + 'px ' + y + 'px)';
                ov.style.transition = 'clip-path ' + (DUR / 1000) + 's cubic-bezier(0.76,0,0.24,1)';
                ov.getBoundingClientRect();
                ov.style.clipPath = 'circle(' + maxR + 'px at ' + x + 'px ' + y + 'px)';
                var d1 = false;
                ov.addEventListener('transitionend', function h1(){
                    if (d1) return; d1 = true;
                    apply(next);
                    ov.style.transition = 'opacity .25s ease';
                    ov.getBoundingClientRect();
                    ov.style.opacity = '0';
                    setTimeout(cleanup, 280);
                });

            } else if (MODE === 'swipe') {
                ov.style.transform = 'translateX(-100%)';
                ov.style.transition = 'transform ' + (DUR / 1000) + 's cubic-bezier(0.76,0,0.24,1)';
                ov.getBoundingClientRect();
                ov.style.transform = 'translateX(0)';
                var d2 = false;
                ov.addEventListener('transitionend', function h2(){
                    if (d2) return; d2 = true;
                    apply(next);
                    ov.style.transform = 'translateX(100%)';
                    setTimeout(cleanup, DUR + 40);
                });

            } else { /* fade */
                ov.style.opacity = '0';
                ov.style.transition = 'opacity ' + (DUR / 2000) + 's ease';
                ov.getBoundingClientRect();
                ov.style.opacity = '1';
                var d3 = false;
                ov.addEventListener('transitionend', function h3(){
                    if (d3) return; d3 = true;
                    apply(next);
                    ov.style.opacity = '0';
                    setTimeout(cleanup, DUR / 2 + 60);
                });
            }

            /* filet de sécurité */
            setTimeout(function(){ if (busy) { apply(next); cleanup(); } }, DUR + 1200);
        });
    }

    if (window.WF) { if (WF.ready) { WF.ready(boot); return; } }
    if (document.readyState !== 'loading') { boot(); } else { document.addEventListener('DOMContentLoaded', boot); }
})();
</script>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
