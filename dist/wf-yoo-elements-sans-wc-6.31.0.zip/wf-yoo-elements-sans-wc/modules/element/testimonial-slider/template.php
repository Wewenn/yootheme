<?php
/**
 * WeFrame – Avis Clients | template.php v2.3 (+ Google Reviews API)
 */
defined( 'ABSPATH' ) || exit;
$meta_c   = $props['meta_color']     ?? '#666666';
$init_ovr = trim( (string) ( $props['initials_bg'] ?? '' ) );
$init_c   = $props['initials_color'] ?? '#ffffff';

// ── Source API : Google Reviews ──────────────────────────────────
$source_mode = $props['source_mode'] ?? 'manual';
$google_items_html = '';
$google_header_html = '';
$google_data = null;

if ( $source_mode === 'google' && function_exists( 'wf_google_reviews_fetch' ) ) {
    $google_data = wf_google_reviews_fetch(
        $props['google_api_key']  ?? '',
        $props['google_place_id'] ?? '',
        [
            'lang'        => $props['google_lang']        ?? 'fr',
            'min_rating'  => (int) ( $props['google_min_rating']  ?? 4 ),
            'max'         => (int) ( $props['google_max']         ?? 5 ),
            'cache_hours' => (int) ( $props['google_cache_hours'] ?? 12 ),
        ]
    );
}

if ( $source_mode === 'google' ) {
    // Sans Google valide et sans merge manuel → rien à afficher
    $has_google = $google_data && ! empty( $google_data['reviews'] );
    $merge      = ! empty( $props['google_merge_manual'] );
    if ( ! $has_google && ( ! $merge || empty( $children ) ) ) { return; }
} else {
    if ( empty( $children ) ) { return; }
}

$speed      = max( 1, (int) ( $props['speed'] ?? 20 ) );
$speed_mob  = max( 0, (int) ( $props['speed_mobile'] ?? 0 ) );
$hover      = ! empty( $props['pause_on_hover'] );
$reverse    = ! empty( $props['reverse'] );
$double_row = ! empty( $props['double_row'] );
$row_gap    = max( 0, (int) ( $props['row_gap'] ?? 24 ) );
$fade       = ! empty( $props['fade_edges'] );
$fade_color = $props['fade_color'] ?? '#ffffff';
$gap        = max( 0, (int) ( $props['gap'] ?? 24 ) );
$gap_mob    = max( 0, (int) ( $props['gap_mobile'] ?? 0 ) );

if ( ! preg_match( '/^#([0-9a-fA-F]{3}){1,2}$/', $fade_color ) ) { $fade_color = '#ffffff'; }

$uid = wf_uid( 'wfts_', $props, count( (array) $children ) );

// Renderer synthétique pour avis Google (même visuel que testimonial_slider_item)
if ( ! function_exists( 'wf_ts_render_google_card' ) ) {
    function wf_ts_render_google_card( array $r, array $el ) {
        $bg      = $el['card_bg']           ?? '#ffffff';
        $border  = ! empty( $el['card_border'] );
        $bcolor  = $el['card_border_color'] ?? '#e5e5e5';
        $radius  = (int)( $el['card_radius']  ?? 16 );
        $padding = (int)( $el['card_padding'] ?? 28 );
        $shadow  = ! empty( $el['card_shadow'] );
        $stars   = ! empty( $el['show_stars'] );
        $scolor  = $el['star_color']        ?? '#f59e0b';
        $ssize   = (int)( $el['star_size']  ?? 18 );
        $nweight = $el['name_weight']       ?? 'bold';
        $min_w   = (int)( $el['card_min_width']        ?? 320 );
        $min_wm  = (int)( $el['card_min_width_mobile'] ?? 260 );
        $max_w   = (int)( $el['card_max_width']        ?? 0 );
        $max_wm  = (int)( $el['card_max_width_mobile'] ?? 0 );
        $c_s     = (int)( $el['content_size']        ?? 15 );
        $c_sm    = (int)( $el['content_size_mobile'] ?? 14 );
        $n_s     = (int)( $el['name_size']           ?? 14 );
        $n_sm    = (int)( $el['name_size_mobile']    ?? 13 );
        $r_s     = (int)( $el['role_size']           ?? 13 );
        $r_sm    = (int)( $el['role_size_mobile']    ?? 12 );
        $t_color = $el['text_color'] ? 'color:' . esc_attr( $el['text_color'] ) . ';' : 'color:inherit;';
        $n_color = $el['name_color'] ? 'color:' . esc_attr( $el['name_color'] ) . ';' : '';
        $r_color = 'color:' . esc_attr( $el['role_color'] ?? '#666' ) . ';';
        $show_src  = ! empty( $el['show_source_icon'] );
        $auto_init = ! empty( $el['auto_initials'] );

        $rating     = min( 5, max( 0, (int) ( $r['rating'] ?? 5 ) ) );
        $content    = (string) ( $r['content'] ?? '' );
        $name       = (string) ( $r['name']    ?? '' );
        $meta       = (string) ( $r['relative'] ?? '' );
        $avatar     = (string) ( $r['avatar']  ?? '' );
        $review_url = (string) ( $r['review_url'] ?? '' );

        $border_css = $border ? "border:1px solid {$bcolor};" : '';
        $shadow_css = $shadow ? 'box-shadow:0 4px 24px rgba(0,0,0,.08);' : '';

        $sf = '<svg width="'.$ssize.'" height="'.$ssize.'" viewBox="0 0 20 20" fill="'.esc_attr($scolor).'"><path d="M10 1.12l2.47 5.01 5.53.8-4 3.9.94 5.5L10 13.77l-4.94 2.6.94-5.5-4-3.9 5.53-.8L10 1.12z"/></svg>';
        $se = '<svg width="'.$ssize.'" height="'.$ssize.'" viewBox="0 0 20 20" fill="none" stroke="'.esc_attr($scolor).'" stroke-width="1.5"><path d="M10 1.12l2.47 5.01 5.53.8-4 3.9.94 5.5L10 13.77l-4.94 2.6.94-5.5-4-3.9 5.53-.8L10 1.12z"/></svg>';
        $gicon = '<svg width="16" height="16" viewBox="0 0 48 48"><path fill="#4285F4" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#34A853" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59A14.5 14.5 0 019.5 24c0-1.59.28-3.14.77-4.59l-7.98-6.19A23.94 23.94 0 000 24c0 3.77.9 7.35 2.56 10.52l7.97-5.93z"/><path fill="#EA4335" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 5.93C6.51 42.62 14.62 48 24 48z"/></svg>';

        // Initiales
        $initials = '';
        if ( $auto_init && ! $avatar && $name ) {
            $parts = preg_split( '/\s+/', trim( $name ) );
            $initials = mb_strtoupper( mb_substr( $parts[0], 0, 1 ) );
            if ( count( $parts ) > 1 ) $initials .= mb_strtoupper( mb_substr( end( $parts ), 0, 1 ) );
        }
        $init_colors = ['#EA5C1C','#8EBE82','#C89CC3','#5A61A7','#f59e0b','#06b6d4','#8b5cf6','#ec4899'];
        $init_bg     = '' !== $init_ovr ? $init_ovr : $init_colors[ crc32( $name ) % count( $init_colors ) ];
        $iid         = 'wtsg_' . substr( md5( $name . $content . ( $r['time'] ?? '' ) ), 0, 6 );

        ob_start();
        ?>
        <div class="wf-ts-card">
            <div id="<?= esc_attr( $iid ) ?>" class="wf-ts-inner" style="min-width:<?= $min_w ?>px;<?= $max_w > 0 ? 'max-width:'.$max_w.'px;' : '' ?>background:<?= esc_attr( $bg ) ?>;<?= $border_css ?><?= $shadow_css ?>border-radius:<?= $radius ?>px;padding:<?= $padding ?>px;display:flex;flex-direction:column;gap:12px;">
                <?php if ( ( $stars && $rating > 0 ) || $show_src ) : ?>
                <div style="display:flex;align-items:center;justify-content:space-between;">
                    <?php if ( $stars && $rating > 0 ) : ?>
                    <div style="display:flex;gap:2px;" aria-label="<?= $rating ?> étoiles sur 5">
                        <?php for ( $i = 1; $i <= 5; $i++ ) echo $i <= $rating ? $sf : $se; ?>
                    </div>
                    <?php else : ?><div></div><?php endif; ?>
                    <?php if ( $show_src ) : ?><div style="opacity:.6;" title="Avis Google"><?= $gicon ?></div><?php endif; ?>
                </div>
                <?php endif; ?>
                <?php if ( $content ) : ?>
                <p class="wf-ts-content" style="margin:0;font-size:<?= $c_s ?>px;line-height:1.65;<?= $t_color ?>flex:1;font-style:italic;"><?= esc_html( $content ) ?></p>
                <?php endif; ?>
                <div style="display:flex;align-items:center;gap:12px;margin-top:auto;padding-top:8px;">
                    <?php if ( $avatar ) : ?>
                        <img src="<?= esc_url( $avatar ) ?>" alt="<?= esc_attr( $name ) ?>" loading="lazy" referrerpolicy="no-referrer" style="width:40px;height:40px;border-radius:50%;object-fit:cover;flex-shrink:0;">
                    <?php elseif ( $initials ) : ?>
                        <div style="width:40px;height:40px;border-radius:50%;background:<?= esc_attr( $init_bg ) ?>;display:flex;align-items:center;justify-content:center;flex-shrink:0;color:<?= esc_attr( $init_c ) ?>;font-size:14px;font-weight:700;letter-spacing:.5px;"><?= esc_html( $initials ) ?></div>
                    <?php endif; ?>
                    <div style="flex:1;min-width:0;">
                        <?php if ( $name ) : ?>
                        <div class="wf-ts-name" style="font-weight:<?= esc_attr( $nweight ) ?>;font-size:<?= $n_s ?>px;line-height:1.3;text-transform:uppercase;<?= $n_color ?>"><?= esc_html( $name ) ?></div>
                        <?php endif; ?>
                        <?php if ( $meta ) : ?>
                        <div class="wf-ts-role" style="font-size:<?= $r_s ?>px;<?= $r_color ?>line-height:1.3;"><?= esc_html( $meta ) ?></div>
                        <?php endif; ?>
                    </div>
                    <?php if ( $review_url ) : ?>
                    <a href="<?= esc_url( $review_url ) ?>" target="_blank" rel="noopener noreferrer" aria-label="Voir l'avis Google" style="flex-shrink:0;opacity:.4;transition:opacity .2s;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='.4'">
                        <svg width="14" height="14" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7 17L17 7"/><path d="M7 7h10v10"/></svg>
                    </a>
                    <?php endif; ?>
                </div>
            </div>
            <style>
            @media(max-width:767px){
                #<?= esc_attr( $iid ) ?>{min-width:<?= $min_wm ?>px !important<?php if ( $max_wm > 0 ) : ?>;max-width:<?= $max_wm ?>px !important<?php elseif ( $max_w > 0 ) : ?>;max-width:<?= $max_w ?>px !important<?php endif; ?>}
                #<?= esc_attr( $iid ) ?> .wf-ts-content{font-size:<?= $c_sm ?>px !important}
                #<?= esc_attr( $iid ) ?> .wf-ts-name{font-size:<?= $n_sm ?>px !important}
                #<?= esc_attr( $iid ) ?> .wf-ts-role{font-size:<?= $r_sm ?>px !important}
            }
            </style>
        </div>
        <?php
        return ob_get_clean();
    }
}

// Prépare les HTML de cartes (Google + manuels)
$google_cards_html = '';
if ( $source_mode === 'google' && $google_data && ! empty( $google_data['reviews'] ) ) {
    foreach ( $google_data['reviews'] as $rev ) {
        $google_cards_html .= wf_ts_render_google_card( $rev, $props );
    }
}

// Manuels : rendu uniquement si mode manual OU merge_manual activé
$manual_allowed = ( $source_mode === 'manual' ) || ( $source_mode === 'google' && ! empty( $props['google_merge_manual'] ) );

if ( $double_row && $manual_allowed && is_array( $children ) && count( $children ) >= 4 ) {
    $ga = $gb = [];
    foreach ( $children as $i => $c ) { $i % 2 === 0 ? $ga[] = $c : $gb[] = $c; }
    $html_a = $html_b = '';
    foreach ( $ga as $c ) { $html_a .= $builder->render( $c, [ 'element' => $props ] ); }
    foreach ( $gb as $c ) { $html_b .= $builder->render( $c, [ 'element' => $props ] ); }
    // Préfixe Google sur chaque rangée, alterné
    if ( $google_cards_html ) {
        $html_a = $google_cards_html . $html_a;
    }
    $has_double = trim( $html_a ) && trim( $html_b );
} else { $double_row = false; $has_double = false; }

if ( ! $has_double ) {
    $html_a = '';
    if ( $manual_allowed && is_array( $children ) ) {
        foreach ( $children as $c ) { $html_a .= $builder->render( $c, [ 'element' => $props ] ); }
    }
    $html_a = $google_cards_html . $html_a;
    if ( ! trim( $html_a ) ) { return; }
}

// Use shared keyframes from weframe-shared.css
$a1 = $reverse ? 'wf-scroll-rev' : 'wf-scroll-fwd';
$a2 = $reverse ? 'wf-scroll-fwd' : 'wf-scroll-rev';
$fw = max( 40, (int)( $gap * 3 ) );
$hg = (int) round( $gap / 2 );
$hgm = ( $gap_mob > 0 && $gap_mob !== $gap ) ? (int) round( $gap_mob / 2 ) : 0;
$ms = $speed_mob > 0 && $speed_mob !== $speed;

?>
<?php
// Bandeau note globale Google (rating + total)
if ( $source_mode === 'google' && ! empty( $props['google_show_header'] ) && $google_data && ! empty( $google_data['rating'] ) ) :
    $g_rating = number_format( (float) $google_data['rating'], 1, ',', '' );
    $g_total  = (int) $google_data['total'];
    $g_label  = $props['google_header_label'] ?? 'Note Google';
    $g_full   = floor( (float) $google_data['rating'] );
    $g_half   = ( (float) $google_data['rating'] - $g_full ) >= 0.3 && ( (float) $google_data['rating'] - $g_full ) < 0.8;
    $g_star_color = $props['star_color'] ?? '#f59e0b';
?>
<div class="wf-ts-gheader" style="display:flex;align-items:center;justify-content:center;gap:16px;margin-bottom:24px;flex-wrap:wrap;">
    <svg width="24" height="24" viewBox="0 0 48 48" aria-hidden="true"><path fill="#4285F4" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#34A853" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59A14.5 14.5 0 019.5 24c0-1.59.28-3.14.77-4.59l-7.98-6.19A23.94 23.94 0 000 24c0 3.77.9 7.35 2.56 10.52l7.97-5.93z"/><path fill="#EA4335" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 5.93C6.51 42.62 14.62 48 24 48z"/></svg>
    <span style="font-size:15px;font-weight:600;"><?= esc_html( $g_label ) ?></span>
    <span style="display:flex;align-items:center;gap:4px;">
        <strong style="font-size:18px;"><?= esc_html( $g_rating ) ?></strong>
        <span style="display:flex;gap:2px;">
        <?php for ( $i = 1; $i <= 5; $i++ ) :
            $fill = $i <= $g_full ? $g_star_color : ( $i == $g_full + 1 && $g_half ? 'url(#wfGhalf)' : 'none' );
        ?>
            <svg width="16" height="16" viewBox="0 0 20 20" fill="<?= esc_attr( $fill ) ?>" stroke="<?= esc_attr( $g_star_color ) ?>" stroke-width="1.5"><?php if ( $g_half && $i == $g_full + 1 ) : ?><defs><linearGradient id="wfGhalf"><stop offset="50%" stop-color="<?= esc_attr( $g_star_color ) ?>"/><stop offset="50%" stop-color="transparent"/></linearGradient></defs><?php endif; ?><path d="M10 1.12l2.47 5.01 5.53.8-4 3.9.94 5.5L10 13.77l-4.94 2.6.94-5.5-4-3.9 5.53-.8L10 1.12z"/></svg>
        <?php endfor; ?>
        </span>
    </span>
    <?php if ( $g_total ) : ?>
    <span style="color:<?= esc_attr( $meta_c ) ?>;font-size:14px;">(<?= number_format( $g_total, 0, ',', ' ' ) ?> avis)</span>
    <?php endif; ?>
</div>
<?php endif; ?>
<?php $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( 'div' ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<div id="<?= esc_attr( $uid ) ?>" class="wf-ts" style="position:relative;overflow:hidden;<?= $has_double ? "display:flex;flex-direction:column;gap:{$row_gap}px;" : '' ?>">
    <?php if ( $fade ) : ?>
    <div aria-hidden="true" style="position:absolute;top:0;left:0;bottom:0;width:<?= $fw ?>px;background:linear-gradient(90deg,<?= esc_attr( $fade_color ) ?>,transparent);z-index:2;pointer-events:none;"></div>
    <div aria-hidden="true" style="position:absolute;top:0;right:0;bottom:0;width:<?= $fw ?>px;background:linear-gradient(270deg,<?= esc_attr( $fade_color ) ?>,transparent);z-index:2;pointer-events:none;"></div>
    <?php endif; ?>
    <div class="wf-ts-track wf-ts-track--r1" style="display:flex;align-items:stretch;width:max-content;"><?= $html_a ?><?= $html_a ?></div>
    <?php if ( $has_double ) : ?>
    <div class="wf-ts-track wf-ts-track--r2" style="display:flex;align-items:stretch;width:max-content;"><?= $html_b ?><?= $html_b ?></div>
    <?php endif; ?>
</div>
<style>
#<?= esc_attr( $uid ) ?> .wf-ts-track--r1{animation:<?= $a1 ?> <?= $speed ?>s linear infinite}
<?php if ( $has_double ) : ?>#<?= esc_attr( $uid ) ?> .wf-ts-track--r2{animation:<?= $a2 ?> <?= $speed ?>s linear infinite}<?php endif; ?>
<?php if ( $hover ) : ?>#<?= esc_attr( $uid ) ?>:hover .wf-ts-track{animation-play-state:paused}<?php endif; ?>
#<?= esc_attr( $uid ) ?> .wf-ts-card{padding:0 <?= $hg ?>px;flex-shrink:0;display:flex}
@media(max-width:767px){
<?php if ( $ms ) : ?>#<?= esc_attr( $uid ) ?> .wf-ts-track{animation-duration:<?= $speed_mob ?>s !important}<?php endif; ?>
<?php if ( $hgm ) : ?>#<?= esc_attr( $uid ) ?> .wf-ts-card{padding-left:<?= $hgm ?>px !important;padding-right:<?= $hgm ?>px !important}<?php endif; ?>
}
@media(prefers-reduced-motion:reduce){#<?= esc_attr( $uid ) ?> .wf-ts-track{animation-play-state:paused}}
</style>

<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
