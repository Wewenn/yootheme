<?php
/**
 * WeFrame – Image Slider | template.php v2
 * Infinite CSS scroll (like logo-slider), hover zoom, dim others.
 * NO && in JS.
 */
defined('ABSPATH') || exit;
if (empty($children)) return;

$ih = (int)($props['image_height']??400); $ihm = (int)($props['image_height_mobile']??250);
$iw = (int)($props['image_width']??0);
$ip = (int)($props['image_padding']??8); $ir = (int)($props['image_radius']??12);
$gap = (int)($props['gap']??12);
$speed = max(5,(int)($props['speed']??25)); $rev = !empty($props['reverse']);
$pause = !empty($props['pause_on_hover']);
$zoom = !empty($props['hover_zoom']); $zs = (int)($props['hover_zoom_scale']??105);
$dim = !empty($props['hover_dim_others']); $dcolor = $props['hover_dim_color']??'rgba(59,130,246,0.5)';
$drag = !empty($props['drag']);

$uid = 'wfis_'.substr(md5(serialize($props).count($children)),0,8);

// Collect images
$images = [];
foreach ($children as $child) {
    $cp = (array)($child->props ?? []);
    $src = $cp['image']??'';
    if ($src) {
        if (!preg_match('#^https?://#i',$src)) $src='/'.ltrim($src,'/');
        $images[] = ['src'=>$src, 'alt'=>$cp['image_alt']??'', 'link'=>$cp['link']??''];
    }
}
if (empty($images)) return;

$wcss = $iw > 0 ? "width:{$iw}px;" : "width:auto;";

// Build single set of slides
$single = '';
foreach ($images as $img) {
    $tag = $img['link'] ? 'a href="'.esc_url($img['link']).'"' : 'div';
    $ctag = $img['link'] ? 'a' : 'div';
    $single .= '<'.$tag.' class="wf-is-slide" style="flex-shrink:0;padding:'.$ip.'px;position:relative;display:block;text-decoration:none;">';
    $single .= '<img src="'.esc_url($img['src']).'" alt="'.esc_attr($img['alt']).'" loading="lazy" draggable="false" style="height:'.$ih.'px;'.$wcss.'border-radius:'.$ir.'px;object-fit:cover;display:block;pointer-events:none;user-select:none;-webkit-user-select:none;transition:transform .4s ease;">';
    if ($dim) {
        $single .= '<div class="wf-is-overlay" style="position:absolute;top:'.$ip.'px;left:'.$ip.'px;right:'.$ip.'px;bottom:'.$ip.'px;border-radius:'.$ir.'px;background:'.$dcolor.';opacity:0;transition:opacity .4s ease;pointer-events:none;"></div>';
    }
    $single .= '</'.$ctag.'>';
}
// Double for infinite scroll
$track = $single . $single;

// Use shared keyframes from weframe-shared.css
$anim = $rev ? 'wf-scroll-rev' : 'wf-scroll-fwd';
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr($uid) ?>" class="wf-img-slider" style="overflow:hidden;user-select:none;-webkit-user-select:none;">
    <div class="wf-is-track" style="display:inline-flex;gap:<?= $gap ?>px;width:max-content;">
        <?= $track ?>
    </div>
</div>

<style>
#<?= esc_attr($uid) ?> .wf-is-track{animation:<?= $anim ?> <?= $speed ?>s linear infinite}

<?php if ($pause) : ?>
#<?= esc_attr($uid) ?>:hover .wf-is-track{animation-play-state:paused}
<?php endif; ?>

<?php if ($zoom) : ?>
#<?= esc_attr($uid) ?> .wf-is-slide:hover img{transform:scale(<?= $zs/100 ?>);z-index:2}
<?php endif; ?>

<?php if ($dim) : ?>
#<?= esc_attr($uid) ?>:hover .wf-is-overlay{opacity:1}
#<?= esc_attr($uid) ?> .wf-is-slide:hover .wf-is-overlay{opacity:0 !important}
<?php endif; ?>

@media(max-width:767px){
    #<?= esc_attr($uid) ?> .wf-is-slide img{height:<?= $ihm ?>px !important}
}
@media(prefers-reduced-motion:reduce){
    #<?= esc_attr($uid) ?> .wf-is-track{animation-play-state:paused}
}
</style>

<?php if ($drag) :
$cfg = json_encode(['uid'=>$uid], JSON_HEX_AMP|JSON_HEX_APOS);
?>
<script>
(function(){
    function boot(){
        
        var c = <?= $cfg ?>;
        var el=document.getElementById(c.uid);if(!el)return;
        var track=el.querySelector('.wf-is-track');if(!track)return;

        var dragging=false;var startX=0;var scrollLeft=0;
        var baseSpeed=<?= $speed ?>;

        el.style.cursor='grab';

        el.addEventListener('pointerdown',function(e){
            dragging=true;el.style.cursor='grabbing';
            el.setPointerCapture(e.pointerId);
            startX=e.clientX;
            track.style.animationPlayState='paused';
        });

        el.addEventListener('pointermove',function(e){
            if(!dragging)return;
            var dx=e.clientX-startX;
            var current=track.style.transform;
            /* Nudge the animation by adjusting margin */
            track.style.marginLeft=dx+'px';
        });

        el.addEventListener('pointerup',function(){
            if(!dragging)return;
            dragging=false;el.style.cursor='grab';
            track.style.marginLeft='0';
            track.style.animationPlayState='';
        });
    }
    WF.ready(boot)
})();
</script>
<?php endif; ?>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
