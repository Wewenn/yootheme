<?php
/**
 * WeFrame – Progress Steps | template.php v2.0
 * Quatre facons d'avancer : etape fixe, defilement automatique, avancement au
 * scroll (avec ou sans section epinglee), ou clic sur une etape.
 * L'etape active est rendue cote serveur : sans JS, la mise en page reste juste.
 * Pas de "&&" ni de "||" dans le JS inline (regle interne du plugin).
 */
defined( 'ABSPATH' ) || exit;
if ( empty( $children ) ) { return; }

$n      = count( $children );
$active = max( 1, min( $n, (int) ( $props['active_step'] ?? 1 ) ) );
$layout = ( 'vertical' === ( $props['layout'] ?? 'horizontal' ) ) ? 'vertical' : 'horizontal';

$mode = (string) ( $props['progress_mode'] ?? 'static' );
if ( ! in_array( $mode, array( 'static', 'auto', 'scroll', 'click' ), true ) ) { $mode = 'static'; }

$autoDelay = max( 1, (int) ( $props['auto_delay'] ?? 3 ) );
$autoLoop  = ! empty( $props['auto_loop'] );
$autoPause = ! empty( $props['auto_pause'] );

$pin     = ! empty( $props['scroll_pin'] );
$pinTop  = max( 0, (int) ( $props['scroll_offset'] ?? 100 ) );
$pinVh   = max( 40, min( 200, (int) ( $props['scroll_dwell'] ?? 80 ) ) );

$ds   = max( 20, (int) ( $props['dot_size'] ?? 40 ) );
$dbg  = (string) ( $props['dot_bg'] ?? '#EA5C1C' );
$dibg = (string) ( $props['dot_inactive_bg'] ?? '#e5e5e5' );
$dc   = (string) ( $props['dot_color'] ?? '#ffffff' );
$dic  = (string) ( $props['dot_inactive_color'] ?? '#999999' );
$lc   = (string) ( $props['line_color'] ?? '#e5e5e5' );
$lac  = (string) ( $props['line_active_color'] ?? '#EA5C1C' );
$lh   = max( 1, (int) ( $props['line_height'] ?? 3 ) );

$tsize = max( 11, (int) ( $props['title_size'] ?? 15 ) );
$tw    = (string) ( $props['title_weight'] ?? '600' );
$dsize = max( 10, (int) ( $props['desc_size'] ?? 13 ) );
$dsc   = (string) ( $props['desc_color'] ?? '#666666' );

$bpMob = max( 320, (int) ( $props['stack_bp'] ?? 700 ) );
$horiz = ( 'horizontal' === $layout );

$uid = wf_uid( 'wfps_', $props, $n );

$steps = array();
foreach ( $children as $i => $child ) {
	$cp = (array) ( $child->props ?? array() );
	$steps[] = array(
		'title' => trim( (string) ( $cp['title'] ?? '' ) ),
		'desc'  => trim( (string) ( $cp['description'] ?? '' ) ),
		'icon'  => trim( (string) ( $cp['icon'] ?? '' ) ),
	);
}

$clickable = ( 'click' === $mode );
$rootCls   = 'wf-steps wf-steps--' . $layout . ' wf-steps--' . $mode;
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>
<?php if ( 'scroll' === $mode && $pin ) : ?>
<div class="wf-steps-track" id="<?= esc_attr( $uid ) ?>-track">
<div class="wf-steps-pin">
<?php endif; ?>

<div id="<?= esc_attr( $uid ) ?>" class="<?= esc_attr( $rootCls ) ?>" data-active="<?= (int) $active ?>" data-count="<?= (int) $n ?>">
	<?php foreach ( $steps as $i => $s ) : ?>
	<?php
	$num  = '' !== $s['icon'] ? $s['icon'] : (string) ( $i + 1 );
	$done = ( $i < $active );
	$cur  = ( $i + 1 === $active );
	$cls  = '__step';
	if ( $done ) { $cls .= ' is-done'; }
	if ( $cur ) { $cls .= ' is-current'; }
	?>
	<?php if ( $clickable ) : ?>
	<button type="button" class="<?= esc_attr( $cls ) ?>" data-step="<?= (int) ( $i + 1 ) ?>"
		aria-current="<?= $cur ? 'step' : 'false' ?>">
	<?php else : ?>
	<div class="<?= esc_attr( $cls ) ?>" data-step="<?= (int) ( $i + 1 ) ?>"<?= $cur ? ' aria-current="step"' : '' ?>>
	<?php endif; ?>
		<div class="__rail">
			<span class="__line __line-before" aria-hidden="true"></span>
			<span class="__dot"><?= esc_html( $num ) ?></span>
			<span class="__line __line-after" aria-hidden="true"></span>
		</div>
		<div class="__txt">
			<?php if ( '' !== $s['title'] ) : ?><span class="__title"><?= esc_html( $s['title'] ) ?></span><?php endif; ?>
			<?php if ( '' !== $s['desc'] ) : ?><span class="__desc"><?= esc_html( $s['desc'] ) ?></span><?php endif; ?>
		</div>
	<?php if ( $clickable ) : ?>
	</button>
	<?php else : ?>
	</div>
	<?php endif; ?>
	<?php endforeach; ?>
</div>

<?php if ( 'scroll' === $mode && $pin ) : ?>
</div>
</div>
<?php endif; ?>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>

<style>
#<?= esc_attr( $uid ) ?>{container-type:inline-size;display:flex;gap:0;}
#<?= esc_attr( $uid ) ?>.wf-steps--horizontal{flex-direction:row;align-items:flex-start;}
#<?= esc_attr( $uid ) ?>.wf-steps--vertical{flex-direction:column;}
#<?= esc_attr( $uid ) ?> .__step{
	position:relative;display:flex;min-width:0;background:none;border:0;padding:0;font-family:inherit;
	color:inherit;text-align:inherit;
}
#<?= esc_attr( $uid ) ?>.wf-steps--horizontal .__step{flex:1 1 0;flex-direction:column;align-items:center;}
#<?= esc_attr( $uid ) ?>.wf-steps--vertical .__step{flex-direction:row;align-items:flex-start;}
#<?= esc_attr( $uid ) ?>.wf-steps--click .__step{cursor:pointer;}
#<?= esc_attr( $uid ) ?>.wf-steps--click .__step:focus-visible{outline:2px solid <?= esc_attr( $dbg ) ?>;outline-offset:4px;border-radius:8px;}
@media (pointer:coarse){#<?= esc_attr( $uid ) ?>.wf-steps--click .__step{min-height:44px;}}

#<?= esc_attr( $uid ) ?> .__rail{display:flex;align-items:center;}
#<?= esc_attr( $uid ) ?>.wf-steps--horizontal .__rail{width:100%;flex-direction:row;}
#<?= esc_attr( $uid ) ?>.wf-steps--vertical .__rail{flex-direction:column;align-self:stretch;margin-right:16px;}
#<?= esc_attr( $uid ) ?> .__line{background:<?= esc_attr( $lc ) ?>;transition:background-color .35s ease;}
#<?= esc_attr( $uid ) ?>.wf-steps--horizontal .__line{flex:1 1 0;height:<?= (int) $lh ?>px;}
#<?= esc_attr( $uid ) ?>.wf-steps--vertical .__line{width:<?= (int) $lh ?>px;flex:1 1 auto;min-height:24px;}
#<?= esc_attr( $uid ) ?> .__step:first-child .__line-before{background:transparent;}
#<?= esc_attr( $uid ) ?> .__step:last-child .__line-after{background:transparent;}
#<?= esc_attr( $uid ) ?>.wf-steps--vertical .__step:last-child .__line-after{display:none;}

#<?= esc_attr( $uid ) ?> .__dot{
	flex:0 0 auto;width:<?= (int) $ds ?>px;height:<?= (int) $ds ?>px;border-radius:50%;
	display:flex;align-items:center;justify-content:center;
	font-size:<?= (int) round( $ds * 0.4 ) ?>px;font-weight:700;line-height:1;
	background:<?= esc_attr( $dibg ) ?>;color:<?= esc_attr( $dic ) ?>;
	transition:background-color .35s ease,color .35s ease,transform .35s ease,box-shadow .35s ease;
}
#<?= esc_attr( $uid ) ?> .__step.is-done .__dot{background:<?= esc_attr( $dbg ) ?>;color:<?= esc_attr( $dc ) ?>;}
#<?= esc_attr( $uid ) ?> .__step.is-done .__line-before{background:<?= esc_attr( $lac ) ?>;}
#<?= esc_attr( $uid ) ?> .__step.is-done:not(.is-current) .__line-after{background:<?= esc_attr( $lac ) ?>;}
#<?= esc_attr( $uid ) ?> .__step.is-current .__dot{
	transform:scale(1.15);
	box-shadow:0 0 0 4px <?= esc_attr( $dbg ) ?>33;
}
#<?= esc_attr( $uid ) ?> .__txt{display:flex;flex-direction:column;gap:4px;min-width:0;}
#<?= esc_attr( $uid ) ?>.wf-steps--horizontal .__txt{text-align:center;margin-top:12px;max-width:180px;}
#<?= esc_attr( $uid ) ?>.wf-steps--vertical .__txt{padding-top:<?= (int) round( $ds * 0.15 ) ?>px;padding-bottom:24px;}
#<?= esc_attr( $uid ) ?> .__title{font-size:<?= (int) $tsize ?>px;font-weight:<?= esc_attr( $tw ) ?>;line-height:1.3;}
#<?= esc_attr( $uid ) ?> .__desc{font-size:<?= (int) $dsize ?>px;color:<?= esc_attr( $dsc ) ?>;line-height:1.45;}

@container (max-width: <?= (int) $bpMob ?>px){
	#<?= esc_attr( $uid ) ?>.wf-steps--horizontal{flex-direction:column;}
	#<?= esc_attr( $uid ) ?>.wf-steps--horizontal .__step{flex-direction:row;align-items:flex-start;}
	#<?= esc_attr( $uid ) ?>.wf-steps--horizontal .__rail{width:auto;flex-direction:column;align-self:stretch;margin-right:16px;}
	#<?= esc_attr( $uid ) ?>.wf-steps--horizontal .__line{width:<?= (int) $lh ?>px;height:auto;flex:1 1 auto;min-height:24px;}
	#<?= esc_attr( $uid ) ?>.wf-steps--horizontal .__txt{text-align:left;margin-top:0;max-width:none;padding-top:<?= (int) round( $ds * 0.15 ) ?>px;padding-bottom:24px;}
	#<?= esc_attr( $uid ) ?>.wf-steps--horizontal .__step:last-child .__line-after{display:none;}
}
@media (prefers-reduced-motion: reduce){
	#<?= esc_attr( $uid ) ?> .__dot,#<?= esc_attr( $uid ) ?> .__line{transition-duration:.001ms;}
}
<?php if ( 'scroll' === $mode && $pin ) : ?>
#<?= esc_attr( $uid ) ?>-track{min-height:calc(<?= (int) $n ?> * <?= (int) $pinVh ?>vh);}
#<?= esc_attr( $uid ) ?>-track .wf-steps-pin{position:sticky;top:<?= (int) $pinTop ?>px;}
<?php endif; ?>
</style>

<?php if ( 'static' !== $mode ) : ?>
<script>
(function(){
	var root = document.getElementById('<?= esc_js( $uid ) ?>');
	if (!root) { return; }
	var steps = [].slice.call(root.querySelectorAll('.__step'));
	var n = steps.length;
	if (!n) { return; }
	var active = parseInt(root.getAttribute('data-active'), 10);
	if (isNaN(active)) { active = 1; }

	function paint(a){
		if (a < 1) { a = 1; }
		if (a > n) { a = n; }
		if (a === active) { return; }
		active = a;
		root.setAttribute('data-active', String(a));
		for (var i = 0; i < n; i++) {
			var done = (i < a);
			var cur = (i + 1 === a);
			steps[i].classList.toggle('is-done', done);
			steps[i].classList.toggle('is-current', cur);
			if (cur) { steps[i].setAttribute('aria-current', 'step'); }
			else { steps[i].removeAttribute('aria-current'); }
		}
	}

	var reduced = false;
	if (window.matchMedia) {
		if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { reduced = true; }
	}

<?php if ( 'click' === $mode ) : ?>
	for (var c = 0; c < n; c++) {
		(function(idx){
			steps[idx].addEventListener('click', function(){ paint(idx + 1); });
		})(c);
	}
<?php endif; ?>

<?php if ( 'auto' === $mode ) : ?>
	// L'avance automatique est une animation : on ne l'impose pas a qui n'en veut pas.
	if (!reduced) {
		var timer = null;
		function tick(){
			var next = active + 1;
			if (next > n) {
				if (!<?= $autoLoop ? 'true' : 'false' ?>) { stop(); return; }
				next = 1;
			}
			paint(next);
		}
		function start(){ stop(); timer = setInterval(tick, <?= (int) $autoDelay ?> * 1000); }
		function stop(){ if (timer) { clearInterval(timer); timer = null; } }
<?php if ( $autoPause ) : ?>
		root.addEventListener('mouseenter', stop);
		root.addEventListener('mouseleave', start);
		root.addEventListener('focusin', stop);
<?php endif; ?>
		// On ne demarre qu'une fois l'element visible : pas de cycle joue dans le vide.
		if (typeof WF !== 'undefined') {
			if (WF.onVisible) { WF.onVisible(root, start, 0.25); }
			else { start(); }
		} else { start(); }
	}
<?php endif; ?>

<?php if ( 'scroll' === $mode ) : ?>
	var track = document.getElementById('<?= esc_js( $uid ) ?>-track');
	var scope = track ? track : root;
	function onScroll(){
		var r = scope.getBoundingClientRect();
		var vh = window.innerHeight;
		var span, p;
		if (track) {
			// Section epinglee : la progression suit la course du bloc haut.
			span = r.height - vh;
			p = span > 0 ? (-r.top) / span : 0;
		} else {
			// Sans epinglage : la progression suit la traversee de l'ecran.
			span = r.height + vh;
			p = span > 0 ? (vh - r.top) / span : 0;
		}
		if (p < 0) { p = 0; }
		if (p > 1) { p = 1; }
		paint(Math.min(n, Math.floor(p * n) + 1));
	}
	window.addEventListener('scroll', onScroll, { passive: true });
	window.addEventListener('resize', onScroll);
	onScroll();
<?php endif; ?>
})();
</script>
<?php endif; ?>
