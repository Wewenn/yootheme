<?php
/**
 * WeFrame – Bande d'images : image (item).
 */
defined( 'ABSPATH' ) || exit;
$img = trim( (string) ( $props['image'] ?? '' ) );
if ( '' === $img ) { return; }
if ( ! preg_match( '#^https?://#i', $img ) ) { $img = '/' . ltrim( $img, '/' ); }
$cap  = (string) ( $props['caption'] ?? '' );
$link = $props['link'] ?? '';
if ( is_array( $link ) ) { $link = $link['url'] ?? ''; }
$link = (string) $link;
$tag  = '' !== $link ? 'a' : 'div';
$href = '' !== $link ? ' href="' . esc_url( $link ) . '"' : '';
?>
<<?= $tag ?> class="wf-str-i"<?= $href ?> style="display:block;position:relative;text-decoration:none;">
    <img src="<?= esc_url( $img ) ?>" alt="<?= esc_attr( $cap ) ?>" loading="lazy" style="width:100%;height:100%;object-fit:cover;display:block;">
    <?php if ( '' !== $cap ) : ?><span style="position:absolute;left:0;right:0;bottom:0;padding:14px 16px;color:#fff;font-size:14px;font-weight:600;background:linear-gradient(transparent,rgba(0,0,0,.6));"><?= esc_html( $cap ) ?></span><?php endif; ?>
</<?= $tag ?>>
