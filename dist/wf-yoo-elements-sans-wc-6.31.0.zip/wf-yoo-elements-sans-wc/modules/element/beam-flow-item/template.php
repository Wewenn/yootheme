<?php
/**
 * WeFrame - Faisceaux animes (etape enfant) | template.php v1.0
 * Le parent place les etapes et trace les fils : l'enfant n'affiche rien seul.
 */
defined( 'ABSPATH' ) || exit;
echo '';
