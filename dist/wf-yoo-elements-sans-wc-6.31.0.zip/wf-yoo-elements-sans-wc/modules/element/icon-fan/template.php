<?php
/**
 * WeFrame – Pile qui se déploie | template.php
 *
 * Une pastille d'annonce : les vignettes sont empilées au repos, elles
 * s'écartent au survol et un rond « +N » apparaît pour celles qui restent
 * cachées. Tout se joue en CSS — pas de script, donc rien à réveiller.
 */
defined( 'ABSPATH' ) || exit;

$props = is_array( $props ?? null ) ? $props : array();

if ( empty( $children ) ) { return; }

$parts = array();
foreach ( $children as $child ) {
	$one = (string) $builder->render( $child, array( 'element' => $props ) );
	if ( '' !== trim( $one ) ) { $parts[] = $one; }
}
if ( ! $parts ) { return; }

$total = count( $parts );
$max   = max( 1, min( 20, (int) ( $props['max_visible'] ?? 5 ) ) );
$shown = array_slice( $parts, 0, $max );
$rest  = $total - count( $shown );

$label  = trim( (string) ( $props['label'] ?? '' ) );
$lsize  = max( 10, min( 40, (int) ( $props['label_size'] ?? 15 ) ) );
$lcol   = (string) ( $props['label_color'] ?? '#111827' );
$size   = max( 16, min( 120, (int) ( $props['size'] ?? 40 ) ) );
$rad    = max( 0, min( 60, (int) ( $props['radius'] ?? 12 ) ) );
$over   = max( 0, min( $size, (int) ( $props['overlap'] ?? 22 ) ) );
$gap    = max( 0, min( 60, (int) ( $props['gap'] ?? 8 ) ) );
$moreBg = (string) ( $props['more_bg'] ?? '#f3f4f6' );
$moreC  = (string) ( $props['more_color'] ?? '#6b7280' );
$pillBg = (string) ( $props['pill_bg'] ?? '#ffffff' );
$ring   = (string) ( $props['ring'] ?? '#ffffff' );
$shadow = ! empty( $props['shadow'] );
$align  = (string) ( $props['align'] ?? 'center' );
if ( ! in_array( $align, array( 'left', 'center', 'right' ), true ) ) { $align = 'center'; }
$open   = 'always' === ( $props['open'] ?? 'hover' ) ? 'always' : 'hover';

$link = $props['link'] ?? '';
if ( is_array( $link ) ) { $link = $link['url'] ?? ''; }
$link = (string) $link;

$tag  = '' !== $link ? 'a' : 'div';
$href = '' !== $link ? ' href="' . esc_url( $link ) . '"' : '';

$uid = wf_uid( 'wfif_', $props, $total );

$justify = 'center';
if ( 'left' === $align )  { $justify = 'flex-start'; }
if ( 'right' === $align ) { $justify = 'flex-end'; }

// L'état déployé est décrit une seule fois puis rejoué sous plusieurs
// préfixes : survol, focus clavier, écran tactile, ou réglage « toujours ».
// Chaque règle porte son préfixe complet — une liste séparée par une virgule
// rendrait la seconde règle globale au lieu de rester dans l'élément.
$more    = $rest > 0;
$openCss = static function ( $prefix ) use ( $gap, $size, $more ) {
	$css = $prefix . ' .wf-if-i + .wf-if-i{margin-left:' . $gap . 'px;}';
	if ( $more ) {
		$css .= $prefix . ' .wf-if-more{margin-left:' . $gap . 'px;width:' . $size . 'px;opacity:1;}';
	}
	return $css;
};

$selectors = array();
if ( 'always' === $open ) {
	$selectors[] = '#' . $uid . ' .wf-if-stack';
} else {
	$selectors[] = '#' . $uid . ' .wf-if-pill:hover .wf-if-stack';
	$selectors[] = '#' . $uid . ' .wf-if-pill:focus-visible .wf-if-stack';
}
?>
<?php $wfTag = ! empty( $props['html_element'] ) ? $props['html_element'] : 'div'; $wfEl = ( isset( $this ) && is_object( $this ) && method_exists( $this, 'el' ) ) ? $this->el( $wfTag ) : null; if ( $wfEl ) { echo $wfEl( $props, isset( $attrs ) ? $attrs : array() ); } ?>

<div id="<?= esc_attr( $uid ) ?>" class="wf-if">
	<<?= $tag ?> class="wf-if-pill"<?= $href ?>>
		<span class="wf-if-stack"><?= implode( '', $shown ) ?><?php if ( $rest > 0 ) : ?><span class="wf-if-more">+<?= (int) $rest ?></span><?php endif; ?></span>
		<?php if ( '' !== $label ) : ?><span class="wf-if-label"><?= esc_html( $label ) ?></span><?php endif; ?>
	</<?= $tag ?>>
</div>

<style>
#<?= esc_attr( $uid ) ?>{display:flex;justify-content:<?= $justify ?>;}
#<?= esc_attr( $uid ) ?> .wf-if-pill{display:inline-flex;align-items:center;gap:<?= max( 8, (int) round( $size * 0.3 ) ) ?>px;padding:<?= max( 4, (int) round( $size * 0.16 ) ) ?>px <?= max( 12, (int) round( $size * 0.5 ) ) ?>px <?= max( 4, (int) round( $size * 0.16 ) ) ?>px <?= max( 4, (int) round( $size * 0.16 ) ) ?>px;border-radius:999px;background:<?= esc_attr( $pillBg ) ?>;text-decoration:none;<?= $shadow ? 'box-shadow:0 10px 30px rgba(0,0,0,.12),0 2px 6px rgba(0,0,0,.06);' : '' ?>}
#<?= esc_attr( $uid ) ?> .wf-if-stack{display:inline-flex;align-items:center;}
#<?= esc_attr( $uid ) ?> .wf-if-i{display:block;width:<?= $size ?>px;height:<?= $size ?>px;border-radius:<?= $rad ?>px;overflow:hidden;background:#e5e7eb;box-shadow:0 0 0 2px <?= esc_attr( $ring ) ?>,0 4px 10px rgba(0,0,0,.14);transition:margin-left .35s cubic-bezier(.16,1,.3,1);}
#<?= esc_attr( $uid ) ?> .wf-if-i img{width:100%;height:100%;object-fit:cover;display:block;}
#<?= esc_attr( $uid ) ?> .wf-if-i + .wf-if-i{margin-left:-<?= $over ?>px;}
<?php if ( $more ) : ?>
#<?= esc_attr( $uid ) ?> .wf-if-more{display:inline-flex;align-items:center;justify-content:center;width:0;height:<?= $size ?>px;margin-left:-<?= $over ?>px;border-radius:999px;background:<?= esc_attr( $moreBg ) ?>;color:<?= esc_attr( $moreC ) ?>;font-size:<?= max( 10, (int) round( $size * 0.3 ) ) ?>px;font-weight:600;opacity:0;overflow:hidden;box-shadow:0 0 0 2px <?= esc_attr( $ring ) ?>;transition:width .35s cubic-bezier(.16,1,.3,1),margin-left .35s cubic-bezier(.16,1,.3,1),opacity .25s ease;}
<?php endif; ?>
#<?= esc_attr( $uid ) ?> .wf-if-label{font-size:<?= $lsize ?>px;font-weight:500;color:<?= esc_attr( $lcol ) ?>;white-space:nowrap;}
<?php foreach ( $selectors as $sel ) : ?>
<?= $openCss( $sel ) ?>

<?php endforeach; ?>
@media(hover:none){<?= $openCss( '#' . $uid . ' .wf-if-stack' ) ?>}
@media(max-width:480px){#<?= esc_attr( $uid ) ?> .wf-if-label{white-space:normal;}}
</style>
<?php if ( ! empty( $wfEl ) ) { echo $wfEl->end(); } ?>
